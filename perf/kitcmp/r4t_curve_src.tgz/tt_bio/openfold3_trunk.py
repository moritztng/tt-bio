"""OF3 trunk assembly device port (P8 -> P10 fully-device).

Assembles the OpenFold3 ``run_trunk`` (AF3 Algorithm 1 lines 1-14) end-to-end on device:

    m = msa_module_embedder(msa_feat, s_input)           # constant across cycles
    for cycle in range(num_cycles):                       # num_cycles = num_recycles+1 = 4
        z = z_init + linear_z(layer_norm_z(z))            # top-level z glue  (device code)
        z = z + template_embedder(template_feat, z)       # template embedder  (device)
        z = msa_module(m, z)                              # 4-block MSA module  (device)
        s = s_init + linear_s(layer_norm_s(s))            # top-level s glue  (device code)
        s, z = pairformer_stack(s, z, ...)                # 48-block Pairformer (device)
    return s, z                                           # s_trunk, z_trunk

s/z start at zeros; ``s_input``, ``s_init``, ``z_init`` come from the InputEmbedder
(already PCC-gated end-to-end in P7). The top-level ``linear_z``/``layer_norm_z``/
``linear_s``/``layer_norm_s`` are SEPARATE trunk weights (not the InputEmbedder's
linears): affine LayerNorms (eps=1e-5) + bias-free ``init="final"`` Linears
(128->128 and 384->384). ``OF3TrunkGlue`` is the device code landed in P8 tick 13 and
PCC-gated in isolation (PCC=1.00000 across all 4 cycles).

Fully-device scope (see docs/openfold3-port.md):
  - Top-level cycle glue (OF3TrunkGlue): GATED in isolation (PCC=1.00000) -- unchanged
    from P8 tick 13.
  - Template embedder: REAL device path (``TemplateEmbedder``, un-xfailed since the
    sub-tile head_dim=16 TriangleAttention fix landed, P8 tick 13 cont.: z_template
    PCC=0.99995). ``template_feat`` is host-precomputed mask products (constant across
    cycles, captured in the golden); the device part is the feature linears + pair_stack.
  - MSA module: REAL device path (``MSAModuleEmbedder`` -> ``MSAModule``, 4-block
    ``opm_first`` stack). The MSA pair_stack z-track is an INTRINSIC bf16
    ill-conditioning limit at OF3's activation magnitude (z_pcc ~0.75 over 4 blocks,
    root-caused P8 tick 17 -- NOT a kernel bug, NOT the softmax lever; the fp32-z-path
    fix is release-gated). The trunk accepts this degradation as a known, quantified
    real number and measures its propagation into s_trunk/z_trunk; it is NOT chased
    further here.
  - Assembled trunk (cycle glue + template + MSA + 48-block Pairformer, s AND z tracks,
    NO golden substitution): GATED on the real settled trunk distribution -- see
    tests/test_openfold3_trunk.py::test_of3_trunk_assembly_on_device for the actual
    s_trunk_pcc / z_trunk_pcc numbers (z_trunk drops from the P8 0.99936
    golden-substituted figure once the real, degraded MSA pair_stack feeds the
    Pairformer; the real number is reported by the test, not assumed).
"""
from __future__ import annotations

import os

import ttnn

from .tenstorrent import (Module, Pairformer, accurate_softmax_site, msa_embed,
                          triatt_sdpa_hifi_site)
from .openfold3_weights import remap_pairformer_stack, is_openbind, _sub

# `m` up to this size stays on the chip for the whole trunk, up to this many tokens; past either, it
# waits on the host and every MSA block streams it up and back one depth chunk at a time. Most Galaxy
# chips sit on a PCIe Gen4 x1 link, where that round trip cost the served 835-token fold 26 s of a
# 66 s trunk (10,186 rows, 1.09 GB of m). 1.25 GiB holds every served alignment at that size. The
# token line is the largest size measured to fit with `m` at the cap (1184 tokens x 8,855 rows); at
# 1536 tokens the cycle's updated copy of a 1.34 GB `m` no longer fits on a 12 GiB Wormhole part.
M_KEEP_BYTES = 5 << 28
M_KEEP_MAX_TOKENS = 1184
from .openfold3_template import TemplateEmbedder
from .openfold3_msa_embedder import MSAModuleEmbedder, MSAModule


# OF3 pairformer_stack dims (config.model_config): c_hidden_pair_att=32, no_heads_pair=4,
# c_hidden_pair_bias=24, no_heads_pair_bias=16. transform_s=True.
_PF_DIMS = (32, 4, 24, 16)
_N_PAIRFORMER_BLOCKS = 48


class OF3TrunkGlue(Module):
    """OF3 top-level trunk cycle glue.

    z = z_init + linear_z(layer_norm_z(z_prev))   [128 -> 128, bias-free]
    s = s_init + linear_s(layer_norm_s(s_prev))   [384 -> 384, bias-free]

    Four weight-only ops (two affine LayerNorms, eps=1e-5; two bias-free
    ``init="final"`` Linears). These weights live at the top level of the OpenFold3
    checkpoint, separate from the InputEmbedder's ``linear_s``/``linear_z_i``/
    ``linear_z_j``. This is the genuinely-new device code in the trunk assembly.

    Inputs (device bf16):
        z_prev / s_prev: the previous cycle's Pairformer z / s output (zeros at c0).
        z_init / s_init: the InputEmbedder's constant single/pair init (broadcast-added).
    """

    def __init__(self, state_dict, compute_kernel_config):
        super().__init__(state_dict, compute_kernel_config)
        self.ln_z_w = self.torch_to_tt("layer_norm_z.weight")
        self.ln_z_b = self.torch_to_tt("layer_norm_z.bias")
        self.w_linz = self.torch_to_tt("linear_z.weight")
        self.ln_s_w = self.torch_to_tt("layer_norm_s.weight")
        self.ln_s_b = self.torch_to_tt("layer_norm_s.bias")
        self.w_lins = self.torch_to_tt("linear_s.weight")

    def glue_z(self, z_prev, z_init):
        zn = ttnn.layer_norm(
            z_prev, weight=self.ln_z_w, bias=self.ln_z_b, epsilon=1e-5,
            compute_kernel_config=self.compute_kernel_config)
        dz = self._lin(zn, self.w_linz)
        z = ttnn.add(z_init, dz)
        ttnn.deallocate(zn)
        ttnn.deallocate(dz)
        return z

    def glue_s(self, s_prev, s_init):
        sn = ttnn.layer_norm(
            s_prev, weight=self.ln_s_w, bias=self.ln_s_b, epsilon=1e-5,
            compute_kernel_config=self.compute_kernel_config)
        ds = self._lin(sn, self.w_lins)
        s = ttnn.add(s_init, ds)
        ttnn.deallocate(sn)
        ttnn.deallocate(ds)
        return s


class OF3Trunk(Module):
    """Assembled OF3 trunk forward -- fully device-real end-to-end (P10).

    Composes ``OF3TrunkGlue`` + ``TemplateEmbedder`` + ``MSAModuleEmbedder`` +
    ``MSAModule`` + the 48-block OF3-dims ``Pairformer``. No golden substitution: the
    template pair_stack and the MSA pair_stack both run on device. The template path is
    un-xfailed (sub-tile head_dim=16 TriangleAttention fix, P8 tick 13 cont.); the MSA
    pair_stack runs at its known intrinsic bf16 ill-conditioning limit (z_pcc ~0.75,
    P8 tick 17), accepted as a quantified degradation.

    Args:
        state_dict: the full OF3 checkpoint (top-level glue keys + ``pairformer_stack``
            + ``template_embedder`` + ``msa_module`` + ``msa_module_embedder``).
        compute_kernel_config: HiFi4 + fp32 dest acc.
        num_cycles: recycle cycles (OF3 default = num_recycles+1 = 4).
    """

    def __init__(self, state_dict, compute_kernel_config, num_cycles: int = 4):
        super().__init__(state_dict, compute_kernel_config)
        self.num_cycles = num_cycles
        self.glue = OF3TrunkGlue(state_dict, compute_kernel_config)
        pf_sd = remap_pairformer_stack(state_dict, prefix="pairformer_stack")
        # Ending-node triangle-attention bias orientation. Every pair stack in the
        # trunk (pairformer, template, MSA) shares one upstream PairBlock, so they
        # all move together. preview2 builds the bias from the TRANSPOSED pair, which
        # indexes it off z_ji where AF3 Algorithm 15 wants z_ij; v0.5.0 added
        # `transpose_bias=True` to PairBlock.tri_att_end to put it back on z_ij. That
        # is tt-bio's `transpose_bias=False` -- the flag names read opposite because
        # ours describes the bias following the pair transpose, theirs describes
        # undoing it. No weights change, so the checkpoint has to select it.
        tri_att_end_bias_follows_pair = not is_openbind(state_dict)
        # Measurement lever, of3t-foldab. Unset -- the only state any shipped path is in --
        # leaves the line above untouched; "1"/"0" force the orientation so a seeded fold A/B
        # can attribute an Angstrom delta to this flag alone. Nothing else reads the variable
        # and no default moves with it. RELEASE-GATED: branch only.
        _forced = os.environ.get("TT_BIO_OF3_TRI_END_BIAS_FOLLOWS_PAIR")
        if _forced is not None:
            tri_att_end_bias_follows_pair = _forced == "1"
        # openfold3 adds both pair biases UNSCALED (q is pre-scaled by 1/sqrt(d) in the
        # reference Attention), and the two kernels under this one layer need opposite flags
        # to deliver that. `AttentionPairBias` folds the bias inside its own score scale, so
        # unscaled-at-the-reference means pre-baked by sqrt(d) here: scale_pair_bias=True.
        # `TriangleAttention` adds it outside, so the same convention is
        # tri_att_scale_pair_bias=False. Passing one False to both is what left the token
        # bias at 1/sqrt(24) = 0.204 of reference for all 48 blocks.
        #
        # The SPLIT is landed; the OF3 trunk DEFAULT is deliberately NOT flipped, and
        # `scale_pair_bias=False` below matches `main`. `of3t-pairbias` measured the
        # corrected bias end to end and its own verdict is "Land the MECHANISM. Do NOT flip
        # the OF3 trunk default on this evidence": over nine seeds on 1UBQ it buys 0.050 A of
        # best-of-5 and costs 0.463 A on the structure a user actually receives, against this
        # target's own 0.324 A seed floor. The loss is the confidence head preferring the
        # looser of two sample modes (D10), not a worse ensemble, so the fix must ship with a
        # selector fix or not at all. `of3t-confhead` owns that pair. Flipping this one token
        # is the whole lever, and `compose_verify.sh` asserts it stays False.
        #
        # What that costs at the ACTIVATION level, which the fold-level reading above cannot
        # see: this one token IS the trunk's A18 single-track failure, all of it. Against
        # upstream 0.4.3's float64 forward on the captured boundary the shipped trunk reads
        # 1.065338e-01 masked at crop 64 and 1.061989e-01 at N=384, both over the 5.0e-02 bar;
        # with the bias pre-scaled it reads 1.655263e-02 and 1.855062e-02, both under it, and
        # the pair track is bit-identical either way because tri_att_scale_pair_bias does not
        # move. In float64 the pre-scaled convention reproduces upstream's single-track update
        # to 4.2e-16, so this is a convention and not a precision cost. It hides until the last
        # blocks only because that is where q.k collapses and the bias stops being negligible:
        # |bias|/|q.k| is 0.0039 at block 8 and 0.0302 at block 45, and the block-45 update is
        # 78.0 % wrong against upstream's 0.9 % bf16 floor. Measured in perf/of3t_trunkcliff.
        self.pairformer = Pairformer(
            _N_PAIRFORMER_BLOCKS, *_PF_DIMS, True, pf_sd, compute_kernel_config,
            scale_pair_bias=True, tri_att_scale_pair_bias=False, fp32_softmax=True,
            transpose_bias=tri_att_end_bias_follows_pair,
            accurate_softmax=accurate_softmax_site("openfold3.trunk"),
            # Default ON. 34.138 -> 22.574 s at 512 aa, 1.5123x, 11.564 s, on A/A floors of
            # 0.888 and 0.950 s, with firing counted 384 served / 0 declined / 0 too_short
            # on every leg. The route also carries the faithful reduction order (see
            # PairformerLayer), which is what makes it clear the accuracy standard: at
            # 298 aa over three matched seeds it moves the structure 2.5805 / 7.7510 /
            # 8.0075 A CA against a six-pair main-vs-main seed floor of 5.2283 / 7.7276 /
            # 9.7768 -- median exactly 1.00x the floor median and worst case 0.82x its
            # maximum, i.e. inside the variation re-seeding already produces. pLDDT moves
            # the same way, 0.50319 -> 0.56667. Without the reduction order the same route
            # fails at 1.61x the floor median, which is why the two are coupled.
            #
            # The template site stays OFF: alone it moves the c730 ipTM from 0.67 to 0.48 (spd-of3
            # ab11t). The confidence site ships ON (openfold3_confidence.py); see there.
            tri_att_sdpa_hifi=triatt_sdpa_hifi_site("openfold3.trunk", True))
        self.template = TemplateEmbedder(
            _sub(state_dict, "template_embedder"), compute_kernel_config,
            transpose_bias=tri_att_end_bias_follows_pair)
        self.msa_embedder = MSAModuleEmbedder(
            _sub(state_dict, "msa_module_embedder"), compute_kernel_config)
        self.msa_module = MSAModule(state_dict, compute_kernel_config,
                                    transpose_bias=tri_att_end_bias_follows_pair)

    def _zeros_like(self, t):
        # TILE_LAYOUT so the cycle-0 zeros are tile-padded (96, not 76) -- a ROW_MAJOR
        # 4D zeros passed straight into ttnn.linear hits the tile-size check (flattened
        # M = 76*76 not %32). The N-dim padding does not affect per-channel LayerNorm.
        shape = tuple(int(x) for x in t.shape)
        return ttnn.zeros(shape, device=self.device, dtype=ttnn.bfloat16,
                          layout=ttnn.TILE_LAYOUT)

    def __call__(self, s_init, z_init, template_feat, msa_feat, s_input,
                 progress_fn=None, template_slots=None, pair_mask=None, attn_mask=None):
        """Fully-device assembled trunk forward.

        s_init, z_init: device bf16 [1,N,384] / [1,N,N,128] (InputEmbedder constants).
        template_feat: dict of per-template feature tensors [N_templ,N,N,c], host or device
            bf16 (host-precomputed mask products, constant across cycles -- see
            TemplatePairFeatureEmbedder). Host features go up one at a time and are freed
            once projected, so only their 64-channel projection stays on the device.
        msa_feat: [1,N_seq,N,34], host float or device bf16 (post-subsample, constant
            across cycles -- ``m`` is identical every cycle in the reference).
        s_input: device bf16 [1,N,449] (InputEmbedder single input, constant).
        pair_mask: device bf16 [1,N,N] or None -- the token bucket's outer-product pad mask,
            multiplied into every TriangleMultiplication contraction.
        attn_mask: device bf16 [1,1,1,N] or None -- the additive -1e9 companion, added to every
            TriangleAttention and PairWeightedAveraging softmax over the token axis.

        Returns (s_trunk, z_trunk): device bf16 [1,N,384] / [1,N,N,128].
        """
        s = self._zeros_like(s_init)
        z = self._zeros_like(z_init)
        # m is identical across cycles (verified in the reference golden); compute once.
        # A host `msa_feat` past 1 GiB is uploaded and embedded one depth chunk at a time and
        # `m` lands on the host; past 1 GiB the pristine `m` waits there between cycles and each
        # MSA block works on depth chunks (openfold3_msa_embedder.MSAModuleBlock), as in the
        # protenix trunk. A device `msa_feat` is embedded whole and consumed: at 1024 tokens x
        # 14191 alignment rows it is 1 860 042 752 B that must not be held across the trunk.
        keep = M_KEEP_BYTES if msa_feat.shape[2] <= M_KEEP_MAX_TOKENS else None
        m = msa_embed(msa_feat, lambda x: self.msa_embedder(x, s_input), keep=keep)
        # the template feature half is a function of template_feat alone, so it is the
        # same tensor in every cycle -- compute it once, exactly like m above.
        a_tmpl = self.template.features(template_feat)
        for cyc in range(self.num_cycles):
            if progress_fn:
                progress_fn("trunk", step=cyc, total=self.num_cycles)
            z = self.glue.glue_z(z, z_init)              # device z-glue
            z_tmpl = self.template(template_feat, z, template_slots, a_tmpl,
                                   pair_mask, attn_mask)
            z = ttnn.add(z, z_tmpl)
            ttnn.deallocate(z_tmpl)
            z = self.msa_module(m, z, pair_mask, attn_mask)[1]   # device 4-block MSA module (degraded z); m reused next cycle
            s = self.glue.glue_s(s, s_init)              # device s-glue
            s, z = self.pairformer(s, z, pair_mask, attn_mask, attn_mask)  # device 48-block Pairformer
        return s, z
