"""The trimul channel move ``permute(x, (0, 3, 1, 2))`` as a hand-written Tensix kernel.

Shape is ``[1, N, N, C]`` bf16 TILE with ``C`` a multiple of 32. **The channel count is not fixed
at 32.** ``_trimul_chunk_size`` doubles the trunk's chunk width while the chunk still fits an L1
budget scaled by the compute grid, so 298 aa folds with ``C = 64`` on a 13x10 grid and with
``C = 32`` on an 11x10 one. A kernel hardcoded to 32 channels serves zero calls on the wider grid.

The three kernels under ``tt_bio/kernels/reblock_permute/`` are run through ``ttnn.generic_op``,
which JIT-compiles a kernel named by a ``KernelDescriptor`` against the shipped ttnn wheel. No
tt-metal source build, no nanobind registration, no dependency bump.

The move is a pure index reordering, so it is bit-exact against ``ttnn.permute`` by construction and
is measured with ``torch.equal`` rather than argued.

**Why the descriptor is cached.** ``generic_op`` takes the whole program description per call.
Building it in Python costs ~155 us at N=320 (100 cores x 3 kernels of per-core runtime args), which
is more than the 91 us of device time the op needs, so a rebuilt-per-call descriptor is a net loss.
Everything in the descriptor except the two buffer addresses is a pure function of the shape, the
dtype/layout, the buffer types and the core grid; the addresses now live in ``common_runtime_args``
(see the kernels), so a cached descriptor needs two scalars rewritten per call.
"""

from __future__ import annotations

import os
from pathlib import Path

import ttnn

from . import core_split
from . import genq
from .envflags import env_flag
from . import ops as _ops

KERNEL_DIR = Path(__file__).resolve().parent / "kernels" / "reblock_permute"
KERNEL_DIR_BACK = Path(__file__).resolve().parent / "kernels" / "reblock_permute_back"

TILE_H = TILE_W = 32
FACE_H = FACE_W = 16
GROUP_TILES = 32
IN_CB, OUT_CB, STAGE_CB = 0, 16, 24

# How the cached descriptor gets its two per-call addresses. Set on first use; kept as module state
# only so a probe can report which path the wheel took.
ADDR_WRITE_MODE = None

# The element width the kernels are built for. bf16 at every call site in the engine; a probe moves
# it so the BYTE SENSITIVITY of this path can be measured instead of assumed. The three gates below
# admit only `_DTYPE`, so moving this alone changes nothing a caller can reach -- a probe that wants
# a different width sets it and forces the call. `perf/ttx_reblock_bfp8/byte_sensitivity.py` is the
# reader; its header says why fp32 (2x the bytes at an unchanged transaction count) is the control
# that decides whether bfp8 (half the bytes) could ever pay here.
_DTYPE = ttnn.bfloat16
_ELEM_BYTES = {ttnn.bfloat16: 2, ttnn.float32: 4}


def set_dtype(dtype):
    """Probe-only: build the kernels for ``dtype``. Returns the previous value."""
    global _DTYPE
    prev, _DTYPE = _DTYPE, dtype
    return prev


def _elem():
    return _ELEM_BYTES[_DTYPE]


_CACHE: dict = {}
_CACHE_BACK: dict = {}
# Bench only (perf/spd_trimul/back_bench.py): 1 skips the DRAM read, 2 the L1 gather, 4 the DRAM write. Output is garbage
# under any of them; the model path never sets it.
BACK_ABL = 0
# Bench flag: the writer RISC reads each group's source tiles one group ahead on its own NOC, so the DRAM read overlaps
# the reader's L1 gather (RPB_SPLIT). Same bytes in the same order; off until it is timed.
BACK_SPLIT = False
# Counters for the A/B harness: (eligible calls served, calls that fell through to ttnn.permute).
STATS = [0, 0]
# The same pair for the back direction, counted separately so one A/B can read both legs.
STATS_BACK = [0, 0]
# Why calls were refused, keyed by (reason, shape). A gate that never fires has to say why: the
# first wiring of this op served zero calls in a whole fold because the production shape is
# [1, 298, 298, 32] and the kernel required N % 32 == 0.
REJECTS: dict = {}


# --- the wheel's own work split has a hole, and `core_split` fills it ------------------------------
#
# `ttnn.split_work_to_cores` raises `TT_FATAL @ work_split.cpp:305: remaining == 0` whenever
# `units > cores` and `units % cores` is a non-zero multiple of the grid height, because it anchors
# core group 2 at the bottom of the next column instead of the top. `tt_bio.core_split` performs the
# same split in Python and without that bug -- its docstring carries the upstream one-word fix we are
# pinned below -- so every shape gets the whole grid.
#
# What this replaced was a memoised search for the largest rectangular sub-grid the wheel would
# accept, plus a `work_split` refusal in each of the three gates for the shapes where even that
# failed. The search always found something on an 11x10 grid, so no shape was actually losing the
# leg here, but it cost the busiest core an extra group on the affected bands: the back leg at
# N=640, C=128 ran its 1600 groups 16 deep on a 10x10 sub-grid where the full 11x10 grid runs them
# 15 deep. `scripts/verify_core_split.py` prints that census and checks the replacement against the
# wheel on every unit count the wheel can serve.

# How many cores a split may use, 0 meaning the whole grid. The whole grid is right at every shape
# measured and this exists only to reproduce a reduced grid for an A/B.
#
# It used to look like a real tuning knob: sweeping it moved this leg 1.10x-1.19x with optima at
# 80/100/88 cores rather than 110, and the best count differed per shape. That was an artifact of
# how groups are handed to cores, not a property of the core count -- see `WALK` below for the bank
# arithmetic. Once the aliasing is removed the cost is a function of depth alone: the 400-group
# 80..99-core band lands within 1.2% of itself where it spread 1.30x, and the whole grid is the
# fastest point at all four shapes. So there was never a core count to fit.
# `perf/ttx_splitwork/core_count_sweep.py` is the harness and the JSON sits beside it.
REBLOCK_CORES = int(os.environ.get("TT_BIO_REBLOCK_CORES", "0"))

# How a core walks the groups it owns. Every mode gives every core the SAME groups and the same
# count, so the output is bit-identical; what moves is which groups are in flight together, and
# therefore which DRAM banks are live at once.
#
#   "block"   (default, and what main ships) the contiguous run of `per_core` groups.
#   "stride"  round-robin: core i takes groups i, i+num_cores, ... Concurrent groups become
#             consecutive indices, so every bank is live, at the cost of page locality.
#   "rotate"  the contiguous run kept, started at the core's own phase `i % per_core`. Spreads the
#             banks without scattering the pages.
#
# All three are the same kernel loop: `num_groups` steps of `group_stride` from `first_group`, with
# a fold back to `group_wrap_lo` at `group_wrap_hi`.
#
# The default stays "block" because NEITHER alternative is safe, which was measured and is the
# whole finding. Aliasing is real and large: page p lives in bank p % banks, every page of group g
# is congruent to g, and a contiguous block puts core k at k*w, so the machine sits on
# banks/gcd(w, banks) of them -- two of eight at w = 4, which reads 1.71x slower per wave at
# identical traffic. Fixing it is worth 1.10x-1.44x. But the shapes that pay it are not the shapes
# a fold asks for. On the Boltz-2 ladder (`perf/ttx_splitwork/shape_census_ladder.json`) 298 aa
# runs the forward leg at 100 groups over 110 cores, one group a core, where all three walks are
# the same walk; every larger size runs only the gated and back legs, at 1024, 1600 and 4096
# groups. Measured there, against "block" on the whole grid
# (`prod_shapes_ab.json`, `prod_ladder_ab.json`):
#
#             512 aa   640 aa   1024 aa
#   gated     stride    0.964x   1.082x   0.910x        rotate  1.030x  0.753x  1.004x
#   back      stride    1.019x   1.023x   1.188x        rotate  1.018x  0.831x  1.077x
#
# Each column wants a different walk and each alternative regresses by up to 33% somewhere, so no
# fixed walk ships. Neither does a rule: `work1 >= banks`, fitted on six Blackhole shapes, mispicks
# twice on Wormhole's 12 banks (`walk_wh_j10glx02c0.json`) and picks the 0.753x at 640 aa. The bank
# arithmetic alone cannot choose either -- `perf/ttx_splitwork/bank_model.py` computes the exact
# per-wave bank histogram from the kernels' own index expressions and gets "block is never the
# cheapest walk" right at 12 of 12 while picking the device's winner at only 6, because the forward
# and back legs at N=960 have IDENTICAL bank costs and opposite winners. What separates them is the
# per-kernel issue pattern, which an index model cannot see.
#
# So: the knob is understood, it is bit-exact, and it stays off. The flag is here so a future pass
# can re-open it with wider coverage without rebuilding any of this.
WALK = os.environ.get("TT_BIO_REBLOCK_WALK", "block")
_NO_WRAP = 0xFFFFFFFF


def _index_of(assign, cx, cy):
    """This core's position in the placement loop's own order."""
    return list(assign).index((cx, cy))


def _genq_ct(assign, core_grid, shape_words):
    """The compile-time block the cheap dispatch path needs, or eleven zeros for the old path.

    Refused unless ``WALK`` is ``block``. The other two walks make ``first_group`` depend on the
    core's index in a way the slice alone does not carry, and both are measured, off by default
    and documented above as staying off; a mode this cannot express keeps its per-core args.
    """
    if not genq.compact():
        return [0] * 11
    if WALK != "block":
        genq.REFUSED["walk_" + WALK] = genq.REFUSED.get("walk_" + WALK, 0) + 1
        return [0] * 11
    plan = genq.compact_plan(assign, core_grid)
    return ([1] + plan + shape_words) if plan else [0] * 11


def _walk(mode, i, block, per_core, num_cores):
    """``(first_group, group_stride, group_wrap_hi, group_wrap_lo)`` for linear core index ``i``.

    ``block`` is where this core's contiguous run of ``per_core`` groups starts.
    """
    if mode == "stride":
        return i, num_cores, _NO_WRAP, 0
    if mode == "rotate" and per_core > 1:
        return block + i % per_core, 1, block + per_core, block
    return block, 1, _NO_WRAP, 0

_SPLIT_CACHE: dict = {}


def _split_plan(device, units):
    """The work split for ``units`` groups over the whole compute grid.

    ``(grid_x, grid_y, <the six-tuple ttnn.split_work_to_cores returns>)``, or ``None`` when there
    is no work to split at all. Cached per ``(device, grid, units, REBLOCK_CORES)`` because
    `_channel_move` runs 4352 times in a 298 aa fold, and with the knob in the key so an in-process
    A/B can move it between two arms.
    """
    g = device.compute_with_storage_grid_size()
    key = (device.id(), g.x, g.y, units, REBLOCK_CORES)
    if key not in _SPLIT_CACHE:
        plan = ((g.x, g.y, core_split.split_work_to_cores(g, units, REBLOCK_CORES))
                if units > 0 else None)
        _SPLIT_CACHE[key] = plan
    return _SPLIT_CACHE[key]


def _reject(reason, shape):
    k = (reason, tuple(shape))
    REJECTS[k] = REJECTS.get(k, 0) + 1
    STATS[1] += 1
    return False


def _cache_key(x, out, device, reader_ct, writer_ct):
    """Everything the descriptor depends on except the two buffer addresses.

    The compile-time args of both TensorAccessors are in the key **verbatim**, so anything the
    accessor bakes into the kernel (buffer type, page size, shape, shard spec) is covered whether or
    not this function knows what it means. What is left is a pure function of ``(N, C, grid)``: the
    CB sizes, the core ranges, the work split and the per-core ``start`` / ``per_core`` / ``Nt`` /
    ``Ct``. The two addresses are the only per-call values and they are written on every call.
    """
    g = device.compute_with_storage_grid_size()
    return (
        device.id(),
        int(x.shape[1]), int(x.shape[3]),
        str(x.dtype), str(x.layout),
        str(x.memory_config()), str(out.memory_config()),
        g.x, g.y, WALK, genq.compact(),
        tuple(reader_ct), tuple(writer_ct),
    )


def _build(x, out, device, reader_ct, writer_ct):
    N = int(x.shape[1])
    Ct = int(x.shape[3]) // TILE_W
    # The fold runs this at N=298, not at a multiple of 32, so the tile grid is ceil(N/32) in both
    # directions and the last row-group is ragged. The kernels take N and handle it.
    Nt = (N + TILE_H - 1) // TILE_H
    num_groups = Nt * Nt

    plan = _split_plan(device, num_groups)
    # `eligible` has already refused any shape with no plan, so this cannot fire from the production
    # path. It stays as an assertion because a direct caller of `reblock_permute` bypasses the gate.
    assert plan is not None, f"no expressible work split for {num_groups} groups"
    _, _, (num_cores, core_grid, cg1, cg2, work1, work2) = plan

    tile_bytes = TILE_H * TILE_W * _elem()

    def cb(idx, depth):
        fmt = ttnn.CBFormatDescriptor(
            buffer_index=idx, data_format=_DTYPE, page_size=tile_bytes
        )
        return ttnn.CBDescriptor(
            total_size=depth * tile_bytes, core_ranges=core_grid, format_descriptors=[fmt]
        )

    # c_16 depth MUST be a multiple of the 32-tile group or the writer's L1 window wraps mid-group.
    cbs = [cb(IN_CB, 2), cb(OUT_CB, GROUP_TILES * 2), cb(STAGE_CB, 2)]

    reader_rt, compute_rt, writer_rt = ttnn.RuntimeArgs(), ttnn.RuntimeArgs(), ttnn.RuntimeArgs()
    # `first` is this core's linear index, `block` the start of its contiguous run of groups. Both
    # counters are kept for every mode because `_walk` needs each of them; `placed` is the audit.
    assign, first, placed, block = {}, 0, 0, 0
    for group, per_core in ((cg1, work1), (cg2, work2)):
        for cr in group.ranges():
            for cx in range(cr.start.x, cr.end.x + 1):
                for cy in range(cr.start.y, cr.end.y + 1):
                    assign[(cx, cy)] = (block, per_core)
                    first += 1
                    block += per_core
                    placed += per_core
    assert (first, placed) == (num_cores, num_groups), (first, placed, num_cores, num_groups)

    genq_ct = _genq_ct(assign, core_grid, [Nt, N, Ct])
    if genq_ct[0] == 0:
        for (cx, cy), (blk, per_core) in assign.items():
            i = _index_of(assign, cx, cy)
            g0, gs, ghi, glo = _walk(WALK, i, blk, per_core, num_cores)
            reader_rt[cx][cy] = [g0, per_core, Nt, N, Ct, gs, ghi, glo]
            compute_rt[cx][cy] = [per_core * GROUP_TILES * Ct]
            writer_rt[cx][cy] = [g0, per_core, Nt, N, Ct, gs, ghi, glo]
    compute_ct = [IN_CB, OUT_CB] + genq_ct[:8] + [GROUP_TILES * Ct]

    reader = ttnn.KernelDescriptor(
        kernel_source=str(KERNEL_DIR / "reader_reblock_permute.cpp"),
        source_type=ttnn.KernelDescriptor.SourceType.FILE_PATH,
        core_ranges=core_grid, compile_time_args=genq_ct + reader_ct, runtime_args=reader_rt,
        common_runtime_args=[0], config=ttnn.ReaderConfigDescriptor(),
    )
    writer = ttnn.KernelDescriptor(
        kernel_source=str(KERNEL_DIR / "writer_reblock_permute.cpp"),
        source_type=ttnn.KernelDescriptor.SourceType.FILE_PATH,
        core_ranges=core_grid, compile_time_args=genq_ct + writer_ct, runtime_args=writer_rt,
        common_runtime_args=[0], config=ttnn.WriterConfigDescriptor(),
    )
    compute = ttnn.KernelDescriptor(
        kernel_source=str(KERNEL_DIR / "compute_reblock_permute.cpp"),
        source_type=ttnn.KernelDescriptor.SourceType.FILE_PATH,
        core_ranges=core_grid, compile_time_args=compute_ct, runtime_args=compute_rt,
        config=ttnn.ComputeConfigDescriptor(
            math_fidelity=ttnn.MathFidelity.HiFi2, fp32_dest_acc_en=True
        ),
    )
    pd = ttnn.ProgramDescriptor(kernels=[reader, writer, compute], semaphores=[], cbs=cbs)

    # Decide once how the addresses reach the descriptor. Mutating the kernels held inside the
    # cached ProgramDescriptor is the cheap path; if the binding hands back copies, fall back to
    # rebuilding the ProgramDescriptor from the cached kernel objects (still ~3 orders cheaper than
    # rebuilding the per-core runtime args).
    global ADDR_WRITE_MODE
    if ADDR_WRITE_MODE is None:
        probe = 0xABCD1234
        pd.kernels[0].common_runtime_args = [probe]
        got = list(pd.kernels[0].common_runtime_args)
        ADDR_WRITE_MODE = "in_place" if got == [probe] else "rebuild_pd"
        pd.kernels[0].common_runtime_args = [0]

    return {"pd": pd, "kernels": [reader, writer, compute], "cbs": cbs, "core_grid": core_grid}


def _prepare(x, out, device):
    reader_ct = list(ttnn.TensorAccessorArgs(x).get_compile_time_args())
    writer_ct = [_elem(), OUT_CB, TILE_H, TILE_W, FACE_H, FACE_W, STAGE_CB]
    writer_ct.extend(ttnn.TensorAccessorArgs(out).get_compile_time_args())
    key = _cache_key(x, out, device, reader_ct, writer_ct)
    entry = _CACHE.get(key)
    if entry is None:
        entry = _CACHE[key] = _build(x, out, device, reader_ct, writer_ct)
    return entry


@_ops.fused_kernel("reblock_permute")
def reblock_permute(x, memory_config=None, device=None):
    """``ttnn.permute(x, (0, 3, 1, 2))`` for ``x`` of shape ``[1, N, N, C]`` bf16 TILE, C % 32 == 0."""
    device = device or x.device()
    mc = memory_config or x.memory_config()
    N, C = int(x.shape[1]), int(x.shape[3])
    out = ttnn.allocate_tensor_on_device(
        ttnn.Shape([1, C, N, N]), _DTYPE, ttnn.TILE_LAYOUT, device, mc
    )
    entry = _prepare(x, out, device)
    src, dst = x.buffer_address(), out.buffer_address()
    if ADDR_WRITE_MODE == "in_place":
        pd = entry["pd"]
        pd.kernels[0].common_runtime_args = [src]
        pd.kernels[1].common_runtime_args = [dst]
    else:
        reader, writer, compute = entry["kernels"]
        reader.common_runtime_args = [src]
        writer.common_runtime_args = [dst]
        pd = entry["pd"] = ttnn.ProgramDescriptor(
            kernels=[reader, writer, compute], semaphores=[], cbs=entry["cbs"]
        )
    STATS[0] += 1
    return ttnn.generic_op([x, out], pd)


# The L1 leg's window edges, named so a fold-level A/B can move one of them in-process without
# editing the gate. See eligible()'s docstring for what measured them.
#
# The env overrides exist because `predict` folds in spawned worker processes, so setting the
# module attribute in the launcher does not reach the code that reads it, and an in-process A/B
# is only possible for a caller that folds in its own process. They default to the measured
# constants, so with neither variable set this is byte-for-byte the shipped gate.
#
# Why they were added: ESMFold2 on Wormhole asks this gate 8672 times per fold at 256 aa and is
# refused every time on `window_BufferType.L1`, because its call sites want an L1 output and no
# rung of the 256/512/640/768/896/1024 size ladder falls inside 288..352. The 352 edge is one
# grid's collapse point (qb1 13x10) applied to every grid, while qb2 measured 1.02-1.62x wins on
# an L1 output out to N=544. Whether the window should be wider on a given card type is a
# measurement, and this is what makes it measurable per rung.
L1_N_MIN = int(os.environ.get("TT_BIO_REBLOCK_L1_N_MIN", "288"))
L1_N_MAX = int(os.environ.get("TT_BIO_REBLOCK_L1_N_MAX", "352"))

# Below L1_N_MIN the moves still open on L1 once the Nt*Nt work groups reach this many per
# core. The 288 edge was measured on 110- and 130-core grids, where it is Nt=9 = 81 groups; on a
# Wormhole chip's 64 cores the same kernel already wins at Nt=7 = 49 groups (N=195: 1.17x at C=64,
# N=224: 1.22x) and loses at Nt=6 = 36 groups (N=192: 0.97x), every point torch.equal
# (.114 chip 7, perf/bigswing/reblock_window_band.py, state/spd-gap-bind.md). What decides the win is
# whether the groups fill the grid: 0.74 (Nt=9 on 110 cores) and 0.77 (Nt=7 on 64, Nt=10 on 130) win;
# 0.62 (Nt=9 on a 130-core p150a: 0.89 / 1.08 / 0.95x at N=257 / 272 / 288, qb1 card 0) is break-even,
# and 0.56-0.58 lose (N=256 on 110 cores 0.952x, N=192 on 64 cores 0.97x). 0 restores the plain N edge.
# The back and gated legs take the same floor: AF2-IG at 195 tokens on a Wormhole chip folds in 5.395 s
# with the old gate, 5.336 s with only the forward move opened and 5.232 s with all three, every
# structure digest identical (.114 chip 6, out/whgate_fa1b3cbfa). On 130 cores the rule needs Nt=10,
# which is above L1_N_MIN already, so a p150a is unchanged.
# The floor is 0.68, not 0.7, because the Galaxy's Wormhole chips report 8x9 = 72 cores, where Nt=7 is
# 0.68 per core. At 0.7 the gate shut there and AF2-IG at 195 tokens fell back to 5.40-5.49 s; at
# 0.68 it folds in 5.22-5.25 s with the same coordinates (.114 chip 1, 3 reps each,
# out/af2igwh_rj_322104346). 0.68 moves no other grid listed here (64, 110 or 130 cores).
L1_GROUPS_PER_CORE = float(os.environ.get("TT_BIO_REBLOCK_L1_GROUPS_PER_CORE", "0.68"))

# The gated move on L1 below that window, by size of the move rather than by N. The gated kernel
# replaces the four-way split, two `p * sigmoid(g)` and two plain moves, so it wins wherever that
# chain costs more than the kernel's own floor (~0.22 ms for the pair on 110 cores), and the chain
# scales with the slice's N*N*C elements. Measured on qb2 card 1 (11x10, 1350 MHz), split against
# gated on an L1 projection, every point torch.equal (perf/rfd4/e2e/gated_window.py): the win starts
# at 2**21 elements -- 128^2 x 128 1.09x, 256^2 x 32 1.06x, 192^2 x 64 1.17x, 96^2 x 256 1.17x,
# 128^2 x 256 1.32x (RFD4's trimul) -- and every point below it loses (160^2 x 64 0.93x, 224^2 x 32
# 0.91x, 128^2 x 64 0.72x). Keyed by grid core count because only the 110-core grid is measured;
# other grids keep the N window above.
GATED_L1_MIN_ELEMS = {110: 2 ** 21}

# The DRAM legs take the same grid-fill rule below their N=256 edge. 256 was measured on 110- and
# 130-core Blackhole grids, where the rule needs Nt=10 and so moves nothing; on a 72-core Wormhole
# chip a DRAM -> DRAM move wins at Nt=7: forward [1, N, N, 128] 1.31x at N=195 and 1.33x at N=224,
# every point torch.equal (.114 chip 12, 1000 MHz, out/rbdram_67a5e6b56). That is BindCraft 2's pair
# track, which lives in DRAM, so its trimul channel moves were all on the stock permute.
# The fused gated leg is not an index move, so it was graded on its own: at 224 tokens on Wormhole it
# leaves BindCraft 2's gradients bit-identical over 30 iterations and AF2-IG's coordinates equal, and
# takes the on-card iteration 5.34 -> 5.02 s (.114 chip 19, 1000 MHz, out/gfill_2c9346e08).
# TT_BIO_REBLOCK_DRAM_FILL=0 / TT_BIO_REBLOCK_DRAM_FILL_GATED=0 restore the plain N edge for an A/B.
# On Blackhole the plain moves also win at N=224 without filling the grid (49 groups on 110 cores):
# p150a qb1 card 0, 1350 MHz, [1, 224, 224, C] DRAM -> DRAM, torch.equal throughout: back
# (0, 2, 3, 1) 0.375 -> 0.128 ms at C=128 and 0.170 -> 0.121 at C=64 against the two transposes,
# forward (0, 3, 1, 2) 0.267 -> 0.221 and 0.142 -> 0.112 against the stock permute. At N=192 the
# forward loses (0.202 -> 0.213), so the edge is 224, and only for a tile-aligned N.
DRAM_N_ALIGNED_MIN = 224
DRAM_FILL = env_flag("TT_BIO_REBLOCK_DRAM_FILL", True)
DRAM_FILL_GATED = env_flag("TT_BIO_REBLOCK_DRAM_FILL_GATED", True)
_GRID_CORES = {}


def _dram_open(x, N: int) -> bool:
    """The DRAM legs' window: N >= 256, a tile-aligned N >= 224, or below that where the groups
    fill the grid (`DRAM_FILL`)."""
    if N >= 256:
        return True
    return DRAM_FILL and ((N >= DRAM_N_ALIGNED_MIN and N % TILE_H == 0) or _l1_fills_grid(x, N))


def _grid_cores(x) -> int:
    device = x.device()
    key = device.id()
    if key not in _GRID_CORES:
        g = device.compute_with_storage_grid_size()
        _GRID_CORES[key] = g.x * g.y
    return _GRID_CORES[key]


def _gated_l1_big(xw, N: int, slice_c: int) -> bool:
    """Whether one gated slice reaches `GATED_L1_MIN_ELEMS` on xw's grid (never on an unmeasured grid)."""
    floor = GATED_L1_MIN_ELEMS.get(_grid_cores(xw))
    return floor is not None and N * N * slice_c >= floor


def _l1_fills_grid(x, N: int) -> bool:
    """Whether an N x N move's Nt*Nt groups reach L1_GROUPS_PER_CORE per core of x's grid."""
    if not L1_GROUPS_PER_CORE:
        return False
    nt = (N + TILE_H - 1) // TILE_H
    return nt * nt >= L1_GROUPS_PER_CORE * _grid_cores(x)


def eligible(x, memory_config, taped_ok: bool = False) -> bool:
    """The gate, measured against the wheel's own ``ttnn.permute`` on the card that runs it.

    Two things decide it: the destination buffer type and ``N``. On DRAM the custom move wins from
    N=256 upward on both wheels measured (qb1 / 0.67.4: 1.90x at 298 and 320; qb2 / 0.68.0: 1.5x).
    On L1 the margin is smaller and grid-dependent. It opens at 288 because below that there are
    fewer work groups than cores and the per-call cost is not amortised: N=256 on an L1 output
    measures 0.952x on 110 cores, a real loss, and it is the shape boltzgen runs 2384 of its 3024
    channel moves on. Below 288 the L1 leg still opens where the Nt*Nt groups fill the grid
    (`L1_GROUPS_PER_CORE`), which on a 64-core Wormhole chip is from N=193.

    The upper edge stays 352. It was widened to 544 on qb2 evidence and reverted: the widening is
    worth 0.000 s/fold at 512 aa (the fit test already routes the pair tensor to DRAM, where the leg
    is open, so 52224 of 52224 moves were already served and 0 declined), and re-measured on qb1's
    13x10 grid it does not reproduce -- two runs there read 0.68/0.72x at N=320, 0.65/0.86x at N=384,
    and a run-to-run spread up to 23 % at N=512. A no-op with ambiguous cross-grid evidence is not
    worth a shipped behaviour change. The qb2 band below is kept because it is the measurement, and
    the qb1 repeats are in perf/bigswing/reblock_window_band_qb1c0{,_r2}.json.

    The qb2 measurement was: 544, on the 11x10 grid at ttnn 0.68.0
    (``perf/bigswing/reblock_window_band_qb2c0.json``): every N in {320, 352, 384, 416, 448, 480,
    512, 544} wins on an L1 output and every one is ``torch.equal`` against ``ttnn.permute`` --
    1.3317 / 1.0150 / 1.1500 / 1.3549 / 1.5587 / 1.3401 / 1.3958 / 1.6163x. There is no cliff in
    that range, and the weakest point is N=352, which is where the window used to close. That 352
    came from qb1's 13x10 grid, where Nt=12 puts 144 groups on 130 cores and the win was measured
    to collapse to 1.002x. The band above 352 has NOT been re-measured on a 130-core grid, so this
    edge is qb2-evidenced only and a qb1 re-measure is owed before it ships.

    The channel count is deliberately not part of the window: the kernel handles any ``C`` that is a
    multiple of 32, because the trunk's own chunk width depends on the compute grid.
    """
    from . import ops
    if ops.declines_under_tape("reblock_permute", x) and not (taped_ok and TAPED_MOVE):
        # A DIRECT caller under a tape gets no node for this `generic_op`, so it has to keep
        # the stock permute the tape can follow. `taped_ok` is the tape itself asking, and for
        # these two moves the tape can follow the kernel: the move is a pure index reordering
        # whose VJP is the OTHER kernel in this file, so `taped_ttnn._permute_fwd` records the
        # node and the reason to refuse is gone. `eligible_gated` keeps the blanket refusal --
        # it fuses a sigmoid and a multiply and its VJP is not an index move.
        return False

    if not _ENABLED:
        return False
    shape = [int(d) for d in x.shape]
    if len(shape) != 4 or shape[0] != 1 or shape[1] != shape[2] or shape[3] % TILE_W:
        return _reject("shape", shape)
    N = shape[1]
    if x.dtype != _DTYPE or x.layout != ttnn.TILE_LAYOUT:
        return _reject("dtype_layout", shape)
    if memory_config.memory_layout != ttnn.TensorMemoryLayout.INTERLEAVED:
        return _reject("sharded_out", shape)
    if x.memory_config().memory_layout != ttnn.TensorMemoryLayout.INTERLEAVED:
        return _reject("sharded_in", shape)
    bt = memory_config.buffer_type
    if not ((bt == ttnn.BufferType.DRAM and _dram_open(x, N))
            or (bt == ttnn.BufferType.L1 and N <= L1_N_MAX
                and (N >= L1_N_MIN or _l1_fills_grid(x, N)))):
        return _reject(f"window_{bt}", shape)
    return True


# Whether the two index-move kernels may serve a TAPED forward.
#
# Both are `generic_op`, which has no tape entry, so a direct caller under a tape would drop the
# gradient of everything upstream. `eligible`/`eligible_back` therefore refuse while a tape is
# open and a gradient round runs the stock `ttnn.permute` forward -- while its BACKWARD runs the
# kernel, because `taped_ttnn._permute_back` already routes there. That asymmetry is what
# `bcx-p10-trilay` measured as the triangle multiplication at 31.7 % of the DRAM roof forward
# against 55.3 % backward.
#
# With this on, `taped_ttnn._permute_fwd` takes the kernel and records the node itself. The two
# moves are each other's inverse -- `permute(0,3,1,2)` sends x[b,i,j,c] to y[b,c,i,j], so its VJP
# is `permute(0,2,3,1)` -- so the backward is the kernel the backward already used. Both are
# `torch.equal` against `ttnn.permute`, so the arm is bit-exact by construction.
#
# Default OFF, release-gated. A module switch as well as an env var, so an A/B flips it in one
# process without a second device context.
TAPED_MOVE = env_flag("TT_BIO_TAPED_CHANNEL_MOVE", False)


def set_taped_channel_move(on: bool) -> bool:
    """Turn the taped channel move on or off. Returns the previous setting."""
    global TAPED_MOVE
    prev, TAPED_MOVE = TAPED_MOVE, bool(on)
    return prev


# Whether `_channel_move` reaches for this kernel at all. Bit-exact: a permute is a pure index
# reordering, `torch.equal` against `ttnn.permute` at all 24 shapes in `eligible`'s window including
# the ragged group's output tile padding, and twelve on/off fold pairs across five models on both
# grids write byte-identical structures. Worth 209-251 ms/fold on a 298 aa protenix-v2 fold: four
# sessions on byte-identical code (209.3 / 217.7 / 218.5 / 251.2), qb1 at ttnn 0.67.4, all four read
# on the trimul block wall because that host's fold-wall A/A floor runs to 1480 ms and cannot
# resolve the effect. 4352 of 4352 eligible calls served in a live fold; esmfold2 serves 4336 of its
# own at 298 aa and none at 117 aa, where the window declines them. openfold3, boltz2 and opendde
# all gain (+236 / +314 / +681 ms/fold as qb2 ratios). Every model here is N-dependent, boltzgen
# included: it serves none of the 3024 moves in an `examples/binder.yaml` design, whose pair track is
# the [1,256,256,64] shape the window excludes for losing, and 4768 of 5408 against a 214-residue
# target, which lands at N=320.
# Evidence: state/protenix-trunk--y-permute-flip.md, y-permute-crossmodel.md, z-permute-bands.md,
# z-permute-flip-land.md (the per-model release gate at this default).
REBLOCK_PERMUTE = True
# `TT_BIO_REBLOCK_PERMUTE` stays as an out-of-process override for A/B harnesses; the default is
# the constant above, so the release gate and any in-process import can see and set it.
_ENABLED = env_flag("TT_BIO_REBLOCK_PERMUTE", REBLOCK_PERMUTE)


def set_enabled(on: bool) -> bool:
    """A/B switch for the paired harness. Returns the previous state."""
    global _ENABLED
    prev, _ENABLED = _ENABLED, bool(on)
    return prev


# --- the inverse move, permute(x, (0,2,3,1)) -------------------------------------------------------
#
# The trimul's channel loop moves the chunk to the batch axis for the per-channel contraction and
# then has to move it back. Forward is one kernel; back was two `ttnn.transpose` calls, and the pair
# reads and writes the tensor TWICE. Measured at 512 aa on qb2 card 0 (state/trimul-absolute-optimal
# §5): `transpose(1,2)` on [1,256,512,512] is 4.082 ms at 65.8 GB/s, 17.5 % of the measured combined
# roof and the single largest class in the module, because the destination tile it feeds spans 32
# channels while the source tile spans one, so a source tile scatters 32 rows into 32 destinations.
# Its partner `transpose(2,3)` is tile-local and already at 93 %. One pass over the tensor at the
# forward kernel's own measured rate is 1.51 ms against the pair's 4.849.
#
# Bit-exact by construction and verified with `torch.equal`: a permute is a pure index reordering,
# and the tile transpose the compute kernel applies is the same `transpose_wh` the stock op uses.


def _cache_key_back(x, out, device, reader_ct, writer_ct):
    g = device.compute_with_storage_grid_size()
    return (
        device.id(),
        int(x.shape[1]), int(x.shape[2]),
        str(x.dtype), str(x.layout),
        str(x.memory_config()), str(out.memory_config()),
        g.x, g.y, WALK, genq.compact(),
        tuple(reader_ct), tuple(writer_ct), BACK_ABL, BACK_SPLIT,
    )


def _build_back(x, out, device, reader_ct, writer_ct):
    C, N = int(x.shape[1]), int(x.shape[2])
    Nt, Ct = N // TILE_H, C // TILE_W
    # A group is (it, jt, ct) and owns 32 output tiles. Keeping `ct` INSIDE the group index rather
    # than looping over it per group is what makes the work split even: at 512 aa with C=256 that is
    # 2048 groups over 110 cores (19 and 18 per core, 5 % imbalance) where Nt*Nt groups would be 256
    # over 110 (3 and 2, 33 %).
    num_groups = Nt * Nt * Ct

    plan = _split_plan(device, num_groups)
    assert plan is not None, f"no expressible work split for {num_groups} groups"
    _, _, (num_cores, core_grid, cg1, cg2, work1, work2) = plan

    tile_bytes = TILE_H * TILE_W * _elem()

    def cb(idx, depth):
        fmt = ttnn.CBFormatDescriptor(
            buffer_index=idx, data_format=_DTYPE, page_size=tile_bytes
        )
        return ttnn.CBDescriptor(
            total_size=depth * tile_bytes, core_ranges=core_grid, format_descriptors=[fmt]
        )

    # Both 32-tile CBs MUST have a depth that is a multiple of 32, or the ring wraps mid-group: the
    # reader would gather from a scratch window that is not contiguous and the writer would stream 32
    # tiles from an address range that runs off the end of the buffer. That failure is silent -- it
    # passes at N=128 and N=256, where a group is the whole buffer, and produces garbage at N=512.
    # 64 is the smallest multiple that also double-buffers.
    cbs = [cb(IN_CB, 2), cb(OUT_CB, GROUP_TILES * 2), cb(STAGE_CB, GROUP_TILES * 2)]

    reader_rt, compute_rt, writer_rt = ttnn.RuntimeArgs(), ttnn.RuntimeArgs(), ttnn.RuntimeArgs()
    # `first` is this core's linear index, `block` the start of its contiguous run of groups. Both
    # counters are kept for every mode because `_walk` needs each of them; `placed` is the audit.
    assign, first, placed, block = {}, 0, 0, 0
    for group, per_core in ((cg1, work1), (cg2, work2)):
        for cr in group.ranges():
            for cx in range(cr.start.x, cr.end.x + 1):
                for cy in range(cr.start.y, cr.end.y + 1):
                    assign[(cx, cy)] = (block, per_core)
                    first += 1
                    block += per_core
                    placed += per_core
    assert (first, placed) == (num_cores, num_groups), (first, placed, num_cores, num_groups)

    genq_ct = _genq_ct(assign, core_grid, [Nt, 0, Ct])
    if genq_ct[0] == 0:
        for (cx, cy), (blk, per_core) in assign.items():
            i = _index_of(assign, cx, cy)
            g0, gs, ghi, glo = _walk(WALK, i, blk, per_core, num_cores)
            reader_rt[cx][cy] = [g0, per_core, Nt, Ct, gs, ghi, glo]
            compute_rt[cx][cy] = [per_core * GROUP_TILES]
            writer_rt[cx][cy] = [g0, per_core, Nt, Ct, gs, ghi, glo]
    compute_ct = [IN_CB, OUT_CB] + genq_ct[:8] + [GROUP_TILES]

    reader = ttnn.KernelDescriptor(
        kernel_source=str(KERNEL_DIR_BACK / "reader_reblock_permute_back.cpp"),
        source_type=ttnn.KernelDescriptor.SourceType.FILE_PATH,
        core_ranges=core_grid, compile_time_args=genq_ct + reader_ct, runtime_args=reader_rt,
        common_runtime_args=[0], config=ttnn.ReaderConfigDescriptor(),
        defines=[(d, "1") for b, d in ((1, "RPB_NO_DRAM"), (2, "RPB_NO_GATHER"), (8, "RPB_SPLIT"))
                 if (BACK_ABL | 8 * BACK_SPLIT) & b],
    )
    writer = ttnn.KernelDescriptor(
        kernel_source=str(KERNEL_DIR_BACK / "writer_reblock_permute_back.cpp"),
        source_type=ttnn.KernelDescriptor.SourceType.FILE_PATH,
        core_ranges=core_grid, compile_time_args=genq_ct + writer_ct, runtime_args=writer_rt,
        common_runtime_args=[0, Ct, 0, 0], config=ttnn.WriterConfigDescriptor(),
        defines=[(d, "1") for b, d in ((4, "RPB_NO_WRITE"), (8, "RPB_SPLIT")) if (BACK_ABL | 8 * BACK_SPLIT) & b],
    )
    # The compute kernel is the forward direction's, unchanged: both moves end in one `transpose_wh`
    # per tile, and the CB indices are the same.
    compute = ttnn.KernelDescriptor(
        kernel_source=str(KERNEL_DIR / "compute_reblock_permute.cpp"),
        source_type=ttnn.KernelDescriptor.SourceType.FILE_PATH,
        core_ranges=core_grid, compile_time_args=compute_ct, runtime_args=compute_rt,
        config=ttnn.ComputeConfigDescriptor(
            math_fidelity=ttnn.MathFidelity.HiFi2, fp32_dest_acc_en=True
        ),
    )
    pd = ttnn.ProgramDescriptor(kernels=[reader, writer, compute], semaphores=[], cbs=cbs)

    # Same one-off probe as the forward direction: find out whether the binding hands back a
    # reference to the kernel held inside the cached descriptor or a copy of it.
    global ADDR_WRITE_MODE
    if ADDR_WRITE_MODE is None:
        probe = 0xABCD1234
        pd.kernels[0].common_runtime_args = [probe]
        ADDR_WRITE_MODE = "in_place" if list(pd.kernels[0].common_runtime_args) == [probe] \
            else "rebuild_pd"
        pd.kernels[0].common_runtime_args = [0]

    return {"pd": pd, "kernels": [reader, writer, compute], "cbs": cbs, "core_grid": core_grid}


def _prepare_back(x, out, device):
    reader_ct = [_elem(), STAGE_CB, IN_CB, TILE_H, TILE_W, FACE_H, FACE_W]
    reader_ct.extend(ttnn.TensorAccessorArgs(x).get_compile_time_args())
    writer_ct = [_elem(), OUT_CB, TILE_H, TILE_W]
    writer_ct.extend(ttnn.TensorAccessorArgs(out).get_compile_time_args())
    if BACK_SPLIT:
        writer_ct.append(STAGE_CB)
        writer_ct.extend(ttnn.TensorAccessorArgs(x).get_compile_time_args())
    key = _cache_key_back(x, out, device, reader_ct, writer_ct)
    entry = _CACHE_BACK.get(key)
    if entry is None:
        entry = _CACHE_BACK[key] = _build_back(x, out, device, reader_ct, writer_ct)
    return entry


# The move takes permute_back_pk (the packer re-tiles, the writer copies whole tiles) where it serves, on both archs:
# bit-exact, and faster than this kernel, whose reader gathers 64 NOC packets a tile. Wormhole (Galaxy chip, 1000 MHz)
# 1.48 vs 2.09 ms at 512 c256, 5.67 vs 6.91 ms at 1024; p150a (1350 MHz) 0.47 vs 0.56 ms at 512 c128, 1.92 vs
# 3.18 ms at 1024. TT_BIO_PBPK=0 turns it off.
_PBPK = None
STATS_PBPK = [0]


def _pbpk():
    global _PBPK
    if _PBPK is None:
        _PBPK = env_flag("TT_BIO_PBPK", True)
    return _PBPK


@_ops.fused_kernel("reblock_permute_back")
def reblock_permute_back(x, memory_config=None, device=None, out=None, c_off=0):
    """``ttnn.permute(x, (0, 2, 3, 1))`` for ``x`` of shape ``[B, C, N, N]`` bf16 TILE.

    With ``out`` (a ``[B, N, N, C_out]`` tensor, ``C_out >= c_off + C``) the result is written into
    its channels ``[c_off, c_off + C)`` and ``out`` is returned: a channel loop then fills one tensor
    in place instead of concatenating its chunks. Same bytes, same order, bit-exact. B > 1 (RFD4's
    sample batch) is served by `permute_back_pk` only; `eligible_back` admits it only where that runs.
    """
    device = device or x.device()
    mc = memory_config or x.memory_config()
    B, C, N = int(x.shape[0]), int(x.shape[1]), int(x.shape[2])
    if out is None:
        out = ttnn.allocate_tensor_on_device(
            ttnn.Shape([B, N, N, C]), _DTYPE, ttnn.TILE_LAYOUT, device, mc
        )
    c_out = int(out.shape[-1])
    assert c_off % TILE_W == 0 and c_off + C <= c_out and [int(out.shape[i]) for i in range(3)] == [B, N, N], (
        "reblock_permute_back: the channel slice must be tile-aligned and inside `out`",
        C, c_off, [int(d) for d in out.shape])
    if _pbpk() and (x.memory_config().memory_layout == out.memory_config().memory_layout
                    == ttnn.TensorMemoryLayout.INTERLEAVED):
        from . import permute_back_pk as _pk
        from .tenstorrent import COMPUTE_GRID_MAIN
        if _pk.ok(x, out, c_off):
            STATS_BACK[0] += 1
            STATS_PBPK[0] += 1
            return _pk.permute_back_pk(x, out, tuple(COMPUTE_GRID_MAIN), c_off=c_off)
    assert B == 1, ("reblock_permute_back: a batch needs permute_back_pk", [int(d) for d in x.shape])
    entry = _prepare_back(x, out, device)
    src, dst = x.buffer_address(), out.buffer_address()
    wargs = [dst, c_out // TILE_W, c_off // TILE_W, src]
    if ADDR_WRITE_MODE == "in_place":
        pd = entry["pd"]
        pd.kernels[0].common_runtime_args = [src]
        pd.kernels[1].common_runtime_args = wargs
    else:
        reader, writer, compute = entry["kernels"]
        reader.common_runtime_args = [src]
        writer.common_runtime_args = wargs
        pd = entry["pd"] = ttnn.ProgramDescriptor(
            kernels=[reader, writer, compute], semaphores=[], cbs=entry["cbs"]
        )
    STATS_BACK[0] += 1
    return ttnn.generic_op([x, out], pd)


# Whether `_channel_move_back` reaches for the kernel at all.
REBLOCK_PERMUTE_BACK = True
_ENABLED_BACK = os.environ.get(
    "TT_BIO_REBLOCK_PERMUTE_BACK", "1" if REBLOCK_PERMUTE_BACK else "0") == "1"


def set_enabled_back(on: bool) -> bool:
    """A/B switch for the paired harness. Returns the previous state."""
    global _ENABLED_BACK
    prev, _ENABLED_BACK = _ENABLED_BACK, bool(on)
    return prev


def back_x8_ok(memory_config, batch: int = 2) -> bool:
    """Whether the move back takes a bfp8 x: a batch under `pair_x8` (RFD4), one fold under `trimul_x8`. The kernel,
    DRAM interleaved, no tape."""
    from . import ops
    from .tenstorrent import lever
    on = lever("pair_x8") and lever("pair_batch") if batch > 1 else lever("trimul_x8")
    return bool(on and _pbpk() and _ENABLED_BACK and not ops.taping()
                and memory_config.buffer_type == ttnn.BufferType.DRAM
                and memory_config.memory_layout == ttnn.TensorMemoryLayout.INTERLEAVED)


def eligible_back(x, memory_config, taped_ok: bool = False) -> bool:
    """The gate for the back direction.

    Deliberately narrower than the forward one. ``N`` must be a multiple of 32: the forward kernels
    carry an explicit ragged path because the trunk runs them at 298 aa, and the back direction can
    simply decline that shape and keep the two transposes, since the class it exists for is the DRAM
    path at 512 aa and above. The destination must be DRAM for the same reason -- that is the only
    place the two-transpose pair is expensive, and it is where `_triangle_mul_memory_config` puts the
    chunk from 352 aa up.
    """
    from . import ops
    if ops.declines_under_tape("reblock_permute_back", x) and not (taped_ok and TAPED_MOVE):
        # A DIRECT caller under a tape gets no node for this `generic_op`, so it has to keep
        # the stock permute the tape can follow. `taped_ok` is the tape itself asking, and for
        # these two moves the tape can follow the kernel: the move is a pure index reordering
        # whose VJP is the OTHER kernel in this file, so `taped_ttnn._permute_fwd` records the
        # node and the reason to refuse is gone. `eligible_gated` keeps the blanket refusal --
        # it fuses a sigmoid and a multiply and its VJP is not an index move.
        return False

    if not _ENABLED_BACK:
        return False
    shape = [int(d) for d in x.shape]
    if len(shape) != 4 or shape[0] < 1 or shape[2] != shape[3] or shape[1] % TILE_W:
        return _reject("back_shape", shape)
    C, N = shape[1], shape[2]
    if N % TILE_H:
        return _reject("back_ragged", shape)
    if shape[0] > 1:
        # A sample batch, under RFD4's `pair_batch` only. permute_back_pk is the one kernel that takes it, and the
        # alternative is the two transposes over the whole batch, not a stock permute, so the batch-1 window below does not
        # apply. b16 at 128: 3.69 + 0.69 ms a move for the transposes (state/rfd4/bets/b128.md).
        from .tenstorrent import lever
        if not (lever("pair_batch") and _pbpk() and memory_config.buffer_type == ttnn.BufferType.DRAM
                and (x.dtype == _DTYPE or x.dtype == ttnn.bfloat8_b and back_x8_ok(memory_config))
                and x.layout == ttnn.TILE_LAYOUT
                and x.memory_config().memory_layout == memory_config.memory_layout
                == ttnn.TensorMemoryLayout.INTERLEAVED):
            return _reject("back_batch", shape)
        return True
    if (x.dtype != _DTYPE and not (x.dtype == ttnn.bfloat8_b and back_x8_ok(memory_config, 1))
            or x.layout != ttnn.TILE_LAYOUT):
        return _reject("back_dtype_layout", shape)
    if memory_config.memory_layout != ttnn.TensorMemoryLayout.INTERLEAVED:
        return _reject("back_sharded_out", shape)
    if x.memory_config().memory_layout != ttnn.TensorMemoryLayout.INTERLEAVED:
        return _reject("back_sharded_in", shape)
    if memory_config.buffer_type != ttnn.BufferType.DRAM or not _dram_open(x, N):
        return _reject(f"back_window_{memory_config.buffer_type}", shape)
    # An L1 SOURCE is the channel loop's L1 path, where this kernel replaces a permute into L1
    # plus a clone to DRAM. It carries the forward kernel's L1 floor rather than the DRAM one:
    # MEASURED on the 11x10 grid, qb1 card 0, 1350 MHz sampled during, 9 interleaved reps against
    # an A/A floor of 1.0002-1.0015x -- 256 LOSES at 0.9918x / 0.9903x, 288 wins 1.0086x /
    # 1.0092x, 320 wins 1.0135x / 1.0172x (perf/trix_layout/back_onepass_qb1c0.json). 256's
    # chunks are 4.19 MB, small enough that the kernel's own dispatch outweighs the deleted pass.
    if (x.memory_config().buffer_type == ttnn.BufferType.L1 and N < L1_N_MIN
            and not _l1_fills_grid(x, N)):
        return _reject("back_l1_src_narrow", shape)
    return True


# --- E6: the gate folded into the forward move ------------------------------------------------------
#
# The trimul's channel loop produces one wide projection [1, N, N, 4*Cg] and then spends three full
# DRAM passes taking it apart: `ttnn.chunk(_, 4, dim=-1)` and two `multiply_(p, g, [SIGMOID])`. At
# 512 aa those three ops measure 2.832 + 2 x 1.022 = 4.876 ms per call on qb2 card 1, at 95-99 % of
# the 399.2 GB/s combined roof (perf/trimul_f2/e6_prize.py), so there is no tuning left in them: the
# only way to make them cheaper is to stop doing them.
#
# The forward move runs at 47.5 % of that roof and its critical path is the WRITER RISC's gather,
# 2048 local transactions per 32-tile group against 32 DRAM writes. So it has room on both of the
# RISCs this work lands on: the reader gains a second DRAM stream and the compute kernel gains an
# SFPU sigmoid and an FPU multiply, and neither is the binding resource.
#
# Bit-exactness is not by construction here -- unlike the plain permute, this kernel does
# arithmetic. It is achieved by mirroring binary_ng's own kernel structure (see
# compute_reblock_permute_gated.cpp) and pinned by `torch.equal` against the two-op sequence on
# device, per shape, in perf/trimul_f2/e6_parity.py.

KERNEL_DIR_GATED = Path(__file__).resolve().parent / "kernels" / "reblock_permute_gated"

# Tiles per DST acquire in the gated compute kernel; TT_BIO_GATE_GRANULARITY=1 restores the
# per-tile acquire. Same three stages in the same order through the same two bf16 circular
# buffers, so every rounding point is untouched and this kernel's standing `torch.equal` claim
# against the two-op ttnn sequence still holds -- checked, not assumed, at every value on both
# architectures.
#
# 2, not the 4 that is fastest on Wormhole. The two architectures do not agree: WH reads
# 1.0420x at 2 and 1.0759x at 4, Blackhole reads 1.0149x at 2 and 1.0011x at 4, so 4 is a wash on
# the architecture the published cell is measured on. 2 is the value that wins on one and keeps
# most of the other (perf/b2z_levers/gategran_512_qb2c0_n40.json,
# perf/b2z_sdpa_floor/gategran_512_whglx_c3.json). Worth 0.014 s on a 512 aa Blackhole fold,
# which is under the A/A floor -- it ships because it is free and bit-exact, not for the fold.
# Capped at 4 because the multiply stage holds two DST slots a tile against 8 slots of a 16-bit
# DST; above that the kernel would corrupt.
GATE_GRANULARITY = max(1, min(4, int(os.environ.get("TT_BIO_GATE_GRANULARITY", "2"))))

P_CB, G_CB, SIG_CB, MUL_CB = 0, 1, 2, 3

_CACHE_GATED: dict = {}
STATS_GATED = [0, 0]


def _cache_key_gated(x, out, device, reader_ct, writer_ct):
    """As `_cache_key`, plus the slice width. The two slice OFFSETS are deliberately absent: they
    are common runtime args, so one descriptor serves both the `a` and the `b` call."""
    g = device.compute_with_storage_grid_size()
    return (
        device.id(),
        int(x.shape[1]), int(x.shape[3]), int(out.shape[1]), int(out.shape[2]),
        str(x.dtype), str(x.layout),
        str(x.memory_config()), str(out.memory_config()),
        g.x, g.y, WALK,
        tuple(reader_ct), tuple(writer_ct),
        # `_build_gated` bakes this into the compute kernel's compile-time args AND into four CB
        # depths, so it has to be in the key. Without it an A/B that flips the granularity gets the
        # FIRST arm's compiled program back for both legs and reads a 1.000x that means nothing.
        GATE_GRANULARITY, _gate_lean(),
    )


def _build_gated(x, out, device, reader_ct, writer_ct, fidelity, fp32_acc):
    # `x` may be a ROW BLOCK of the wide projection, [1, R, N, Cw] with R < N, while `out` is
    # always the full [1, slice_c, N, N] destination. Nt is therefore read off the destination and
    # Nrt off the source: the block is its own tensor and is addressed locally, while every
    # destination index is absolute via the `row_off` common arg. R == N is the whole-tensor move
    # and is byte-for-byte what it was.
    N = int(out.shape[2])
    Ctw = int(x.shape[3]) // TILE_W       # channel tiles of the wide input
    Ct = int(out.shape[1]) // TILE_W      # channel tiles of one slice
    Nt = (N + TILE_H - 1) // TILE_H
    Nrt = (int(x.shape[1]) + TILE_H - 1) // TILE_H
    # A group is (row-tile, col-tile, channel-tile). Keeping the channel tile INSIDE the group
    # index is what makes the split even on a row block: a 64-row block at 512 aa is 2*16*8 = 256
    # groups over 110 cores where (row-tile, col-tile) alone would be 32, i.e. 8 waves against the
    # whole-tensor move's 3. `_build_back` does the same and records the same arithmetic.
    num_groups = Nrt * Nt * Ct

    plan = _split_plan(device, num_groups)
    assert plan is not None, f"no expressible work split for {num_groups} groups"
    _, _, (num_cores, core_grid, cg1, cg2, work1, work2) = plan

    tile_bytes = TILE_H * TILE_W * _elem()
    # The two input CBs take the projection's own format, so a bfp8 producer is read as written
    # (`GATED_IN_DTYPES`); the unpacker converts on the way into the gate. Everything after the
    # gate stays in `_DTYPE`.
    in_dtype = x.dtype
    in_bytes = _TILE_BYTES_ANY[in_dtype]

    def cb(idx, depth, dtype=_DTYPE, page=tile_bytes):
        fmt = ttnn.CBFormatDescriptor(
            buffer_index=idx, data_format=dtype, page_size=page
        )
        return ttnn.CBDescriptor(
            total_size=depth * page, core_ranges=core_grid, format_descriptors=[fmt]
        )

    # c_16 keeps the 32-tile group multiple the writer's L1 window needs. The four working CBs are
    # double-buffered singles at the default granularity: the compute kernel consumes and produces
    # one tile at a time, and a deeper ring would only hold more of a stream the writer is already
    # the slow end of. That last clause is exactly what GATE_GRANULARITY tests -- if the writer is
    # the slow end then removing compute barriers buys nothing and the A/B reads 1.00x.
    cbs = [cb(P_CB, 2 * GATE_GRANULARITY, in_dtype, in_bytes),
           cb(G_CB, 2 * GATE_GRANULARITY, in_dtype, in_bytes),
           cb(SIG_CB, 2 * GATE_GRANULARITY), cb(MUL_CB, 2 * GATE_GRANULARITY),
           cb(OUT_CB, GROUP_TILES * 2), cb(STAGE_CB, 2)]

    reader_rt, compute_rt, writer_rt = ttnn.RuntimeArgs(), ttnn.RuntimeArgs(), ttnn.RuntimeArgs()
    # `first` is this core's linear index, `block` the start of its contiguous run of groups. Both
    # counters are kept for every mode because `_walk` needs each of them; `placed` is the audit.
    first, placed, block = 0, 0, 0
    for group, per_core in ((cg1, work1), (cg2, work2)):
        for cr in group.ranges():
            for cx in range(cr.start.x, cr.end.x + 1):
                for cy in range(cr.start.y, cr.end.y + 1):
                    g0, gs, ghi, glo = _walk(WALK, first, block, per_core, num_cores)
                    reader_rt[cx][cy] = [g0, per_core, Nt, N, Ct, Ctw, gs, ghi, glo]
                    compute_rt[cx][cy] = [per_core * GROUP_TILES]
                    writer_rt[cx][cy] = [g0, per_core, Nt, N, Ct, gs, ghi, glo]
                    first += 1
                    block += per_core
                    placed += per_core
    assert (first, placed) == (num_cores, num_groups), (first, placed, num_cores, num_groups)

    reader = ttnn.KernelDescriptor(
        kernel_source=str(KERNEL_DIR_GATED / "reader_reblock_permute_gated.cpp"),
        source_type=ttnn.KernelDescriptor.SourceType.FILE_PATH,
        core_ranges=core_grid, compile_time_args=reader_ct, runtime_args=reader_rt,
        common_runtime_args=[0, 0, 0, 0], config=ttnn.ReaderConfigDescriptor(),
    )
    # The writer is a fork of the ungated one: same gather, same staging, same DRAM write, but the
    # work unit carries the channel tile and the destination index carries the block's row offset.
    writer = ttnn.KernelDescriptor(
        kernel_source=str(KERNEL_DIR_GATED / "writer_reblock_permute_gated.cpp"),
        source_type=ttnn.KernelDescriptor.SourceType.FILE_PATH,
        core_ranges=core_grid, compile_time_args=writer_ct, runtime_args=writer_rt,
        common_runtime_args=[0, 0], config=ttnn.WriterConfigDescriptor(),
    )
    compute = ttnn.KernelDescriptor(
        kernel_source=str(KERNEL_DIR_GATED / "compute_reblock_permute_gated.cpp"),
        source_type=ttnn.KernelDescriptor.SourceType.FILE_PATH,
        core_ranges=core_grid,
        compile_time_args=[P_CB, G_CB, SIG_CB, MUL_CB, OUT_CB, int(GATE_SKIP_SIGMOID),
                           GATE_GRANULARITY, int(in_dtype != ttnn.bfloat16), _gate_lean()],
        runtime_args=compute_rt,
        config=ttnn.ComputeConfigDescriptor(
            math_fidelity=fidelity, fp32_dest_acc_en=fp32_acc
        ),
    )
    pd = ttnn.ProgramDescriptor(kernels=[reader, writer, compute], semaphores=[], cbs=cbs)

    global ADDR_WRITE_MODE
    if ADDR_WRITE_MODE is None:
        probe = 0xABCD1234
        pd.kernels[0].common_runtime_args = [probe, 0, 0, 0]
        ADDR_WRITE_MODE = "in_place" if list(pd.kernels[0].common_runtime_args)[0] == probe \
            else "rebuild_pd"
        pd.kernels[0].common_runtime_args = [0, 0, 0, 0]

    return {"pd": pd, "kernels": [reader, writer, compute], "cbs": cbs, "core_grid": core_grid}


def _prepare_gated(x, out, device, fidelity, fp32_acc):
    reader_ct = list(ttnn.TensorAccessorArgs(x).get_compile_time_args())
    writer_ct = [_elem(), OUT_CB, TILE_H, TILE_W, FACE_H, FACE_W, STAGE_CB]
    writer_ct.extend(ttnn.TensorAccessorArgs(out).get_compile_time_args())
    key = _cache_key_gated(x, out, device, reader_ct, writer_ct)
    entry = _CACHE_GATED.get(key)
    if entry is None:
        entry = _CACHE_GATED[key] = _build_gated(
            x, out, device, reader_ct, writer_ct, fidelity, fp32_acc)
    return entry


# The compute config the kernel has to run under to stay bit-exact against . Both
# values are load-bearing and neither is a default: see the kernel for the two mechanisms and
# perf/trimul_f2/e6_parity.py for the shapes they were pinned at. A change here is a silent
# precision change, not an error.
GATE_FIDELITY = ttnn.MathFidelity.HiFi4
GATE_FP32_ACC = False
# Diagnostic, never on in production: drops the activation so the multiply can be measured alone.
GATE_SKIP_SIGMOID = False

# The lean gated compute (`lean` in compute_reblock_permute_gated.cpp): g and p are transposed on
# the unpack, so a tile takes two pack round trips instead of three. 1 multiplies on the FPU from
# DST, which truncates into the 16-bit DST (one bf16 ULP low on about a quarter of elements; WH
# module rel_rms 0.0084 against 0.0081). 2 keeps the incumbent's SFPU multiply and is bit-exact
# (torch.equal to 0 on WH and BH, both trimul variants), so it is the default. 0 is the incumbent
# three-round-trip compute. spd-trimul A/B arms `glean` (1) and `noglean` (0).
GATE_LEAN = int(os.environ.get("TT_BIO_GATED_LEAN", "2"))


def set_gate_lean(mode) -> int:
    """A/B switch for the paired harness: 0 off, 1 lean FPU multiply, 2 lean exact. Returns the previous."""
    global GATE_LEAN
    prev, GATE_LEAN = GATE_LEAN, int(mode)
    return prev


def _gate_lean() -> int:
    return GATE_LEAN


@_ops.fused_kernel("reblock_permute_gated")
def reblock_permute_gated(xw, p_slice, g_slice, slice_c, memory_config=None, device=None,
                          out=None, row_off=0):
    """``permute(chunk(xw, 4, -1)[p_slice] * sigmoid(chunk(xw, 4, -1)[g_slice]), (0, 3, 1, 2))``.

    ``xw`` is ``[1, N, N, Cw]`` bf16 TILE and the result is ``[1, slice_c, N, N]``. The slice
    arguments are in CHANNELS, not tiles; the kernel takes tile offsets.

    Pass ``out`` and ``row_off`` to move ONE ROW BLOCK: ``xw`` is then ``[1, R, N, Cw]`` holding
    the rows starting at ``row_off``, and the block is written into the full ``out`` in place.
    That is what lets the projection feeding this move stay L1-resident -- the whole
    ``[1, N, N, Cw]`` projection is 512 MB at 512 aa against 160 MB of L1, and a 64-row block is
    67 MB. The result is identical to moving the whole tensor: the destination index is absolute
    and the blocks partition it.
    """
    device = device or xw.device()
    if out is None:
        mc = memory_config or xw.memory_config()
        N = int(xw.shape[1])
        out = ttnn.allocate_tensor_on_device(
            ttnn.Shape([1, slice_c, N, N]), _DTYPE, ttnn.TILE_LAYOUT, device, mc
        )
    assert row_off % TILE_H == 0, f"row_off {row_off} is not a tile boundary"
    entry = _prepare_gated(xw, out, device, GATE_FIDELITY, GATE_FP32_ACC)
    src, dst = xw.buffer_address(), out.buffer_address()
    common_r = [src, p_slice // TILE_W, g_slice // TILE_W, row_off // TILE_H]
    common_w = [dst, row_off // TILE_H]
    if ADDR_WRITE_MODE == "in_place":
        pd = entry["pd"]
        pd.kernels[0].common_runtime_args = common_r
        pd.kernels[1].common_runtime_args = common_w
    else:
        reader, writer, compute = entry["kernels"]
        reader.common_runtime_args = common_r
        writer.common_runtime_args = common_w
        pd = entry["pd"] = ttnn.ProgramDescriptor(
            kernels=[reader, writer, compute], semaphores=[], cbs=entry["cbs"]
        )
    STATS_GATED[0] += 1
    return ttnn.generic_op([xw, out], pd)


# Formats the gated move reads its projection in. bfp8_b is the spd-trimul lever: the in-projection
# writes it (`TT_BIO_TRIMUL_INPROJ_B8`), halving its output drain, and only the two input CBs change.
GATED_IN_DTYPES = (ttnn.bfloat16, ttnn.bfloat8_b)
_TILE_BYTES_ANY = {ttnn.bfloat16: 2048, ttnn.float32: 4096, ttnn.bfloat8_b: 1088}


# Master switch for folding the trimul's chunk and its two sigmoid gates into the forward move.
# ON, but every TriangleMultiplication still has to opt in (`gated_move=`). The recorded reason was
# that the fused pair is a measured LOSS on boltz2 (+0.373 s/fold at 512 aa, only 64 of 560 of its
# moves eligible) against 1.5046x on opendde's, `torch.equal` at both of its slice widths
# (perf/odde512/screen3.json). The loss was COVERAGE, not the kernel: `eligible_gated`'s caller
# required `mask_u is None` and boltz2 always passes a pair mask, so none of those 64 moves can
# have been in the pairformer. With the mask moved past the channel move the same kernel is
# 1.2981x / 1.3329x per trimul at 512 aa and 1.0555x on the fold, bit-exact
# (perf/b2x_trimul/). The model decides; this only says whether the kernel exists at all.
REBLOCK_PERMUTE_GATED = True
_ENABLED_GATED = os.environ.get(
    "TT_BIO_REBLOCK_PERMUTE_GATED", "1" if REBLOCK_PERMUTE_GATED else "0") == "1"


def set_enabled_gated(on: bool) -> bool:
    """A/B switch for the paired harness. Returns the previous state."""
    global _ENABLED_GATED
    prev, _ENABLED_GATED = _ENABLED_GATED, bool(on)
    return prev


def eligible_gated(xw, slice_c, memory_config) -> bool:
    """The gate for the fused path, deliberately the forward gate's window plus what fusion adds.

    Everything `eligible` checks applies unchanged: the same reader, the same writer, the same work
    split. On top of it the wide input must actually be the four-way fused projection, and the
    slice width must be a whole number of tiles, because the reader addresses slices in tile units.
    """
    from . import ops
    if ops.declines_under_tape("reblock_permute_gated"):
        # No tape entry installed. This one is not just a permutation -- it slices a four-way
        # fused projection and folds `p * sigmoid(g)` into the move -- so its VJP is the gate's
        # as well as the permutation's: `taped_ttnn._k_reblock_permute_gated`, with the fused
        # `reblock_permute_gated_bw` below. Off TT_BIO_TAPED_KERNELS it declines.
        return False

    if not _ENABLED_GATED:
        return False
    shape = [int(d) for d in xw.shape]
    # `xw` is either the whole [1, N, N, 4*slice_c] projection or ONE ROW BLOCK of it,
    # [1, R, N, 4*slice_c] with R a whole number of tiles, which is the mode `_build_gated`'s
    # `out`/`row_off` arguments exist for. N is the DESTINATION width in both cases, so it comes
    # off axis 2 and never off axis 1. The whole-tensor case keeps its exact old window: any N,
    # including the 298 that production runs and that is not a tile multiple.
    if len(shape) != 4 or shape[0] != 1:
        return _reject("gated_shape", shape)
    if shape[1] != shape[2] and not (shape[1] < shape[2] and shape[1] % TILE_H == 0):
        return _reject("gated_rowblock", shape)
    if shape[1] != shape[2] and ops.taping():
        # A row block writes into a caller-owned destination across calls, which no single tape
        # node owns. The tape entry covers the whole-tensor move only.
        return _reject("gated_rowblock_taped", shape)
    if shape[3] != 4 * slice_c or slice_c % TILE_W:
        return _reject("gated_slice", shape)
    N = shape[2]
    if xw.dtype not in GATED_IN_DTYPES or xw.layout != ttnn.TILE_LAYOUT:
        return _reject("gated_dtype_layout", shape)
    if xw.dtype != _DTYPE and shape[1] != shape[2]:
        return _reject("gated_b8_rowblock", shape)      # only the whole-tensor move was measured
    if memory_config.memory_layout != ttnn.TensorMemoryLayout.INTERLEAVED:
        return _reject("gated_sharded_out", shape)
    if xw.memory_config().memory_layout != ttnn.TensorMemoryLayout.INTERLEAVED:
        return _reject("gated_sharded_in", shape)
    bt = memory_config.buffer_type
    if not ((bt == ttnn.BufferType.DRAM and (N >= 256 or (DRAM_FILL_GATED and _dram_open(xw, N))))
            or (bt == ttnn.BufferType.L1 and N <= L1_N_MAX
                and (N >= L1_N_MIN or _l1_fills_grid(xw, N) or _gated_l1_big(xw, N, slice_c)))):
        return _reject(f"gated_window_{bt}", shape)
    return True


# --- the gated move's backward ---------------------------------------------------------------------
#
# Under a tape the forward above needs a VJP, and the composed one costs more than the forward it
# differentiates: per role, the move back and then sigmoid, rsub and five multiplies, each a full
# [1, N, N, C] bf16 round trip through DRAM (perf/bcp_evo/census_blocks.txt: ~1.0 ms a role at
# 288 tokens on p300c).
#
# This kernel is the move back with the gate's VJP folded into its compute stage:
#   da' = permute(da, (0, 2, 3, 1));  s = sigmoid(g);  dp = da' * s;  dg = da' * p * s * (1 - s)
# The reader is reader_reblock_permute_back.cpp, verbatim. The writer also fetches the p and g
# tiles at each output position (whole aligned tiles, off the reader RISC, which is the busy one)
# and writes dp and dg as two [1, N, N, C] tensors in the projection's layout, so the tape joins
# them into the projection's gradient exactly where it joins the slices' gradients today.
#
# Precision: everything between the cotangent and the two gradients stays in a float32 DST and is
# rounded once, at the pack. The composed chain rounds six times. Graded against float64.

KERNEL_DIR_GATED_BW = Path(__file__).resolve().parent / "kernels" / "reblock_permute_gated_bw"
# Whether the tape entry's backward runs this kernel or the composed chain. Default off like every
# gradient lever; `bindcraft2.fast_round` arms it. Read live, so one process can A/B both arms.
GATED_BW_FUSED = env_flag("TT_BIO_GATED_BW_FUSED", False)
# Write dp and dg straight into the wide projection's gradient (`autograd.Tensor.grad_slab`) at the
# channel offsets they were read from. The tape otherwise keeps the four slice gradients of a
# triangle multiplication's in-projection and joins them with one concat into [1, N, N, 4C]
# (0.446 ms at 288 tokens) before the projection's matmul VJP. Same tiles, new pages: bit-exact.
GATED_GRAD_PACKED = env_flag("TT_BIO_GATED_GRAD_PACKED", False)
P_BW_CB, G_BW_CB, DP_CB, DG_CB = 1, 2, 16, 17
_CACHE_GATED_BW: dict = {}
STATS_GATED_BW = [0, 0]


def eligible_gated_bw(da, xw) -> bool:
    """Whether the fused backward serves ``da [1, C, N, N]`` against ``xw [1, N, N, Cw]``.

    The back move's window minus its DRAM floor: N and C whole tiles, TILE, interleaved, ``xw``
    bf16 and ``da`` bf16 or float32 (a cotangent with two consumers arrives promoted). A shape
    outside it takes the composed VJP, which is correct everywhere.
    """
    sd, sx = [int(d) for d in da.shape], [int(d) for d in xw.shape]
    ok = (len(sd) == 4 and len(sx) == 4 and sd[0] == 1 and sx[0] == 1 and sd[2] == sd[3]
          and sx[1] == sd[2] and sx[2] == sd[2] and sd[1] % TILE_W == 0
          and sd[2] % TILE_H == 0 and sx[3] % TILE_W == 0)
    ok = ok and xw.dtype == _DTYPE and da.dtype in _ELEM_BYTES and all(
        t.layout == ttnn.TILE_LAYOUT
        and t.memory_config().memory_layout == ttnn.TensorMemoryLayout.INTERLEAVED
        for t in (da, xw))
    if not ok:
        STATS_GATED_BW[1] += 1
    return ok


def _build_gated_bw(da, xw, device, reader_ct, writer_ct, packed=False):
    C, N = int(da.shape[1]), int(da.shape[2])
    Nt, Ct, Ctw = N // TILE_H, C // TILE_W, int(xw.shape[3]) // TILE_W
    num_groups = Nt * Nt * Ct
    plan = _split_plan(device, num_groups)
    assert plan is not None, f"no expressible work split for {num_groups} groups"
    _, _, (num_cores, core_grid, cg1, cg2, work1, work2) = plan
    def cb(idx, depth, dtype=_DTYPE):
        tile_bytes = TILE_H * TILE_W * _ELEM_BYTES[dtype]
        fmt = ttnn.CBFormatDescriptor(buffer_index=idx, data_format=dtype, page_size=tile_bytes)
        return ttnn.CBDescriptor(total_size=depth * tile_bytes, core_ranges=core_grid,
                                 format_descriptors=[fmt])

    # The scratch window and the four group-wide CBs each hold one whole 32-tile group. The
    # cotangent's two (scratch and gathered) are in its own dtype; everything else is bf16.
    cbs = [cb(IN_CB, 2, da.dtype), cb(STAGE_CB, GROUP_TILES * 2, da.dtype), cb(P_BW_CB, GROUP_TILES),
           cb(G_BW_CB, GROUP_TILES), cb(DP_CB, GROUP_TILES), cb(DG_CB, GROUP_TILES)]
    reader_rt, compute_rt, writer_rt = ttnn.RuntimeArgs(), ttnn.RuntimeArgs(), ttnn.RuntimeArgs()
    block = 0
    for group, per_core in ((cg1, work1), (cg2, work2)):
        for cr in group.ranges():
            for cx in range(cr.start.x, cr.end.x + 1):
                for cy in range(cr.start.y, cr.end.y + 1):
                    # Blocked walk, always: the writer walks the same contiguous run.
                    reader_rt[cx][cy] = [block, per_core, Nt, Ct, 1, _NO_WRAP, 0]
                    compute_rt[cx][cy] = [per_core * GROUP_TILES]
                    writer_rt[cx][cy] = [block, per_core, Nt, Ct, Ctw]
                    block += per_core
    assert block == num_groups, (block, num_groups)
    reader = ttnn.KernelDescriptor(
        kernel_source=str(KERNEL_DIR_BACK / "reader_reblock_permute_back.cpp"),
        source_type=ttnn.KernelDescriptor.SourceType.FILE_PATH,
        core_ranges=core_grid, compile_time_args=[0] * 11 + reader_ct, runtime_args=reader_rt,
        common_runtime_args=[0], config=ttnn.ReaderConfigDescriptor(),
    )
    writer = ttnn.KernelDescriptor(
        kernel_source=str(KERNEL_DIR_GATED_BW / "writer_reblock_permute_gated_bw.cpp"),
        source_type=ttnn.KernelDescriptor.SourceType.FILE_PATH,
        core_ranges=core_grid, compile_time_args=writer_ct, runtime_args=writer_rt,
        common_runtime_args=[0] * 5, config=ttnn.WriterConfigDescriptor(),
        defines=[("PACKED_GRAD", "1")] if packed else [],
    )
    compute = ttnn.KernelDescriptor(
        kernel_source=str(KERNEL_DIR_GATED_BW / "compute_reblock_permute_gated_bw.cpp"),
        source_type=ttnn.KernelDescriptor.SourceType.FILE_PATH,
        core_ranges=core_grid, compile_time_args=[IN_CB, P_BW_CB, G_BW_CB, DP_CB, DG_CB],
        runtime_args=compute_rt,
        config=ttnn.ComputeConfigDescriptor(math_fidelity=ttnn.MathFidelity.HiFi4,
                                            fp32_dest_acc_en=True),
    )
    return {"kernels": [reader, writer, compute], "cbs": cbs}


def reblock_permute_gated_bw(da, xw, p_slice, g_slice, out=None):
    """``(dp, dg)``, the VJP of ``reblock_permute_gated(xw, p_slice, g_slice, C)`` at ``da``.

    ``da`` is ``[1, C, N, N]`` (the move's output layout) and ``xw`` the ``[1, N, N, Cw]``
    projection the forward read; both results are ``[1, N, N, C]`` bf16 TILE in DRAM. The slice
    offsets are in CHANNELS, like the forward's.

    With `out`, a bf16 ``[1, N, N, Cw]`` tensor, dp and dg are written into it at ``p_slice`` and
    ``g_slice`` instead (`GATED_GRAD_PACKED`) and ``(out, out)`` is returned.
    """
    device = da.device()
    C, N = int(da.shape[1]), int(da.shape[2])
    if out is not None:
        dp = dg = out
    else:
        dp, dg = (ttnn.allocate_tensor_on_device(ttnn.Shape([1, N, N, C]), _DTYPE,
                                                 ttnn.TILE_LAYOUT, device, ttnn.DRAM_MEMORY_CONFIG)
                  for _ in range(2))
    reader_ct = [_ELEM_BYTES[da.dtype], STAGE_CB, IN_CB, TILE_H, TILE_W, FACE_H, FACE_W]
    reader_ct.extend(ttnn.TensorAccessorArgs(da).get_compile_time_args())
    writer_ct = [P_BW_CB, G_BW_CB, DP_CB, DG_CB]
    for t in (xw, dp, dg):
        writer_ct.extend(ttnn.TensorAccessorArgs(t).get_compile_time_args())
    g = device.compute_with_storage_grid_size()
    key = (device.id(), C, N, int(xw.shape[3]), g.x, g.y, REBLOCK_CORES,
           tuple(reader_ct), tuple(writer_ct), out is not None)
    entry = _CACHE_GATED_BW.get(key)
    if entry is None:
        entry = _CACHE_GATED_BW[key] = _build_gated_bw(da, xw, device, reader_ct, writer_ct,
                                                       packed=out is not None)
    reader, writer, compute = entry["kernels"]
    reader.common_runtime_args = [da.buffer_address()]
    writer.common_runtime_args = [xw.buffer_address(), p_slice // TILE_W, g_slice // TILE_W,
                                  dp.buffer_address(), dg.buffer_address()]
    pd = ttnn.ProgramDescriptor(kernels=[reader, writer, compute], semaphores=[], cbs=entry["cbs"])
    STATS_GATED_BW[0] += 1
    ttnn.generic_op([da, xw, dp] if out is not None else [da, xw, dp, dg], pd)
    return dp, dg
