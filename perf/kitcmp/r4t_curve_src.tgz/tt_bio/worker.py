"""Long-lived prediction worker.

A worker process owns one accelerator slot for its entire lifetime: it loads the
Boltz-2 model once, then pulls jobs from a scheduler over HTTP and runs them
until cancelled. The same loop serves a `predict` run's own scheduler and a
persistent `tt-bio controller`; only the scheduler URL differs.
"""

from __future__ import annotations

import base64
import contextlib
import functools
import gc
import json
import os
import shutil
import signal
import sys
import tempfile
import time
import traceback
from dataclasses import dataclass
from functools import partial
from pathlib import Path
from typing import Any

import torch

from tt_bio.device_lease import CONTENDED_EXIT_CODE, DeviceInUseError, install_parent_death_guard
from tt_bio.host_controller import (HEARTBEAT_PER_LEASE, LEASE_S, ControllerClient,
                                    HttpProgressQueue, diffusion_precision,
                                    run_config_hash)
from tt_bio.envflags import env_flag
from tt_bio import ranking as rank
from tt_bio.cache import EMPTY_MSA, cached, msa_pinned, seq_hash, single_flight, staged
from tt_bio.capabilities import check_capabilities


_REAL_STDERR_FD: int | None = None
_CAPTURE_PATH: Path | None = None


def _recycles(cfg: dict, default: int) -> int:
    """--recycling_steps from a worker config; None is the model default, 0 is a real 0.

    `cfg.get(...) or default` read an explicit 0 as unset, so rf3 ran 10 cycles and
    openfold3 4 when a user asked for 0.
    """
    r = cfg.get("recycling_steps")
    return default if r is None else int(r)


def worker_capture_path(pid: int) -> Path:
    """Path a silenced worker's native stderr (fd 2) is captured to.

    Keyed by pid so the launcher, which knows each child's ``proc.pid``, can read
    it back after the worker dies (see ``read_worker_capture``).
    """
    return Path(tempfile.gettempdir()) / f"tt-bio-worker-{pid}.stderr"


def read_worker_capture(pid: int, max_bytes: int = 4000, *, consume: bool = True) -> str:
    """Return the tail of a dead worker's captured native stderr, or "".

    Consumes the file by default, so a caller that never thinks about it still
    leaves nothing in /tmp per crashed worker.
    """
    path = worker_capture_path(pid)
    try:
        data = path.read_bytes()
    except OSError:
        return ""
    if consume:
        try:
            path.unlink()
        except OSError:
            pass
    return data[-max_bytes:].decode("utf-8", "replace").strip()


def _silence_subprocess_output() -> None:
    """Hide library noise while keeping a worker fatal recoverable.

    stdout is genuine per-op noise and goes to /dev/null. Native stderr (fd 2)
    goes to a per-worker capture *file*, not /dev/null, so a fatal that never
    reaches Python survives: a C-level abort such as an MPI_Init failure or a
    tt-metal L1 circular-buffer throw writes to fd 2 and exits without
    unwinding, so ``_report_fatal`` never runs and /dev/null turns it into a
    0-byte log behind a run that just failed (#12, #14). A dup of the real
    stderr is still kept so ``_report_fatal`` can surface Python fatals to the
    terminal immediately.
    """
    global _REAL_STDERR_FD, _CAPTURE_PATH
    _REAL_STDERR_FD = os.dup(2)
    dn_fd = os.open(os.devnull, os.O_WRONLY)
    os.dup2(dn_fd, 1)
    os.close(dn_fd)
    _CAPTURE_PATH = worker_capture_path(os.getpid())
    cap_fd = os.open(str(_CAPTURE_PATH), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    os.dup2(cap_fd, 2)
    os.close(cap_fd)
    sys.stdout = open(os.devnull, "w")
    sys.stderr = os.fdopen(2, "w", buffering=1, closefd=False)


def _cleanup_worker_capture() -> None:
    """Remove this worker's capture file on a clean or Python-level exit. A
    native abort skips this (it never unwinds), so its file is left for the
    launcher, which consumes it in ``read_worker_capture``."""
    global _CAPTURE_PATH
    if _CAPTURE_PATH is not None:
        try:
            os.remove(_CAPTURE_PATH)
        except OSError:
            pass
        _CAPTURE_PATH = None


def _report_fatal(message: str) -> None:
    """Write a worker-fatal to the launcher's real stderr, silenced or not."""
    fd = _REAL_STDERR_FD if _REAL_STDERR_FD is not None else 2
    try:
        os.write(fd, message.encode("utf-8", "replace"))
    except Exception:
        pass


def _apply_tt_environment(worker_info: dict[str, Any]) -> None:
    """Configure TT visibility for this worker before importing ttnn."""
    if worker_info["accelerator"] != "tenstorrent":
        return
    os.environ["TT_VISIBLE_DEVICES"] = str(worker_info.get("visible_devices") or worker_info["device_id"])
    os.environ["TT_BIO_LOGICAL_DEVICE_ID"] = str(worker_info.get("logical_device_id", 0))
    mgd = worker_info.get("mesh_graph_descriptor")
    if mgd and not os.environ.get("TT_MESH_GRAPH_DESC_PATH"):
        os.environ["TT_MESH_GRAPH_DESC_PATH"] = str(mgd)


def _bind_host_threads() -> None:
    """Bind torch's thread pools to the cap ``main._cap_worker_threads`` exported
    before spawning. See ``runtime.bind_host_threads``."""
    from . import runtime

    runtime.bind_host_threads()


def _ensure_local_artifacts(cfg: dict[str, Any]) -> None:
    """Make sure model files and caches exist locally for this worker.

    Model checkpoints and the molecule library are always resolved to the
    worker's own ~/.boltz/ cache. For the MSA directory we prefer the path
    the controller asked for (so single-machine and shared-filesystem runs
    keep populating <out_dir>/msa/ exactly like the legacy pipeline) and
    only fall back to the local cache when that path is not writable by
    this worker (another user, container or mount namespace).
    """
    from tt_bio import weights

    cache = weights.cache_root()
    cache.mkdir(parents=True, exist_ok=True)
    # One template-structure cache for every model that reads a `templates:` npz, so a CIF
    # fetched for an OpenFold3 fold is reused by a Protenix or OpenDDE one.
    cfg["template_structures"] = _template_structure_dir(cache)
    # Every checkpoint below resolves through tt_bio.weights: it honours the row's env
    # overrides, verifies whatever is already cached, and re-fetches only what is
    # missing or corrupt, so a truncated file from a killed download can never be
    # loaded as if it were complete.
    if cfg.get("model") in _protenix_family():
        cfg["msa_dir"] = _resolve_msa_dir(cfg.get("msa_dir"), cache)
        cfg["protenix_ckpt"] = cfg.get("checkpoint") or str(weights.fetch(cfg["model"]))
        cfg["mol_dir"] = str(weights.fetch("mols"))    # CCD templates for nucleic acids / ligands
        _own_conformers(cfg)
        return
    # OpenFold3 / OpenBind: $TT_BIO_OPENFOLD3 / $OF3_CKPT or $TT_BIO_OPENBIND, else the
    # local cache, else upstream's bucket. The artifact key is the model id, so the
    # right checkpoint follows from --model with no second mapping to keep in sync.
    if cfg.get("model") in _of3_family():
        cfg["msa_dir"] = _resolve_msa_dir(cfg.get("msa_dir"), cache)
        cfg["of3_ckpt"] = str(weights.fetch(cfg["model"]))
        cfg["of3_max_msa_seqs"] = os.environ.get("OF3_MAX_MSA_SEQS")
        return
    # RF3: checkpoint from files.ipd.uw.edu (or $RF3_CKPT), MSA dir like the rest.
    # main.py pre-fetches in the parent before fanning out, so this is normally a
    # cache hit; a worker serving a persistent controller fetches for itself.
    if cfg.get("model") == "rf3":
        cfg["msa_dir"] = _resolve_msa_dir(cfg.get("msa_dir"), cache)
        cfg["rf3_ckpt"] = str(weights.fetch("rf3"))
        return
    # OpenDDE loads its weights from HF on the first fold; None means "the registry
    # resolves it", which is what load_opendde_checkpoint does with a null path. Its
    # ligands and CCD-templated residues read the same molecule library as Protenix.
    if cfg.get("model", "boltz2") in ("opendde", "opendde-abag"):
        cfg["opendde_ckpt"] = os.environ.get("TT_BIO_OPENDDE") or os.environ.get("OPENDDE_CKPT")
        cfg["mol_dir"] = str(weights.fetch("mols"))
        _own_conformers(cfg)
        return
    # AF2-IG reads one member out of DeepMind's 4 GB parameter archive (weights.py:
    # `af2-params`), and folds single-sequence, so it needs no MSA dir and no molecule
    # library. main.py pre-fetches in the parent before fanning out; a worker joined to a
    # remote controller fetches on its own host.
    if cfg.get("model") == "af2ig":
        # The row's derived output is the directory; $AF2IG_PARAMS may name either it or the
        # one member inside it, and both spellings are in use on this fleet.
        got = weights.fetch("af2-params", root=cache)
        cfg["af2_params"] = str(got if got.is_file() else got / "params_model_1_ptm.npz")
        return
    # ESMFold2 loads its weights from HF on the first fold and needs no Boltz-2
    # checkpoints / molecule library — only a writable MSA dir.
    if cfg.get("model", "boltz2") in ("esmfold2", "esmfold2-fast"):
        cfg["msa_dir"] = _resolve_msa_dir(cfg.get("msa_dir"), cache)
        return
    # Embedding models (ESMC, SaProt): weights come straight from the HF cache,
    # no Boltz-2 checkpoints/molecule library/MSA dir needed.
    if _is_embed_model(cfg.get("model", "boltz2")):
        return
    cfg["conf_ckpt"] = str(weights.fetch("boltz2-conf"))
    cfg["aff_ckpt"] = str(weights.fetch("boltz2-aff"))
    cfg["mol_dir"] = str(weights.fetch("mols"))
    cfg["msa_dir"] = _resolve_msa_dir(cfg.get("msa_dir"), cache)


def _template_structure_dir(cache: Path) -> str:
    """The shared cache the `templates:` CIFs are downloaded into.

    One directory for every model that takes a template, so a template fetched for an
    OpenFold3 fold is reused by a Protenix one. $OF3_TEMPLATE_STRUCTURES still names it, and
    weights.py already keeps it off the prunable list under this name.
    """
    d = Path(os.environ.get("OF3_TEMPLATE_STRUCTURES")
             or str(cache / "of3_template_structures"))
    d.mkdir(parents=True, exist_ok=True)
    return str(d)


def _resolve_msa_dir(requested: str | None, cache: Path) -> str:
    """Honor controller's msa_dir if it already exists and is writable by this
    worker; otherwise fall back to ~/.boltz/msa/ on the worker."""
    if requested:
        path = Path(requested)
        if path.is_dir() and os.access(path, os.W_OK):
            return str(path)
    fallback = cache / "msa"
    fallback.mkdir(parents=True, exist_ok=True)
    return str(fallback)


def _write_atom_array_structure(atom_array, coords, outpath, output_format,
                                b_factors=None):
    """Write a prediction as PDB/mmCIF from a biotite AtomArray: the featurization's
    array carries all atom metadata, and only the coordinates and the per-atom pLDDT
    B-factors (0-100, the AF/Boltz convention) are replaced. Used by OpenFold3 and RF3,
    both of which featurize into an AtomArray."""
    import biotite.structure.io.pdbx as _pdbx

    from tt_bio.data.pdb import write_atom_array

    arr = atom_array.copy()
    arr.coord = coords.detach().cpu().numpy().astype("float32")
    if "b_factor" not in arr.get_annotation_categories():
        arr.add_annotation("b_factor", float)
    arr.b_factor[:] = (b_factors.detach().cpu().numpy().astype("float32")
                       if b_factors is not None else 0.0)
    # Bio.PDB.MMCIFParser hard-requires _atom_site.occupancy; biotite only writes
    # it when the annotation exists.
    if "occupancy" not in arr.get_annotation_categories():
        arr.add_annotation("occupancy", float)
        arr.occupancy[:] = 1.0
    outpath = Path(outpath)
    if output_format == "pdb":
        write_atom_array(arr, outpath)
    else:
        from tt_bio import cif_text
        cf = _pdbx.CIFFile()
        _pdbx.set_structure(cf, arr)
        cif_text.write(cf, str(outpath))


def _template_map(path: Path, model: str, chains, struct_dir) -> dict[str, str]:
    """Per-chain template alignment (npz) paths from a YAML input's `templates:` keys.

    The shared chain reader has no template field, so the models that take one re-read the
    YAML for `{protein: {id: X, sequence: ..., templates: <npz>}}`. One reader and one file
    format for OpenFold3, OpenBind, Protenix and OpenDDE, so a template written for one
    folds on the others. A template path on a non-protein chain, an unknown chain id, or a
    missing file is a hard error: silently dropping a user-supplied template would fold a
    different input than asked.

    The unknown-id check lives HERE and not at the three call sites, which each carried their
    own copy of it. It needs the parsed chain list, which is the only thing the caller has and
    this function did not, so passing it in is what collapses the copies.

    A top-level `templates:` block (Boltz-2's form: a cif and the chains it templates) is
    aligned into the same npz by `template_cif`, so it reaches every one of those models
    through the per-chain path. One chain may carry one form or the other, not both.
    """
    if path.suffix.lower() not in (".yml", ".yaml"):
        return {}
    import yaml
    doc = yaml.safe_load(path.read_text()) or {}
    out: dict[str, str] = {}
    for entry in doc.get("sequences", []):
        if not isinstance(entry, dict):
            continue
        for key, mt in (("protein", "protein"), ("rna", "rna"), ("dna", "dna")):
            sub = entry.get(key)
            if not (isinstance(sub, dict) and sub.get("sequence")):
                continue
            tmpl = sub.get("templates")
            if tmpl in (None, "", "~"):
                continue
            if mt != "protein":
                raise RuntimeError(
                    f"--model {model}: templates are only valid on protein chains, "
                    f"not {mt} (chain entry {sub.get('id')!r}).")
            tp = Path(str(tmpl)).expanduser()
            if not tp.exists():
                raise RuntimeError(
                    f"--model {model}: template file {tp} does not exist.")
            ids = sub.get("id", "A")
            id_list = ([str(x) for x in ids] if isinstance(ids, (list, tuple))
                       else str(ids).split(","))
            for c in id_list:
                out[c.strip()] = str(tp)
    unknown = sorted(set(out) - {c[0] for c in chains})
    if unknown:
        raise RuntimeError(
            f"--model {model}: `templates:` given for unknown chain id(s) {unknown}.")
    if doc.get("templates"):
        from tt_bio.template_cif import structure_template_npz
        built = structure_template_npz(doc["templates"], chains, struct_dir, model)
        both = sorted(set(out) & set(built))
        if both:
            raise RuntimeError(
                f"--model {model}: chain(s) {both} carry both a per-chain `templates:` npz "
                f"and a top-level template structure; give one.")
        out.update(built)
    return out


def _prefetch_template_structures(tmpl_map: dict[str, str],
                                            struct_dir: Path) -> None:
    # Download the raw template CIFs a `templates:` npz needs from RCSB. The npz
    # holds alignments only (index/release_date/idx_map per entry); coordinates
    # come from <pdb_id>.cif files. Only missing files are fetched; a failed
    # download is a hard error (a skipped template would fold the wrong input).
    import numpy as np
    pdb_ids: set[str] = set()
    for npz_path in tmpl_map.values():
        with np.load(npz_path, allow_pickle=True) as z:
            pdb_ids |= {k.split("_")[0] for k in z.keys()}
    missing = [p for p in sorted(pdb_ids) if not cached(struct_dir / f"{p}.cif")]
    if not missing:
        return
    import urllib.request
    for p in missing:
        url = f"https://files.rcsb.org/download/{p.upper()}.cif"
        try:
            # Publish by rename, like every other artifact cache: a dropped
            # connection or a full disk mid-transfer must not leave a partial CIF
            # under the final name, which every later fold needing that template
            # would then accept forever.
            with staged(struct_dir / f"{p}.cif") as tmp:
                urllib.request.urlretrieve(url, tmp)
        except Exception as exc:
            raise RuntimeError(
                f"failed to fetch template structure {url}: {exc}")


def _err_text(exc: BaseException, limit: int = 2000) -> str:
    """Bounded error text for a job row that never loses the tail.

    TT_FATAL messages put the diagnostic payload LAST. An allocator OOM reads
    `TT_FATAL @ ...bank_manager.cpp:439 ... Out of Memory: Not enough space to
    allocate N B DRAM buffer across 12 banks, where each bank needs to store N B,
    but bank size is N B (allocated: N B, free: N B, largest free block: N B)` --
    the leading 78 chars are a fixed file/line prefix and the closing parenthetical
    is the only part that says how full the chip actually was. A plain
    `str(exc)[:200]` lands mid-number just before it, so every recorded OOM in the
    AbAg-XM Wormhole campaign was indistinguishable between a genuinely full chip
    and one oversized request. Keep both ends instead of just the head.

    400 was still too tight, for the opposite reason. A TT_THROW puts its payload in the
    MIDDLE -- `... clash with L1 buffers. L1 buffer allocated at X and static circular
    buffer region ends at Y`, followed by the backtrace frames that name the op -- so
    keeping both ends elided the diagnosis and the op together, and every L1
    circular-buffer clash in the AbAg-XM campaign was recorded unattributably. 2000 keeps
    the OOM parenthetical, the TT_THROW payload and the first backtrace frames.
    """
    s = str(exc)
    if len(s) > limit:
        keep = limit - 5                   # room for the " ... " elision marker
        head = keep // 2
        s = s[:head] + " ... " + s[-(keep - head):]
    origin = _origin_frame(exc)
    return f"{s}\n[tt_bio origin: {origin}]" if origin else s


def _origin_frame(exc: BaseException) -> str | None:
    """The deepest tt_bio frame in the traceback, i.e. which of our ops made the request.

    An allocator refusal arrives as a RuntimeError whose text is a tt-metal message and a
    C++ backtrace. Neither names a tt-bio op, and the Python traceback that does is thrown
    away when the exception is turned into a job row -- so a recorded OOM says how many bytes
    were refused and nothing about what asked for them. esmfold2 at 1536 tokens was refused
    4831838208 B with no attributable site at all, which is a measurement that cannot be acted
    on. Appended after the length budget rather than inside it, so it is never the part that
    gets elided.
    """
    tb, deepest = exc.__traceback__, None
    while tb is not None:
        code = tb.tb_frame.f_code
        if f"{os.sep}tt_bio{os.sep}" in code.co_filename:
            deepest = f"{os.path.basename(code.co_filename)}:{tb.tb_lineno} in {code.co_name}"
        tb = tb.tb_next
    return deepest


def _is_esmc_model(model_id: str) -> bool:
    """True for any ESMC embedding model name (esmc-300m/600m/6b).

    Reads the name registry from tt_bio.main, NOT tt_bio.esmc: esmc.py imports
    ttnn at module scope, and this check runs for every model (including a
    boltz2 CPU fold), so importing esmc here would make the CPU/GPU path
    require the ttnn wheel (issue #6).
    """
    from tt_bio.main import EMBED_MODELS

    return model_id in EMBED_MODELS


def _is_saprot_model(model_id: str) -> bool:
    """True for any SaProt embedding model name (saprot-35m/650m/1.3b)."""
    from tt_bio.main import SAPROT_MODELS

    return model_id in SAPROT_MODELS


def _build_chain_specs(chains, msa_dir, cfg, protein_only: bool):
    """(sequence, a3m text or None, mol_type) per chain, honouring --single_sequence.

    ONE place, because this was two copies and both had the same hole. `--single_sequence` is
    documented as "skip MSA entirely", and the MSA SEARCH above each call site already checks
    the flag -- but `_resolve_a3m_text` has two other sources the search never touches: an a3m
    the YAML pinned with `msa:`, and one already cached under msa_dir for this sequence hash.
    Neither call site checked the flag here, so on any target with an MSA from either source
    the flag was a silent no-op: the fold used the MSA and the only hint was `msa: true` in the
    metrics row. Measured on a 117-aa target, protenix-v1 at 20 steps -- with the flag ignored,
    pLDDT 0.764634; honoured, 0.501251. A user asking for a no-MSA baseline was getting the
    MSA answer.

    protein_only keeps each caller's existing per-chain-type behaviour: Protenix resolves an
    a3m for protein chains only, OpenDDE for every chain. That difference is not what this
    function is fixing, so it is a parameter rather than a silent unification.

    ``--max_msa_seqs`` is applied here too, for the same reason: it was a silent no-op on
    protenix-v1/v2 and opendde, which read the resolved alignment whole however deep it was.
    """
    from tt_bio.main import _resolve_a3m_text

    single_seq = bool(cfg.get("single_sequence"))
    cap = cfg.get("msa_cap")
    return [(cseq,
             (_resolve_a3m_text(spec, cseq, msa_dir, max_seqs=cap)
              if not single_seq and (mt == "protein" or not protein_only) else None),
             mt)
            for _cid, cseq, spec, mt, _mods in chains]


def _chain_rows(conf) -> dict:
    """Boltz-2's two chain-level row keys from a confidence dict carrying
    ``pair_chains_iptm`` (``protenix.ConfidenceHead._chain_confidence``): the full chain-pair
    ipTM matrix and its diagonal, each chain's own pTM. Empty for a monomer."""
    pci = conf.get("pair_chains_iptm")
    return {"pair_chains_iptm": pci, "chains_ptm": {c: pci[c][c] for c in pci}} if pci else {}


def _paired_msa(path, chains, msa_dir, cfg):
    """The complex's species-paired MSA, ``{seq_hash: a3m_text}``, or None when it does not
    pair. The one pairing rule every model whose upstream pairs goes through.

    A complex pairs when it has more than one unique protein sequence: Protenix
    (``msa_featurizer.py``: ``need_pairing = len(unique_prot_seqs) > 1``), OpenDDE (same
    file, lines 64-66), OpenBind (OpenFold3 0.5.0 ``colabfold_msa_server.py``: "Only do
    pairing if number of unique protein sequences is > 1"; preview2 on 0.4.x drops the
    rows, so ``openfold3`` does not pair) and Boltz-2 (``compute_msa`` pairs when
    ``len(seqs) > 1``, seqs keyed by sequence). A homomer's copies are one sequence and do
    not pair. The search runs against the ColabFold server or a local DB; a
    ``--msa_endpoint`` run is not sent to the public server behind the user's back, and a
    cache-only run reads the complex's paired MSA if it is there. Best-effort: a failed
    search folds unpaired rather than failing the job.
    """
    from tt_bio.main import _generate_paired_a3m

    if cfg.get("single_sequence"):
        return None
    # A chain the input marked `msa: empty` takes no part in pairing either: pairing is a
    # search, and the paired block is that chain's alignment as much as the unpaired one.
    seqs = {seq_hash(s): s for _c, s, sp, mt, _m in chains
            if mt == "protein" and sp != EMPTY_MSA}
    if len(seqs) < 2:
        return None
    try:
        paired = _generate_paired_a3m(
            seqs, path.stem, msa_dir, cfg.get("msa_server_url"),
            cfg.get("msa_pairing_strategy"), cfg.get("msa_server_username"),
            cfg.get("msa_server_password"), cfg.get("api_key_value"),
            msa_db_path=cfg.get("msa_db_path"), use_envdb=cfg.get("use_envdb", False),
            search=bool(cfg.get("use_msa_server") or cfg.get("msa_db_path")))
    except Exception as e:  # noqa: BLE001 -- best-effort, fall back to unpaired
        print(f"paired MSA search failed ({e!r}); folding unpaired-only", file=sys.stderr)
        return None
    if paired is None:
        print("no paired MSA cached for this complex and no search source; folding "
              "unpaired-only", file=sys.stderr)
    return paired


def _protein(chains) -> bool:
    return any(mt == "protein" for _c, _s, _sp, mt, _m in chains)


def _paired_a3ms(path, chains, msa_dir, cfg):
    """:func:`_paired_msa` as the per-chain list ``build_complex_features`` walks in step
    with ``chains`` (None off protein), capped by ``--max_msa_seqs`` like the unpaired MSA."""
    from tt_bio.main import cap_a3m_text

    paired = _paired_msa(path, chains, msa_dir, cfg)
    if paired is None:
        return None
    return [cap_a3m_text(paired[seq_hash(s)], cfg.get("msa_cap"))
            if mt == "protein" and sp != EMPTY_MSA else None
            for _c, s, sp, mt, _m in chains]


def _tfg_guidance(path, cfg, feats, chains, bonds):
    """The OpenDDE sampler guidance for one input, or None for a plain fold.

    The input's ``constraint:`` is validated with upstream's rules whatever the flag says (an
    epitope without --use_tfg_guidance is an error, contact pairs without it a warning, as
    upstream). With the flag, the constraint and the physics-restraint geometry are resolved
    onto this fold's atoms."""
    from tt_bio.main import _read_bio_constraint
    from tt_bio.tfg import features as F

    constraint = F.validate_constraint(_read_bio_constraint(path), bool(cfg.get("use_tfg_guidance")))
    if not cfg.get("use_tfg_guidance"):
        return None
    from tt_bio.tfg.guidance import Guidance

    entities = F.entity_groups(path)
    gfeats = dict(feats)
    gfeats.update(F.constraint_features(constraint, feats, chains, entities))
    gfeats.update(F.geometry_features(feats, chains, entities, bonds=bonds))
    # In-process on the fold's own threads: a step is milliseconds, so per-sample child processes lost more to their
    # pipes than they saved (1bzq 0.9 vs 2.7 s, 9xqn 2.3-2.8 vs 5.7-6.1 s per fold on a Galaxy host).
    return Guidance(gfeats)


def _target_seed(path, cfg) -> int:
    """The sampler seed for one target: the seed an upstream JSON job was staged for, else ``--seed``."""
    from tt_bio.protenix_json import sidecar
    side = sidecar(path)
    if side and side.get("seed") is not None:
        return int(side["seed"])
    return int(cfg.get("seed") or 0)


def _own_conformers(cfg) -> None:
    """A checkpoint that ships its own reference conformers (Mol-1, OpenDDE) reads them instead of
    the CCD ideal coordinates, as upstream does: cfg["conformer_table"] names its ccd_table.npz."""
    from tt_bio import weights
    for art in weights.artifacts_for(cfg["model"]):
        if art.derived and art.derived.producer == "rdkit-conformers":
            cfg.setdefault("conformer_table", str(weights.fetch(art.key) / "ccd_table.npz"))


@functools.lru_cache(maxsize=2)
def _conformer_table(path):
    """A model's own reference conformers (protenix_data.load_conformer_table), read once per path; None
    keeps the CCD ideal ones."""
    from tt_bio.protenix_data import load_conformer_table
    return load_conformer_table(path) if path else None


def _write_upstream_layout(path, cfg, feats, chains, coords, confs) -> None:
    """``<results>/<job>/seed_<s>/predictions/`` exactly as Mol-1 / Protenix write it (tt_bio.protenix_output), from
    the per-sample confidence logits and the fold's contact probabilities the engine puts in each conf."""
    from tt_bio import protenix_output as po
    from tt_bio.main import _read_bio_bonds, protenix_atom_array
    from tt_bio.protenix_data import MOL_TYPE_IDS
    from tt_bio.protenix_json import sidecar
    from tt_bio.tfg.features import entity_groups

    side = sidecar(path)
    job = side["job"] if side else path.stem
    a2t = feats["atom_to_token_idx"].long().cpu()
    stack = lambda k: torch.stack([c[k].float().cpu() for c in confs])  # noqa: E731
    xyz = torch.stack([torch.as_tensor(c).float().cpu().reshape(-1, 3) for c in coords])
    summaries, fulls = po.summarize(
        stack("pae_logits"), stack("plddt_logits"), stack("pde_logits"), confs[0]["contact_probs"].float().cpu(),
        feats["asym_id"].long().cpu(), po.token_frames(feats), xyz, a2t,
        (feats["mol_type"].cpu() != MOL_TYPE_IDS["ligand"])[a2t].long(), int(cfg.get("recycling_steps") or 0))

    entities, bonds = entity_groups(path), _read_bio_bonds(path, chains)

    def structure(i, out, b_factor):
        arr = protenix_atom_array(coords[i], feats, out, b_factors=torch.as_tensor(b_factor),
                                  mod_names=_artifact_residue_names(chains), chain_ids=[cid for cid, *_r in chains],
                                  mirror_carboxylates=True)
        po.write_cif(arr, out, job, chains, entities, bonds)

    po.write(Path(cfg["struct_dir"]) / po.SHIPPED, job, _target_seed(path, cfg),
             summaries, fulls, write_structure=structure, need_atom_confidence=bool(cfg.get("write_pae")))


def stage_input(job: dict, path: Path) -> Path:
    """A leased job's input written to ``path``, with the sidecar an upstream Protenix / Mol-1 JSON input carries
    (its MSAs) restored beside it (host_controller.job_payloads)."""
    from tt_bio.protenix_json import sidecar_path

    path.write_bytes(base64.b64decode(job.get("input_b64", "")))
    if job.get("sidecar_b64"):
        sidecar_path(path).write_bytes(base64.b64decode(job["sidecar_b64"]))
    return path


def _left_to_search(path, chains):
    """The chains an input leaves to the MSA search: all of them, less those an upstream Protenix / Mol-1 JSON
    gave an alignment for (its sidecar), which upstream never searches."""
    from tt_bio.protenix_json import sidecar
    side = sidecar(path)
    given = set(side["paired_msa"]) | set(side["unpaired_msa"]) if side else set()
    return [c for c in chains if c[0] not in given]


def _with_searched(side: dict, chains, chain_specs, paired_a3ms) -> dict:
    """The sidecar's alignments, with the searched unpaired (and paired) a3m filled in for each protein chain the
    JSON gave none for."""
    given = set(side["paired_msa"]) | set(side["unpaired_msa"])
    out = {**side, "paired_msa": dict(side["paired_msa"]), "unpaired_msa": dict(side["unpaired_msa"])}
    for k, (cid, _s, _sp, mt, _m) in enumerate(chains):
        if mt != "protein" or cid in given:
            continue
        if chain_specs[k][1]:
            out["unpaired_msa"][cid] = chain_specs[k][1]
        if paired_a3ms and paired_a3ms[k]:
            out["paired_msa"][cid] = paired_a3ms[k]
    return out


def search_msas(path, chains, cfg, progress=None) -> None:
    """Search the unpaired a3m of every protein chain the input left to the search and the
    cache lacks, batched into one call, into ``cfg["msa_dir"]``. Touches no device.

    The one unpaired MSA stage of every model but Boltz-2 (whose CSV cache is
    :func:`tt_bio.main.search_boltz2_msas`) and OpenFold3 (whose resolver also relinks).

    Only the a3m counts as cached. Boltz-2's CSV for the same sequence hash is not what
    Protenix, OpenDDE or RF3 read (``_resolve_a3m_path`` skips it), so counting it let a
    Boltz-2 fold in the same msa_dir turn a later ``--use_msa_server`` fold of those models
    into a silent single-sequence one: 6.07 A instead of 1.78 A for protenix-v1 on 7ROA."""
    from tt_bio.main import _generate_esmfold2_a3m

    if cfg.get("single_sequence") or not _msa_source(cfg):
        return
    msa_dir = Path(cfg["msa_dir"])
    need = {seq_hash(s): s for _c, s, spec, mt, _m in chains
            if mt == "protein" and not msa_pinned(spec)}
    need = {h: s for h, s in need.items() if not cached(msa_dir / f"{h}.a3m")}
    if not need:
        return
    if progress:
        progress("msa")
    single_flight(msa_dir, need, lambda h: not cached(msa_dir / f"{h}.a3m"), lambda todo: _generate_esmfold2_a3m(
        {h: need[h] for h in todo}, path.stem, msa_dir, cfg.get("msa_db_path"), cfg.get("use_envdb", False),
        cfg.get("msa_server_url"), cfg.get("msa_pairing_strategy"),
        cfg.get("msa_server_username"), cfg.get("msa_server_password"),
        cfg.get("api_key_value"), msa_endpoint=cfg.get("msa_endpoint")))


def _msa_source(cfg) -> bool:
    return bool(cfg.get("use_msa_server") or cfg.get("msa_db_path") or cfg.get("msa_endpoint"))


#: Models that read no alignment at all, so there is nothing to search ahead of the lease.
_NO_MSA = ("esmfold2-fast", "af2ig")
#: Models whose upstream pairs a heteromer's MSA (see _paired_msa).
_PAIRS = ("esmfold2", "opendde", "opendde-abag", "openbind")


def prefetch_msas(model: str, paths, cfg) -> None:
    """Search every alignment a run's targets will fold with, before any chip is leased.

    A worker holds its chip from the moment it leases a target, and JapanFold bills that
    lease. The search is database and CPU work: on a cold 730-token Protenix-v2 complex it
    was 191.6 s of a 526.7 s job, all of it a Tensix chip reserved, idle, and charged for.
    So ``tt-bio predict`` calls this in the submitting process, which holds no chip, and
    only then submits the run; each worker then runs the same search code, finds everything
    cached, and goes straight to device work.

    Unpaired searches for the whole run go in one batched call, which is one pass over the
    database instead of one per target. It changes when the search runs, never what it
    returns: every file written here is the file the worker would have written, through the
    same function. And it is best-effort, so a failed search here is only logged and the
    worker searches, and fails, exactly as it did before this existed."""
    from tt_bio.main import _read_bio_chains, search_boltz2_msas

    if (model in _NO_MSA or _is_embed_model(model) or cfg.get("single_sequence")
            or not _msa_source(cfg)):
        return
    t0 = time.time()
    msa_dir = Path(cfg["msa_dir"])
    msa_dir.mkdir(parents=True, exist_ok=True)
    targets = []
    for p in map(Path, paths):
        try:
            targets.append((p, _read_bio_chains(p, what=model)))
        except Exception:  # noqa: BLE001 -- the worker reports an unreadable input
            continue
    try:
        if model == "boltz2":
            # Boltz-2 searches each complex whole (pairing keys), so one call per target.
            for p, chains in targets:
                prot = {seq_hash(s): s for _c, s, spec, mt, _m in chains
                        if mt == "protein" and not spec}
                if prot:
                    search_boltz2_msas(
                        prot, p.stem, msa_dir, use_msa=cfg.get("use_msa_server"),
                        msa_db_path=cfg.get("msa_db_path"), use_envdb=cfg.get("use_envdb", False),
                        msa_url=cfg.get("msa_server_url"), msa_strategy=cfg.get("msa_pairing_strategy"),
                        msa_user=cfg.get("msa_server_username"),
                        msa_pass=cfg.get("msa_server_password"), api_key=cfg.get("api_key_value"))
        else:
            # The unpaired batch and the paired searches read and write disjoint files, so
            # they run side by side. Neither scales with cores (hb on a 64-core Galaxy:
            # 10.3 s at 32 or 64 threads each), so this halves the wait: 19.5 -> 10.3 s,
            # byte-identical a3m files.
            from concurrent.futures import ThreadPoolExecutor

            run = [c for p, chains in targets for c in _left_to_search(p, chains)]
            with ThreadPoolExecutor(2) as pool:
                jobs = []
                if run:
                    jobs.append(pool.submit(search_msas, Path(f"{len(targets)}_targets"), run, cfg))
                if model in _PAIRS or model in _protenix_family():
                    jobs.append(pool.submit(lambda: [_paired_msa(p, chains, msa_dir, cfg)
                                                     for p, chains in targets
                                                     if _protein(_left_to_search(p, chains))]))
                for j in jobs:
                    j.result()
    except Exception as e:  # noqa: BLE001 -- see the docstring: the worker searches instead
        print(f"MSA prefetch failed ({e!r}); each target searches on its chip instead",
              file=sys.stderr)
        return
    print(f"MSA ready for {len(targets)} target(s) in {time.time() - t0:.1f} s, "
          "before any chip was leased", flush=True)


def _artifact_residue_names(chains) -> dict:
    """(asym_id, residue_index) -> the CCD code for every token `restype` cannot name.

    build_complex_features assigns asym_id by chain order, so both kinds key the same way
    and the structure writer does not have to know how either was tokenized.

    A `modifications:` residue keeps its own 1-indexed position. A CCD ligand chain is
    tokenized per atom with restype UNK and every atom on residue_index 1, so one entry
    names the whole chain; without it the writer falls back to "LIG" and the artifact no
    longer says which ligand was folded, while the same input through ESMFold2 reads back
    as ATP. A SMILES ligand has no code to keep and stays "LIG"."""
    names = {}
    for ci, (_cid, seq, _spec, mol_type, mods) in enumerate(chains):
        if mol_type == "ligand" and str(seq).upper().startswith("CCD_"):
            # a multi-CCD ligand (glycan "CCD_NAG,NAG") is one residue per component
            for r, code in enumerate(str(seq)[4:].upper().split(","), start=1):
                names[(ci, r)] = code.strip()
        for m in mods or ():
            names[(ci, int(m["position"]))] = str(m["ccd"]).upper()
    return names


def _rf3_sequence(seq: str, mods) -> str:
    """A polymer sequence in RF3's spec form, where a modified residue is its CCD code in
    parentheses (``AC(SEP)GH``, atomworks' generalized FASTA)."""
    if not mods:
        return seq
    at = {m["position"]: str(m["ccd"]).upper() for m in mods}
    return "".join(f"({at[i]})" if i in at else c for i, c in enumerate(seq, 1))


def _rf3_bonds(components: list[dict], bonds) -> list[list[str]] | None:
    """`bond` constraints as the top-level ``bonds`` of RF3's JSON spec, whose atoms are
    ``CHAIN/RES_NAME/RES_ID/ATOM`` strings (atomworks ``spoof_struct_conn_dict_from_string``).

    The residue name and id are read off the atom array upstream builds from the same
    components, so a modified residue, a CCD ligand and a SMILES ligand (residue ``L:0``,
    id 0) resolve the way upstream will. A SMILES atom is named the portable way, element
    plus its 1-based count in SMILES order (C1 is the first carbon), which is Protenix's
    naming; atomworks counts from 0, so C1 becomes its C0.
    """
    if not bonds:
        return None
    from tt_bio._vendor.atomworks.io.tools.inference import components_to_atom_array

    aa = components_to_atom_array([{k: v for k, v in c.items() if k != "msa_path"}
                                   for c in components])
    smiles = {c["chain_id"] for c in components if "smiles" in c}

    def endpoint(cid, res, name):
        atom, on = name, aa[aa.chain_id == cid]
        if not len(on):
            raise ValueError(f"bond constraint references chain '{cid}', which is not in "
                             "the input.")
        ids = list(dict.fromkeys(on.res_id.tolist()))
        if cid in smiles:
            el, n = atom.rstrip("0123456789"), atom[len(atom.rstrip("0123456789")):]
            atom = f"{el}{int(n) - 1}" if n else atom
            res = 1
        if not 1 <= res <= len(ids):
            raise ValueError(f"bond constraint references residue {res} on chain '{cid}', "
                             f"which has {len(ids)}.")
        r = on[on.res_id == ids[res - 1]]
        if atom not in r.atom_name:
            names = r.atom_name.tolist()
            if cid in smiles:
                names = [f"{x.rstrip('0123456789')}{int(x[len(x.rstrip('0123456789')):]) + 1}"
                         for x in names]
            raise ValueError(f"bond constraint references atom '{name}' on residue {res} "
                             f"({r.res_name[0]}) of chain '{cid}', which it does not have. "
                             f"Its atoms: {', '.join(names)}.")
        return f"{cid}/{r.res_name[0]}/{ids[res - 1]}/{atom}"

    return [[endpoint(*a1), endpoint(*a2)] for a1, a2 in bonds]


# The models whose upstream writes `<job>/seed_<s>/predictions/` (summary_confidence + full_data per sample), so a
# fold of theirs keeps the confidence logits and lands that layout beside tt-bio's own files.
UPSTREAM_LAYOUT_MODELS = ("mol1", "opendde", "opendde-abag")


def _protenix_family() -> tuple[str, ...]:
    """The --model ids the tt_bio.protenix implementation serves (v0.5.0 base and v2).

    Imported lazily for the same reason as _of3_family: tt_bio.main imports this module.
    """
    from tt_bio.main import PROTENIX_FAMILY

    return PROTENIX_FAMILY


def _trace_default(flag) -> bool:
    """Whether a fold replays its per-step diffusion from a captured trace.

    An explicit flag decides. Unset (None), it is on for Blackhole: the replay is lossless (same
    CIF digest) and, paired in one process on a p150a at 512 tokens x 1 sample, cuts 1.0-1.4 s off
    a Protenix fold and ~0.3 s off a Boltz-2 fold in both modes (state/spd-gap-small.md), for a
    27-36 MiB/bank region. Wormhole stays opt-in until its ceilings are re-walked with the region
    reserved.
    """
    if flag is not None:
        return bool(flag)
    from tt_bio.tenstorrent import arch_name

    return arch_name() == "blackhole"


def _protenix_trace(cfg: dict[str, Any]) -> bool:
    """protenix-v1/v2: --trace / --no_trace, else the arch default (`_trace_default`)."""
    return _trace_default(cfg.get("trace"))


def _region_reserved(capture: str) -> bool:
    """Whether the open chip carries a region ``capture``'s step fits in. A worker kept resident
    across jobs reloads on the model config only (run_config_hash), so a load asks the chip it
    got rather than assume an earlier load reserved one."""
    from tt_bio.tenstorrent import trace_region_bytes, trace_region_size

    return trace_region_size() >= trace_region_bytes(capture)


def _protenix_region_reserved() -> bool:
    return _region_reserved("protenix")


def protenix_open(cfg: dict[str, Any]) -> None:
    """Open the chip a Protenix-family fold runs on: with the protenix trace region when the fold
    replays its trace (`_protenix_trace`). The region is reserved only at open, so a chip opened
    without it is closed and reopened. perf/spd/bench.py builds Protenix-v2 itself (lever arms) and
    calls this too: without it the bench folded untraced, unlike every served Blackhole fold."""
    from tt_bio.tenstorrent import cleanup, get_device

    if _protenix_trace(cfg) and not _protenix_region_reserved():
        cleanup()
        get_device(trace="protenix")


def _of3_family() -> tuple[str, ...]:
    """The --model ids the OpenFold3 implementation serves (preview2 and OpenBind).

    Imported lazily like the two predicates below: tt_bio.main imports this module,
    so a module-level import would be a cycle.
    """
    from tt_bio.main import OF3_FAMILY

    return OF3_FAMILY


def _is_embed_model(model_id: str) -> bool:
    """True for any model this worker serves through the embed path.

    Both families produce ``ESMCEmbedding`` and ship through the same npz/parquet
    writer; they differ only in loader and tokenizer. Dispatching on the family
    rather than on ESMC alone is what lets a saprot-* job reach a worker at all --
    before this, it fell through to the Boltz-2 branch and tried to load Boltz-2
    checkpoints.
    """
    return _is_esmc_model(model_id) or _is_saprot_model(model_id)


@contextlib.contextmanager
def _rng_state_preserved():
    """Run a block without letting it advance the global RNG streams."""
    import random as _random

    import numpy as _np

    states = (_random.getstate(), _np.random.get_state(), torch.random.get_rng_state())
    try:
        yield
    finally:
        _random.setstate(states[0])
        _np.random.set_state(states[1])
        torch.random.set_rng_state(states[2])


@dataclass
class OpenFold3HostInputs:
    """Everything `OpenFold3.fold` needs that is computed on the host, plus what reading the
    result back needs. No device is touched to build it: measured 3.9 s for a 22-token
    single-sequence query on pc with no card."""

    features: dict
    of3_query: Any
    chains: list
    msa_feat: Any
    aux: dict
    template_feat: Any
    template_slots: Any
    relpos: Any
    seed: int


def openfold3_host_inputs(path: Path, cfg: dict[str, Any], *, model_name: str = "openfold3",
                          levers: tuple = ()) -> "OpenFold3HostInputs":
    """Query -> MSA -> features -> block aux, template slots and relpos.

    Lifted verbatim out of `_WorkerState._predict_openfold3_one`, which now calls it, so the
    serving path and RFD4's beam-search oracle featurize a candidate through the same code
    rather than through two copies that drift. Everything here runs on the host, which is why
    it can be tested on a box with no card; the device half (input atom encoder, ref-atom
    embedding, the fold itself) stays in the caller, which owns the model.
    """
    from tt_bio.esmfold2 import report_progress
    from tt_bio.main import _read_bio_chains, _read_bio_constraints, _read_cyclic

    model = model_name
    chains = _read_bio_chains(path)
    if not chains:
        raise RuntimeError("no protein/nucleic-acid sequences")
    check_capabilities(path, chains, model,
                       output_format=cfg.get("output_format"))
    tmpl_map = _template_map(path, model, chains, cfg["template_structures"])
    msa_dir = Path(cfg["msa_dir"])

    _MT = {"protein": "PROTEIN", "rna": "RNA", "dna": "DNA", "ligand": "LIGAND"}

    def _query_chain(cid, cseq, spec, mt, mods):
        """One upstream Chain dict. Ligands take smiles/ccd_codes and NO sequence.

        `_read_bio_chains` hands a ligand its spec in the sequence slot, using the
        same "CCD_<code>" convention the boltz2 and protenix paths already parse:
        a CCD code becomes ccd_codes=[code], anything else is treated as SMILES.
        Upstream keys off exactly these two fields (inference_query_format.Chain),
        and a LIGAND chain with `sequence` set is not a thing upstream builds.

        `modifications:` becomes non_canonical_residues, upstream's own {res_id: CCD}
        field: structure_with_ref_mols_from_sequence builds that position from
        atom_array_from_ccd_code instead of the standard residue, so the modified
        residue's real atoms reach the featurizer. The field existed all along and this
        port hardcoded it None, which is why the row was refused.
        """
        chain = {"molecule_type": _MT[mt], "chain_ids": [cid],
                 "non_canonical_residues": ({m["position"]: str(m["ccd"]).upper()
                                             for m in mods} if mods else None),
                 "paired_msa_file_paths": None,
                 "template_alignment_file_path": None,
                 "template_entry_chain_ids": None,
                 "sdf_file_path": None}
        if mt == "ligand":
            ccd = cseq[4:].strip() if cseq.upper().startswith("CCD_") else None
            chain.update(sequence=None, smiles=None if ccd else cseq.strip(),
                         ccd_codes=[ccd] if ccd else None,
                         main_msa_file_paths=None)
            return chain
        if spec == EMPTY_MSA:
            from tt_bio.openfold3_data import query_only_msa
            msa_paths = [str(query_only_msa(msa_dir, cseq))]
        elif spec and Path(spec).expanduser().exists():
            msa_paths = [str(Path(spec).expanduser())]
        else:
            msa_paths = None
        chain.update(sequence=cseq, smiles=None, ccd_codes=None,
                     main_msa_file_paths=msa_paths)
        chain["template_alignment_file_path"] = tmpl_map.get(cid)
        return chain

    query = {
        "query_name": path.stem, "use_msas": True, "use_paired_msas": False,
        "use_main_msas": True, "covalent_bonds": None,
        "chains": [_query_chain(cid, cseq, spec, mt, mods)
                   for cid, cseq, spec, mt, mods in chains],
    }

    import json as _json
    import tempfile

    import numpy as np
    import torch as _torch

    from tt_bio._vendor.openfold3.projects.of3_all_atom.config.inference_query_format import (
        InferenceQuerySet,
    )
    from tt_bio.openfold3_data import (
        build_openfold3_features, make_openfold3_msa_features)
    from tt_bio.envflags import env_flag
    from tt_bio.openfold3_host_prep import (
        RELPOS_CODES, derive_block_aux, derive_relpos, derived_template_slots,
        derive_relpos_codes)

    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as fh:
        _json.dump({"queries": {path.stem: query}}, fh)
        qpath = fh.name
    seed = int(cfg.get("seed") or 0)
    _torch.manual_seed(0)
    np.random.seed(0)
    # The vendored featurizer draws its RDKit conformer seed from python"s
    # unseeded `random` (conformer.py: "we set a random seed here"), which made
    # ref_pos — and therefore the whole fold — nondeterministic across
    # processes even at fixed --seed. Pin it to the fold seed.
    import random as _pyrandom
    _pyrandom.seed(seed)
    from tt_bio._vendor.openfold3.core.data.primitives.structure import query as _of3_query
    _of3_query.REF_MOL_MEMO = "ref_memo" in tuple(levers)
    iqs = InferenceQuerySet.from_json(qpath)
    of3_query = next(iter(iqs.queries.values()))
    # The MSA stage delegates to the shared resolver: it exposes the cached
    # hash-named ColabFold a3m under the canonical source basename OF3's parser
    # filters on (a raw hash-named path parses to ZERO chains and dies on an
    # IndexError deep in the vendored pipeline), and preserves user-specified
    # per-chain MSA paths.
    want_msa = _msa_source(cfg)
    from tt_bio.openfold3_data import (
        attach_openfold3_paired_msas, normalize_openfold3_msa_paths,
        resolve_openfold3_msas)
    # A YAML `msa:` path is used verbatim by the vendored parser, which filters by
    # file STEM and drops anything non-canonical -- so `msa: ./my.a3m` died on an
    # IndexError. Relink it under the canonical name first; bytes unchanged.
    of3_query = normalize_openfold3_msa_paths(
        of3_query, msa_dir, openbind=(model == "openbind"))
    if want_msa:
        report_progress("msa")
    of3_query = resolve_openfold3_msas(
        of3_query, msa_dir, target_id=path.stem,
        msa_db_path=cfg.get("msa_db_path"),
        use_envdb=cfg.get("use_envdb", False),
        msa_server_url=cfg.get("msa_server_url"),
        msa_pairing_strategy=cfg.get("msa_pairing_strategy"),
        msa_server_username=cfg.get("msa_server_username"),
        msa_server_password=cfg.get("msa_server_password"),
        api_key=cfg.get("api_key_value"),
        msa_endpoint=cfg.get("msa_endpoint"),
        fetch=bool(want_msa))
    if want_msa:
        missing = [c.chain_ids for c in of3_query.chains
                   if c.molecule_type.name == "PROTEIN" and not c.main_msa_file_paths]
        if missing:
            raise RuntimeError(
                f"MSA was requested but none resolved for protein chain(s) {missing} "
                "-- refusing to silently fold single-sequence.")
    # OpenBind only. preview2 runs upstream on 0.4.x, whose create_paired_from_precomputed
    # never sets n_rows_paired_subsampled, so the featurizer drops the paired block
    # (primitives/featurization/msa.py:112) and upstream folds a heteromer unpaired;
    # 0.5.0 (PR #373) keeps it. Keyed on the checkpoint like the other 0.5.0 MSA fixes.
    # Feeding preview2 the rows anyway cost 0.06 DockQ on 8WT4, worse on 6 of 6 seeds.
    if model == "openbind" and (paired := _paired_msa(path, chains, msa_dir, cfg)) is not None:
        of3_query = attach_openfold3_paired_msas(of3_query, msa_dir, paired)
    if cfg.get("single_sequence"):
        # --single_sequence is upstream's no-MSA mode, not an MSA-stack
        # disable: upstream substitutes a one-row alignment holding the
        # query sequence and keeps use_msas on
        # (augment_main_msa_with_query_sequence). Folding the same chain
        # with the stack off instead costs 1.50 A CA-RMSD on ubiquitin
        # (2.34 A against the 1.8 A ceiling, vs 0.84 A one-row).
        from tt_bio.openfold3_data import (
            augment_openfold3_msas_with_query_sequence,
        )
        of3_query = augment_openfold3_msas_with_query_sequence(of3_query, msa_dir)
    if not any(c.main_msa_file_paths for c in of3_query.chains):
        of3_query.use_msas = False
        of3_query.use_main_msas = False
    report_progress("prep")
    if tmpl_map:
        _prefetch_template_structures(
            tmpl_map, Path(cfg["template_structures"]))
    features = build_openfold3_features(
        of3_query,
        template_structures_directory=cfg["template_structures"],
        openbind=(model == "openbind"),
        bonds=_read_bio_constraints(path), cyclic=_read_cyclic(path))
    # Default = the featurizer max_rows (16384), i.e. NO extra subsampling: the
    # CPU reference folds the full featurized MSA, so any lower cap is an input
    # divergence (measured on 9BK6: the 1024-row subsample cost chain A
    # 11.1 vs 7.6 A Ca-RMSD). --max_msa_seqs is the flag for it and wins over the
    # OF3_MAX_MSA_SEQS env escape hatch; neither set means no extra subsampling.
    msa_feat = make_openfold3_msa_features(
        features,
        max_sequences=int(cfg.get("msa_cap") or cfg.get("of3_max_msa_seqs") or 16384),
        seed=0)
    aux = derive_block_aux(features)
    template_feat, template_slots = derived_template_slots(features)
    relpos = (derive_relpos_codes(features) if env_flag(RELPOS_CODES, True)
              else derive_relpos(features))

    return OpenFold3HostInputs(
        features=features, of3_query=of3_query, chains=chains, msa_feat=msa_feat, aux=aux,
        template_feat=template_feat, template_slots=template_slots, relpos=relpos, seed=seed)


def openfold3_device_fold(model, host: "OpenFold3HostInputs", *, sampling_steps: int,
                          diffusion_samples: int = 1, distogram: bool = False,
                          progress_fn=None, max_parallel_samples=None):
    """The device half: input atom encoder, ref-atom embedding, then the fold.

    Lifted out of `_WorkerState._predict_openfold3_one` alongside `openfold3_host_inputs`, so
    RFD4's beam-search oracle folds a candidate through the serving path's own code rather than a
    second copy. `model` is an open `OpenFold3`; this is the half that needs a card.

    The result carries the full confidence dict per sample -- pae, plddt_atom, ptm, iptm,
    pair_chains_iptm -- in memory. `write_pae` only mirrors it to disk, so an oracle never needs a
    per-candidate file round trip to read a PAE.
    """
    import numpy as np
    import torch as _torch

    from tt_bio.envflags import env_flag
    from tt_bio.openfold3_host_prep import (
        DEVICE_REF_ATOM, ref_atom_embed, ref_atom_embed_device,
        input_atom_transformer, run_input_atom_encoder)
    from tt_bio.openfold3_weights import _sub

    dev = model.device
    if getattr(model, "input_atom_transformer", None) is None:
        model.input_atom_transformer = input_atom_transformer(model.ckc, model.sd)
    ai = run_input_atom_encoder(dev, model.ckc, model.sd, host.features, host.aux,
                                model.input_atom_transformer)
    s_input = _torch.cat(
        [ai, host.features["restype"], host.features["profile"],
         host.features["deletion_mean"].unsqueeze(-1)], dim=-1)
    rafe_sd = _sub(
        model.sd, "diffusion_module.atom_attn_enc.ref_atom_feature_embedder")
    if env_flag(DEVICE_REF_ATOM, False):
        cl0, plm0 = None, None
        cl0_d, plm0_d = ref_atom_embed_device(
            model.ckc, rafe_sd, host.features, host.aux["atom_mask"], n_pad=host.aux["NP"])
    else:
        cl0_d, plm0_d = None, None
        cl0, plm0 = ref_atom_embed(rafe_sd, host.features)
    dm_aux_host = dict(
        cl0=cl0, plm0=plm0, cl0_d=cl0_d, plm0_d=plm0_d, atom_mask=host.aux["atom_mask"],
        atom_to_token_index=host.aux["atom_to_token_index"],
        npe_q_indices=host.aux["npe_q_indices"], npe_k_indices=host.aux["npe_k_indices"],
        zij_mask=host.aux["zij_mask"], key_block_idxs=host.aux["key_block_idxs"],
        invalid_mask=host.aux["invalid_mask"], mask_trunked=host.aux["mask_trunked"],
        atom_to_token_mean=host.aux["atom_to_token_mean"], nb=host.aux["nb"], NP=host.aux["NP"])
    ca_mask = host.aux["ca_mask"]
    atom_to_token = host.aux["atom_to_token_index"].long()
    polymer_token = (host.features["is_protein"] | host.features["is_rna"]
                     | host.features["is_dna"]).bool()
    confidence_aux = dict(
        representative_atom_indices=_torch.from_numpy(
            np.flatnonzero(ca_mask.numpy())).long(),
        max_atom_per_token_mask=host.aux["max_atom_per_token_mask"],
        atom_array=host.features["atom_array"], asym_id=host.features["asym_id"],
        atom_to_token_index=atom_to_token, atom_mask=host.features["atom_mask"].bool(),
        polymer_mask=polymer_token[atom_to_token],
        repr_batch={k: host.features[k] for k in (
            "is_protein", "is_dna", "is_rna", "is_atomized", "restype",
            "start_atom_index", "atom_mask", "token_mask")},
        # `get_token_frame_atoms` reads the representative-atom features plus the two
        # that place an atom in a chain, which is how it rejects a frame whose three
        # atoms straddle one.
        frame_batch={k: host.features[k] for k in (
            "is_protein", "is_dna", "is_rna", "is_atomized", "restype",
            "start_atom_index", "atom_mask", "token_mask",
            "num_atoms_per_token", "asym_id")})

    return model.fold(
        template_feat=host.template_feat, template_slots=host.template_slots,
        msa_feat=host.msa_feat, s_input=s_input,
        relpos=host.relpos, token_bonds=host.features["token_bonds"],
        token_mask=host.features["token_mask"], dm_aux_host=dm_aux_host,
        n_atom=host.aux["n_atom"], n_token=host.aux["n_token"],
        no_rollout_steps=int(sampling_steps), seed=int(host.seed),
        no_samples=int(diffusion_samples), confidence_aux_host=confidence_aux,
        progress_fn=progress_fn, max_parallel_samples=max_parallel_samples,
        distogram=bool(distogram))


class _WorkerState:
    """Holds the loaded model and per-run helpers."""

    def __init__(self, accelerator: str) -> None:
        self.accelerator = accelerator
        self.run_id: str | None = None
        self.config_hash: str | None = None
        self.model_id: str | None = None   # the loaded model — reported to the
                                           # scheduler so it can keep this worker
                                           # on the same model (affinity).
        self.model = None
        self.aff_model = None
        self.prepare = None
        self.pfn = None  # progress callback (rebound per run)
        self._ccd = self._tokenizer = self._featurizer = self._mol_dir = None  # Boltz-2, cached
        self._heads: tuple[tuple, dict] = ((), {})  # --head specs and their loaded callables
        if accelerator == "gpu" and torch.cuda.is_available():
            self.torch_device = torch.device("cuda:0")
        else:
            self.torch_device = torch.device("cpu")

    def configured_for(self, cfg: dict[str, Any]) -> bool:
        # Residency is keyed on the model setup only, NOT the run id: the loaded
        # weights are run-independent, so a resident model serves jobs from any
        # run/user of the same model with no reload. Per-run bits (output/MSA
        # paths, progress) are refreshed cheaply in bind_run().
        return self.model is not None and self.config_hash == run_config_hash(cfg)

    def reset(self) -> None:
        self.model = None
        self.aff_model = None
        self.prepare = None
        self.pfn = None
        self.run_id = None
        self.config_hash = None
        self.model_id = None
        self._ccd = self._tokenizer = self._featurizer = self._mol_dir = None
        gc.collect()
        if self.accelerator == "tenstorrent":
            try:
                from tt_bio.tenstorrent import cleanup as _tt_cleanup

                _tt_cleanup()
            except Exception:
                pass

    def free_model(self) -> None:
        """Free the resident predict model but KEEP the device open.

        Used before running an in-process design shard: the shard reuses this
        worker's already-open chip and loads its own models, so we must drop the
        predict weights (free memory) WITHOUT closing the device. Closing and
        re-opening a chip per shard is exactly what deadlocked the UMD
        device-init path (see device_lease.device_init_lock); reusing one
        persistent open avoids it entirely."""
        self.model = None
        self.aff_model = None
        self.prepare = None
        self.pfn = None
        self.run_id = None
        self.config_hash = None
        self.model_id = None
        self._ccd = self._tokenizer = self._featurizer = self._mol_dir = None
        gc.collect()

    def load_model(self, cfg: dict[str, Any]) -> None:
        """Load the heavy model weights onto the device. Keyed on the model
        config (see configured_for), so it runs once per model, not once per run."""
        if self.accelerator == "tenstorrent":
            from tt_bio.tenstorrent import set_fast_mode

            set_fast_mode(cfg.get("fast", False))

        model_id = cfg.get("model", "boltz2")
        # Boltz-2 is the only model with a torch CPU/GPU path. Every other port is
        # ttnn-only: its load imports ttnn and opens a chip no matter what accelerator
        # this worker was started with, which is how a `--accelerator cpu` submission
        # used to silently fold on the card (issue #10). The CLI refuses these models
        # off-card up front; this is the same guard worker-side, so a CPU/GPU worker
        # joined to a controller cannot be handed a ttnn-only job by any client.
        if model_id != "boltz2" and self.accelerator != "tenstorrent":
            raise RuntimeError(
                f"model {model_id!r} runs on Tenstorrent only (tt-bio has no torch/CPU "
                f"path for it), but this worker was started with --accelerator "
                f"{self.accelerator}. Start the worker with --accelerator tenstorrent; "
                f"boltz2 is the one model a CPU/GPU worker can serve."
            )
        if model_id in ("esmfold2", "esmfold2-fast"):
            from tt_bio.esmfold2_runtime import load_ttnn_esmfold2

            repo = "biohub/ESMFold2-Fast" if model_id == "esmfold2-fast" else "biohub/ESMFold2"
            self.model = load_ttnn_esmfold2(esmfold2_repo=repo, fast=cfg.get("fast", False))
            self.model._esmc.preload()
        elif model_id in _protenix_family():
            from tt_bio.protenix import Protenix

            protenix_open(cfg)

            # Same class for both ids: c_z, the stack depths and the recycling count all come
            # off the weights (Trunk._derive_c_z / n_blocks / trunk_recycles).
            # --diffusion_precision; unset keeps the class default (fp32, or the env override).
            prec = cfg.get("diffusion_precision")
            self.model = Protenix.load_from_checkpoint(
                cfg["protenix_ckpt"], diffusion_fp32=None if prec is None else prec == "fp32")
        elif model_id in _of3_family():
            import ttnn

            from tt_bio import openfold3_sample_diffusion
            from tt_bio.openfold3_fold import OpenFold3
            from tt_bio.tenstorrent import cleanup, get_device, trace_region_size

            if openfold3_sample_diffusion.TRACE and trace_region_size() <= 0:
                # The rollout replays a captured step, and the region it needs is reserved only
                # at open: close a chip opened without one (as for esmc-300m/600m below).
                cleanup()
                get_device(trace="openfold3")
            dev = get_device()
            ckc = ttnn.init_device_compute_kernel_config(
                dev.arch(), math_fidelity=ttnn.MathFidelity.HiFi4,
                fp32_dest_acc_en=True, packer_l1_acc=True)
            sd = _of3_state_dict(cfg)
            # CLI --recycling_steps counts recycles; the trunk runs recycles+1 cycles.
            self.model = OpenFold3(sd, ckc, num_cycles=_recycles(cfg, 3) + 1, model=model_id)
        elif model_id == "rf3":
            import ttnn

            from tt_bio.rf3 import model as rf3_model
            from tt_bio.tenstorrent import cleanup, get_device, trace_region_size

            if rf3_model.TRACE and trace_region_size() <= 0:
                # The rollout replays a captured denoiser step, and its region is reserved only
                # at open: close a chip opened without one (as for openfold3 above).
                cleanup()
                get_device(trace="rf3")
            dev = get_device()
            ckc = ttnn.init_device_compute_kernel_config(
                dev.arch(), math_fidelity=ttnn.MathFidelity.HiFi4,
                fp32_dest_acc_en=True, packer_l1_acc=True)
            self.model = rf3_model.load(
                cfg["rf3_ckpt"], ckc,
                num_timesteps=int(cfg.get("sampling_steps") or 200))
        elif model_id in ("opendde", "opendde-abag"):
            from tt_bio.opendde import OpenDDE

            # OpenDDE denoises through Protenix-v2's sampler, so it takes the family's trace rule.
            protenix_open(cfg)

            prec = diffusion_precision(cfg)
            self.model = OpenDDE.load_from_checkpoint(
                cfg.get("opendde_ckpt"), abag=(model_id == "opendde-abag"),
                diffusion_fp32=None if prec is None else prec == "fp32")
        elif model_id == "af2ig":
            from tt_bio.af2 import load_af2_device_model
            from tt_bio.af2_weights import load_af2_state_dict

            # template=True is the binder protocol: AF2-IG's template IS the complex you
            # submitted, which is also its initial guess.
            self.model = load_af2_device_model(load_af2_state_dict(cfg["af2_params"]),
                                               template=True).eval()
        elif _is_esmc_model(model_id):
            from tt_bio.esmc import load_esmc

            if model_id in ("esmc-300m", "esmc-600m"):
                # The traced single-sequence forward needs its trace region
                # reserved at device-open; load_esmc requests it only on a
                # fresh open. Guarantee the fresh open here instead of relying
                # on reset() having closed the chip — a cleanup that failed
                # (swallowed there) would otherwise pin this worker eager
                # forever. Scoped to the 300M/600M embedders: esmc-6b cannot
                # be traced, and a 256 MB reservation risks OOM for the big
                # models, so no other model's device-open is touched.
                from tt_bio.tenstorrent import cleanup as _tt_cleanup
                from tt_bio.tenstorrent import trace_region_size

                if trace_region_size() <= 0:
                    _tt_cleanup()
            self.model = load_esmc(model_id, fast=cfg.get("fast", False))
        elif _is_saprot_model(model_id):
            from tt_bio.saprot import load_saprot
            from tt_bio.tenstorrent import cleanup as _tt_cleanup
            from tt_bio.tenstorrent import trace_region_size

            # A repeated batch layout replays a captured forward, whose region load_saprot reserves only on a fresh
            # open (as for the ESMC embedders above).
            if trace_region_size() <= 0:
                _tt_cleanup()
            self.model = load_saprot(model_id, fast=cfg.get("fast", False))
        else:
            from tt_bio.boltz2 import Boltz2
            from tt_bio.data.featurizer import Boltz2Featurizer
            from tt_bio.data.mol import load_canonicals
            from tt_bio.data.tokenize import Boltz2Tokenizer

            self._tokenizer, self._featurizer = Boltz2Tokenizer(), Boltz2Featurizer()
            self._mol_dir = Path(cfg["mol_dir"])
            self._ccd = load_canonicals(self._mol_dir)
            # diffusion_fp32_device scopes a ttnn-only hybrid flag; off-card it is a
            # no-op, and importing tt_bio.tenstorrent here would make the CPU/GPU path
            # require the ttnn wheel (issue #6).
            if self.accelerator == "tenstorrent":
                from tt_bio.tenstorrent import diffusion_fp32_device

                struct_fp32_device = (
                    env_flag("BOLTZ2_STRUCTURE_DIFFUSION_FP32_DEVICE", False)
                )
                ctx = diffusion_fp32_device(struct_fp32_device)
            else:
                ctx = contextlib.nullcontext()
            conf_kwargs = cfg["conf_kwargs"]
            if self.accelerator == "tenstorrent":
                # --diffusion_trace / --no_diffusion_trace, else the arch default. The region is
                # reserved only at open, so a chip opened without it is closed and reopened.
                dit_trace = _trace_default(conf_kwargs.get("diffusion_trace"))
                if dit_trace and not _region_reserved("diffusion"):
                    from tt_bio.tenstorrent import cleanup, get_device

                    cleanup()
                    get_device(trace="diffusion")
                conf_kwargs = {**conf_kwargs, "diffusion_trace": dit_trace}
            with ctx:
                self.model = (
                    Boltz2.load_from_checkpoint(cfg["conf_ckpt"], **conf_kwargs)
                    .eval()
                    .to(self.torch_device)
                )
        self.config_hash = run_config_hash(cfg)
        self.model_id = model_id

    def bind_run(self, run_id: str, cfg: dict[str, Any]) -> None:
        """Cheap per-run rebinding so a resident model serves a new run/user
        correctly: point Boltz-2's featurizer at this run's MSA/output dirs.
        ESMFold2 / Protenix read those straight from cfg in predict_one."""
        self.run_id = run_id
        if self.model_id == "boltz2":
            from tt_bio.main import prepare_features

            self.prepare = partial(
                prepare_features,
                ccd=self._ccd, mol_dir=self._mol_dir, msa_dir=Path(cfg["msa_dir"]),
                tokenizer=self._tokenizer, featurizer=self._featurizer,
                use_msa=cfg["use_msa_server"], msa_url=cfg["msa_server_url"],
                msa_strategy=cfg["msa_pairing_strategy"], msa_user=cfg["msa_server_username"],
                msa_pass=cfg["msa_server_password"], api_key=cfg["api_key_value"],
                max_msa=cfg["max_msa_seqs"], msa_db_path=cfg.get("msa_db_path"),
                use_envdb=cfg.get("use_envdb", False),
                single_sequence=cfg.get("single_sequence", False),
            )
        else:
            self.prepare = None

    def _maybe_ref_bf16(self):
        """Integration-parity envelope (scripts/full_parity_gate.py): when TT_BIO_REF_BF16=1 and
        this is the CPU/host reference (NOT tenstorrent), run the model forward under a bf16
        autocast so its closed-loop divergence from the fp32 reference measures the intrinsic
        bf16 cost of the full sampler trajectory (chaotic amplification included). Applied at
        every forward the device runs in bf16 — the structure ``predict_step`` (bf16 unless
        BOLTZ2_STRUCTURE_DIFFUSION_FP32_DEVICE=1) AND the affinity ``aff_model.predict_step``
        (bf16 unless BOLTZ2_AFFINITY_DIFFUSION_FP32_DEVICE=1) — so the bf16 reference mirrors
        the device's dtype boundary rather than leaving the scalar in fp32. Shared draws are
        preserved: the diffusion ``torch.randn`` draws
        (tt_bio/boltz2.py::AtomDiffusion.sample) run on CPU MT19937
        from the one seed, unaffected by autocast, so fp32 and bf16 references differ only in
        arithmetic dtype, nothing stochastic. Default off — device runs and the fp32 reference
        get a nullcontext and are untouched."""
        import contextlib
        _on = env_flag("TT_BIO_REF_BF16", False)
        if _on and self.accelerator != "tenstorrent":
            return torch.autocast(device_type="cpu", dtype=torch.bfloat16)
        return contextlib.nullcontext()

    def predict_one(self, path: Path, cfg: dict[str, Any]):
        if cfg.get("model") in ("opendde", "opendde-abag"):
            return self._predict_opendde_one(path, cfg)
        if cfg.get("model") in _protenix_family():
            return self._predict_protenix_one(path, cfg)
        if cfg.get("model") in _of3_family():
            return self._predict_openfold3_one(path, cfg)
        if cfg.get("model") == "rf3":
            return self._predict_rf3_one(path, cfg)
        if cfg.get("model") == "af2ig":
            return self._predict_af2ig_one(path, cfg)
        if cfg.get("model", "boltz2") in ("esmfold2", "esmfold2-fast"):
            return self._predict_esmfold2_one(path, cfg)
        if _is_embed_model(cfg.get("model", "boltz2")):
            return self._predict_embed_one(path, cfg)

        from tt_bio.main import to_batch, write_result

        # The boltz-2 path calls ``predict_step`` directly (unlike the esmfold2 /
        # protenix / opendde paths, which re-seed via ``_seed_context`` inside
        # ``fold_complex``). This worker is spawned with ``mp.get_context(
        # "spawn")``, so the controller's ``torch.manual_seed(seed)`` does NOT
        # propagate here, and the boltz-2 forward never re-seeds on its own. The
        # official ``boltz`` reference calls ``seed_everything(seed)`` once at
        # the start of ``predict`` and then runs structure -> affinity from that
        # one global RNG stream, so the affinity diffusion's ``torch.randn``
        # draws are reproducible. Without this seed the device's affinity value
        # swings ~0.05 log10(IC50) between identical-seed runs (verified: two
        # seed-0 runs gave -0.394 vs -0.440, a 0.047 spread larger than the whole
        # FKBP12 GAP of 0.041 and the reference floor R=0.010), which the tight
        # affinity floor catches as a GAP. Seed once here (before the structure
        # forward) and do NOT re-seed before ``predict_affinity`` so the device
        # matches the reference's single-seed structure->affinity RNG stream.
        if cfg.get("seed") is not None:
            from tt_bio.runtime import seed_everything
            seed_everything(cfg["seed"])

        feats, input_struct = self.prepare(path, method=cfg.get("method"), progress=self.pfn)
        batch = to_batch(feats, self.torch_device)
        with torch.no_grad():
            with self._maybe_ref_bf16():
                pred = self.model.predict_step(batch)
        metrics, best = write_result(
            pred,
            batch,
            input_struct,
            Path(cfg["struct_dir"]),
            cfg["output_format"],
            cfg["write_pae"],
            cfg["write_pde"],
            cfg["write_embeddings"],
            cfg.get("contact_cutoff", 8.0),
        )
        if cfg.get("heads") and not pred.get("exception"):
            from tt_bio import heads

            heads.run(self._load_heads(cfg), heads.fold_view(pred, batch),
                      Path(cfg["struct_dir"]), batch["record"][0].id)
        return metrics, best, feats

    def _load_heads(self, cfg: dict[str, Any]) -> dict:
        """The --head callables, loaded once per worker and again only if the specs change."""
        from tt_bio import heads

        specs = tuple(cfg["heads"])
        if self._heads[0] != specs:
            self._heads = (specs, {heads.name(h): heads.load(h) for h in specs})
        return self._heads[1]

    def _predict_af2ig_one(self, path: Path, cfg: dict[str, Any]):
        """AF2-IG: re-predict a designed complex from its own coordinates, report the
        interface. No MSA search, no diffusion, no seed -- the whole job is the trunk."""
        import types

        from tt_bio import af2ig
        from tt_bio.esmfold2 import report_progress

        # af2ig reads its own input shape (a structure plus a binder sequence), so the chain
        # columns of its capability row are a record rather than the enforcement -- see
        # capabilities.CHAINS_ELSEWHERE. The keyed features (a pocket constraint, an affinity
        # block) are still checked here, which is what refuses a boltz2 YAML pasted at it.
        chains = None
        check_capabilities(path, chains, "af2ig")
        spec = af2ig.read_af2ig_input(path)
        report_progress("prep")
        recycles = _recycles(cfg, 3)
        pred = af2ig.fold(self.model, spec, recycles=recycles,
                          progress=lambda i, n: report_progress("trunk", i, n))
        report_progress("saving")
        fmt = cfg["output_format"]
        _write_atom_array_structure(
            pred.atom_array, torch.from_numpy(pred.coords),
            Path(cfg["struct_dir"]) / f"{path.stem}.{fmt}", fmt,
            b_factors=torch.from_numpy(pred.b_factors))
        metrics = {**pred.metrics,
                   "n_residues": pred.tokens,
                   "n_atoms": int(pred.atom_array.array_length()),
                   "n_chains": 2,
                   "binder_residues": pred.binder_length,
                   "msa": False,
                   "recycling_steps": recycles}
        if cfg.get("write_pae"):
            from tt_bio import confidence_export
            confidence_export.write(
                Path(cfg["struct_dir"]), path.stem, "af2ig", pae=pred.pae,
                distogram=pred.distogram, cutoff=cfg.get("contact_cutoff", 8.0),
                absent={"pde": "AF2 has no PDE head"})
        # _execute_job inspects feats["record"].affinity; AF2-IG has no affinity head.
        return metrics, None, {"record": types.SimpleNamespace(affinity=False)}

    def _predict_esmfold2_one(self, path: Path, cfg: dict[str, Any]):
        import types

        from tt_bio.esmfold2 import report_progress
        from tt_bio.esmfold2_runtime import (ESMFOLD2_MSA_ROWS, fold_complex, pair_keyed_msa,
                                             resolve_msa)
        from tt_bio.main import _read_bio_bonds, _read_bio_chains, _write_structure

        chains = _read_bio_chains(path, what=cfg.get("model", "esmfold2"))
        if not chains:
            raise RuntimeError("no sequences")
        check_capabilities(path, chains, cfg.get("model", "esmfold2"),
                           output_format=cfg.get("output_format"))
        # covalent bonds + ring closures, upstream's covalent_bonds -> token_bonds
        bonds = _read_bio_bonds(path, chains)
        msa_dir = Path(cfg["msa_dir"])
        # Upstream's featurizer reads at most ESMFOLD2_MSA_ROWS, so that is the pool unless the
        # user asked for less; the MSA encoder draws its per-loop subsample from it.
        max_msa = min(cfg.get("msa_cap") or ESMFOLD2_MSA_ROWS, ESMFOLD2_MSA_ROWS)
        # Only the checkpoints that ship an MSA encoder can use an MSA. ESMFold2
        # has one; ESMFold2-Fast does not (model.msa_encoder is None), so there's
        # nothing to consume an alignment — skip the search and fold single-seq
        # rather than do wasted work and falsely report msa=true.
        #
        # --single_sequence lands here too. It used to be read only by the models that go
        # through _build_chain_specs, so on esmfold2 it was a silent no-op for the two MSA
        # sources the search below does not touch: an a3m pinned by the YAML `msa:` key, and
        # one already cached under msa_dir for this sequence hash. The fold used the MSA and
        # only `msa: true` in the metrics row hinted at it.
        uses_msa = (getattr(self.model, "msa_encoder", None) is not None
                    and not cfg.get("single_sequence"))

        # MSA phase — rendered as the "MSA" stage, exactly like Boltz-2 (which
        # generates worker-side in prepare_features). When a source is given we
        # search any chain whose {seq_hash}.a3m/.csv is not already cached, into
        # the shared msa_dir. MSA is optional: with no source, fold single-seq.
        if uses_msa:
            search_msas(path, chains, cfg, report_progress)

        report_progress("prep")
        # Only protein chains carry an MSA; a nucleic or ligand chain keeps msa=None, and a
        # ligand's `seq` is its CCD/SMILES spec, so hashing it for an alignment is meaningless.
        paired = _paired_msa(path, chains, msa_dir, cfg) if uses_msa else None

        def _msa(spec, seq):
            msa = resolve_msa(spec, seq, msa_dir, max_sequences=max_msa)
            return (pair_keyed_msa(msa, paired[seq_hash(seq)], max_msa)
                    if paired and spec != EMPTY_MSA else msa)

        chains = [(cid, seq, _msa(spec, seq) if (uses_msa and mt == "protein") else None,
                   mt, mods)
                  for cid, seq, spec, mt, mods in chains]
        from tt_bio import heads

        with (heads.esmfold2_capture(self.model) if cfg.get("heads")
              else contextlib.nullcontext()) as seen:
            ranked = fold_complex(
                self.model, chains,
                num_loops=cfg["recycling_steps"], num_sampling_steps=cfg["sampling_steps"],
                num_diffusion_samples=cfg["diffusion_samples"], seed=cfg.get("seed") or 0,
                return_all=True, bonds=bonds,
            )
        res = ranked[0]
        # Write every sample, not just the winner: best as "{stem}.{fmt}" and the rest as
        # "{stem}_model_{rank}.{fmt}", the same convention Protenix-v2 and OpenDDE use. The
        # samples were always drawn -- they were discarded in fold_complex -- so this costs
        # nothing but the writes, and the winner's file is byte-identical to before.
        fmt = cfg["output_format"]
        struct_dir = Path(cfg["struct_dir"])
        for r, s in enumerate(ranked):
            name = f"{path.stem}.{fmt}" if r == 0 else f"{path.stem}_model_{r}.{fmt}"
            _write_structure(s.complex, struct_dir / name, fmt)

        def _sample_scalars(s):
            m = {"plddt": round(float(s.plddt.mean()), 4)}
            for k in ("ptm", "iptm"):
                if getattr(s, k, None) is not None:
                    m[k] = round(float(getattr(s, k)), 4)
            # Chain-pair ipTM keyed by chain id, in the shape every other model writes it.
            if getattr(s, "pair_chains_iptm", None) is not None and len(chains) > 1:
                ids = [c[0] for c in chains]
                pci = s.pair_chains_iptm.float()
                m["pair_chains_iptm"] = {a: {b: round(float(pci[i, j]), 4)
                                             for j, b in enumerate(ids)} for i, a in enumerate(ids)}
                m["chains_ptm"] = {a: m["pair_chains_iptm"][a][a] for a in ids}
            return m

        metrics = {
            **_sample_scalars(res),
            # A ligand chain's sequence slot is a CCD/SMILES spec, not residues.
            "n_residues": sum(len(c[1]) for c in chains if c[3] != "ligand"),
            "n_chains": len(chains),
            "n_ligands": sum(1 for c in chains if c[3] == "ligand"),
            "msa": any(c[2] is not None for c in chains),
            "samples": cfg["diffusion_samples"],  # best-of-N: report N (plddt is the winner's)
        }
        # Per-sample records, keyed like the other models' so one dataset harness reads them all.
        # Only when there is more than one, matching _scalars/all_runs in main.py.
        if len(ranked) > 1:
            metrics["all_runs"] = [{"rank": r, **_sample_scalars(s)} for r, s in enumerate(ranked)]
        if cfg.get("write_pae"):
            from tt_bio import confidence_export
            confidence_export.write(struct_dir, path.stem, cfg.get("model", "esmfold2"),
                                    pae=res.pae, pde=res.pde, distogram=res.distogram,
                                    cutoff=cfg.get("contact_cutoff", 8.0))
        if seen is not None:
            heads.run(self._load_heads(cfg), heads.esmfold2_view(seen), struct_dir, path.stem)
        # _execute_job inspects feats["record"].affinity; ESMFold2 has no affinity.
        feats = {"record": types.SimpleNamespace(affinity=False)}
        return metrics, None, feats

    def _predict_opendde_one(self, path: Path, cfg: dict[str, Any]):
        """OpenDDE protein co-fold: sequence(s) -> (optional per-chain MSA) -> on-device
        structural-token fold -> structure. Rides the SAME MSA stage as Protenix-v2 /
        ESMFold2 / Boltz-2: each protein chain whose {seq_hash}.a3m is not cached is
        searched into the shared msa_dir, resolved, and featurized via
        build_complex_features' block-diagonal MSA. Protein, RNA, DNA and ligand chains all
        fold; nucleotides split into backbone/base structural tokens. Ligand atoms are tokenized per-atom by
        build_complex_features and expand to one "atom"-role structural token each
        (opendde_data.build_structural_token_features), so a covalent inhibitor bonded
        to a protein Cys is honored end-to-end. Confidence-based best-of-N ranking and
        CIF writing reuse Protenix-v2's machinery verbatim (OpenDDE.fold rides the same
        ConfidenceHead / build_complex_features / _write_protenix_structure)."""
        from tt_bio.esmfold2 import report_progress
        from tt_bio.main import _read_bio_bonds, _read_bio_chains
        from tt_bio.protenix_data import build_complex_features

        model = cfg.get("model", "opendde")
        chains = _read_bio_chains(path)
        if not chains:
            raise RuntimeError("no protein sequences")
        check_capabilities(path, chains, model,
                           output_format=cfg.get("output_format"))
        bonds = _read_bio_bonds(path, chains)   # covalent bonds + ring closures -> token_bonds
        msa_dir = Path(cfg["msa_dir"])

        search_msas(path, chains, cfg, report_progress)
        chain_specs = _build_chain_specs(chains, msa_dir, cfg, protein_only=False)

        # --msa_cache_only: the cache is the only source, so a miss is an error. Without this
        # _resolve_a3m_text returns None for an uncached chain and the fold quietly proceeds
        # single-sequence for it -- a large, invisible accuracy loss in a benchmark run.
        if cfg.get("msa_cache_only"):
            uncached = [cid for (cid, _s, _sp, mt, _mo), (_q, a3m, _m)
                        in zip(chains, chain_specs) if mt == "protein" and not a3m]
            if uncached:
                raise RuntimeError(
                    f"--msa_cache_only: no cached a3m in {msa_dir} for protein chain(s) "
                    f"{uncached}. Folding them single-sequence would silently change MSA "
                    "depth; search them first, or drop --msa_cache_only.")

        paired_a3ms = _paired_a3ms(path, chains, msa_dir, cfg)

        report_progress("prep")
        # `templates:` -> real template features. The template embedder is always on for
        # protenix-v2 and opendde (a 2-block pairformer stack), and until now it only ever
        # saw dummy_template_features, so a template in the input reached the validator and
        # then nothing.
        tmpl_map = _template_map(path, model, chains, cfg["template_structures"])
        tmpl_dir = cfg.get("template_structures")
        if tmpl_map:
            _prefetch_template_structures(tmpl_map, Path(tmpl_dir))
        feats = build_complex_features(chain_specs, mol_dir=cfg.get("mol_dir"),
                                       chain_ids=[cid for cid, _s, _sp, _mt, _mods in chains],
                                       bonds=bonds, paired_a3ms=paired_a3ms,
                                       modifications=[mods for *_x, mods in chains],
                                       templates=[tmpl_map.get(cid) for cid, *_r in chains],
                                       template_dir=tmpl_dir,
                                       conformer_table=_conformer_table(cfg.get("conformer_table")))

        # OpenDDE.fold rides the Protenix-v2 trunk + EDM sampler, so the same
        # progress_fn path reports trunk iterations and diffusion steps — no
        # separate OpenDDE progress wiring, and no premature "diffusion" emit
        # that would skip the trunk phase on the live view.
        n_sample = int(cfg["diffusion_samples"])
        guidance = _tfg_guidance(path, cfg, feats, chains, bonds)
        trunk_cache = None
        if cfg.get("trunk_cache"):
            from tt_bio.cache import TrunkCache
            trunk_cache = TrunkCache(cfg["trunk_cache"])
        # Integration-parity envelope: run the bf16 CPU reference fold under bf16
        # autocast (see _predict_protenix_one / _maybe_ref_bf16). nullcontext on
        # device and on the fp32 reference, so those paths are untouched.
        with torch.no_grad(), self._maybe_ref_bf16():
            coords, conf = self.model.fold(
                feats, n_step=cfg["sampling_steps"], n_sample=n_sample,
                seed=_target_seed(path, cfg), progress_fn=report_progress,
                n_cycles=cfg.get("recycling_steps"), trace=_protenix_trace(cfg) and _protenix_region_reserved(),
                return_confidence=True, max_parallel_samples=cfg.get("max_parallel_samples"),
                distogram=bool(cfg.get("write_pae")), guidance=guidance, trunk_cache=trunk_cache,
                return_logits=cfg.get("model") in UPSTREAM_LAYOUT_MODELS)
        confs = conf if isinstance(conf, list) else [conf]

        # Rank, write and emit through the Protenix-v2 builder: OpenDDE rides that trunk, sampler
        # and ConfidenceHead, so it gets the same structure names and the same metrics row.
        return self._protenix_emit(path, cfg, feats, chains, chain_specs, coords, confs)

    def _protenix_inputs(self, path: Path, cfg: dict[str, Any]):
        """Sequences -> (optional per-chain MSA) -> model-ready features for one target.
        Shared by the single and batched protenix entry points."""
        from tt_bio.esmfold2 import report_progress
        from tt_bio.main import _read_bio_bonds, _read_bio_chains, _read_mol1_constraints
        from tt_bio.protenix_data import build_complex_features

        model = cfg.get("model", "protenix-v2")
        conditions = _read_mol1_constraints(path)
        if conditions and model != "mol1":
            raise RuntimeError(f"site / contact / exclusion constraints are Mol-1-constraint's; {model} has no "
                               "conditioner. Use --model mol1.")
        chains = _read_bio_chains(path)
        if not chains:
            raise RuntimeError("no protein/nucleic-acid sequences")
        check_capabilities(path, chains, model,
                           output_format=cfg.get("output_format"))
        bonds = _read_bio_bonds(path, chains)   # covalent bonds + ring closures -> token_bonds
        msa_dir = Path(cfg["msa_dir"])
        # An input staged from upstream Protenix/Mol-1 JSON carries its paired and unpaired alignments in a
        # sidecar. A chain that has them is not searched, as upstream does not; the rest are, as upstream does.
        from tt_bio.protenix_json import sidecar
        side = sidecar(path)
        left = _left_to_search(path, chains)

        search_msas(path, left, cfg, report_progress)
        chain_specs = _build_chain_specs(chains, msa_dir, cfg, protein_only=True)
        paired_a3ms = _paired_a3ms(path, chains, msa_dir, cfg) if _protein(left) else None

        report_progress("prep")
        # `templates:` -> real template features. The template embedder is always on for
        # protenix-v2 and opendde (a 2-block pairformer stack), and until now it only ever
        # saw dummy_template_features, so a template in the input reached the validator and
        # then nothing.
        tmpl_map = _template_map(path, model, chains, cfg["template_structures"])
        tmpl_dir = cfg.get("template_structures")
        if tmpl_map:
            _prefetch_template_structures(tmpl_map, Path(tmpl_dir))
        feats = build_complex_features(chain_specs, mol_dir=cfg.get("mol_dir"),
                                       chain_ids=[cid for cid, _s, _sp, _mt, _mods in chains], bonds=bonds,
                                       paired_a3ms=paired_a3ms,
                                       modifications=[mods for *_x, mods in chains],
                                       templates=[tmpl_map.get(cid) for cid, *_r in chains],
                                       template_dir=tmpl_dir,
                                       conformer_table=_conformer_table(cfg.get("conformer_table")),
                                       constraints=conditions)
        # A JSON input's MSA features are built exactly as upstream builds them, from the sidecar alignments
        # plus the searched ones for chains it left out. Ordinary YAML/FASTA inputs have no sidecar.
        if side and not cfg.get("single_sequence"):
            from tt_bio.protenix_msa import features_from_sidecar
            feats.update(features_from_sidecar(feats, chains, _with_searched(side, chains, chain_specs, paired_a3ms),
                                               use_rna_msa=bool(cfg.get("use_rna_msa"))))
        if side:
            # its templates too: templatesPath hits under --use_template, upstream's empty set otherwise
            from tt_bio import protenix_templates_json as ptj
            feats.update(ptj.features_from_sidecar(feats, chains, side, bool(cfg.get("use_template"))))
        return feats, chains, chain_specs

    def _protenix_emit(self, path: Path, cfg: dict[str, Any], feats, chains, chain_specs,
                       coords, confs):
        """Rank samples, write structures, build the metrics row for one target."""
        import types

        from tt_bio.main import _write_protenix_structure

        # The family rule, `tt_bio.ranking.ranking_score`. Protenix/OpenDDE compute neither
        # the RASA disorder term nor the inter-chain clash indicator, so those go in as 0.0
        # and the interface branch is the 0.8*ipTM + 0.2*pTM this site already had.
        def _score(c):
            return rank.ranking_score(ptm=c.get("ptm", 0.0), iptm=c.get("iptm", 0.0),
                                      plddt=c["plddt"])

        order = sorted(range(len(confs)), key=lambda k: _score(confs[k]), reverse=True)
        rank_of = {k: r for r, k in enumerate(order)}    # sample index -> rank (0 = best)

        struct_dir = Path(cfg["struct_dir"])
        stem, fmt = path.stem, cfg["output_format"]
        # Write best as "{stem}.{fmt}" and the rest as "{stem}_model_{rank}.{fmt}",
        # exactly like Boltz-2's write_result, so the web portal's progress count,
        # ensemble-similarity and downloads treat both models identically.
        for k in range(len(confs)):
            r = rank_of[k]
            name = f"{stem}.{fmt}" if r == 0 else f"{stem}_model_{r}.{fmt}"
            # per-atom pLDDT (0-1) -> B-factors (0-100), the AF/Boltz convention
            _write_protenix_structure(coords[k], feats, None, struct_dir / name, fmt,
                                      b_factors=confs[k]["plddt_atom"] * 100.0,
                                      mod_names=_artifact_residue_names(chains),
                                      chain_ids=[cid for cid, *_r in chains])

        def _row(c):
            row = {"complex_plddt": round(c["plddt"], 6), "plddt": round(c["plddt"], 6),
                   "ptm": round(c.get("ptm", 0.0), 6), "iptm": round(c.get("iptm", 0.0), 6),
                   "confidence_score": round(_score(c), 6)}
            # Boltz-2's two chain-level keys, in the shape tt_bio.main writes for Boltz-2: the
            # full chain-pair ipTM matrix and its diagonal lifted out as each chain's own pTM.
            # Per sample rather than winner-only, because an antibody-vs-antigen chain-pair
            # ipTM is what ranks that interface and the winner's value cannot rank the rest
            # (AbAg-XM audit 2026-07-27). Absent for a monomer.
            row.update(_chain_rows(c))
            return row

        if "pae_logits" in confs[0]:
            # upstream's own layout and confidence files (D6), beside tt-bio's structures/ + results row
            _write_upstream_layout(path, cfg, feats, chains, coords, confs)

        best = confs[order[0]]
        metrics = {
            **_row(best),
            "n_residues": sum(len(cseq) for _c, cseq, _s, mt, _mods in chains if mt != "ligand"),
            "n_chains": len(chains), "n_tokens": int(feats["restype"].shape[0]),
            "msa": any(a for _, a, _ in chain_specs),
            # the depth actually folded, so --max_msa_seqs is checkable from results.json
            # instead of only from a "msa: true" that says nothing about how deep it went
            "msa_depth": int(feats["msa"].shape[0]),
            "n_atoms": int(coords[0].shape[-2]), "samples": len(confs),
        }
        if len(confs) > 1:
            metrics["all_runs"] = [{"rank": rank_of[k], **_row(confs[k])} for k in order]
        if cfg.get("write_pae"):                       # token-token PAE/PDE of the best sample
            from tt_bio import confidence_export
            model = cfg.get("model", "protenix-v2")
            confidence_export.write(
                struct_dir, stem, model, pae=best["pae"], pde=best["pde"],
                distogram=best.get("distogram"), cutoff=cfg.get("contact_cutoff", 8.0),
                absent={} if "distogram" in best else
                {"contact_probs": f"tt-bio does not run the {model} distogram head"})
        return metrics, None, {"record": types.SimpleNamespace(affinity=False)}

    def _predict_protenix_one(self, path: Path, cfg: dict[str, Any]):
        """Protenix-v2 protein fold: sequence(s) -> (optional per-chain MSA) -> on-device fold
        -> structure. Rides the same MSA stage as ESMFold2/Boltz-2: each chain whose
        {seq_hash}.a3m is not cached is searched into the shared msa_dir, resolved, and
        featurized. Multi-chain inputs fold as a true complex (per-chain asym/entity/sym +
        block-diagonal MSA via build_complex_features)."""
        from tt_bio.esmfold2 import report_progress

        feats, chains, chain_specs = self._protenix_inputs(path, cfg)

        # One shared progress path: report_progress has exactly the progress_fn
        # signature, so hand it straight to the model -- trunk iterations report
        # as "trunk", diffusion steps as "diffusion" (no remapping that would
        # hide the trunk phase).
        n_sample = int(cfg["diffusion_samples"])
        # Integration-parity envelope: the bf16 CPU reference must run the whole
        # protenix fold under bf16 autocast (mirroring the boltz2 path at
        # predict_step), otherwise the bf16 ref runs in fp32, the envelope
        # denominator collapses to ~0 and any device residual reads as a false GAP.
        # On device (accelerator == "tenstorrent") and on the fp32 reference this
        # is a nullcontext, so those paths are untouched.
        with torch.no_grad(), self._maybe_ref_bf16():
            coords, conf = self.model.fold(
                feats, n_step=cfg["sampling_steps"], n_sample=n_sample,
                seed=_target_seed(path, cfg), progress_fn=report_progress,
                return_confidence=True, n_cycles=cfg.get("recycling_steps"),
                max_parallel_samples=cfg.get("max_parallel_samples"),
                # Without this --trace was a silent no-op for --model protenix-v2: main.py
                # reserves the trace region and puts "trace" in the worker config, and
                # Protenix.fold accepts trace=, but this call site never forwarded it, so
                # every protenix fold ran the untraced per-step dispatch. The OpenDDE branch
                # above forwards it, which is why the flag looked plumbed.
                trace=_protenix_trace(cfg) and _protenix_region_reserved(),
                return_logits=cfg.get("model") in UPSTREAM_LAYOUT_MODELS,
            )
        confs = conf if isinstance(conf, list) else [conf]
        return self._protenix_emit(path, cfg, feats, chains, chain_specs, coords, confs)

    def predict_many(self, paths: list, cfg: dict[str, Any]):
        """Fold several targets in one batched diffusion trajectory. Returns one
        (metrics, best, feats) tuple per input path, in input order.

        Only Protenix has a batched path today; anything else folds serially through
        predict_one, so callers can always use this entry point. Targets must share their
        atom and token counts (bucket first) -- a mismatch raises.
        """
        if (cfg.get("model") not in _protenix_family() or len(paths) == 1
                or int(cfg["diffusion_samples"]) != 1
                or any(_target_seed(p, cfg) != (cfg.get("seed") or 0) for p in paths)):
            return [self.predict_one(p, cfg) for p in paths]

        from tt_bio.esmfold2 import report_progress

        prepared = [self._protenix_inputs(p, cfg) for p in paths]
        with torch.no_grad(), self._maybe_ref_bf16():
            coords, confs = self.model.fold_many(
                [f for f, _c, _s in prepared], n_step=cfg["sampling_steps"],
                seed=cfg.get("seed") or 0, progress_fn=report_progress,
                return_confidence=True, n_cycles=cfg.get("recycling_steps"))
        return [self._protenix_emit(p, cfg, prepared[b][0], prepared[b][1], prepared[b][2],
                                    coords[b], [confs[b]])
                for b, p in enumerate(paths)]


    def _predict_rf3_one(self, path: Path, cfg: dict[str, Any]):
        """RF3 fold: chains -> RF3 input spec -> vendored featurizer -> on-device trunk,
        diffusion and confidence -> structure + summary_confidences.json.

        RF3 reads its own documented JSON input spec, and `tt_bio.rf3.featurize` runs the
        real upstream pipeline on it, so this builds a spec from the tt-bio input rather
        than reimplementing featurization. Protein, RNA, DNA and ligand (CCD code or
        SMILES) chains all go through the same path. MSA is the shared stage every other
        model uses: any uncached protein chain is searched into msa_dir and attached to
        its component as `msa_path`.
        """
        import json as _json
        import tempfile
        import types

        from tt_bio.esmfold2 import report_progress
        from tt_bio.main import (_read_bio_chains, _read_bio_constraints, _resolve_a3m_path,
                                 cap_a3m_file)
        from tt_bio.protenix import ConfidenceHead
        from tt_bio.rf3 import confidence as rf3_confidence
        from tt_bio.rf3.featurize import featurize

        chains = _read_bio_chains(path)
        if not chains:
            raise RuntimeError("no sequences")
        check_capabilities(path, chains, "rf3",
                           output_format=cfg.get("output_format"))
        msa_dir = Path(cfg["msa_dir"])
        # `templates:` (either form) -> the template's CA coordinates on the aligned residues,
        # which is how RF3 templates (featurize.apply_template_ca).
        tmpl_dir = cfg["template_structures"]
        tmpl_map = _template_map(path, "rf3", chains, tmpl_dir)
        template_ca = None
        if tmpl_map:
            from tt_bio.template_cif import chain_ca
            _prefetch_template_structures(tmpl_map, Path(tmpl_dir))
            template_ca = {cid: chain_ca(len("".join(cseq.split())), tmpl_map[cid], tmpl_dir,
                                         "rf3")
                           for cid, cseq, *_r in chains if cid in tmpl_map}

        search_msas(path, chains, cfg, report_progress)

        report_progress("prep")
        _CHAIN_TYPE = {"rna": "POLYRIBONUCLEOTIDE", "dna": "POLYDEOXYRIBONUCLEOTIDE"}
        components, msa_used = [], False
        for cid, cseq, spec, mt, mods in chains:
            if mt == "ligand":
                # _read_bio_chains carries a CCD code as "CCD_<code>" and a SMILES raw. The
                # chain_id is the user's: without it atomworks hands out the next free letter
                # and a ligand submitted as L comes back as B.
                components.append({"ccd_code": cseq[4:]} if cseq.startswith("CCD_")
                                  else {"smiles": cseq})
                components[-1]["chain_id"] = cid
                continue
            comp = {"seq": _rf3_sequence(cseq, mods), "chain_id": cid}
            if mt in _CHAIN_TYPE:
                comp["chain_type"] = _CHAIN_TYPE[mt]
            elif not cfg.get("single_sequence"):
                a3m = _resolve_a3m_path(spec, cseq, msa_dir)
                if a3m:
                    # absolute: upstream resolves a component's msa_path against the
                    # process cwd, not against the input file
                    comp["msa_path"] = str(a3m.resolve())
                    msa_used = True
            components.append(comp)
        if cfg.get("msa_cache_only") and _msa_source(cfg) and not msa_used:
            raise RuntimeError(
                "--msa_cache_only: no cached a3m for any protein chain of "
                f"{path.name} -- refusing to silently fold single-sequence.")

        n_recycles = _recycles(cfg, 10)
        n_sample = max(1, int(cfg.get("diffusion_samples") or 1))
        seed = int(cfg.get("seed") or 0)
        partial_t = int(cfg.get("partial_t") or 0)
        early_stop_plddt = cfg.get("early_stop_plddt")
        with tempfile.TemporaryDirectory() as td:
            # --max_msa_seqs: upstream's featurizer reads a component's msa_path whole, so the
            # cap is applied by handing it a truncated copy of the a3m instead of the cached
            # one. Uncapped runs keep pointing at the cache file itself.
            for comp in components:
                if comp.get("msa_path"):
                    comp["msa_path"] = str(cap_a3m_file(
                        comp["msa_path"], cfg.get("msa_cap"), td))
            spec_path = Path(td) / f"{path.stem}.json"
            spec_path.write_text(_json.dumps(
                [{"name": path.stem, "components": components,
                  "bonds": _rf3_bonds(components, _read_bio_constraints(path))}]))
            # Partial diffusion noises a structure, so it featurizes the structure
            # directly: RF3's own reader takes .cif/.pdb/.json, and a spec built from
            # sequences has no coordinates to start the rollout from.
            src = Path(cfg["partial_structure"]) if partial_t else spec_path
            out = featurize(src, n_recycles=n_recycles,
                            diffusion_batch_size=n_sample, seed=seed,
                            template_ca=template_ca)[0]

        f = out["feats"]
        atom_array = out["atom_array"]
        is_real_atom = out["confidence_feats"]["is_real_atom"]
        chain_iid = out["ground_truth"]["chain_iid_token_lvl"]
        coord_to_be_noised = None
        if partial_t:
            coord_to_be_noised = out.get("coord_atom_lvl_to_be_noised")
            if coord_to_be_noised is None or not bool(coord_to_be_noised.abs().any()):
                raise RuntimeError(
                    f"--partial_t {partial_t}: {Path(cfg['partial_structure']).name} "
                    "featurized to all-zero coordinates, so there is nothing to noise. "
                    "Give a .cif/.pdb that carries them.")

        # The trunk runs once and the diffusion batch is D independent rollouts off it,
        # each with its own confidence. Rank them by upstream's ranking score
        # (0.8*ipTM + 0.2*pTM - 100*clash) and write the winner as {stem}.{fmt} with the
        # rest as {stem}_model_{rank}.{fmt} -- the convention Protenix-v2, OpenDDE and
        # ESMFold2 already use, so one dataset harness reads every model's output.
        # predict() hands each sample's heads here as they come off the device, so only
        # one sample's [I, I, 64] logits are ever alive on the host.
        def one(d, per, x):
            per = {k: v[0] for k, v in per.items()}
            coord = x.detach().cpu().numpy().astype("float32")
            plddt = rf3_confidence.atomwise_plddt(per["plddt_logits"], is_real_atom)
            summary = rf3_confidence.summary(per, f, is_real_atom, chain_iid,
                                             atom_array, coord)
            # Order on the full-precision score, not on summary["ranking_score"], which is
            # rounded to 4 decimals for the published summary_confidences.json. Two samples
            # whose scores differ below 1e-4 round to the same value and were then ordered by
            # sample index; rf3/multimer seed 1 did exactly that at ranks 3 and 4, pTM 0.7647
            # against 0.7630, and it is the only site in the family that sorted on a rounded
            # number.
            r = {"d": d, "coord": x, "plddt": plddt, "summary": summary,
                 "score": summary["ranking_score"]}
            # The chain-pair ipTM matrix the other models report, on RF3's own bin
            # midpoints. Kept out of `summary`, which is upstream's summary_confidences.json.
            pae_l, (n_bins, max_a) = per["pae_logits"], rf3_confidence.BINS["pae"]
            r.update(ConfidenceHead._chain_confidence(
                pae_l.reshape(*pae_l.shape[-3:]), f["asym_id"],
                centers=rf3_confidence.bin_midpoints(max_a, n_bins)))
            if cfg.get("write_pae"):              # the [I, I] matrices summary() reduces
                for k in ("pae", "pde"):
                    lg = per[f"{k}_logits"]
                    r[k] = rf3_confidence.unbin(lg.reshape(*lg.shape[-3:]), k)
            return r

        # One shared progress path, same as protenix-v2/openfold3/opendde:
        # report_progress already has the progress_fn signature, so it goes straight
        # into predict() and the trunk recycles / diffusion steps tick per iteration.
        # A single report_progress("trunk") here instead left the live view with a
        # zero-total trunk bar and no diffusion phase at all.
        torch.manual_seed(seed)
        got = self.model.predict(
            f, n_recycles=n_recycles, diffusion_batch_size=n_sample,
            rep_atom_idxs=out.get("ground_truth", {}).get("rep_atom_idxs"),
            coord_to_be_noised=coord_to_be_noised, partial_t=partial_t,
            early_stop_plddt=early_stop_plddt, is_real_atom=is_real_atom,
            progress_fn=report_progress, per_sample=one)
        if got.get("early_stopped"):
            # Abandoned, not failed: the caller has to be able to tell those apart, so this
            # returns metrics rather than raising, and writes no structure.
            return ({"early_stopped": True,
                     "plddt": round(got["mean_plddt"], 6),
                     "early_stop_plddt": got["early_stop_plddt"],
                     "n_tokens": int(f["asym_id"].reshape(-1).shape[0]),
                     "n_atoms": int(atom_array.array_length()),
                     "recycling_steps": n_recycles},
                    None, {"record": types.SimpleNamespace(affinity=False)})

        samples = sorted(got["per_sample"], key=lambda r: -r["score"])
        fmt = cfg["output_format"]
        struct_dir = Path(cfg["struct_dir"])
        for rank, r in enumerate(samples):
            stem = path.stem if rank == 0 else f"{path.stem}_model_{rank}"
            _write_atom_array_structure(atom_array, r["coord"],
                                        struct_dir / f"{stem}.{fmt}", fmt,
                                        b_factors=r["plddt"] * 100.0)
            published = dict(r["summary"],
                              ranking_score=round(r["summary"]["ranking_score"], 4))
            (struct_dir / f"{stem}_summary_confidences.json").write_text(
                _json.dumps(published, indent=2) + "\n")

        def scalars(r):
            sm = r["summary"]
            # pLDDT is [0, 1] out of the head and is reported that way, which is what every
            # other model in this repo reports and what --early_stop_plddt is compared against.
            # The B-factor column is the same value times 100, the PDB convention, so mean
            # B-factor / 100 reproduces this number (perf/plddt_column/FINDINGS.md).
            return {"plddt": round(float(r["plddt"].mean()), 6),
                    "ptm": round(sm["ptm"], 4),
                    "iptm": round(sm["iptm"], 4) if sm["iptm"] is not None else None,
                    "ranking_score": round(sm["ranking_score"], 4),
                    "has_clash": sm["has_clash"], **_chain_rows(r)}

        best = samples[0]
        metrics = {
            **scalars(best),
            "n_tokens": int(f["asym_id"].reshape(-1).shape[0]),
            "n_atoms": int(atom_array.array_length()),
            "n_chains": len({c[0] for c in chains}),
            "msa": msa_used,
            "msa_depth": int(f["msa_stack"].shape[1]),
            "recycling_steps": n_recycles,
            "samples": len(samples),
        }
        if partial_t:
            metrics["partial_t"] = partial_t
        if early_stop_plddt is not None:
            metrics["early_stopped"] = False
            metrics["early_stop_plddt"] = float(early_stop_plddt)
        if len(samples) > 1:
            metrics["all_runs"] = [{"rank": i, **scalars(r)}
                                   for i, r in enumerate(samples)]
        if cfg.get("write_pae"):
            from tt_bio import confidence_export
            n = best["pae"].shape[-1]
            dist = got["distogram"].reshape(*got["distogram"].shape[-3:])[:n, :n]
            confidence_export.write(struct_dir, path.stem, "rf3", pae=best["pae"],
                                    pde=best["pde"], distogram=dist,
                                    cutoff=cfg.get("contact_cutoff", 8.0))
        return metrics, None, {"record": types.SimpleNamespace(affinity=False)}

    def _predict_openfold3_one(self, path: Path, cfg: dict[str, Any]):
        """OpenFold3 fold: sequence(s) -> per-chain MSA -> fixture-free on-device fold
        (host featurization + device glue/trunk/diffusion/confidence) -> structure.
        Rides the same MSA stage as Protenix-v2: uncached protein chains are searched
        into the shared msa_dir and attached to the query as main_msa_file_paths.
        Polymer chains only (protein/RNA/DNA). Templates are opt-in per protein chain
        via the YAML `templates:` key (precomputed alignment npz, the format the
        upstream benchmark cache ships); there is no template SEARCH."""
        import types

        from tt_bio.esmfold2 import report_progress

        host = openfold3_host_inputs(path, cfg, model_name=cfg.get("model", "openfold3"),
                                     levers=tuple(getattr(self.model, "_levers", ())))
        chains, of3_query, features = host.chains, host.of3_query, host.features
        msa_feat = host.msa_feat

        n_sample = int(cfg["diffusion_samples"])
        result = openfold3_device_fold(
            self.model, host, sampling_steps=int(cfg["sampling_steps"]),
            diffusion_samples=n_sample, distogram=bool(cfg.get("write_pae")),
            progress_fn=report_progress,
            max_parallel_samples=cfg.get("max_parallel_samples"))

        confs = result.confidence
        order = sorted(range(len(confs)),
                       key=lambda k: confs[k]["ranking_score"], reverse=True)
        rank_of = {k: r for r, k in enumerate(order)}

        struct_dir = Path(cfg["struct_dir"])
        stem, fmt = path.stem, cfg["output_format"]
        for k in range(len(confs)):
            r = rank_of[k]
            name = f"{stem}.{fmt}" if r == 0 else f"{stem}_model_{r}.{fmt}"
            _write_atom_array_structure(
                features["atom_array"], result.samples[k], struct_dir / name, fmt,
                b_factors=confs[k]["plddt_atom"] * 100.0)

        def _row(c):
            return {"complex_plddt": round(c["plddt"], 6), "plddt": round(c["plddt"], 6),
                    "ptm": round(c.get("ptm", 0.0), 6), "iptm": round(c.get("iptm", 0.0), 6),
                    "confidence_score": round(c["ranking_score"], 6), **_chain_rows(c)}

        best = confs[order[0]]
        metrics = {
            **_row(best),
            "n_residues": sum(len(cseq) for _c, cseq, _s, _mt, _mods in chains),
            "n_chains": len(chains), "n_tokens": int(features["restype"].shape[0]),
            "msa": any(c.main_msa_file_paths for c in of3_query.chains),
            "msa_depth": int(msa_feat.shape[0]),
            "n_atoms": int(result.samples[0].shape[0]), "samples": n_sample,
        }
        if len(confs) > 1:
            metrics["all_runs"] = [{"rank": rank_of[k], **_row(confs[k])} for k in order]
        if cfg.get("write_pae"):
            from tt_bio import confidence_export
            confidence_export.write(struct_dir, stem, cfg.get("model", "openfold3"),
                                    pae=best["pae"], pde=best["pde"], distogram=best["distogram"],
                                    cutoff=cfg.get("contact_cutoff", 8.0))
        return metrics, None, {"record": types.SimpleNamespace(affinity=False)}

    def _predict_embed_one(self, path: Path, cfg: dict[str, Any]):
        """Embed one job's shard of sequences with the resident embedding model.

        Serves both families: ESMC reads a ``{id: sequence}`` shard, SaProt a
        ``{id: [aa, 3di]}`` one.

        ``path`` is a YAML ``{id: sequence}`` mapping (one shard of a larger
        --controller embed run). Writes per-sequence ``.npz`` (or one shard
        parquet, named by job id to avoid colliding with other shards' output
        once every job's outputs land in the same directory) into struct_dir —
        the same output-shipping path predict/design jobs already use.
        """
        import types

        from tt_bio.esmc import write_npz_many, write_parquet

        model_id = cfg.get("model", "")
        if _is_saprot_model(model_id):
            from tt_bio.saprot import embed_sequences, read_shard_yaml

            sequences = read_shard_yaml(path)
        else:
            from tt_bio.esmc import embed_sequences, load_sequences

            sequences = load_sequences(path)
        t0 = time.perf_counter()
        results = embed_sequences(
            self.model, sequences, return_logits=cfg.get("return_logits", False),
            pool=cfg.get("pool", "mean"), batch_size=cfg.get("batch_size", 8),
        )
        device_s = time.perf_counter() - t0
        struct_dir = Path(cfg["struct_dir"])
        t0 = time.perf_counter()
        if cfg.get("output_format") == "parquet":
            write_parquet(results, struct_dir / f"{cfg['job_id']}.parquet")
        else:
            # Threaded, not a serial write_npz loop. np.savez_compressed sits in
            # zlib's C compress loop, which releases the GIL, and on the served
            # batch-8 x 76 aa shape the serial loop costs 369 ms against 64 ms of
            # device work -- 85 % of the job's wall spent compressing while the
            # chip idles (measured on the Wormhole Galaxy, UMD 26).
            write_npz_many(results, struct_dir)
        write_s = time.perf_counter() - t0
        metrics = {
            "n_sequences": len(results),
            "d_model": int(results[0].pooled.shape[0]) if results else 0,
            "ids": [e.id for e in results],
            "lengths": [len(e.sequence) for e in results],
            # Reported separately so an ESM-C embed leg is comparable to SaProt's,
            # which times embed_sequences alone.
            "device_s": round(device_s, 4),
            "write_s": round(write_s, 4),
        }
        return metrics, None, {"record": types.SimpleNamespace(affinity=False)}

    def predict_affinity(self, path: Path, pred_structure, cfg: dict[str, Any]) -> dict[str, float]:
        from tt_bio.boltz2 import Boltz2
        from tt_bio.main import to_batch

        if self.aff_model is None:
            # Same ttnn-only flag as the structure load above; see that comment.
            if self.accelerator == "tenstorrent":
                from tt_bio.tenstorrent import diffusion_fp32_device

                fp32_device = (
                    env_flag("BOLTZ2_AFFINITY_DIFFUSION_FP32_DEVICE", False)
                )
                ctx = diffusion_fp32_device(fp32_device)
            else:
                ctx = contextlib.nullcontext()
            # Building a Boltz2 draws heavily from the global RNG (every nn.Linear
            # initialises its weights before load_state_dict overwrites them), and this
            # load happens lazily inside the FIRST affinity target of a run. That left
            # target 1's affinity diffusion drawing its noise from a different RNG state
            # than every later target's, so identical compounds got different scalars
            # depending on position in the job. Later targets are also the ones that match
            # the reference, which loads both checkpoints before it seeds. Keep the load
            # invisible to the sampler.
            with ctx, _rng_state_preserved():
                self.aff_model = (
                    Boltz2.load_from_checkpoint(cfg["aff_ckpt"], **cfg["aff_kwargs"])
                    .eval()
                    .to(self.torch_device)
                )

        feats, _ = self.prepare(path, method="other", affinity=True, pred_structure=pred_structure)
        batch = to_batch(feats, self.torch_device)
        with torch.no_grad():
            with self._maybe_ref_bf16():
                pred = self.aff_model.predict_step(batch)
        if pred.get("exception"):
            return {}
        keys = [
            "affinity_pred_value",
            "affinity_probability_binary",
            "affinity_pred_value1",
            "affinity_probability_binary1",
            "affinity_pred_value2",
            "affinity_probability_binary2",
        ]
        return {k: round(pred[k].item(), 6) for k in keys if k in pred}


def _of3_state_dict(cfg: dict[str, Any]) -> dict:
    """The weights an OF3-family fold loads: ``--checkpoint`` when given, else the shipped file.

    Both are the same format. `tt-bio train` writes its trained weights as OUT/weights.pt for
    exactly this; its adapter-*.safetensors files hold optimizer state for resuming a run.
    """
    ckpt = cfg.get("checkpoint")
    if ckpt and Path(ckpt).suffix == ".safetensors":
        raise RuntimeError(
            f"{ckpt} is a training checkpoint, which resumes a run. Fold with the weights.pt "
            f"that `tt-bio train` wrote beside it")
    return torch.load(ckpt or cfg["of3_ckpt"], map_location="cpu", weights_only=False)


def _install_orphan_guard(dispatcher_pid: int) -> None:
    """Die with the dispatcher, whatever this worker is in the middle of.

    ``run_worker_loop``'s orphan check only runs between leases, so a worker
    orphaned DURING a job never reaches it and keeps its chip open and its card
    lease flocked forever. One was found holding /dev/tenstorrent/0 and card 3's
    lease for 6 h at 100% CPU, deferring every later job pinned to that card.
    Mechanism and the parent-THREAD caveat: ``install_parent_death_guard``.

    A worker can afford the SIGTERM handler ``_install_signal_handlers`` puts on
    top of this, which unwinds through close_device and leaves the chip clean,
    because a worker too deep in ttnn to take the signal is still caught: by the
    heartbeat 60 s later if the interpreter runs, and by the guard's reaper with
    SIGKILL if it does not (a worker wedged in the bring-up dispatch probe, before
    the heartbeat starts). A process with neither backstop must leave SIGTERM at its
    default disposition instead.

    Workers are started from the dispatcher's main thread
    (``main._spawn_worker_processes``, ``_supervise_worker_processes``), which is
    what makes the kernel's parent-thread delivery rule a no-op here.
    """
    install_parent_death_guard(dispatcher_pid)


class WorkerSignalled(KeyboardInterrupt):
    """The signal that stopped this worker, carried to whoever handles it.

    A subclass of KeyboardInterrupt so every existing ``except KeyboardInterrupt``
    (this module's loop, the vendored atomworks transforms) behaves exactly as
    before; the extra ``signum`` is what lets the loop name the signal instead of
    reporting "an interrupt".
    """

    def __init__(self, signum: int):
        super().__init__(f"worker received signal {signum}")
        self.signum = int(signum)


def _install_signal_handlers() -> None:
    def _raise(signum, _frame):
        raise WorkerSignalled(signum)

    try:
        signal.signal(signal.SIGTERM, _raise)
        signal.signal(signal.SIGINT, _raise)
    except Exception:
        pass


def run_worker_loop(
    controller_url: str,
    worker_info: dict[str, Any],
    debug: bool = False,
    idle_poll: float = 1.0,
) -> None:
    """Connect to a scheduler and process jobs until cancelled.

    Loads model artifacts once per run and reuses them for every job in that
    run. If the run's config changes, the model is reloaded.
    """
    if not debug:
        _silence_subprocess_output()
    _install_signal_handlers()
    _apply_tt_environment(worker_info)
    _bind_host_threads()

    # A locally-spawned worker (CLI fan-out / serve pool) records its dispatcher
    # here; a dispatcher killed with SIGTERM skips its finally-block and would
    # otherwise orphan us holding the chip open indefinitely (observed: a stray
    # worker pinned /dev/tenstorrent/3 for 2h, silently blocking later runs on
    # that card). Workers of a `tt-bio worker` pool leave the var unset.
    _dispatcher_pid = int(os.environ.get("TT_BIO_PARENT_PID") or 0)
    _install_orphan_guard(_dispatcher_pid)

    client = ControllerClient(controller_url)
    worker_id = worker_info["worker_id"]
    meta = {
        "dev": worker_info["device_id"],
        "worker": worker_id,
        "host": worker_info["host"],
        "accelerator": worker_info["accelerator"],
        "label": worker_info["label"],
    }

    # Background heartbeat: while the main loop is blocked computing (MSA fetch,
    # folding, a design-shard subprocess) it isn't leasing, so without this the
    # controller would mark a perfectly healthy worker offline. A daemon thread
    # pings the controller so a worker counts as online whenever its process is.
    # It starts AFTER the chip is open (below), never before: the first heartbeat
    # is what registers this worker, so heartbeating first would advertise a slot
    # that may be about to exit without ever holding a device.
    import threading
    _stop_beat = threading.Event()

    # Paced to the controller's own lease, which every answer names, so a lease set
    # with `tt-bio controller --lease-s` needs no matching change here.
    beat_s = [LEASE_S / HEARTBEAT_PER_LEASE]

    def _heartbeat_loop():
        orphaned_since = None
        while not _stop_beat.wait(beat_s[0]):
            if _dispatcher_pid and os.getppid() != _dispatcher_pid:
                # PDEATHSIG (see _install_orphan_guard) had 60 s to unwind this
                # cleanly and did not, so we are stuck inside a call that does not
                # take signals. Leave anyway: an orphan has no consumer for its
                # results, and its card lease blocks every later job on this chip.
                orphaned_since = orphaned_since or time.monotonic()
                if time.monotonic() - orphaned_since > 60:
                    os._exit(70)
                continue
            orphaned_since = None
            try:
                lease_s = client.heartbeat(worker_info).get("lease_s")
                if lease_s:
                    beat_s[0] = float(lease_s) / HEARTBEAT_PER_LEASE
            except Exception:
                pass

    def emit(run_id: str, event: str, **kw):
        try:
            client.event(run_id, worker_id, {"event": event, **meta, **kw})
        except Exception:
            pass

    state = _WorkerState(worker_info["accelerator"])
    # Open this worker's chip once, now, while the fleet is quiescent (startup),
    # and keep it open for every job — predict AND design. Every device open then
    # happens at startup, never during active operation, which is what keeps us
    # off the UMD concurrent-device-init deadlock (see device_lease.device_init_lock).
    if state.accelerator == "tenstorrent":
        try:
            from tt_bio.tenstorrent import get_device as _get_device
            _get_device()
        except Exception as exc:
            _report_fatal(f"tt-bio worker {worker_info['label']}: device open failed\n"
                          f"{traceback.format_exc()}")
            # The chip didn't come up with working local dispatch (e.g. a raced
            # "remote-only" bring-up). Do NOT stay online serving jobs we'd fail:
            # exit so the pool supervisor respawns us. The respawn reopens under the
            # host-wide device-init lock (one chip at a time), which is exactly what
            # clears the concurrent-init race behind a bad bring-up.
            #
            # Exit non-zero, and on CONTENDED_EXIT_CODE when a co-tenant holds the card,
            # because `predict` reads these codes back: a fan-out whose workers never
            # opened a chip has measured nothing, and main._stream_run used to report it
            # as a run failure. Six v0.7.0 release-gate legs were scored as accuracy
            # misses that way. The serve supervisor is unaffected, it respawns on any exit.
            raise SystemExit(
                CONTENDED_EXIT_CODE if isinstance(exc, DeviceInUseError) else 1
            ) from None

    # The chip is ours. Only now does this worker exist as far as the fleet is
    # concerned, so `online_workers` counts devices we can actually compute on.
    threading.Thread(target=_heartbeat_loop, daemon=True).start()
    # The job this worker is computing right now, or None between leases. The
    # KeyboardInterrupt handler below reads it to tell an ordinary stop from a
    # killed fold.
    inflight: dict[str, Any] | None = None
    try:
        while True:
            if _dispatcher_pid and os.getppid() != _dispatcher_pid:
                return
            # Tolerate a controller that's briefly unreachable (restart, network
            # blip): retry leasing instead of crashing the worker. This makes the
            # fleet self-healing — a worker reconnects on its own when the
            # controller comes back, with no manual restart.
            try:
                # Tell the scheduler which model we already have resident so it
                # can keep us on it (affinity) and avoid a reload.
                worker_info["model"] = state.model_id
                worker_info["warm"] = state.config_hash
                lease = client.lease(worker_info, batch_size=1)
            except Exception:
                time.sleep(idle_poll)
                continue
            jobs = lease.get("jobs") or []
            if not jobs:
                time.sleep(idle_poll)
                continue

            run_id = lease["run_id"]
            cfg = dict(lease["config"])
            # The chip is this run's from here. A cold worker spends the next
            # ~100 s loading the model, before any job's own clock starts; each
            # job reports that stretch as load_s so a lease can be billed whole.
            leased_at = time.time()

            # Design shards ride the same scheduler as prediction. They run the
            # BoltzGen single-device pipeline IN-PROCESS on this worker's already-
            # open chip — reusing the persistent device instead of cold-opening a
            # fresh one per shard (which raced the UMD device-init path and
            # deadlocked). Free the predict model first (memory) but keep the chip.
            if cfg.get("kind") == "design":
                state.free_model()
                shard = {"rfd3": _execute_rfd3_job_inprocess,
                         "pxdesign": _execute_pxdesign_job_inprocess,
                         "rfd4": _execute_rfd4_job_inprocess}.get(
                             cfg.get("engine"), _execute_design_job_inprocess)
                for job in jobs:
                    shard(client, run_id, worker_id, worker_info, meta, job, cfg)
                continue

            # A design engine held from an earlier design run would otherwise keep RFD4's
            # weights in DRAM while this worker loads a predict model onto the same chip.
            _free_rfd4_engine()
            _ensure_local_artifacts(cfg)

            try:
                # Reload weights only when the model actually changes — a resident
                # model is reused across runs/users of the same model.
                if not state.configured_for(cfg):
                    state.reset()
                    emit(run_id, "loading")
                    state.load_model(cfg)
                # Per-run rebinding (cheap) every job: output/MSA paths + a fresh
                # progress callback aimed at this run.
                state.bind_run(run_id, cfg)
                from tt_bio.progress import make_progress_fn

                pfn = make_progress_fn(
                    HttpProgressQueue(client, run_id, worker_id),
                    worker_info["device_id"], worker_id, meta,
                )
                state.pfn = pfn
                if cfg.get("model", "boltz2") == "boltz2":
                    state.model.progress_fn = pfn
                else:
                    from tt_bio import esmfold2 as _E

                    _E.set_progress(pfn)  # esmfold2 + protenix report via this module
            except Exception as exc:
                traceback.print_exc()
                _complete_failure(client, run_id, worker_id, meta, jobs, _err_text(exc))
                state.reset()
                continue

            for job in jobs:
                # Cleared only on the way OUT of a finished job, deliberately not in a
                # finally: a finally runs before the exception reaches the handler
                # below, which would hide the very case this exists to catch.
                inflight = job
                _execute_job(state, job, cfg, run_id, client, worker_id, meta, leased_at)
                inflight = None
                leased_at = time.time()
    except KeyboardInterrupt as exc:
        # SIGINT between leases is how _stop_worker_processes ends a FINISHED run, so
        # that case is an ordinary shutdown: it stays silent and exits 0, as before.
        # A signal that lands mid-job is not. _execute_job never reaches its
        # client.complete, so the job stays leased, the run never turns terminal, and
        # the dispatcher's liveness check fires with "The worker's own traceback above
        # says why" printed above nothing at all. The entire diagnosis this worker
        # produced was `SpawnProcess-1 exit 0`. Measured on rf3 at 1536 tokens
        # (2026-09-09 23:20Z): gone between `trunk 3/10` and `trunk 4/10` after eight
        # minutes of folding, no results row, no traceback, empty structures/.
        # So: complete the job as failed, name the signal on the launcher's real
        # stderr, and exit 128+signum so a caller reading return codes can tell a
        # killed fold from a clean stop.
        if inflight is not None:
            signum = getattr(exc, "signum", 0)
            try:
                name = signal.Signals(signum).name
            except ValueError:
                name = f"signal {signum}"
            text = (f"worker {worker_info['label']} was stopped by "
                    f"{name if signum else 'an interrupt'} while running job "
                    f"{inflight.get('name') or inflight['id']}; the fold did not finish")
            _complete_failure(client, run_id, worker_id, meta, [inflight], text)
            _report_fatal(f"tt-bio {text}\n")
            raise SystemExit(128 + signum if signum else 1) from None
    except BaseException:
        # Anything escaping the per-job handling above kills this worker, and with
        # stdout/stderr on /dev/null the traceback would otherwise vanish — the
        # only diagnostic a local `predict` fan-out (no supervisor) will ever get
        # for why a worker slot went quiet.
        _report_fatal(f"tt-bio worker {worker_info['label']}: uncaught error, exiting\n"
                      f"{traceback.format_exc()}")
        raise
    finally:
        state.reset()
        _cleanup_worker_capture()


def _execute_job(
    state: _WorkerState,
    job: dict[str, Any],
    cfg: dict[str, Any],
    run_id: str,
    client: ControllerClient,
    worker_id: str,
    meta: dict[str, Any],
    leased_at: float | None = None,
) -> None:
    job_id = job["id"]
    filename = job.get("name") or f"{job_id}.yaml"
    t0 = time.time()
    # runtime_s is the job; load_s is the lease before it, the model load on a
    # cold worker and ~0 on a warm one. Their sum is what this attempt held.
    row: dict[str, Any] = {"id": job_id, "status": "failed",
                           "load_s": round(t0 - (leased_at or t0), 1)}

    def emit(event: str, **kw):
        try:
            client.event(run_id, worker_id, {"event": event, **meta, **kw})
        except Exception:
            pass

    workdir = Path(tempfile.mkdtemp(prefix=f"tt-bio-{job_id}-"))
    input_path = workdir / filename
    output_dir = workdir / "out"
    output_dir.mkdir(parents=True, exist_ok=True)

    job_cfg = dict(cfg)
    job_cfg["struct_dir"] = str(output_dir)
    job_cfg["job_id"] = job_id

    outputs: dict[str, str] = {}
    emit("start", name=job_id)
    try:
        try:
            stage_input(job, input_path)
        except Exception as exc:
            raise RuntimeError(f"failed to decode input bytes: {exc}") from exc

        metrics, best, feats = state.predict_one(input_path, job_cfg)
        emit("stage", stage="saving")
        if metrics:
            row.update(metrics)
            row["status"] = "ok"
            # runtime_s is the whole job, affinity included. Stamping it here, before
            # predict_affinity, made results.json report the structure leg only: a 191 s
            # affinity prediction read 32 s, so anyone pricing the affinity path off the
            # result file was off by ~6x. The split is reported too, because the two legs
            # have very different cost drivers.
            structure_runtime_s = round(time.time() - t0, 1)
            if feats["record"].affinity and best is not None:
                t_aff = time.time()
                try:
                    aff = state.predict_affinity(input_path, best, job_cfg)
                    row.update(aff)
                except Exception as exc:
                    # The structure stands, so the row stays ok; but a screen reads the
                    # affinity, and a row with no affinity and no reason reads as a pass.
                    traceback.print_exc()
                    row["affinity_error"] = _err_text(exc)
                row["structure_runtime_s"] = structure_runtime_s
                row["affinity_runtime_s"] = round(time.time() - t_aff, 1)
            row["runtime_s"] = round(time.time() - t0, 1)
        outputs = _read_outputs(output_dir, _shared_outputs_dir(cfg))
    except Exception as exc:
        traceback.print_exc()
        row["error"] = _err_text(exc)
    finally:
        shutil.rmtree(workdir, ignore_errors=True)

    try:
        client.complete(
            run_id,
            worker_id,
            row,
            {
                **meta,
                "event": "done",
                "name": job_id,
                "time": round(time.time() - t0, 1),
                "status": row["status"],
                "error": row.get("error", ""),
                "row": row,
            },
            outputs=outputs or None,
        )
    except Exception:
        traceback.print_exc()


def _execute_design_job_inprocess(
    client: ControllerClient,
    run_id: str,
    worker_id: str,
    worker_info: dict[str, Any],
    meta: dict[str, Any],
    job: dict[str, Any],
    cfg: dict[str, Any],
) -> None:
    """Run one design shard IN-PROCESS on this worker's persistent device.

    The BoltzGen single-device pipeline runs each stage in-process on
    get_device(), so invoking it here transparently reuses this worker's
    already-open chip — no per-shard cold-open, hence no UMD device-init deadlock.
    A daemon thread relays the pipeline's stage progress while the run blocks this
    (heartbeat-covered) worker thread; cancellation is shard-granular (the run
    finishes its shard, bounded by the platform watchdog)."""
    import threading
    job_id = job["id"]
    t0 = time.time()
    device = str(worker_info["device_id"])

    def emit(event: str, **kw):
        try:
            client.event(run_id, worker_id, {"event": event, **meta, **kw})
        except Exception:
            pass

    workdir = Path(tempfile.mkdtemp(prefix=f"tt-bio-design-{job_id}-"))
    out_dir = workdir / "out"
    progress_file = workdir / "progress.jsonl"
    progress_file.write_text("")
    row: dict[str, Any] = {"id": job_id, "status": "failed"}
    outputs: dict[str, str] = {}
    emit("start", name=job_id)

    # Relay BoltzGen's per-stage progress while run_command blocks this thread
    # (heartbeats keep flowing on the background thread set up in run_worker_loop).
    pos = [0]
    stop = threading.Event()

    def _pump():
        while not stop.wait(1.0):
            pos[0] = _forward_design_progress(progress_file, pos[0], emit)

    pump = threading.Thread(target=_pump, daemon=True)
    pump.start()
    try:
        data = json.loads(base64.b64decode(job.get("input_b64", "")).decode("utf-8"))
        num_designs = int(data.get("num_designs") or 1)
        spec_paths = []
        for spec in cfg.get("specs", []):
            p = workdir / Path(str(spec["name"])).name
            p.write_text(str(spec["content"]))
            spec_paths.append(str(p))
        if not spec_paths:
            raise RuntimeError("design run has no spec")

        # execute_command reads this per-call, so set it just before running.
        os.environ["BOLTZGEN_PROGRESS_FILE"] = str(progress_file)
        argv = ["run", *spec_paths, "--output", str(out_dir),
                "--num_designs", str(num_designs), "--device_ids", device,
                "--protocol", cfg.get("protocol", "protein-anything")]
        if cfg.get("steps"):
            argv += ["--steps", *cfg["steps"]]
        if cfg.get("fast"):
            argv.append("--fast")
        if cfg.get("moldir"):
            argv += ["--moldir", str(cfg["moldir"])]
        if data.get("seed") is not None:
            argv += ["--seed", str(data["seed"])]

        from tt_bio.boltzgen.cli.boltzgen import build_parser, run_command
        run_command(build_parser().parse_args(argv))  # reuses get_device(); no cold-open
        outputs = _read_outputs(out_dir, _shared_outputs_dir(cfg))
        row.update({"status": "ok", "num_designs": num_designs,
                    "runtime_s": round(time.time() - t0, 1)})
    except Exception as exc:
        traceback.print_exc()
        row["error"] = _err_text(exc)
    finally:
        stop.set()
        pos[0] = _forward_design_progress(progress_file, pos[0], emit)  # flush the tail
        shutil.rmtree(workdir, ignore_errors=True)
        os.environ.pop("BOLTZGEN_PROGRESS_FILE", None)
        gc.collect()  # drop the design models' host refs; the chip stays open

    try:
        client.complete(
            run_id, worker_id, row,
            {**meta, "event": "done", "name": job_id, "status": row["status"],
             "time": round(time.time() - t0, 1), "error": row.get("error", ""), "row": row},
            outputs=outputs or None,
        )
    except Exception:
        traceback.print_exc()


def _execute_rfd3_job_inprocess(
    client: ControllerClient,
    run_id: str,
    worker_id: str,
    worker_info: dict[str, Any],
    meta: dict[str, Any],
    job: dict[str, Any],
    cfg: dict[str, Any],
) -> None:
    """Run one RFD3 design shard IN-PROCESS on this worker's persistent device.

    Same reuse pattern as the BoltzGen shard path: rfd3.design.run_design loads
    its modules on get_device(), which returns this worker's already-open chip —
    no per-shard cold-open. One shard owns ALL designs of its spec (they share
    the featurize + TokenInitializer pass and batch bit-identically), so the
    shard payload is just {spec_id, num_designs}; the spec JSON and the input
    structure's content ride in cfg (fleet-safe, no shared filesystem needed).
    """
    import threading
    job_id = job["id"]
    t0 = time.time()

    def emit(event: str, **kw):
        try:
            client.event(run_id, worker_id, {"event": event, **meta, **kw})
        except Exception:
            pass

    workdir = Path(tempfile.mkdtemp(prefix=f"tt-bio-rfd3-{job_id}-"))
    out_dir = workdir / "out"
    row: dict[str, Any] = {"id": job_id, "status": "failed"}
    outputs: dict[str, str] = {}
    emit("start", name=job_id)

    # The sampler has no step hook, so while the shard runs silently, relay a
    # periodic liveness event — the orchestrator's log keeps growing (its stall
    # watchdog stays fed) and the UI sees the job is alive.
    stop = threading.Event()

    def _beat():
        while not stop.wait(15.0):
            emit("progress", name=job_id, elapsed_s=round(time.time() - t0, 1))

    beat = threading.Thread(target=_beat, daemon=True)
    beat.start()
    try:
        data = json.loads(base64.b64decode(job.get("input_b64", "")).decode("utf-8"))
        spec_id = str(data["spec_id"])
        num_designs = int(data.get("num_designs") or 1)

        structures: dict[str, str] = {}
        for s in cfg.get("structures", []):
            p = workdir / Path(str(s["name"])).name
            p.write_text(str(s["content"]))
            structures[str(s["name"])] = str(p)
        specs: dict[str, dict] = {}
        for s in cfg.get("specs", []):
            doc = json.loads(str(s["content"]))
            for sid, spec in doc.items():
                spec = dict(spec)
                inp = spec.get("input")
                if inp is not None:
                    local = structures.get(Path(str(inp)).name)
                    if local is None:
                        raise RuntimeError(f"spec {sid!r}: input {inp!r} was not shipped")
                    spec["input"] = local
                specs[str(sid)] = spec
        if spec_id not in specs:
            raise RuntimeError(f"design run has no spec for {spec_id!r}")

        from tt_bio.main import ensure_rfd3_weights
        from tt_bio.rfd3.design import run_design
        cache = Path(os.environ.get("BOLTZ_CACHE", str(Path("~/.boltz").expanduser())))
        checkpoint_dir = ensure_rfd3_weights(cache)
        results = run_design(
            {spec_id: specs[spec_id]}, out_dir,
            checkpoint_dir=checkpoint_dir, from_pdb=True,
            num_timesteps=int(cfg.get("num_timesteps") or 4),
            seed=int(cfg.get("seed") or 42),
            partial_t=cfg.get("partial_t"),
            cfg_scale=cfg.get("cfg_scale"),
            fp32_residual=bool(cfg.get("fp32_residual")),
            fast=bool(cfg.get("fast")),
            num_designs=num_designs,
            batch_size=int(cfg.get("batch_size") or 8),
            verbose=False,
        )
        if not results:
            raise RuntimeError("no designs were produced")
        outputs = _read_outputs(out_dir, _shared_outputs_dir(cfg))
        row.update({"status": "ok", "num_designs": len(results),
                    "runtime_s": round(time.time() - t0, 1)})
    except Exception as exc:
        traceback.print_exc()
        row["error"] = _err_text(exc)
    finally:
        stop.set()
        shutil.rmtree(workdir, ignore_errors=True)
        gc.collect()  # drop the design modules' host refs; the chip stays open

    try:
        client.complete(
            run_id, worker_id, row,
            {**meta, "event": "done", "name": job_id, "status": row["status"],
             "time": round(time.time() - t0, 1), "error": row.get("error", ""), "row": row},
            outputs=outputs or None,
        )
    except Exception:
        traceback.print_exc()



def _execute_pxdesign_job_inprocess(
    client: ControllerClient,
    run_id: str,
    worker_id: str,
    worker_info: dict[str, Any],
    meta: dict[str, Any],
    job: dict[str, Any],
    cfg: dict[str, Any],
) -> None:
    """Run one PXDesign shard IN-PROCESS on this worker's persistent device.

    A shard is a SLICE of the run (first/count/total): n_sample is a batch axis, so the card
    makes its designs in one trajectory rather than one per job.
    Same reuse pattern as the RFD3 shard path: pxdesign.design.run_design loads its
    model on get_device(), which returns this worker's already-open chip, so no shard
    cold-opens a device. Unlike RFD3 a shard is ONE design, not a whole spec — the
    payload is {stem, seed} and the target YAML plus its structure ride in cfg, so
    workers need no shared filesystem.
    """
    import threading
    job_id = job["id"]
    t0 = time.time()

    def emit(event: str, **kw):
        try:
            client.event(run_id, worker_id, {"event": event, **meta, **kw})
        except Exception:
            pass

    workdir = Path(tempfile.mkdtemp(prefix=f"tt-bio-pxdesign-{job_id}-"))
    out_dir = workdir / "out"
    row: dict[str, Any] = {"id": job_id, "status": "failed"}
    outputs: dict[str, str] = {}
    emit("start", name=job.get("name") or job_id)

    # The sampler has no step hook, so relay a periodic liveness event while the shard
    # runs silently — keeps the orchestrator's stall watchdog fed.
    stop = threading.Event()

    def _beat():
        while not stop.wait(15.0):
            emit("progress", name=job.get("name") or job_id,
                 elapsed_s=round(time.time() - t0, 1))

    beat = threading.Thread(target=_beat, daemon=True)
    beat.start()
    try:
        data = json.loads(base64.b64decode(job.get("input_b64", "")).decode("utf-8"))
        stem = str(data.get("stem") or job_id)
        seed = int(data.get("seed") or 0)
        row["name"] = stem          # the CIF this shard writes; the client collects by it

        for s in cfg.get("structures", []):
            (workdir / Path(str(s["name"])).name).write_text(str(s["content"]))
        target = cfg.get("target") or {}
        if not target.get("content"):
            raise RuntimeError("design run shipped no target YAML")
        # Rewrite target.file to the copy just landed here: the submitting host's path
        # means nothing on this worker.
        import yaml
        doc = yaml.safe_load(str(target["content"])) or {}
        named = Path(str((doc.get("target") or {}).get("file") or "")).name
        if not named:
            raise RuntimeError("target YAML has no target.file")
        doc["target"]["file"] = str(workdir / named)
        target_path = workdir / (Path(str(target.get("name") or "target.yaml")).name)
        target_path.write_text(yaml.safe_dump(doc, sort_keys=False))

        from tt_bio.pxdesign.design import run_design
        cache = Path(os.environ.get("BOLTZ_CACHE", str(Path("~/.boltz").expanduser())))
        count = int(data.get("count") or 1)
        first = int(data.get("first") or 0)
        total = int(data.get("total") or count)
        rows = run_design(target_path, out_dir, cache, count,
                          int(cfg.get("n_step") or 400), seed, stem=stem,
                          first_index=first, total_designs=total, verbose=False)
        if not rows:
            raise RuntimeError("no designs were produced")
        outputs = _read_outputs(out_dir, _shared_outputs_dir(cfg))
        # fit_rmsd is the end-to-end correctness signal and the platform shows it per
        # design, so it rides back on the row rather than being recomputed from the CIF
        # (which no longer holds the target it was fitted against).
        row.update({"status": "ok", "num_designs": len(rows),
                    "names": [Path(r["cif"]).stem for r in rows],
                    "fit_rmsd": rows[0].get("fit_rmsd"),
                    "binder_residues": rows[0].get("binder_residues"),
                    "binder_atoms": rows[0].get("binder_atoms"),
                    "conditioned_tokens": rows[0].get("conditioned_tokens"),
                    "runtime_s": round(time.time() - t0, 1)})
    except Exception as exc:
        traceback.print_exc()
        row["error"] = _err_text(exc)
    finally:
        stop.set()
        shutil.rmtree(workdir, ignore_errors=True)
        gc.collect()  # drop the design model's host refs; the chip stays open

    try:
        client.complete(
            run_id, worker_id, row,
            {**meta, "event": "done", "name": row.get("name") or job_id,
             "status": row["status"], "time": round(time.time() - t0, 1),
             "error": row.get("error", ""), "row": row},
            outputs=outputs or None,
        )
    except Exception:
        traceback.print_exc()


def _execute_rfd4_job_inprocess(
    client: ControllerClient,
    run_id: str,
    worker_id: str,
    worker_info: dict[str, Any],
    meta: dict[str, Any],
    job: dict[str, Any],
    cfg: dict[str, Any],
) -> None:
    """Run one RFD4 design IN-PROCESS on this worker's persistent device.

    A shard is a SLICE of a run: the payload carries the annotated CIF the submitter built, a
    stem, a seed, and ``first``/``count``/``total`` naming which designs of the run this card
    makes, so the worker needs neither the spec nor the structures it names. The slice is run as
    one batched trajectory, which is what makes a card worth giving designs to at all (num_designs
    is RFD4's batch axis). The engine is kept
    on this worker across shards (``_RFD4_ENGINE``) — loading the bundle costs more than a small
    design, and a cold device open per shard is what deadlocked the UMD init path on the RFD3
    path, so the engine is built on the chip this worker already holds.
    """
    import threading
    job_id = job["id"]
    t0 = time.time()

    def emit(event: str, **kw):
        try:
            client.event(run_id, worker_id, {"event": event, **meta, **kw})
        except Exception:
            pass

    workdir = Path(tempfile.mkdtemp(prefix=f"tt-bio-rfd4-{job_id}-"))
    out_dir = workdir / "out"
    row: dict[str, Any] = {"id": job_id, "status": "failed"}
    outputs: dict[str, str] = {}
    emit("start", name=job.get("name") or job_id)

    # The sampler reports nothing until a design finishes, so relay a heartbeat; without it
    # the orchestrator's stall watchdog reads a long design as a hang.
    stop = threading.Event()

    def _beat():
        while not stop.wait(15.0):
            emit("progress", name=job.get("name") or job_id,
                 elapsed_s=round(time.time() - t0, 1))

    beat = threading.Thread(target=_beat, daemon=True)
    beat.start()
    try:
        from tt_bio import rfd4

        data = json.loads(base64.b64decode(job.get("input_b64", "")).decode("utf-8"))
        stem = str(data.get("stem") or job_id)
        seed = int(data.get("seed") or 0)
        row["name"] = stem
        row["example_id"] = data.get("example_id")
        if not data.get("cif"):
            raise RuntimeError("design shard shipped no annotated CIF")
        cif = workdir / f"{stem}.cif"
        cif.write_text(str(data["cif"]))

        engine = _rfd4_engine(cfg)
        tokens: list[int] = []
        count = int(data.get("count") or 1)
        first = int(data.get("first") or 0)
        total = int(data.get("total") or count)
        written = rfd4.design(cif, out_dir, num_designs=count, first_index=first,
                              total_designs=total, nsteps=cfg.get("nsteps"), seed=seed,
                              annotated_cif=True, engine=engine,
                              on_design=lambda _id, n, _cif: tokens.append(n))
        row.update({"status": "ok", "tokens": tokens[0] if tokens else None,
                    "names": [p.name[:-len("_generated.cif")] for p in written],
                    "runtime_s": round(time.time() - t0, 1)})
        outputs = _read_outputs(out_dir, _shared_outputs_dir(cfg))
    except Exception as exc:
        traceback.print_exc()
        row["error"] = _err_text(exc)
    finally:
        stop.set()
        shutil.rmtree(workdir, ignore_errors=True)
        gc.collect()  # drop host refs; the engine and the chip stay

    try:
        client.complete(
            run_id, worker_id, row,
            {**meta, "event": "done", "name": row.get("name") or job_id,
             "status": row["status"], "time": round(time.time() - t0, 1),
             "error": row.get("error", ""), "row": row},
            outputs=outputs or None,
        )
    except Exception:
        traceback.print_exc()


#: ((recipe, fast), engine) — the RFD4 engine this worker holds, reused across shards of a run.
_RFD4_ENGINE: tuple[Any, Any] = (None, None)


def _free_rfd4_engine() -> None:
    """Drop this worker's RFD4 engine, if it holds one. Called before a predict model loads."""
    global _RFD4_ENGINE
    if _RFD4_ENGINE[1] is not None:
        _RFD4_ENGINE = (None, None)
        gc.collect()


def _rfd4_engine(cfg: dict[str, Any]):
    """This worker's RFD4 engine, loading it on first use and on a recipe or `--fast` change.

    The recipe and the lever set (`--fast`) are what a run can change that the loaded engine
    carries, so they key the cache; everything else per design (seed, steps, the input) is an argument.
    """
    global _RFD4_ENGINE
    recipe, fast = cfg.get("recipe"), bool(cfg.get("fast"))
    if _RFD4_ENGINE[0] != (recipe, fast) or _RFD4_ENGINE[1] is None:
        from tt_bio.rfd4 import get_engine
        from tt_bio.tenstorrent import set_fast_mode

        _RFD4_ENGINE = (None, None)
        set_fast_mode(fast)   # read once, when the trunk picks its lever set
        _RFD4_ENGINE = ((recipe, fast), get_engine(**({"recipe": recipe} if recipe else {})))
    return _RFD4_ENGINE[1]


def _forward_design_progress(path: Path, pos: int, emit) -> int:
    """Tail BoltzGen's progress JSONL and relay each stage start to the
    controller as a 'stage' event, so the orchestrator (and the platform's
    progress bar) see the pipeline advance live. Returns the new read offset."""
    try:
        with open(path, "r") as f:
            f.seek(pos)
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    ev = json.loads(line)
                except Exception:
                    continue
                if ev.get("t") == "start" and ev.get("name"):
                    emit("stage", stage=ev["name"])
            return f.tell()
    except Exception:
        return pos


# Marks an output value as "the file is already where the client wants it" rather than
# base64 bytes. Only ever emitted after _shared_outputs_dir proves co-location.
SHARED_OUTPUT_PREFIX = "tt-bio-shared-path:"


def _shared_outputs_dir(cfg: dict[str, Any]) -> Path | None:
    """The client's own results directory, when this worker provably shares it.

    Routing bulk results back as base64 inside JSON costs more than the compute for
    embeddings: a 1024-sequence esmc run ships ~635 MB of per-residue arrays, inflated
    33% by base64, through one controller process while every card sits idle. When the
    worker and the client are the same filesystem the copy is pure waste.

    "Provably" matters. A worker on another machine can happily create the client's
    path and write into it, and the client would then find nothing -- so writability is
    not proof of sharing. The client leaves a nonce file in its results directory and
    names it here; seeing that exact file is what makes co-location certain.
    """
    share = cfg.get("shared_outputs")
    if not isinstance(share, dict):
        return None
    directory, token = share.get("dir"), share.get("token")
    if not directory or not token or os.sep in str(token):
        return None
    d = Path(directory)
    return d if (d / str(token)).is_file() else None


def _read_outputs(output_dir: Path, share_dir: Path | None = None) -> dict[str, str]:
    """Read every file in output_dir and return name -> base64 bytes.

    With ``share_dir`` set (see _shared_outputs_dir) each file is moved there instead
    and reported as a path, so the bytes never enter the controller. Any file that
    cannot be moved falls back to base64 individually, so a partial failure degrades
    to the old behaviour rather than losing an output.
    """
    outputs: dict[str, str] = {}
    if not output_dir.exists():
        return outputs
    for path in sorted(output_dir.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(output_dir).as_posix()
        if share_dir is not None:
            target = share_dir / rel
            try:
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(path), str(target))
                outputs[rel] = SHARED_OUTPUT_PREFIX + str(target)
                continue
            except Exception:
                pass  # fall through to base64 for this one file
        outputs[rel] = base64.b64encode(path.read_bytes()).decode("ascii")
    return outputs


def _complete_failure(
    client: ControllerClient,
    run_id: str,
    worker_id: str,
    meta: dict[str, Any],
    jobs: list[dict[str, Any]],
    error: str,
) -> None:
    """Mark each leased job as failed when worker setup itself fails."""
    for job in jobs:
        row = {"id": job["id"], "status": "failed", "error": error}
        try:
            client.complete(
                run_id,
                worker_id,
                row,
                {**meta, "event": "done", "name": job["id"], "status": "failed",
                 "time": 0, "error": error, "row": row},
            )
        except Exception:
            pass
