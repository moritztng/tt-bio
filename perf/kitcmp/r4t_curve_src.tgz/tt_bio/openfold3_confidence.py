"""OpenFold3 confidence heads (AF3 Algorithm 31) on Tenstorrent.

Ports ``aux_heads`` (PAE / PDE / pLDDT / distogram / experimentally_resolved) to device,
reusing the gated 4-block confidence ``Pairformer`` (``aux_heads.pairformer_embedding.
pairformer_stack``) for the confidence trunk's pair channel, and the Protenix-v2
``ConfidenceHead`` discipline (z-embedding + output heads host-fp32).

Hybrid confidence Pairformer (precision-motivated split):

  * **z-path on device (bf16, HiFi4 + fp32 dest acc)** -- the heavy pair compute
    (TriangleMultiplication / TriangleAttention / Transition on [N, N, 128]). Gates at
    zij_conf PCC 0.99624 vs the reference.
  * **s-path on host (fp32)** -- LN + AttentionPairBias + Transition on [N, 384]. The
    confidence Pairformer receives the trunk's raw final single ``si_trunk`` at ~196k
    magnitude (the reference passes it with NO glue/LayerNorm, unlike the trunk's own
    Pairformer which starts each cycle at s~187 via the s-glue). At 196k, bf16
    (resolution ~1024) corrupts the small per-block s-updates and the attention amplifies
    the error across the 4 blocks; the plddt / experimentally_resolved LayerNorm then
    strips the dominant residual and exposes the corruption. Running the s-path in fp32
    on host (fed the per-block device z for the pair bias) recovers it -- the s-track is
    light ([N, 384] attention) and the device keeps the heavy pair compute.

The host AttentionPairBias uses the reference formula (q scaled by 1/sqrt(c_hidden),
pair bias = ``linear_z(LN_z(z))`` with no further scaling), matching the fp32 golden.

The OF3 confidence Pairformer block layout is bit-identical to the trunk's
``pairformer_stack`` block (c_z=128, 4 tri-att heads, 16 attn-pair-bias heads,
c_hidden_pair_bias=24, c_s=384), so ``remap_pairformer_stack`` + ``Pairformer`` build it
with no new primitive code. The output heads differ from Protenix's layout (OF3 pLDDT /
resolved are a flat ``[N_tok, 23 * c_out]`` linear -> ``masked_select`` to atoms; PDE /
distogram symmetrise as ``L(z) + L(z).T``; distogram reads the trunk pair, not the
confidence-Pairformer output), so they are ported here rather than reused.

Validated vs the real OF3 reference golden
(``~/of3_ref_out.pkl["intermediates"]["confidence_heads_real"]``, captured by
``scripts/of3_confidence_golden.py``); see ``tests/test_openfold3_confidence.py`` for
per-head PCC.
"""

import math

import torch
import torch.nn.functional as F
import ttnn

from .tenstorrent import Pairformer, accurate_softmax_site, download, k1_linear, triatt_sdpa_hifi_site
from .openfold3_weights import remap_pairformer_stack

# aux_heads.pairformer_embedding distance bins (config.model_config).
_MIN_BIN, _MAX_BIN, _NO_BIN, _INF = 3.25, 50.75, 39, 1e8
_MAX_ATOMS_PER_TOKEN = 23
# Confidence pairformer dims (config.model_config.heads.pairformer_embedding.pairformer
# + attn_pair_bias: c_s=384, c_z=128, c_s_input=449, 16 attn-pair-bias heads, head_dim 24).
_C_S, _C_Z, _C_S_INPUT = 384, 128, 449
_APB_HEADS, _APB_HEAD_DIM = 16, 24
_BLK = "pairformer_embedding.pairformer_stack.blocks.%d."
# The device weights `forward_device` applies, as `_wd` will ask for them: (key, transpose,
# fp32). They are uploaded in `__init__` rather than on first use, because the optimizer's
# parameter set comes from `walk_device_weights`, the walk runs after a forward, and the forward
# it runs is INFERENCE -- which takes the host s-path and never calls `_wd`. So the cache these
# five heads live in was empty at every walk, and `aux_heads.distogram.linear.weight`, 2.8431 %
# of OpenFold3's squared gradient norm on its own, was absent from every optimizer this port has
# ever built. The weight was always on the card; nothing ever handed it to the tape.
#
# transpose=True is a Linear's weight, False a LayerNorm's gain or bias. The fp32 column is
# `_ln(..., fp32=True)` for the two atom heads and the bf16 pair track for the rest, which is
# the split the LayerNorm docstring below argues for on magnitude.
_DEVICE_HEAD_WEIGHTS = (
    ("pairformer_embedding.linear_i.weight", True, False),
    ("pairformer_embedding.linear_j.weight", True, False),
    ("pairformer_embedding.linear_distance.weight", True, False),
    ("distogram.linear.weight", True, False),
    ("pae.layer_norm.weight", False, False),
    ("pae.layer_norm.bias", False, False),
    ("pae.linear.weight", True, False),
    ("pde.layer_norm.weight", False, False),
    ("pde.layer_norm.bias", False, False),
    ("pde.linear.weight", True, False),
    ("plddt.layer_norm.weight", False, True),
    ("plddt.layer_norm.bias", False, True),
    ("plddt.linear.weight", True, True),
    ("experimentally_resolved.layer_norm.weight", False, True),
    ("experimentally_resolved.layer_norm.bias", False, True),
    ("experimentally_resolved.linear.weight", True, True),
)

# Which s-track the host-tensor entry point runs. "host" is torch fp32 and is
# what inference gates against; "device" is the differentiable one. Training
# does not read this -- it calls forward_device directly.
_S_PATH_DEFAULT = "host"


class OF3ConfidenceHead:
    """OF3 AF3-family confidence heads (device z-path + host-fp32 s-path).

    Args:
        aux_state_dict: ``aux_heads`` sub-state-dict (keys stripped of ``aux_heads.``).
        device: ttnn device.
        compute_kernel_config: HiFi4 + fp32 dest acc.
    """

    def __init__(self, aux_state_dict, device, compute_kernel_config):
        import re

        self._w = dict(aux_state_dict)
        self.dev = device
        self.compute_kernel_config = compute_kernel_config

        _pf_prefix = "pairformer_embedding.pairformer_stack"
        pf_sd = remap_pairformer_stack(self._w, prefix=_pf_prefix)
        _blk = re.compile(rf"^{re.escape(_pf_prefix)}\.blocks\.(\d+)\.")
        n_blocks = 1 + max(int(_blk.match(k).group(1)) for k in self._w if _blk.match(k))
        b0z = _BLK % 0 + "pair_stack."
        tri_att_n_heads = self._w[b0z + "tri_att_start.linear_z.weight"].shape[0]
        tri_att_head_dim = self._w[b0z + "tri_att_start.mha.linear_q.weight"].shape[0] // tri_att_n_heads
        apb0 = _BLK % 0 + "attn_pair_bias."
        att_n_heads = self._w[apb0 + "linear_z.weight"].shape[0]
        att_head_dim = self._w[apb0 + "mha.linear_q.weight"].shape[0] // att_n_heads
        # Pairformer holds the z-path sub-modules (and the s-path sub-modules, used by the
        # device path; the host path runs the s-track in fp32 via _host_s_block).
        # scale_pair_bias=True pre-bakes sqrt(d) into the TOKEN bias, which is what
        # AttentionPairBias needs to add it unscaled; tri_att_scale_pair_bias=False keeps the
        # TRIANGLE bias unbaked, which is what TriangleAttention needs for the same
        # convention. Both triangle attentions here are on the z-path this head's pae/pde
        # logits read, so the flag that fixes the s-track must not reach them.
        self.pf = Pairformer(n_blocks, tri_att_head_dim, tri_att_n_heads,
                             att_head_dim, att_n_heads, True, pf_sd, compute_kernel_config,
                             scale_pair_bias=True,
                             tri_att_scale_pair_bias=False,
                             fp32_softmax=True,
                             accurate_softmax=accurate_softmax_site("openfold3.confidence"),
                             # Default ON: the fused route moves no coordinate (this head runs
                             # after sampling) and at 730 tokens on Wormhole it takes 14 s off
                             # a 184 s fold (spd-of3 ab11c, 5 samples x 4 blocks).
                             tri_att_sdpa_hifi=triatt_sdpa_hifi_site("openfold3.confidence", True),
                             s_fp32_residual=True)
        self.n_blocks = n_blocks

        bins = torch.linspace(_MIN_BIN, _MAX_BIN, _NO_BIN, dtype=torch.float32)
        self._squared_bins = bins ** 2
        self._upper = torch.cat([self._squared_bins[1:], self._squared_bins.new_tensor([_INF])])
        # No `materialize_device_weights()` here: inference takes the host s-path and never
        # reads them, so uploading in `__init__` was 16 `from_torch` per fold for nothing. The
        # training adapter materialises them before its walk (`train/openfold3.py`).

    # The host path reads every weight through these three, so setting `_dtype` to
    # torch.float64 runs it in float64 WITHOUT a second implementation. PROTOCOL SS3c
    # wants a float64 reference that is not another approximation; the cheapest way to
    # be sure of that is for the reference and the shipped path to be one function.
    _dtype = torch.float32

    def _g(self, k):
        return self._w[k].to(self._dtype)

    def _bias(self, k):
        return self._w[k].to(self._dtype) if k in self._w else 0.0

    def _bw(self, i, name):
        return self._w[(_BLK % i) + name].to(self._dtype)

    def _pair_bias_device(self, z_d, i, N):
        """Block ``i``'s attention-pair bias, LN_z + linear_z in fp32 on device -> host [H, N, N]."""
        pfx = (_BLK % i) + "attn_pair_bias."
        f32 = ttnn.float32
        z32 = ttnn.typecast(z_d, f32)
        zn = ttnn.layer_norm(z32, weight=self._wd(pfx + "layer_norm_z.weight", False, f32),
                             bias=self._wd(pfx + "layer_norm_z.bias", False, f32), epsilon=1e-5,
                             compute_kernel_config=self.compute_kernel_config)
        ttnn.deallocate(z32)
        b = ttnn.linear(zn, self._wd(pfx + "linear_z.weight", True, f32),
                        compute_kernel_config=self.compute_kernel_config)
        ttnn.deallocate(zn)
        out = torch.Tensor(download(b)).float().reshape(N, N, _APB_HEADS).permute(2, 0, 1)
        ttnn.deallocate(b)
        return out

    def _host_s_block(self, s, z_host, i, s_mask=None, bias=None):
        """One host-fp32 s-path block: AttentionPairBias + Transition (reference formula).

        ``s`` is [N, c_s] fp32; ``z_host`` is the device-computed [N, N, c_z] pair for this
        block (brought host-side for the pair-bias LN+linear, which must match the
        reference's no-sqrt-scaling formula), unless ``bias`` [H, N, N] is passed already
        computed (:meth:`_pair_bias_device`). Returns the updated ``s``.

        ``s_mask`` is the reference's ``single_mask`` as a [N] float, or None. Upstream's
        AttentionPairBias adds ``inf * (mask - 1)`` to the scores over the key axis and its
        SwiGLUTransition multiplies its output by the mask; both are reproduced here.
        """
        pfx = "attn_pair_bias."
        a = F.layer_norm(s, (_C_S,), self._bw(i, pfx + "layer_norm_a.weight"),
                         self._bw(i, pfx + "layer_norm_a.bias"))
        if bias is None:
            zn = F.layer_norm(z_host, (_C_Z,), self._bw(i, pfx + "layer_norm_z.weight"),
                              self._bw(i, pfx + "layer_norm_z.bias"))
            bias = F.linear(zn, self._bw(i, pfx + "linear_z.weight")).permute(2, 0, 1)  # [H, N, N]
        q = F.linear(a, self._bw(i, pfx + "mha.linear_q.weight"),
                     self._bw(i, pfx + "mha.linear_q.bias"))
        k = F.linear(a, self._bw(i, pfx + "mha.linear_k.weight"))
        v = F.linear(a, self._bw(i, pfx + "mha.linear_v.weight"))
        N = a.shape[0]
        q = q.view(N, _APB_HEADS, _APB_HEAD_DIM).permute(1, 0, 2) / math.sqrt(_APB_HEAD_DIM)
        k = k.view(N, _APB_HEADS, _APB_HEAD_DIM).permute(1, 0, 2)
        v = v.view(N, _APB_HEADS, _APB_HEAD_DIM).permute(1, 0, 2)
        scores = torch.einsum("hqd,hkd->hqk", q, k) + bias
        if s_mask is not None:
            scores = scores + (s_mask.reshape(1, 1, N) - 1.0) * 1e9
        o = torch.einsum("hqk,hkd->hqd", F.softmax(scores, dim=-1), v)
        o = o.permute(1, 0, 2).reshape(N, _APB_HEADS * _APB_HEAD_DIM)
        g = torch.sigmoid(F.linear(a, self._bw(i, pfx + "mha.linear_g.weight")))
        o = F.linear(o * g, self._bw(i, pfx + "mha.linear_o.weight"))
        s = s + o
        # single_transition (SwiGLU)
        tpfx = "single_transition."
        xn = F.layer_norm(s, (_C_S,), self._bw(i, tpfx + "layer_norm.weight"),
                          self._bw(i, tpfx + "layer_norm.bias"))
        t = F.silu(F.linear(xn, self._bw(i, tpfx + "swiglu.linear_a.weight"))) * \
            F.linear(xn, self._bw(i, tpfx + "swiglu.linear_b.weight"))
        t = F.linear(t, self._bw(i, tpfx + "linear_out.weight"))
        if s_mask is not None:
            t = t * s_mask.reshape(-1, 1)
        s = s + t
        return s


    # ------------------------------------------------------------------
    # Device path. Everything from the trunk outputs to the head logits is a
    # ttnn verb, so a tape following those verbs carries a confidence-loss
    # gradient back into the trunk. The host path below is the same arithmetic
    # with the s-track in torch fp32; it is kept for inference and it SEVERS
    # the graph, which is why training does not get to choose it.
    # ------------------------------------------------------------------

    def _wd(self, key, transpose=True, dtype=None):
        """Upload one weight once (TILE), cached. ``transpose`` for a Linear."""
        dtype = dtype or ttnn.bfloat16
        cache = self.__dict__.setdefault("_wd_cache", {})
        v = cache.get((key, transpose, dtype))
        if v is None:
            if key not in self._w:
                return None
            w = self._w[key].float()
            v = ttnn.from_torch(w.t().contiguous() if transpose else w,
                                layout=ttnn.TILE_LAYOUT, device=self.dev, dtype=dtype)
            cache[(key, transpose, dtype)] = v
            # A weight minted after `materialize_device_weights` ran is one the walk that
            # built the optimizer could not have seen, so it will train no matter what the
            # tape does. That is exactly the failure this table exists to close, and it comes
            # back the moment a caller hands `forward_device` an activation dtype the table
            # did not predict. Recorded rather than raised: raising would break the fp32
            # survey arms that legitimately pass float32 z. `late_device_weights()` is the
            # check, and the gradient measurement asserts it is empty.
            if self.__dict__.get("_wd_materialized"):
                self.__dict__.setdefault("_wd_late", []).append((key, transpose, str(dtype)))
        return v

    def materialize_device_weights(self):
        """Upload the heads' device weights now, so a walk can find them.

        Returns the number uploaded. `walk_device_weights` is what the optimizer's parameter
        set is built from and it only sees tensors a module is already holding, so a weight
        this head uploads lazily inside `forward_device` does not exist when the walk runs.
        Inference takes the host s-path and never calls `_wd` at all, which is why the cache
        was empty every time.
        """
        n = 0
        for key, transpose, fp32 in _DEVICE_HEAD_WEIGHTS:
            if self._wd(key, transpose, ttnn.float32 if fp32 else None) is not None:
                n += 1
        self._wd_materialized = True
        return n

    def late_device_weights(self):
        """Device weights minted after :meth:`materialize_device_weights`, as (key, transpose,
        dtype). Non-empty means the optimizer's parameter set is missing one."""
        return list(self.__dict__.get("_wd_late", ()))

    def _lin(self, x, key):
        w = self._wd(key, dtype=x.dtype if x.dtype == ttnn.float32 else None)
        return ttnn.linear(x, w, compute_kernel_config=self.compute_kernel_config)

    def distogram_device(self, z_d):
        """The trunk distogram L(z) + L(z).T on the card in fp32, read back as host [N, N, 64]: half
        the bytes of the [N, N, 128] trunk pair it replaces, and no host matmul."""
        N = int(z_d.shape[-2])
        zt = ttnn.typecast(z_d, ttnn.float32)
        # k1_linear: ttnn's own plan on Wormhole put single logits 64 off float64 (dgram_check, .113).
        dl = k1_linear(zt, self._wd("distogram.linear.weight", dtype=ttnn.float32),
                       compute_kernel_config=self.compute_kernel_config, dtype=ttnn.float32)
        ttnn.deallocate(zt)
        dt = ttnn.permute(dl, (0, 2, 1, 3))
        sym = ttnn.add(dl, dt)
        ttnn.deallocate(dt); ttnn.deallocate(dl)
        out = torch.Tensor(download(sym)).float().reshape(N, N, -1)
        ttnn.deallocate(sym)
        return out

    def _ln(self, x, prefix, fp32=False):
        """One head LayerNorm. ``fp32`` casts the input and the gain first.

        The two atom heads need it and the pair heads do not, and the reason is the
        magnitude of what they normalise. ``si_trunk`` reaches the confidence head raw,
        at absmax 2.28e5 with a per-row std of 1.6e4, so the variance a LayerNorm sums
        is of order 3e8; in bf16 that sum keeps 8 mantissa bits and the reciprocal
        square root it feeds is what the pLDDT logits ARE. The pair track arrives at
        absmax 1.1e3 and has no such problem. Measured: bf16 throughout puts
        plddt_logits at 2.44e-01 relative L2 against the host fp32 path, over the
        PROTOCOL SS3d 5.0e-02 per-tensor bar, while the pair heads read 6.2e-03 (pae)
        and 3.3e-03 (distogram) on the same run.
        """
        dt = ttnn.float32 if fp32 else None
        if fp32 and x.dtype != ttnn.float32:
            x = ttnn.typecast(x, ttnn.float32)
        return ttnn.layer_norm(x, weight=self._wd(prefix + ".layer_norm.weight", False, dt),
                               bias=self._wd(prefix + ".layer_norm.bias", False, dt),
                               epsilon=1e-5, compute_kernel_config=self.compute_kernel_config)

    def _distance_bins(self, repr_x_pred, onehot=False):
        """AF3 Algorithm 31 line 3's distance bin of every token pair, in ``self._dtype``.

        ``onehot`` gives the reference's [N, N, no_bin] one-hot, ``(d2 > lower) & (d2 < upper)``.
        Otherwise the bin index [N, N], with ``no_bin`` for a pair in no bin (on or below the first
        edge, or exactly on an edge, where both strict comparisons fail): the bins tile the line,
        so a one-hot row times a weight is the weight row this index picks."""
        x = repr_x_pred.to(self._dtype)
        d2 = torch.sum((x[..., None, :] - x[..., None, :, :]) ** 2, dim=-1)        # [N, N]
        lo, up = self._squared_bins.to(d2.dtype), self._upper.to(d2.dtype)
        if onehot:
            return ((d2[..., None] > lo) & (d2[..., None] < up)).to(self._dtype)
        k = torch.searchsorted(lo, d2.contiguous(), right=False) - 1              # lo[k] < d2 <= lo[k+1]
        ok = (k >= 0) & (d2 < up[k.clamp(min=0)])
        return torch.where(ok, k, torch.full_like(k, _NO_BIN))

    def distance_onehot(self, repr_x_pred):
        """The AF3 Algorithm 31 line-3 distance one-hot, host -> device.

        It is built on the host and uploaded as a CONSTANT, and that is a property of
        the loss rather than a shortcut: the confidence head is trained on a rolled-out
        structure that upstream detaches, so no gradient flows to ``repr_x_pred``. The
        one-hot is exact in bf16 (it is 0 and 1), so the upload costs no accuracy.
        """
        oh = self._distance_bins(repr_x_pred.float(), onehot=True).float()
        return ttnn.from_torch(oh.unsqueeze(0), layout=ttnn.TILE_LAYOUT, device=self.dev,
                               dtype=ttnn.bfloat16)

    def _z_embed_device(self, shared, si_input, repr_x_pred, use_zij_trunk_embedding=True):
        """AF3 Algorithm 31 lines 1-3 on device for one sample, bf16 [1, N, N, c_z].

        The host path's sums in the host path's order, in fp32, rounded to bf16 once as its
        upload did: the trunk pair is the fold's own device tensor (``shared["zij_trunk_d"]``, the
        bf16 the host copy came from), the two ``si_input`` projections are computed on the host in
        fp32 and go up once per fold, and the distance term is the linear_distance weight row of
        each pair's bin, looked up on device. Per sample only the bin indices cross, 4 B a pair
        where the host path uploaded the whole 128-channel pair. ``ttnn.embedding`` only takes a
        bf16 table, so the fp32 table goes up as a bf16 head and the bf16 of its remainder, looked
        up separately and summed in fp32: 16 mantissa bits, well under the final bf16 rounding."""
        f32 = ttnn.float32
        N = int(si_input.shape[0])
        if "z_ij_d" not in shared:
            up = lambda x, **kw: ttnn.from_torch(x.contiguous(), dtype=f32, device=self.dev, **kw)
            pe = "pairformer_embedding."
            li = F.linear(si_input, self._g(pe + "linear_i.weight"))
            lj = F.linear(si_input, self._g(pe + "linear_j.weight"))
            table = torch.cat([self._g(pe + "linear_distance.weight").t().float(),
                               torch.zeros(1, _C_Z)])                             # row no_bin = no bin
            hi = table.to(torch.bfloat16)
            lo = (table - hi.float()).to(torch.bfloat16)
            bf = lambda x: ttnn.from_torch(x.contiguous(), dtype=ttnn.bfloat16, device=self.dev,
                                           layout=ttnn.ROW_MAJOR_LAYOUT)
            shared["z_ij_d"] = (up(li.reshape(1, N, 1, _C_Z), layout=ttnn.TILE_LAYOUT),
                                up(lj.reshape(1, 1, N, _C_Z), layout=ttnn.TILE_LAYOUT),
                                (bf(hi), bf(lo)))
        li_d, lj_d, tables_d = shared["z_ij_d"]
        z = ttnn.typecast(shared["zij_trunk_d"], f32)
        if not use_zij_trunk_embedding:
            z = ttnn.multiply_(z, 0.0)
        z = ttnn.add_(ttnn.add_(z, li_d), lj_d)
        k = self._distance_bins(repr_x_pred).reshape(1, N * N).to(torch.int32)
        k_d = ttnn.from_torch(k, dtype=ttnn.uint32, layout=ttnn.ROW_MAJOR_LAYOUT, device=self.dev)
        for table_d in tables_d:
            e = ttnn.embedding(k_d, table_d, layout=ttnn.ROW_MAJOR_LAYOUT,
                               memory_config=ttnn.DRAM_MEMORY_CONFIG)             # [1, N*N, c_z]
            et = ttnn.to_layout(ttnn.reshape(e, (1, N, N, _C_Z)), ttnn.TILE_LAYOUT)
            ttnn.deallocate(e)
            e32 = ttnn.typecast(et, f32)
            ttnn.deallocate(et)
            z = ttnn.add_(z, e32)
            ttnn.deallocate(e32)
        ttnn.deallocate(k_d)
        zb = ttnn.typecast(z, ttnn.bfloat16)
        ttnn.deallocate(z)
        return zb

    def forward_device(self, si_input_d, si_trunk_d, zij_trunk_d, oh_d,
                       use_zij_trunk_embedding=True, pair_mask_d=None, attn_mask_d=None):
        """Confidence forward with every tensor on device. The training entry point.

        Shapes are batched-by-one so the shipped ``PairformerLayer`` takes them unchanged:
        ``si_input_d`` [1, N, 449], ``si_trunk_d`` [1, N, 384], ``zij_trunk_d``
        [1, N, N, 128], ``oh_d`` [1, N, N, 39] from :meth:`distance_onehot`.

        Two outputs differ in LAYOUT from the host path, and neither loses information.
        ``plddt_logits`` and ``experimentally_resolved_logits`` come back as
        [1, N_tok, 23 * c_out] rather than gathered to [N_atom, c_out]: the gather is
        ``masked_select`` on a fixed per-batch mask, which on device is either a
        one-hot matmul the size of the token axis squared or a row-major round trip,
        and it buys nothing -- a loss that reads the padded layout with the atom mask
        as its weight computes the same number. :meth:`forward` does the gather for
        inference, where the [N_atom, c_out] shape is what the caller wants.
        """
        N = int(zij_trunk_d.shape[-2])
        pe = "pairformer_embedding."
        z = zij_trunk_d if use_zij_trunk_embedding else ttnn.multiply(zij_trunk_d, 0.0)
        # Out-of-place: zij_trunk_d is the trunk's own output and the distogram head
        # reads it again below. An in-place add here would corrupt both.
        z = ttnn.add(z, ttnn.reshape(self._lin(si_input_d, pe + "linear_i.weight"),
                                     (1, N, 1, _C_Z)))
        z = ttnn.add(z, ttnn.reshape(self._lin(si_input_d, pe + "linear_j.weight"),
                                     (1, 1, N, _C_Z)))
        z = ttnn.add(z, self._lin(oh_d, pe + "linear_distance.weight"))

        # The reference masks this Pairformer (single_mask=repr_x_mask,
        # pair_mask=token_mask outer token_mask); running it unmasked lets every padded token
        # into every k-axis reduction and every softmax key axis, which is the whole of
        # aux_heads' A18 failure (perf/of3t_auxfind/). Both default to None, so the shipped
        # default is unchanged and every existing caller computes the same function.
        #
        # These two masks are the whole repair, which is not obvious: upstream also zeroes both
        # transitions' output on padded positions (_mask_trans, base_blocks.py:453) and the
        # shipped PairformerLayer masks neither. It does not matter. Both transitions are
        # pointwise over the token axis, so that write only ever lands on padded positions, and
        # every op that mixes tokens is masked here. Measured, not argued: upstream 0.4.3 in
        # float64 with _mask_trans=False against the same tree with it True differs by 7.4e+02
        # on the padded rows of z and EXACTLY 0.0 on the real block, on all five heads
        # (perf/of3t_auxfind/arm_p.json, arm P).
        s, z = self.pf(si_trunk_d, z, pair_mask_d, attn_mask_d, attn_mask_d)

        dlog = self._lin(zij_trunk_d, "distogram.linear.weight")
        distogram_logits = ttnn.add(dlog, ttnn.permute(dlog, (0, 2, 1, 3)))
        pae_logits = self._lin(self._ln(z, "pae"), "pae.linear.weight")
        plog = self._lin(self._ln(z, "pde"), "pde.linear.weight")
        pde_logits = ttnn.add(plog, ttnn.permute(plog, (0, 2, 1, 3)))
        plddt_logits = self._lin(self._ln(s, "plddt", fp32=True), "plddt.linear.weight")
        resolved_logits = self._lin(self._ln(s, "experimentally_resolved", fp32=True),
                                    "experimentally_resolved.linear.weight")
        return {
            "plddt_logits": plddt_logits,
            "experimentally_resolved_logits": resolved_logits,
            "pae_logits": pae_logits,
            "pde_logits": pde_logits,
            "distogram_logits": distogram_logits,
            "si_conf": s,
            "zij_conf": z,
        }

    def forward(self, si_input, si_trunk, zij_trunk, repr_x_pred,
                max_atom_per_token_mask, use_zij_trunk_embedding=True,
                s_path=None, dtype=None, token_mask=None, single_mask=None, shared=None,
                return_pair=False, bin_vectors=None):
        """Confidence forward -> dict of head logits (host fp32) + the confidence
        Pairformer (si_conf, zij_conf).

        Inputs are host fp32 tensors:
            si_input:  [N_tok, 449]
            si_trunk:  [N_tok, 384]
            zij_trunk: [N_tok, N_tok, 128]
            repr_x_pred: [N_tok, 3]   representative atom coords per token
            max_atom_per_token_mask: [N_tok * 23] broadcast of token_mask to atom slots
            use_zij_trunk_embedding: reference eval-mode flag (True -> keep zij_trunk)
            token_mask: [N_tok] float/bool, or None. The reference passes
                ``pair_mask = token_mask outer token_mask`` into the confidence Pairformer;
                with None this runs unmasked, which is only equal to the reference when every
                token is real. Pass it whenever the token axis carries padding.
            single_mask: [N_tok], the reference's ``repr_x_mask``. Defaults to ``token_mask``.
            bin_vectors: [64, K] host fp32, fp32 inference only. The pae / pde heads then stay
                on the card through their softmax and come back as ``pae_proj`` [N, N, K] =
                softmax(pae) @ bin_vectors and ``pde_proj`` [N, N] = softmax(pde) @ column 0,
                instead of two [N, N, 64] fp32 logit tensors (134 MB at 512 tokens).
            shared: a dict the caller keeps across the samples of one fold (same trunk
                inputs); the sample-independent z-embedding and distogram are computed into
                it once. None computes them for this call alone.

        Returns:
            plddt_logits:                [N_atom, 50]
            experimentally_resolved_logits: [N_atom, 2]
            pae_logits:      [N_tok, N_tok, 64]
            pde_logits:      [N_tok, N_tok, 64]
            distogram_logits: [N_tok, N_tok, 64]
            si_conf:         [N_tok, 384]   (confidence Pairformer single, host-fp32)
            zij_conf:        [N_tok, N_tok, 128] (device z-path output); in fp32 inference
                             None unless ``return_pair`` (it is not otherwise pulled)
        """
        N = si_trunk.shape[0]
        self._dtype = dtype or torch.float32
        if (s_path or _S_PATH_DEFAULT) == "device":
            to_dev = lambda x, dt=ttnn.bfloat16: ttnn.from_torch(
                x.float().unsqueeze(0), layout=ttnn.TILE_LAYOUT, device=self.dev, dtype=dt)
            out = self.forward_device(
                to_dev(si_input), to_dev(si_trunk, ttnn.float32), to_dev(zij_trunk),
                self.distance_onehot(repr_x_pred),
                use_zij_trunk_embedding=use_zij_trunk_embedding)
            host = {k: torch.Tensor(ttnn.to_torch(v)).float() for k, v in out.items()}
            m = max_atom_per_token_mask.bool()
            for name, c_out in (("plddt_logits", 50), ("experimentally_resolved_logits", 2)):
                host[name] = host[name].reshape(N * _MAX_ATOMS_PER_TOKEN, c_out)[m]
            for name in ("pae_logits", "pde_logits", "distogram_logits", "zij_conf"):
                host[name] = host[name].reshape(N, N, -1)
            host["si_conf"] = host["si_conf"].reshape(N, _C_S)
            return host

        # --- z-embedding (host, AF3 Algorithm 31 lines 1-3) ---
        # The trunk terms are the same for every sample of a fold: `shared` carries them from the
        # first sample's call to the next (same ops on the same inputs, so the same bits).
        si_input, si_trunk = si_input.to(self._dtype), si_trunk.to(self._dtype)
        repr_x_pred = repr_x_pred.to(self._dtype)
        if shared is None:
            shared = {}
        # zij_trunk None: the trunk pair is shared["zij_trunk_d"], read back only by a host path.
        host_z = lambda: (zij_trunk if zij_trunk is not None else torch.Tensor(
            ttnn.to_torch(shared["zij_trunk_d"])).float().reshape(N, N, -1)).to(self._dtype)
        # In fp32 inference the pair never comes back to the host: each block's attention bias
        # (LN_z + linear_z, 16 channels) and the pae / pde heads run on device in fp32, and only
        # their outputs cross. The float64 reference keeps the whole pair on the host.
        device_pair = self._dtype == torch.float32
        to_dev = lambda x: ttnn.from_torch(x.float(), layout=ttnn.TILE_LAYOUT, device=self.dev,
                                           dtype=ttnn.bfloat16)
        if device_pair and shared.get("zij_trunk_d") is not None:
            z_d, z = self._z_embed_device(shared, si_input, repr_x_pred, use_zij_trunk_embedding), None
        else:
            if "z_trunk" not in shared:
                z = host_z() if use_zij_trunk_embedding else host_z() * 0.0
                shared["z_trunk"] = (
                    z
                    + F.linear(si_input, self._g("pairformer_embedding.linear_i.weight")).unsqueeze(-2)
                    + F.linear(si_input, self._g("pairformer_embedding.linear_j.weight")).unsqueeze(-3))
            z = shared["z_trunk"] + F.linear(self._distance_bins(repr_x_pred, onehot=True),
                                             self._g("pairformer_embedding.linear_distance.weight"))
            z_d = to_dev(z.unsqueeze(0))

        # The reference masks the confidence Pairformer; running it unmasked lets padded tokens
        # into every k-axis reduction and every softmax key axis. pair_mask goes to the two
        # triangle multiplications and to the pair transition's output, the additive -1e9
        # companion to the two triangle attentions, and single_mask to the host s-path.
        pm_d = attn_d = None
        s_mask = None
        if token_mask is not None:
            tm = torch.as_tensor(token_mask).reshape(-1).float()
            s_mask = (tm if single_mask is None
                      else torch.as_tensor(single_mask).reshape(-1).float())
            pm_d = to_dev((tm[:, None] * tm[None, :]).reshape(1, N, N))
            pm_u = ttnn.unsqueeze(pm_d, -1)
            attn_d = to_dev(((1.0 - tm) * -1e9).reshape(1, 1, 1, N))
        s = si_trunk.clone()
        zf = z
        for i, blk in enumerate(self.pf.blocks):
            u = blk.triangle_multiplication_start(z_d, pm_d); z_d = ttnn.add_(z_d, u); ttnn.deallocate(u)
            u = blk.triangle_multiplication_end(z_d, pm_d);   z_d = ttnn.add_(z_d, u); ttnn.deallocate(u)
            u = blk.triangle_attention_start(z_d, attn_d);    z_d = ttnn.add_(z_d, u); ttnn.deallocate(u)
            u = blk.triangle_attention_end(z_d, attn_d);      z_d = ttnn.add_(z_d, u); ttnn.deallocate(u)
            u = blk.transition_z(z_d)
            if pm_d is not None:
                u = ttnn.multiply_(u, pm_u)
            z_d = ttnn.add_(z_d, u); ttnn.deallocate(u)
            if device_pair:
                s = self._host_s_block(s, None, i, s_mask, bias=self._pair_bias_device(z_d, i, N))
            else:
                zf = torch.Tensor(ttnn.to_torch(z_d)).float().reshape(N, N, _C_Z)
                s = self._host_s_block(s, zf, i, s_mask)
        s_single = s

        # --- output heads (host fp32) ---
        # Distogram reads the TRUNK pair (reference: computed before the confidence
        # Pairformer), symmetrised as L(z) + L(z).T (no LayerNorm).
        if "distogram" not in shared:
            if device_pair and shared.get("zij_trunk_d") is not None:
                shared["distogram"] = self.distogram_device(shared["zij_trunk_d"])
            else:
                dlog = F.linear(host_z(), self._g("distogram.linear.weight"))
                shared["distogram"] = dlog + dlog.transpose(-2, -3)
        distogram_logits = shared["distogram"]

        if device_pair and bin_vectors is not None:
            z32 = ttnn.typecast(z_d, ttnn.float32)
            w_d = ttnn.from_torch(bin_vectors.float().reshape(1, 1, *bin_vectors.shape),
                                  layout=ttnn.TILE_LAYOUT, device=self.dev, dtype=ttnn.float32)
            proj = {}
            for h in ("pae", "pde"):
                lg = self._lin(self._ln(z32, h, fp32=True), h + ".linear.weight")
                if h == "pde":
                    lt = ttnn.permute(lg, (0, 2, 1, 3))
                    sym = ttnn.add(lg, lt)
                    ttnn.deallocate(lt); ttnn.deallocate(lg)
                    lg = sym
                pr = ttnn.softmax(lg, dim=-1, numeric_stable=True,
                                   compute_kernel_config=self.compute_kernel_config)
                ttnn.deallocate(lg)
                pj = ttnn.matmul(pr, w_d, compute_kernel_config=self.compute_kernel_config)
                ttnn.deallocate(pr)
                proj[h] = torch.Tensor(ttnn.to_torch(pj)).float().reshape(N, N, -1)
                ttnn.deallocate(pj)
            ttnn.deallocate(w_d)
            ttnn.deallocate(z32)
            zij_conf = (torch.Tensor(ttnn.to_torch(z_d)).float().reshape(N, N, _C_Z)
                        if return_pair else None)
            ttnn.deallocate(z_d)
            pae_logits = pde_logits = None
        elif device_pair:
            z32 = ttnn.typecast(z_d, ttnn.float32)
            pae_logits, plog = (
                torch.Tensor(ttnn.to_torch(self._lin(self._ln(z32, h, fp32=True), h + ".linear.weight")))
                .float().reshape(N, N, -1) for h in ("pae", "pde"))
            ttnn.deallocate(z32)
            zij_conf = (torch.Tensor(ttnn.to_torch(z_d)).float().reshape(N, N, _C_Z)
                        if return_pair else None)
            ttnn.deallocate(z_d)
        else:
            zij_conf = zf
            pae_logits = F.linear(
                F.layer_norm(zij_conf, (_C_Z,)) * self._g("pae.layer_norm.weight") + self._bias("pae.layer_norm.bias"),
                self._g("pae.linear.weight"))
            plog = F.linear(
                F.layer_norm(zij_conf, (_C_Z,)) * self._g("pde.layer_norm.weight") + self._bias("pde.layer_norm.bias"),
                self._g("pde.linear.weight"))
        if bin_vectors is None or not device_pair:
            pde_logits = plog + plog.transpose(-2, -3)

        plddt_logits = self._atom_head(s_single, "plddt", max_atom_per_token_mask, 50)
        exp_resolved_logits = self._atom_head(s_single, "experimentally_resolved",
                                              max_atom_per_token_mask, 2)

        return {
            "plddt_logits": plddt_logits,
            "experimentally_resolved_logits": exp_resolved_logits,
            "pae_logits": pae_logits,
            "pde_logits": pde_logits,
            "distogram_logits": distogram_logits,
            "si_conf": s_single,
            "zij_conf": zij_conf,
            **({"pae_proj": proj["pae"], "pde_proj": proj["pde"][..., 0]}
               if device_pair and bin_vectors is not None else {}),
        }

    def _atom_head(self, s_single, name, max_atom_per_token_mask, c_out):
        """pLDDT / experimentally_resolved: Linear(LN(s)) -> [N_tok, 23*c_out] -> reshape
        to [N_tok*23, c_out] -> masked_select to [N_atom, c_out]."""
        ln = F.layer_norm(s_single, (_C_S,)) * self._g(f"{name}.layer_norm.weight") \
            + self._bias(f"{name}.layer_norm.bias")
        logits = F.linear(ln, self._g(f"{name}.linear.weight"))  # [N_tok, 23*c_out]
        n_tok = s_single.shape[0]
        logits = logits.reshape(n_tok * _MAX_ATOMS_PER_TOKEN, c_out)
        return logits[max_atom_per_token_mask.bool()]  # [N_atom, c_out]
