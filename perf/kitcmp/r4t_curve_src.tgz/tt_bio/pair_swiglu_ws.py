"""``fc3(silu(x @ w1) * (x @ w2))`` over a pair tensor, weights resident in L1, one Tensix program.

RFD3's token pair Transition (c_z 128, hidden 256 or 512) runs as fc1, fc2, a gate multiply and fc3 over 64-row
chunks: about 6.3 ms a call in fast mode against ~2 ms of work at the roof. Every core here holds `[w1 | w2]` and
`w3` in L1 for the whole call and takes whole 32-row tiles of the flattened pair tensor: x is read once, the
output written once, and fc1, fc2 and their product never leave the core (kernels/pair_swiglu_ws).

The engine's shared `_transition_swiglu_sharded` does not serve this shape: it needs the output width to split
over 8 core columns, and 128 channels are 4 tiles.

The output is bfloat16; x bfloat16 or bfloat8_b; the weights bfloat16, or bfloat8_b where bf16 weights would not fit L1 (c_z 256,
hidden 1024: 768 weight tiles are 1.5 MB in bf16, 0.8 MB in bfp8). The norm is the caller's op, or with `ln` the
kernel's prologue (kernels/common/ln_prologue.hpp, as trimul T1/T2), so the normalised x never reaches DRAM.

`pair_relu` is the same program for AF2's Transition, ``fc2(relu(x @ w1 + b1)) + b2``: one weight matrix in front of
the activation instead of two, and each bias seeds its matmul's dest.
"""

from __future__ import annotations

from pathlib import Path

import struct

import torch
import ttnn

from . import core_split
from . import ops

KERNEL_DIR = Path(__file__).resolve().parent / "kernels" / "pair_swiglu_ws"
X_CB, W12_CB, W3_CB, GATE_CB, HID_CB, OUT_CB = 0, 1, 2, 3, 4, 16
XRAW_CB, GAMMA_CB, BETA_CB, SCALER_CB = 5, 8, 9, 10     # the LayerNorm prologue's bf16 CBs
LN_F32_CBS = ((11, 1), (12, 1), (13, 1), (14, 1), (17, None), (18, None))   # eps, mean, var, rstd, xc, tmp (None: kt)
ACC_CB = 19               # fp32, _SW tiles: a matmul's K chunks summed by the packer (`l1acc`)
RES_CB = 20               # bf16, 2 row tiles of the residual fc3 adds into (`resid`)
B1_CB, B3_CB = 21, 22     # bf16, `pair_relu`'s biases as row-replicated tiles
DY_CB = 23                # bf16, 2 row tiles of `pair_relu_bw`'s cotangent
ZB_CB, PW_CB, ONE_CB, SQ_CB, PB_CB = 6, 7, 15, 28, 30   # `pb`: z', W^T, ones, z'^2, the head-row tiles
RES2_CB = 24              # bf16, the second residual (`resid2`), as deep as RES_CB
OUTB_CB = 25              # bf16, `pair_relu`'s copy of its float32 residual sum (`resid` float32)
LIST_CB_R, LIST_CB_W = 26, 27   # uint32, a core's page of the `rows` work list (reader, writer)
_NUM_CBS = 64             # unpack_to_dest_mode is indexed by CB id
_TILE = 32 * 32 * 2
_SW = 4                   # hidden tiles per dest pass (one fp32 dest half)
# Bytes of a core's L1 the program may take: weights plus its streaming CBs. A Wormhole core has 1464 KiB,
# a Blackhole core 1536 KiB; the rest is the firmware, the kernel binaries and ttnn's own reserve.
_L1_BUDGET = 1100 * 1024


def _ln_budget() -> int:
    """The budget a plan with the LayerNorm prologue checks against. On Blackhole it is T1's rule, 0.85 of the
    allocator's bank (1242496 B on a p150a), which T1 holds in the same trunk: ESMFold2's c_z 256 bfp8 transition
    with the prologue and its residual takes 1230848 B. Wormhole takes the same rule under `ws_ln_t1l1` (1186110 B of
    a Galaxy chip's 1395424 B bank), where Protenix-v2's --fast c_z 256 bfp8 plan takes 1181696 B; else it keeps
    `_L1_BUDGET`. Plans without the prologue keep `_L1_BUDGET` on both arches, so no other chunking or routing moves."""
    from .tenstorrent import _l1_bank_bytes, is_wormhole, lever
    if is_wormhole() and not lever("ws_ln_t1l1"):
        return _L1_BUDGET
    return max(_L1_BUDGET, int(0.85 * _l1_bank_bytes()))


# One core reads the weights from DRAM and multicasts them to the grid, where every core would otherwise read all of them
# (110 x 256 KB a call for AF2's c_z 128 transition: 0.069 of its 0.33 ms on a p300c). Same bytes in the same CBs.
# Only where the program fills the whole grid rectangle. torch.equal to the per-core read on both arches (Blackhole:
# perf/bc4_swiglu/mcast_ab.py on wk/bc4-bet-swiglu; Wormhole: perf/spd_m_opendde/wmc_ab.py, OpenDDE's c_z 384 transition
# 20.95 -> 20.05 ms at 640 tokens, 6.18 -> 5.26 ms at 320, 1000 MHz). False forces the per-core read, for A/B.
WEIGHTS_MCAST = True


SILU_POLY = 2  # ws5 on WH 1000 MHz: c_z 128 fast 5.64 -> 4.77 ms, c_z 256 13.08 -> 11.28, rel_rms to float64 unchanged


def _tile_bytes(dtype) -> int:
    return 1088 if dtype == ttnn.bfloat8_b else 2 * _TILE if dtype == ttnn.float32 else _TILE
_CACHE: dict = {}


def weights(w1: torch.Tensor, w2: torch.Tensor, w3: torch.Tensor, device, dtype=ttnn.bfloat16):
    """`[w1 | w2]` ([C, 2H]) and `w3` ([H, C]) as `dtype` TILE tensors, from torch [in, out] matrices, in as few
    hidden chunks as keep each chunk's weights inside the L1 budget: a list of (w12, w3) pairs whose
    `pair_swiglu` outputs sum to the whole. One pair wherever the weights fit (c_z 128; c_z 256 in bfp8); c_z 256
    in bf16 and OpenDDE's c_z 384 take two or more, each re-reading x."""
    up = lambda t: ttnn.from_torch(t.contiguous(), dtype=dtype, layout=ttnn.TILE_LAYOUT,  # noqa: E731
                                   device=device)
    kt, ct = w1.shape[0] // 32, w3.shape[1] // 32
    out, i = [], 0
    for h in hidden_chunks(kt, w1.shape[1] // 32, ct, dtype):
        j = i + 32 * h
        out.append((up(torch.cat([w1[:, i:j], w2[:, i:j]], 1)), up(w3[i:j])))
        i = j
    return out


def hidden_chunks(kt, nh, ct, dtype) -> list[int]:
    """Hidden tiles per chunk: the fewest chunks whose largest fits `_L1_BUDGET`, each a multiple of `_SW` and the
    larger ones first. Ragged where `_SW` units do not divide evenly: Mol-1's c_z 448 in bfp8 takes 16, 16, 12, 12
    tiles where equal chunks need seven of 8, and every chunk re-reads x and the running partial."""
    units = nh // _SW
    for p in range(1, units + 1):
        q, r = divmod(units, p)
        sizes = [(q + (n < r)) * _SW for n in range(p)]
        if _l1_bytes(kt, sizes[0], ct, dtype) <= _L1_BUDGET:
            return sizes
    return [nh]


def ln_bytes(kt) -> int:
    """The LayerNorm prologue's extra L1: raw x (2 kt), gamma, beta (kt each), the scaler and the fp32 CBs, less the
    normed x going single-buffered (kt of `_l1_bytes`' 2 kt): compute alone fills and drains it."""
    return (3 * kt + 1) * _TILE + (4 + 2 * kt) * 2 * _TILE


def _ln_vec_ok(v, k) -> bool:
    """gamma / beta as `torch_to_tt` leaves a bf16 norm parameter: TILE, interleaved, k values in row 0."""
    return (v.dtype == ttnn.bfloat16 and v.layout == ttnn.TILE_LAYOUT and int(v.shape[-1]) == k
            and all(int(d) == 1 for d in list(v.shape)[:-1])
            and v.memory_config().memory_layout == ttnn.TensorMemoryLayout.INTERLEAVED)


def _res_depth(base, ct, n_res) -> int:
    """Row tiles each residual CB holds: 2 (read ahead) where both fit beside `base` bytes, else 1. OpenDDE's normal
    c_z 384 chunk takes two residuals only single-buffered (1.163 MB against the 1.100 MB budget)."""
    return 2 if base + n_res * 2 * ct * _TILE <= _L1_BUDGET else 1


# WS_RES_X on; False runs `x + f(LN(x))` with the residual re-read into c_20 (perf/spd_m_protenix6/resx_parity.py's
# bit-identity reference only).
RES_X = True


def _res_x(x, ln, resid, resid2) -> bool:
    """The prologue's raw x row is the residual (`x + f(LN(x))`): fc3 seeds from it in c_5 (WS_RES_X), no c_20."""
    return RES_X and bool(ln) and resid is x and resid2 is None


def eligible(x, w12, w3, ln=(), l1acc=False, resid=None, resid2=None) -> bool:
    """bfloat16 TILE interleaved x, bf16/bfp8 TILE interleaved weights, hidden a multiple of 4 tiles, output
    width at most 4 tiles or a multiple of 2, and the weights plus the streaming CBs inside `_L1_BUDGET`. With
    `ln` = (gamma, beta) also the LayerNorm prologue (beta None: RMSNorm): bf16 x, bf16 [1, C] gamma / beta, and its
    CBs in budget. `l1acc` adds its fp32 accumulator CB; `resid` (bf16, TILE, interleaved DRAM, the output's padded
    shape) its two row tiles; `resid2` (same form, needs `resid`) one or two row tiles beside it."""
    if resid2 is not None and resid is None:
        return False
    if x.dtype not in (ttnn.bfloat16, ttnn.bfloat8_b) or w12.dtype != w3.dtype \
            or w12.dtype not in (ttnn.bfloat16, ttnn.bfloat8_b):
        return False
    for t in (x, w12, w3):
        if t.layout != ttnn.TILE_LAYOUT or t.memory_config().memory_layout != ttnn.TensorMemoryLayout.INTERLEAVED:
            return False
    kt, ct = int(x.padded_shape[-1]) // 32, int(w3.shape[-1]) // 32
    nh = int(w3.shape[0]) // 32
    if not (kt == int(w12.shape[0]) // 32 and int(w12.shape[1]) == 2 * int(w3.shape[0])
            and nh % _SW == 0 and (ct <= 4 or ct % 2 == 0)):
        return False
    if ln and (x.dtype != ttnn.bfloat16 or not all(_ln_vec_ok(v, 32 * kt) for v in ln if v is not None)):
        return False
    for r in (resid, resid2):
        if r is not None and not (
                r.dtype == ttnn.bfloat16 and r.layout == ttnn.TILE_LAYOUT
                and r.memory_config().memory_layout == ttnn.TensorMemoryLayout.INTERLEAVED
                and r.memory_config().buffer_type == ttnn.BufferType.DRAM
                and [int(d) for d in r.padded_shape] == [int(d) for d in x.padded_shape][:-1] + [32 * ct]):
            return False
    base = (_l1_bytes(kt, nh, ct, w12.dtype, x.dtype) + (ln_bytes(kt) if ln else 0)
            + (_SW * 2 * _TILE if l1acc else 0))
    n_res = (resid is not None and not _res_x(x, ln, resid, resid2)) + (resid2 is not None)
    return base + n_res * _res_depth(base, ct, n_res) * ct * _TILE <= (_ln_budget() if ln else _L1_BUDGET)


def _l1_bytes(kt, nh, ct, wdtype, xdtype=ttnn.bfloat16) -> int:
    return ((kt * 2 * nh + nh * ct) * _tile_bytes(wdtype) + 2 * kt * _tile_bytes(xdtype)
            + (2 * _SW + 2 * nh + 2 * ct) * _TILE)


def _build(x, w12, w3, out, device, mt, kt, nh, ct, fidelity, defines, silu_poly, ln, bias=None, bw=False,
           resid2=None, rows=None, pb=None):
    g = device.compute_with_storage_grid_size()
    num_cores, grid, cg1, cg2, work1, work2 = core_split.split_work_to_cores(g, mt, 0)

    def cb(idx, tiles, dtype=ttnn.bfloat16):
        size = _tile_bytes(dtype)
        fmt = ttnn.CBFormatDescriptor(buffer_index=idx, data_format=dtype, page_size=size)
        return ttnn.CBDescriptor(total_size=tiles * size, core_ranges=grid, format_descriptors=[fmt])

    cbs = [cb(X_CB, 2 * kt, x.dtype), cb(W3_CB, nh * ct, w3.dtype), cb(HID_CB, 2 * nh), cb(OUT_CB, 2 * ct)]
    if bias is None or bw:
        cbs += [cb(W12_CB, kt * 2 * nh, w12.dtype), cb(GATE_CB, 2 * _SW)]
    if bw:
        cbs += [cb(B1_CB, nh), cb(DY_CB, 2 * kt)]
        defines = tuple(defines) + (("WS_RELU_BW", "1"),)
    elif bias is not None:
        cbs += [cb(W12_CB, kt * nh, w12.dtype), cb(B1_CB, nh), cb(B3_CB, ct)]
        defines = tuple(defines) + (("WS_RELU", "1"),)
    if ("WS_L1ACC", "1") in defines:
        cbs.append(cb(ACC_CB, _SW, ttnn.float32))
    res32 = ("WS_RES32", "1") in defines
    nocopy = ("WS_RES_NOCOPY", "1") in defines
    if res32:
        # One row tile deep each: the float32 residual, the float32 sum and its bf16 copy. The normed x and the hidden,
        # which compute alone fills and drains, go single-buffered to pay for them (same L1 as without). NOCOPY: the
        # residual is x and the sum bf16, no copy.
        rd = x.dtype if nocopy else ttnn.float32       # bfloat8_b under pair_bfp8z (WS_Z8)
        cbs = ([cb(X_CB, kt, x.dtype), cb(W3_CB, nh * ct, w3.dtype), cb(HID_CB, nh), cb(OUT_CB, ct, rd)]
               + ([] if nocopy else [cb(OUTB_CB, ct)]) + [cb(RES_CB, ct, rd)] + cbs[4:])
    elif ("WS_RESID", "1") in defines and ("WS_RES_X", "1") not in defines:
        base = (_l1_bytes(kt, nh, ct, w12.dtype, x.dtype) + (ln_bytes(kt) if ln is not None else 0)
                + (_SW * 2 * _TILE if ("WS_L1ACC", "1") in defines else 0))
        depth = _res_depth(base, ct, 1 + (resid2 is not None)) * ct
        cbs += [cb(RES_CB, depth)] + ([] if resid2 is None else [cb(RES2_CB, depth)])
    scaler = eps_bits = 0
    if ln is not None:
        import struct
        # The normalised x the matmuls read, bf16. One row deep: the packer writes it only after the unpacker has
        # popped the last row, and the math thread cannot start that row's norm earlier anyway. Bit-identical.
        cbs[0] = cb(X_CB, kt)
        cbs += [cb(XRAW_CB, 2 * kt, x.dtype), cb(GAMMA_CB, kt), cb(BETA_CB, kt), cb(SCALER_CB, 1)]
        cbs += [cb(i, kt if n is None else n, ttnn.float32) for i, n in LN_F32_CBS]
        inv = struct.unpack("<I", struct.pack("<f", 1.0 / (32 * kt)))[0] >> 16
        scaler = (inv << 16) | inv          # 1/K as a packed bf16 pair, exact for K a power of two
        eps_bits = struct.unpack("<I", struct.pack("<f", float(ln[2])))[0]
        defines = tuple(defines) + (("WS_LN", "1"),)
    mcast = WEIGHTS_MCAST and num_cores == g.x * g.y and num_cores > 1
    rd, cp, wr = ttnn.RuntimeArgs(), ttnn.RuntimeArgs(), ttnn.RuntimeArgs()
    first = ordinal = 0
    for group, per in ((cg1, work1), (cg2, work2)):
        for cr in group.ranges():
            for cx in range(cr.start.x, cr.end.x + 1):
                for cy in range(cr.start.y, cr.end.y + 1):
                    f = ordinal if rows is not None else first   # under `rows`: the core's page of the list
                    cp[cx][cy] = wr[cx][cy] = [f, per]
                    rd[cx][cy] = [f, per, int(cx == 0 and cy == 0)]
                    first += per
                    ordinal += 1
    assert first == mt, (first, mt)
    assert rows is None or int(rows.shape[0]) == num_cores, (rows.shape, num_cores)
    mc_args, sems = [], []
    if mcast:
        phys = lambda x, y: device.worker_core_from_logical_core(ttnn.CoreCoord(x, y))  # noqa: E731
        lo, hi = phys(0, 0), phys(g.x - 1, g.y - 1)
        mc_args = [lo.x, lo.y, hi.x, hi.y, num_cores, (lo.x << 16) | lo.y]
        sems = [ttnn.SemaphoreDescriptor(id=i, core_ranges=grid, initial_value=0) for i in (0, 1)]
        defines = tuple(defines) + (("WS_MCAST", "1"),)
    rct = [kt, nh, ct, scaler, eps_bits]
    for t in ((x, w12, w3) + (() if ln is None else ln[:2]) + ((out,) if ("WS_RESID", "1") in defines else ())
              + (() if resid2 is None else (resid2,)) + (() if bias is None else bias)):
        rct.extend(ttnn.TensorAccessorArgs(t).get_compile_time_args())
    wct = [ct] + list(ttnn.TensorAccessorArgs(out).get_compile_time_args())
    if res32 and not nocopy:
        wct += list(ttnn.TensorAccessorArgs(x).get_compile_time_args())
    rdef = wdef = cdef = list(defines)
    if pb is not None:
        # WS_PB: z' again in c_16's format, W^T, ones, z'^2, a row tile's [heads, 32] tile for the writer to scatter
        cbs += [cb(ZB_CB, ct, out.dtype), cb(PW_CB, kt), cb(ONE_CB, 1), cb(SQ_CB, kt), cb(PB_CB, 2)]
        dd = dict(defines)
        rdef = rdef + [("WS_PB_ARGS", str(len(rct))), ("WS_PB_WSLOT", str(9 + len(mc_args)))]
        rct = rct + list(ttnn.TensorAccessorArgs(pb[0]).get_compile_time_args())
        wdef = wdef + [("WS_PB_ARGS", str(len(wct)))]
        wct = wct + [int(dd["WS_PB_NT"]), int(dd["WS_PB_HO"]), int(dd["WS_PB_HV"])] + list(
            ttnn.TensorAccessorArgs(pb[1][0]).get_compile_time_args())
    if rows is not None:
        page = int(rows.shape[1]) * 4
        lfmt = lambda i: ttnn.CBFormatDescriptor(buffer_index=i, data_format=ttnn.uint32, page_size=page)  # noqa: E731
        cbs += [ttnn.CBDescriptor(total_size=page, core_ranges=grid, format_descriptors=[lfmt(i)])
                for i in (LIST_CB_R, LIST_CB_W)]
        lb = [("WS_LIST_BYTES", str(page))]
        rdef = rdef + lb + [("WS_ROWLIST", str(len(rct)))]
        wdef = wdef + lb + [("WS_ROWLIST", str(len(wct)))]
        cdef = cdef + [("WS_ROWLIST", "1")]
        rct.extend(ttnn.TensorAccessorArgs(rows).get_compile_time_args())
        wct.extend(ttnn.TensorAccessorArgs(rows).get_compile_time_args())
        mc_args = mc_args or [0] * 6        # the list's common args sit at fixed slots after them
    src = lambda n: str(KERNEL_DIR / n)  # noqa: E731
    path = ttnn.KernelDescriptor.SourceType.FILE_PATH
    reader = ttnn.KernelDescriptor(kernel_source=src("reader.cpp"), source_type=path, core_ranges=grid,
                                   compile_time_args=rct, runtime_args=rd,
                                   common_runtime_args=[0] * 9 + mc_args + ([] if pb is None else [0]),
                                   defines=rdef, config=ttnn.ReaderConfigDescriptor())
    writer = ttnn.KernelDescriptor(kernel_source=src("writer.cpp"), source_type=path, core_ranges=grid,
                                   compile_time_args=wct, runtime_args=wr,
                                   common_runtime_args=[0, 0] + ([] if pb is None else [0] * len(pb[1])),
                                   defines=wdef, config=ttnn.WriterConfigDescriptor())
    ccfg = ttnn.ComputeConfigDescriptor(math_fidelity=fidelity, fp32_dest_acc_en=True)
    if res32 and not nocopy:   # the float32 residual straight to dest: through srcA it would lose 13 mantissa bits
        modes = [ttnn.UnpackToDestMode.Default] * _NUM_CBS
        modes[RES_CB] = ttnn.UnpackToDestMode.UnpackToDestFp32
        ccfg.unpack_to_dest_mode = modes
    compute = ttnn.KernelDescriptor(
        kernel_source=src("compute.cpp"), source_type=path, core_ranges=grid, compile_time_args=[kt, nh, ct, silu_poly],
        runtime_args=cp, common_runtime_args=[0, 0] if rows is not None else [], defines=cdef, config=ccfg)
    return [reader, writer, compute], cbs, sems, mc_args


def pair_swiglu(x, w12, w3, fidelity=ttnn.MathFidelity.HiFi4, defines=(), silu_poly=None, ln=None, l1acc=False,
                resid=None, resid2=None, pack_silu=False, rows=None, resid_src=None):
    """`fc3(silu(x @ w1) * (x @ w2))` for a TILE `x` [..., C]; a new bfloat16 DRAM tensor [..., C_out].

    Accumulation is fp32 in dest at every fidelity; `fidelity` is the caller's matmul fidelity. `defines` are
    the kernels' WS_NO_* time-attribution switches (perf/spd_fastmode/ws_attr.py), empty in production.
    `silu_poly` picks the silu: 0 metal's silu_tile, whose fp32-dest exp + reciprocal was ~85 % of the kernel on WH
    (c_z 128: 8.97 ms with it, 1.37 ms without), 1 sigmoid_poly.hpp's degree-8 polynomial (sigmoid within 3e-4),
    2 its degree-6 one with fp16 coefficients (7.4e-4, a third fewer SFPU instructions). None takes `SILU_POLY`.
    `ln` = (gamma, beta, eps) runs the LayerNorm over the raw bf16 `x` in the kernel first; gamma / beta bf16 TILE
    [1, C] as `torch_to_tt` leaves a norm parameter. beta None makes it an RMSNorm, as ttnn.rms_norm.
    `l1acc`: every matmul sums at most 2 K tiles in dest and the packer adds the chunks in an fp32 CB. On Wormhole an
    fp32 dest summing all of K writes exact +-1 / 2 / 4 into ~1e-8 of the outputs (tt_bio/dest_guard.py).
    `resid`: fc3's result is added to `resid` in the fp32 dest and written back over it, one bf16 rounding, and
    `resid` is returned; no new tensor. `resid` may be `x` itself (`x + f(x)`, with `ln` reading the raw x): each
    core's reader takes a row tile's x and residual pages before the writer can put that row tile back, and no row
    tile is read by two cores. With hidden chunks (`weights` returning more than one pair) only the last call may
    take `resid is x`, the others would read the updated rows.
    `resid2` (with `resid`): fc3 accumulates onto `resid + resid2`, both added exactly into the fp32 dest, and the sum
    is written over `resid`: one rounding for `z + partial + t`. The last hidden chunk of a chained transition takes
    z as `resid` and the chain's partial sum as `resid2`, so the residual add is not a pass of its own.
    `pack_silu`: the polynomial silu runs from the packer thread and fc1 of the next hidden group is issued before fc2,
    so the FPU's matmuls overlap the SFPU's silu (WS_PACK_SILU in the compute kernel); bit-identical. Also with `ln`
    and `l1acc`; ignored with metal's silu.
    `rows` = `row_list(...)`: only those row tiles are computed and written, every other row tile of the output keeps
    what it held. Each row tile's result is the one the full call writes, bit for bit.
    `resid_src` (with `resid`): the residual is read from `resid_src`, a tensor of `resid`'s form, and `resid` is only
    written: `resid = resid_src + f(x)` out of place."""
    if resid is not None:
        defines = tuple(defines) + (("WS_RESID", "1"),)
    if resid2 is not None:
        assert resid is not None
        defines = tuple(defines) + (("WS_RESID2", "1"),)
    silu_poly = SILU_POLY if silu_poly is None else silu_poly
    if pack_silu and silu_poly in (1, 2):
        defines = tuple(defines) + (("WS_PACK_SILU", "1"),)
    if l1acc:
        defines = tuple(defines) + (("WS_L1ACC", "1"),)
    if ln is not None and ln[1] is None:
        ln = (ln[0], ln[0], ln[2])   # the reader loads a beta either way; the RMS prologue never reads it
        defines = tuple(defines) + (("WS_RMS", "1"),)
    assert resid_src is None or resid is not None
    if resid_src is None and _res_x(x, ln, resid, resid2):
        defines = tuple(defines) + (("WS_RES_X", "1"),)
    return _run(x, w12, w3, fidelity, defines, silu_poly, ln, resid, resid2=resid2, rows=rows, resid_src=resid_src)


def row_list(device, x, rows):
    """`pair_swiglu`'s `rows` over `x` (a tensor, or its padded shape): the row tiles `rows` (flattened row tile indices, 32 rows of x's flattened
    leading dims each), sorted and dealt round-robin to the cores the program splits over, as a uint32 ROW_MAJOR
    [ncores, P] DRAM tensor (P a multiple of 16, so each core's page is 64-byte aligned). Returns (tensor, n)."""
    mt = 1
    for d in list(x if isinstance(x, (list, tuple)) else x.padded_shape)[:-1]:
        mt *= int(d)
    mt //= 32
    ncores = core_split.split_work_to_cores(device.compute_with_storage_grid_size(), mt, 0)[0]
    rows = torch.as_tensor(rows, dtype=torch.int64).sort().values
    n = int(rows.numel())
    p = -(-mt // ncores)
    p += -p % 16
    tab = torch.zeros(ncores * p, dtype=torch.int64)
    k = torch.arange(n)
    tab[(k % ncores) * p + k // ncores] = rows
    return ttnn.from_torch(tab.view(ncores, p).to(torch.int32), dtype=ttnn.uint32, layout=ttnn.ROW_MAJOR_LAYOUT,
                           device=device, memory_config=ttnn.DRAM_MEMORY_CONFIG), n


@ops.fused_kernel("pair_relu")
def pair_relu(x, w1, b1, w2, b2, fidelity=ttnn.MathFidelity.HiFi4, ln=None, bw_weights=None, resid=None, pb=None):
    """AF2's Transition after its norm, `relu(x @ w1 + b1) @ w2 + b2`, for a bf16 TILE `x` [..., C]; a new bf16 DRAM
    tensor [..., C_out]. Weights as `relu_weights` returns them. `ln` = (gamma, beta, eps) runs the LayerNorm in the
    kernel first, as `pair_swiglu`. Same fp32 dest accumulation, the bias summed into it before the products.

    `resid` (float32, x's shape): the residual stream x is the bf16 copy of. The result is added to it in the fp32 dest
    (one float32 rounding, the update never rounded to bf16) and written back over `resid`, and the sum's bf16 copy
    over `x`; returns `(resid, x)`. Each row tile of x is read before its sum is written, by the same core.
    `resid` may also be `x` itself (bf16, RFD4's `pair_bf16z` stream): the sum is rounded once to bf16 and written over
    `x`; returns `(x, x)`.

    `pb` = (wt, eps, heads, n_out), with `resid is x` (the bf16 / bfp8 pair stream, square [B, n, n, C], n a tile
    multiple, no padding): the program
    also returns `dit_pair_bias.rms_pair_bias(z', wt, eps, heads, n_out)` of the z' it writes, computed on the core
    from the tiles it just made, so that call's read of z' goes. Each row tile's 32 head values land as 32 B rows of
    the bias tiles, so the core split and row order stay the default. Returns `(x, x, biases)`, biases a list of n_out [B, heads, n, n].

    Under a tape it runs only through its entry in `taped_ttnn` (`pair_relu`), which needs `bw_weights`
    (`relu_bw_weights`) and `ln`; otherwise it returns None and the caller's composed ops run."""
    if ops.declines_under_tape("pair_relu"):
        return None
    if pb is not None:
        assert pb_eligible(x) and resid is x, "pb needs pb_eligible(x) and the in-place pair stream"
        wt, eps, heads, n_out = pb
        bits = lambda f: "0x%08x" % struct.unpack("<I", struct.pack("<f", f))[0]  # noqa: E731
        ho = 32 // n_out
        assert heads <= ho, (heads, n_out)
        B, n = int(x.padded_shape[0]), int(x.padded_shape[1])
        outs = [ttnn.allocate_tensor_on_device(ttnn.Shape([B, heads, n, n]), ttnn.bfloat16, ttnn.TILE_LAYOUT,
                                               x.device(), ttnn.DRAM_MEMORY_CONFIG) for _ in range(n_out)]
        pbd = (("WS_PB", "1"), ("WS_PB_NT", str(n // 32)), ("WS_PB_HO", str(ho)), ("WS_PB_HV", str(heads)),
                     ("WS_PB_INVC", bits(1.0 / int(x.padded_shape[-1]))), ("WS_PB_EPS", bits(float(eps))))
        defines = (("WS_RESID", "1"), ("WS_RES32", "1"), ("WS_RES_NOCOPY", "1")) + (
            (("WS_Z8", "1"),) if x.dtype == ttnn.bfloat8_b else ()) + pbd
        _run(x, w1, w2, fidelity, defines, SILU_POLY, ln, resid, (b1, b2), pb=(wt, outs))
        return resid, x, outs
    if resid is not None:
        # generic_op hands back a new handle over resid's buffer; the caller keeps its own two
        defines = (("WS_RESID", "1"), ("WS_RES32", "1")) + ((("WS_RES_NOCOPY", "1"),) if resid is x else ()) + (
            (("WS_Z8", "1"),) if x.dtype == ttnn.bfloat8_b else ())
        _run(x, w1, w2, fidelity, defines, SILU_POLY, ln, resid, (b1, b2))
        return resid, x
    return _run(x, w1, w2, fidelity, (), SILU_POLY, ln, None, (b1, b2))


def pb_eligible(x) -> bool:
    """`pair_relu(pb=...)` takes x: [B, n, n, C] with n a tile multiple and no padding, on Wormhole only: its writer
    places 32 B rows in DRAM, which Wormhole's 32 B DRAM alignment allows and Blackhole's 64 B does not."""
    from .tenstorrent import is_wormhole
    ps, ls = [int(d) for d in x.padded_shape], [int(d) for d in x.shape]
    return is_wormhole() and len(ps) == 4 and ps == ls and ps[1] == ps[2] and ps[2] % 32 == 0


def relu_weights(w1: torch.Tensor, b1: torch.Tensor, w2: torch.Tensor, b2: torch.Tensor, device,
                 dtype=ttnn.bfloat16):
    """(w1, b1, w2, b2) for `pair_relu` from torch [in, out] matrices and [out] biases: TILE tensors, the matrices in
    `dtype` (bfloat16, or bfloat8_b where bf16 would not fit L1: RFD4's c_z 384, hidden 768), the biases bf16 and
    repeated over the 32 rows of their tiles (dest is seeded with whole tiles)."""
    up = lambda t, d=ttnn.bfloat16: ttnn.from_torch(t.contiguous(), dtype=d, layout=ttnn.TILE_LAYOUT,  # noqa: E731
                                                    device=device)
    return up(w1, dtype), up(b1.reshape(1, -1).expand(32, -1)), up(w2, dtype), up(b2.reshape(1, -1).expand(32, -1))


def relu_eligible(x, w1, w2, ln=(), resid=None) -> bool:
    """What `pair_relu` serves: bf16 TILE interleaved x, bf16 or bfp8 weights (both the same), hidden a multiple of 4
    tiles, output width at most 4 tiles or a multiple of 4, and everything resident inside `_L1_BUDGET`. `resid` (float32
    TILE interleaved DRAM, x's padded shape, or `x` itself) as `pair_relu` takes it, in the same L1."""
    # a bfp8 x only as pair_bfp8z's z, its own residual under the LayerNorm
    if not (x.dtype == ttnn.bfloat16 or x.dtype == ttnn.bfloat8_b and resid is x and ln) or w1.dtype != w2.dtype or w1.dtype not in (ttnn.bfloat16, ttnn.bfloat8_b):
        return False
    for t in (x, w1, w2):
        if t.layout != ttnn.TILE_LAYOUT or t.memory_config().memory_layout != ttnn.TensorMemoryLayout.INTERLEAVED:
            return False
    kt, nh, ct = int(x.padded_shape[-1]) // 32, int(w2.shape[0]) // 32, int(w2.shape[-1]) // 32
    if not (kt == int(w1.shape[0]) // 32 and int(w1.shape[1]) == 32 * nh and nh % _SW == 0
            and (ct <= 4 or ct % 4 == 0)):
        return False
    if ln and not all(_ln_vec_ok(v, 32 * kt) for v in ln):
        return False
    if resid is not None and not (
            (resid.dtype == ttnn.float32 or resid is x) and resid.layout == ttnn.TILE_LAYOUT and ct == kt
            and resid.memory_config().memory_layout == ttnn.TensorMemoryLayout.INTERLEAVED
            and resid.memory_config().buffer_type == ttnn.BufferType.DRAM
            and x.memory_config().buffer_type == ttnn.BufferType.DRAM
            and [int(d) for d in resid.padded_shape] == [int(d) for d in x.padded_shape]):
        return False
    return ((kt * nh + nh * ct) * _tile_bytes(w1.dtype) + (nh + ct + 2 * kt + 2 * nh + 2 * ct) * _TILE
            + (ln_bytes(kt) if ln else 0) <= _L1_BUDGET)


def pair_relu_bw(x, dy, w12, b1, w3, fidelity=ttnn.MathFidelity.HiFi4, ln=None):
    """The cotangent of `pair_relu`'s normed input: `((xn @ w1 + b1 > 0) * (dy @ w2^T)) @ w1^T`, xn the LayerNorm of x
    under `ln` (else x itself), from `relu_bw_weights`. The pre-activation is recomputed from x, never stored. The
    LayerNorm's own backward is the caller's (`lnbw.layer_norm_bw`)."""
    return _run(x, w12, w3, fidelity, (), SILU_POLY, ln, None, (b1, dy), bw=True)


def relu_bw_weights(w1: torch.Tensor, w2: torch.Tensor, device):
    """(w12, w3) for `pair_relu_bw` from the torch [in, out] matrices: `[w1 | w2^T]` and `w1^T`, bf16 TILE."""
    up = lambda t: ttnn.from_torch(t.contiguous(), dtype=ttnn.bfloat16, layout=ttnn.TILE_LAYOUT,  # noqa: E731
                                   device=device)
    return up(torch.cat([w1, w2.t()], 1)), up(w1.t())


def _run(x, w12, w3, fidelity, defines, silu_poly, ln, resid, bias=None, bw=False, resid2=None, rows=None,
         resid_src=None, pb=None):
    device = x.device()
    xs = [int(d) for d in x.padded_shape]
    mt = 1
    for d in xs[:-1]:
        mt *= d
    mt //= 32
    kt, nh, ct = xs[-1] // 32, int(w3.shape[0]) // 32, int(w3.shape[-1]) // 32
    out = resid if resid is not None else ttnn.allocate_tensor_on_device(
        ttnn.Shape([int(d) for d in x.shape][:-1] + [int(w3.shape[-1])]), ttnn.bfloat16, ttnn.TILE_LAYOUT, device,
        ttnn.DRAM_MEMORY_CONFIG)
    key = (device.id(), tuple(xs), nh, ct, x.memory_config().buffer_type, fidelity, w12.dtype, x.dtype,
           tuple(defines), silu_poly, None if ln is None else float(ln[2]), bias is not None, bw, WEIGHTS_MCAST,
           None if rows is None else tuple(rows[0].shape))
    if key not in _CACHE:
        _CACHE[key] = _build(x, w12, w3, out, device, mt, kt, nh, ct, fidelity, defines, silu_poly, ln, bias, bw,
                             resid2, None if rows is None else rows[0], pb)
    kernels, cbs, sems, mc_args = _CACHE[key]
    g, b = (0, 0) if ln is None else (ln[0].buffer_address(), ln[1].buffer_address())
    b1, b3 = (0, 0) if bias is None else (bias[0].buffer_address(), bias[1].buffer_address())
    src = out if resid_src is None else resid_src
    extra = [] if resid_src is None else [resid_src]
    tail = []
    if rows is not None:
        lst, n = rows
        tail = [lst.buffer_address(), n, int(lst.shape[0])]
        kernels[2].common_runtime_args = tail[1:]
        extra.append(lst)
    kernels[0].common_runtime_args = [x.buffer_address(), w12.buffer_address(), w3.buffer_address(), g, b,
                                      src.buffer_address(), b1, b3, 0 if resid2 is None else resid2.buffer_address()
                                      ] + mc_args + tail + ([] if pb is None else [pb[0].buffer_address()])
    kernels[1].common_runtime_args = [out.buffer_address(), x.buffer_address()] + tail + (
        [] if pb is None else [o.buffer_address() for o in pb[1]])
    if pb is not None:
        extra += [pb[0]] + list(pb[1])
    pd = ttnn.ProgramDescriptor(kernels=kernels, semaphores=sems, cbs=cbs)
    return ttnn.generic_op([x, w12, w3] + ([] if ln is None else list(ln[:2])) + ([] if bias is None else list(bias))
                           + ([] if resid2 is None else [resid2]) + extra + [out], pd)
