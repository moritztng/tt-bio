from __future__ import annotations

import math
from dataclasses import dataclass

import torch
import ttnn

from . import align
from . import ranking as rank
from . import tenstorrent as _T
from .tenstorrent import Module, device_dtype_override, dram_peak
from .openfold3 import InputEmbedderGlue
from .openfold3_confidence import OF3ConfidenceHead
from .openfold3_trunk import OF3Trunk
from .openfold3_sample_diffusion import OF3SampleDiffusion
from .protenix import DEFAULT_MAX_PARALLEL_SAMPLES, ConfidenceHead
from .tenstorrent import pair_lookup_device
from .openfold3_weights import _sub
from .envflags import env_flag

# OpenFold3's `--fast` set is its normal set plus dit_s16 and diffusion_bf16 (the bf16 DiT stack). The stack's
# Blackhole 11-set fast grade against the normal arm, 44 paired folds per model, seeds 101-104: OpenFold3 top pose
# median 0.401 A (seed floor 1.023 A), CA-lDDT -0.0019, docking 18 -> 19/44; OpenBind-0 0.209 A (floor 1.898 A),
# CA-lDDT -0.0017, docking 26 -> 26/44. Both PASS. The old Wormhole reading (9LLG pLDDT 0.733 -> 0.688, 143.2 s against
# 139.6) predates the on-device bf16 atom pad that lets the bf16 rollout trace. acc_off stays out: it cost confidence
# (0.712) and bought nothing.
# transition_bw and transition_shard stay out: OpenFold3 c730 gains nothing with them (113.2 -> 112.9 s, Wormhole
# 1000 MHz) and its normal 11-set grade fails DockQ (-0.0168 [-0.0474, -0.0006], 44 paired folds, spd-trans2).
# dit_qsplit moves work between cores, not arithmetic: CIFs identical with and without it on both models, Wormhole
# and Blackhole (512-token --fast fold A/B, xmodel_ab); -0.22 s (OpenFold3) / -0.24 s (OpenBind-0) on a Galaxy chip
# at 1000 MHz, flat on p150a. opm_jd comes with the shared normal set.
# Normal mode also runs the fast set's trunk kernels on both parts: trimul_t1, trimul_t2 (trimul_t2cm on Blackhole),
# transition_ws, ws_l1dest, triatt_ln and edm_device; the DiT stays fp32. Blackhole 11-set normal grade against the
# normal set before it, paired seeds, 44 folds per model (nbg, p300c, 2026-10-23), PASS: OpenFold3 top pose median
# 0.688 A (floor 1.208 A), CA-lDDT +0.0014 [-0.0010, +0.0048], docking 18 -> 20/44; OpenBind-0 0.519 A (floor 1.898 A),
# CA-lDDT +0.0004 [-0.0004, +0.0014], docking 26 -> 28/44. 512-token page fold on a p300c chip at 1350 MHz,
# off/on/on/off processes (pnb): OpenFold3 11.39 -> 9.72 s, OpenBind-0 12.67 -> 11.54 s.
NORMAL_LEVERS = _T.NORMAL_LEVERS - {"transition_bw", "transition_shard"} | {
    "dit_qsplit", "trimul_t1", "trimul_t2", "trimul_t2cm", "transition_ws", "ws_l1dest", "triatt_ln", "edm_device",
    "trimul_t1_2g", "atom_l1"}
# trimul_t1_2g lets T1 serve above ~1180 tokens, where a + b + g_out pass its 1 GiB cap and every trimul fell back to
# the gated-move channel loop. Inert at and below 1024 (T1 already serves there). 1536-token OpenFold3 fold, p300c:
# fast 87.8 -> 64.2 s, normal 89.0 -> 72.1 s. On Wormhole T1 also needs the chunking gate open, which it is only to
# ~1088 tokens; with the gate held at 1536 (not shipped) the 1536 fold goes 322 -> 205 s fast, 356 -> 248 s normal.
# trimul_t1 + trimul_t2 (the triangle multiplication's input and output as one kernel each) join --fast on the
# Blackhole 11-set fast grade against today's --fast, 44 paired folds per model:
# OpenFold3 top pose median 0.352 A (seed floor 1.328 A), CA-lDDT -0.0002 [-0.0012, +0.0008], docking 19 -> 19/44,
# PASS; OpenBind-0 top pose median 0.391 A (seed floor 2.079 A), CA-lDDT +0.0003 [-0.0004, +0.0011],
# docking 26 -> 26/44, PASS. 512-token fold on a p300c chip: OpenFold3 11.02 -> 10.08 s, OpenBind-0 11.40 -> 9.99 s.
# Wormhole 11-set fast grade, same chip, AICLK 1000: OpenFold3 top pose median 1.191 A (seed floor 1.122 A),
# CA-lDDT -0.0014 [-0.0043, +0.0005], docking 21 -> 21/44, PASS, median fold 77.5 -> 72.4 s; OpenBind-0 CA-lDDT
# +0.0008, docking 27 -> 28/44, PASS, median fold 103.8 -> 89.6 s.
# transition_ws + dit_fuse join on the Blackhole 11-set fast grade (p300c, 44 paired folds) of today's --fast plus
# t2cm, transition_ws and dit_fuse against the --fast before them: OpenFold3 top pose median 0.406 A (seed floor
# 0.917 A), CA-lDDT +0.0031 [+0.0002, +0.0078], docking 19 -> 22/44, PASS; OpenBind-0 top pose median 0.454 A
# (seed floor 0.820 A), CA-lDDT +0.0003 [-0.0005, +0.0012], docking 26 -> 28/44, PASS.
# Wormhole fast grades: transition_ws PASS (see tenstorrent.FAST_LEVERS), dit_fuse PASS on both models (44 paired
# each, state/spd/grade-dfuse-*-wh-fast.md; DiT block 1.080 -> 1.004 ms at 1000 MHz).
# trimul_t2cm (T2 reads the einsum's channel-major output, no reblock_permute_back) is bit-exact: Wormhole l512 coords
# identical to --fast on 4 seeds x both models, fold 43.76 -> 43.45 s (OpenFold3) and 50.33 -> 49.97 s (OpenBind-0).
# edm_device (the traced rollout keeps the coordinates on the card, augment + EDM step in fp32 inside the step trace)
# joins on the 11-set fast grade of --fast + edm_device against --fast, 44 paired folds per model and arch:
# Blackhole p150a OpenFold3 top pose median 0.240 A (seed floor 1.086 A), CA-lDDT +0.0004, docking 22 -> 22/44, PASS;
# OpenBind-0 0.234 A (floor 0.771 A), CA-lDDT +0.0002, docking 28 -> 27/44, PASS. Wormhole OpenFold3 0.341 A (floor
# 1.199 A), CA-lDDT +0.0005 [+0.0000, +0.0011], docking 19 -> 21/44, PASS; OpenBind-0 0.258 A (floor 0.510 A),
# CA-lDDT +0.0004, docking 27 -> 27/44, PASS (state/spd/grade-edm-*-fast.md). 512-token page fold on a p150a at
# 1350 MHz: OpenFold3 ~-0.2 s, OpenBind-0 ~-0.5 s.
# ws_l1dest lets transition_ws take the pair transitions whose residual update fits L1, which at 512 tokens on a
# p150a was every pairformer transition (ws had never fired there). 11-set fast grade of --fast + ws_l1dest against
# --fast, 44 paired folds per model and arch: Blackhole p150a OpenFold3 top pose median 0.455 A (seed floor
# 0.964 A), CA-lDDT -0.0017 [-0.0033, -0.0004], docking 22 -> 20/44, PASS; OpenBind-0 0.450 A (floor 0.790 A),
# CA-lDDT -0.0002, docking 27 -> 28/44, PASS. Wormhole OpenFold3 0.167 A (floor 1.108 A), CA-lDDT +0.0024,
# docking 21 -> 23/44, PASS; OpenBind-0 0.091 A (floor 0.642 A), CA-lDDT +0.0000, docking 27 -> 27/44, PASS
# (state/spd/grade-wsd-*-fast.md). 512-token page fold on a p150a at 1350 MHz: OpenFold3 -0.35 s, OpenBind-0 -0.42 s.
# dit_hifi2 (the bf16 DiT's linears at HiFi2) graded PASS on the Wormhole fast grade and bought OpenFold3 -0.16 s,
# OpenBind-0 -0.28 s, but it is out: the Wormhole --fast diffusion step stalled on the device in ~7 % of processes
# (15 / 210, eager and traced alike), and a bisect of the DiT levers (hbis, 2026-10-24) hung 5 / 56 processes in the
# arms that kept it against 0 / 58 in the arms without it. Same di/dt class as the LoFi hang: HiFi2 makes the
# >48-core DiT matmul's MVMUL stream denser (tt-metal compute_throttle_utils.cpp).
# dit_kc + dit_mask16 (the DiT attention's full k chunk and bf16 pair-bias mask, both Wormhole only) join on the
# Wormhole 11-set fast grade of --fast + both against --fast, 44 paired folds per model: OpenFold3 top pose median
# 0.267 A (floor 1.178 A), CA-lDDT +0.0001 [-0.0004, +0.0006], docking 22 -> 22/44, PASS; OpenBind-0 0.207 A (floor
# 0.748 A), CA-lDDT +0.0001 [-0.0001, +0.0004], docking 27 -> 27/44, PASS (state/spd/grade-kcm-*-wh-fast.md).
# sdpa_probe found 0 wrong pixels at every k chunk. 512-token page fold on a Galaxy chip at 1000 MHz, paired median
# of 4: OpenFold3 -0.37 s, OpenBind-0 -0.46 s.
# triatt_ln (triangle attention's layer_norm and qkvgb projection as one kernel) moves bytes, not arithmetic: CIFs
# identical with and without it on both models, Wormhole and Blackhole (512-token --fast fold A/B, xmodel_ab, 5 pairs).
# Galaxy chip at 1000 MHz, paired median: OpenFold3 -0.37 s, OpenBind-0 -0.20 s; flat on p150a.
# dit_b8 (the fused DiT block's six adaLN-fed weights rounded to bfp8, activations bf16) joins on the 11-set fast grade
# of --fast + dit_b8 against --fast, 44 paired folds per model per chip, PASS on both. Wormhole: OpenFold3 top pose
# median 0.227 A (floor 1.621 A), CA-lDDT -0.0006 [-0.0014, +0.0001], docking 21 -> 19/44; OpenBind-0 0.244 A (floor
# 0.952 A), CA-lDDT +0.0000, docking 27 -> 28/44. Blackhole: OpenFold3 0.222 A (floor 0.953 A), CA-lDDT +0.0003,
# docking 20 -> 20/44; OpenBind-0 0.298 A (floor 1.209 A), CA-lDDT +0.0001, docking 28 -> 27/44
# (state/spd/grade-ditb8-*-fast.md). 512-token page fold, same chip, off/on/on/off processes: Galaxy chip at 1000 MHz
# OpenFold3 -0.32 s, OpenBind-0 -0.22 s; p150a at 1350 MHz -0.13 / -0.10 s.
# ws_lofi (the pair SwiGLU transition at LoFi) joins on the Blackhole 11-set fast grade of --fast (dit_b8 included)
# + ws_lofi against --fast, 44 paired folds per model (p300c, bwl2, 2026-10-18), PASS: OpenFold3 CA-lDDT +0.0014
# [-0.0022, +0.0060], docking 20 -> 23/44; OpenBind-0 CA-lDDT -0.0004 [-0.0020, +0.0014], docking 27 -> 28/44
# (state/spd/grade-wslo2-*-bh-fast.md). Same-seed top pose median 1.54 / 1.26 A (floor 0.98 / 0.97 A). Warm 5-sample
# folds of those complexes at 1343-1350 MHz, per-complex median: OpenFold3 -0.16 s, OpenBind-0 -0.28 s (trunk only,
# so the saving holds at 1 sample). The Wormhole grade is not complete, so Wormhole leaves it out for now.
# dit_l1 only moves the DiT's per-step tensors into L1 (CIF-identical); neutral in Blackhole fast, in the set because
# Blackhole normal takes it (NORMAL_MODEL_LEVERS) and the fast set holds the normal one.
FAST_LEVERS = NORMAL_LEVERS | {"dit_s16", "diffusion_bf16", "trimul_t1", "trimul_t2", "trimul_t2cm", "transition_ws",
                               "dit_fuse", "edm_device", "ws_l1dest", "dit_kc", "dit_mask16", "triatt_ln",
                               "dit_b8", "ws_lofi", "dit_l1"}
# Wormhole --fast adds apb_ln (the attention pair-bias projection reads the pair through the same fused LayerNorm).
# Wormhole 11-set fast grade of --fast + apb_ln against --fast, 44 paired folds per model (whlg, 2026-10-15), PASS:
# OpenFold3 top pose median 0.543 A (floor 1.238 A), CA-lDDT -0.0010 [-0.0036, +0.0007], docking 22 -> 22/44;
# OpenBind-0 0.573 A (floor 0.672 A), CA-lDDT +0.0014 [-0.0000, +0.0036], docking 27 -> 27/44
# (state/spd/grade-apbln-*-wh-fast.md). Not graded on Blackhole, so it stays off there.
# And trimul_sig6 (the trimul gate sigmoid as a degree-6 polynomial). Wormhole 11-set fast grade of --fast +
# trimul_sig6 against --fast, 44 paired folds per model (whs6g, 2026-10-15), PASS: OpenFold3 top pose median 0.565 A
# (floor 1.090 A), CA-lDDT -0.0007 [-0.0027, +0.0007], docking 22 -> 21/44; OpenBind-0 0.743 A (floor 0.812 A),
# CA-lDDT -0.0009 [-0.0021, +0.0001], docking 27 -> 27/44 (state/spd/grade-sig6-*-wh-fast.md). 512-token page fold
# on a Galaxy chip at 1000 MHz, paired median of 4: -0.18 s on both. No saving on p150a, so Wormhole only.
# And trimul_bres (the trimul einsum with b[c] resident in L1, bmm_res, as ESMFold2 ships it): CIFs identical with and
# without it on both models (512-token --fast fold A/B, xmodel_ab, 1760 einsums served, 0 declined). Galaxy chip at
# 1000 MHz, paired median: OpenFold3 -0.18 s (3 pairs; the first paid a 4.7 s program compile), OpenBind-0 -0.24 s (4).
# In the normal mode too, CIFs identical, all 8 pairs faster: OpenFold3 -0.23 s, OpenBind-0 -0.27 s (25.8 s folds).
# Flat on p150a in both modes (paired medians within +-0.07 s), so Wormhole only.
# ws_lofi and triatt_hifi2 (the fused triangle-attention SDPA at HiFi2) join Wormhole fast on its 11-set fast grade of
# the Wormhole fast set + both against it, paired seeds (wsg, 2026-10-18), PASS: OpenFold3 44 folds, top pose median
# 0.961 A (floor 1.638 A), CA-lDDT +0.0024 [-0.0014, +0.0083], docking 19 -> 23/44; OpenBind-0 40 folds (10 complexes),
# 1.137 A (floor 1.093 A), CA-lDDT +0.0003 [-0.0014, +0.0020], docking 24 -> 23/40. 512-token page fold on a Galaxy
# chip at 1000 MHz, ABBA processes: triatt_hifi2 -0.22 / -0.23 s, ws_lofi -0.12 / -0.07 s (wstk).
# dit_sigf32 (the DiT gate linears' fused sigmoid on calculate_silu_f32) joins Wormhole fast on its 11-set fast grade
# of the Wormhole fast set + it against that set, paired seeds (sgg, 2026-10-19), PASS: OpenFold3 44 folds, top pose
# median 0.260 A (floor 1.288 A), CA-lDDT -0.0003 [-0.0006, -0.0000], docking 23 -> 23/44; OpenBind-0 44 folds,
# 0.230 A (floor 1.091 A), CA-lDDT -0.0003 [-0.0006, -0.0000], docking 27 -> 27/44. 512-token page fold on a Galaxy
# chip at 1000 MHz, paired median of 4: OpenFold3 -0.27 s, OpenBind-0 -0.35 s. On p300c -0.04 / -0.12 s and not
# graded there, so Wormhole only.
# triatt_ln_b8 (the fused triangle-attention LayerNorm writes q, k, v as bfp8 into the SDPA) joins Wormhole fast on its
# 11-set fast grade of the Wormhole fast set + it against that set, paired seeds (tlbg, 2026-10-19), PASS: OpenFold3
# 40 folds (10 complexes), top pose median 0.709 A (floor 1.029 A), CA-lDDT -0.0002 [-0.0014, +0.0008], docking
# 20 -> 20/40; OpenBind-0 44 folds, 0.846 A (floor 1.160 A), CA-lDDT -0.0024 [-0.0053, -0.0003], docking 27 -> 28/44.
# 512-token page fold on a Galaxy chip at 1000 MHz, mean of the 3 warm pairs after the compile: OpenFold3 -0.27 s,
# OpenBind-0 -0.28 s. On p300c within noise (-0.03 / -0.11 s paired medians), so Wormhole only.
# dit_l1 (the bf16 token DiT's per-step tensors in L1, placement only): CIFs identical with and without it on both
# models (512-token --fast fold A/B, xmodel_ab, dl1w, 2026-10-19). Galaxy chip at 1000 MHz, the three warm pairs after
# the first (which paid the L1 programs' compile): OpenFold3 -0.95 / -0.87 / -0.71 s, OpenBind-0 -1.04 / -0.99 / -1.09 s.
# Flat on Blackhole (bhl1), so Wormhole only.
# atom_l1 (the atom transformer's per-step tensors in L1, placement only): CIFs identical with and without it on both
# models (512-token --fast fold A/B, a3lw2, 2026-10-19, and at 1024 / 1568 tokens, a3ls). Galaxy chip at 1000 MHz,
# 2 chips x 5 warm pairs after the compile pair, every pair faster: OpenFold3 -0.36 s, OpenBind-0 -0.38 s mean.
# In normal mode too (a3nw, 2026-10-20): CIFs identical, Galaxy chip at 1000 MHz, 4 warm pairs after the compile pair,
# every pair faster: OpenFold3 -0.31 s, OpenBind-0 -0.28 s mean. Blackhole p300 chip at 1350 MHz, 512-token page fold,
# mirrored off/a/.../a/off processes, 2 warm folds each, CIFs identical (bhl, 2026-10-25): OpenBind-0 fast
# 8.47 -> 8.27 s, OpenBind-0 normal 9.90 -> 9.72 s, OpenFold3 normal 8.74 -> 8.61 s. So both parts, both modes.
# ws_psilu (pair SwiGLU's silu on the packer thread, overlapping the matmuls): CIFs identical with and without it on
# both models (512-token --fast fold A/B, psf2, 2026-10-19). Galaxy chip at 1000 MHz, mean of the 5 warm pairs after
# the compile pair: OpenFold3 -0.08 s, OpenBind-0 -0.12 s; the kernel alone 2.63 -> 2.23 ms at c_z 128. Flat in normal
# mode (-0.06 / +0.02 s), so Wormhole fast only.
# dit_mask8 (the token DiT attention's pair-bias mask read as bfp8): Galaxy chip at 1000 MHz, 6 paired 512-token
# --fast folds (m8w, 2026-10-20): OpenFold3 -0.11 s, OpenBind-0 -0.06 s mean. Graded on the 11-complex fast set,
# paired seeds (m8g): PASS on both models (DockQ -0.003 / -0.005, CIs span zero). Blackhole within noise (OpenFold3
# median -0.04 s, m8b2), so Wormhole fast only.
# The Wormhole normal grade of the trunk kernels (with trimul_bres and atom_l1, without trimul_t2cm as in Wormhole fast):
# 11-set normal grade against the normal set before it, paired seeds, 44 folds per model (nwg, 2026-10-21), PASS:
# OpenFold3 top pose median 0.398 A (floor 1.010 A), CA-lDDT +0.0005 [-0.0012, +0.0025], docking 20 -> 21/44;
# OpenBind-0 0.633 A (floor 0.813 A), CA-lDDT -0.0004 [-0.0017, +0.0007], docking 27 -> 27/44. 512-token page fold on a
# Galaxy chip at 1000 MHz, off/on/on/off processes (pnw): OpenFold3 25.20 -> 20.02 s, OpenBind-0 25.27 -> 20.03 s.
WH_NORMAL_LEVERS = NORMAL_LEVERS - {"trimul_t2cm"} | {"trimul_bres"}
# Per-model additions to the normal set, each with the grade the other model failed. OpenFold3 takes the bf16 DiT in
# normal mode; OpenBind-0 failed its Wormhole grade and keeps the fp32 DiT on both parts.
# Wormhole, the stack dit_s16, diffusion_bf16, dit_fuse, dit_l1 on top of WH_NORMAL_LEVERS, 11-set normal grade, paired
# seeds, 44 folds per model (nwd, 2026-10-21): OpenFold3 PASS, top pose median 0.434 A (floor 0.980 A), CA-lDDT -0.0001
# [-0.0013, +0.0011], docking 21 -> 23/44. OpenBind-0 FAIL, CA-lDDT -0.0012 [-0.0020, -0.0006] (without dit_fuse and
# dit_l1 also ligand RMSD +1.52 A [+0.04, +3.96]).
# Blackhole, dit_s16 + diffusion_bf16 on top of NORMAL_LEVERS against the normal set before both (nbg, p300c,
# 2026-10-23): OpenFold3 PASS, top pose median 0.809 A (floor 1.208 A), CA-lDDT -0.0005 [-0.0031, +0.0033], docking
# 18 -> 20/44; page fold at 1350 MHz 9.72 -> 9.12 s (pnb).
# OpenBind-0 on Wormhole takes dit_fuse and dit_l1 on its fp32 DiT alone (ngw, 2026-10-25): PASS, top pose median
# 0.510 A (floor 1.105 A), CA-lDDT +0.0001 [-0.0007, +0.0009], docking 27 -> 26/44; page fold at 1000 MHz 20.2 -> 17.6 s.
# Blackhole, dit_fuse + dit_l1 over dit_s16 + diffusion_bf16, 11-set normal grade, 44 paired folds (nfb+nfr, 11-01):
# OpenFold3 PASS, top pose median 0.291 A (floor 1.583 A), CA-lDDT +0.0004 [-0.0001, +0.0010], docking 20 -> 21/44.
# Warm 5-sample folds at 1350 MHz: -10 to -13 % at 515-611 tokens; from 678 tokens the device refuses the L1 stream,
# the stack reruns in DRAM and dit_fuse alone is -3 to +1 %. OpenBind-0 (fp32 DiT) is refused L1 at every graded size
# on Blackhole and was slower on 10 of 10 complexes (+5 to +7 %), so it stays out there.
NORMAL_MODEL_LEVERS = {"openfold3": frozenset({"dit_s16", "diffusion_bf16", "dit_fuse", "dit_l1"})}
# OpenBind-0 on Wormhole normal also takes dit_kl1 + apb_ln + trimul_sig6. They were graded with triatt_hifi2 as one stack
# (nxg, 2026-11-12, 11 complexes x 4 seeds): PASS, every CI covers 0 or favours the stack, pLDDT -0.0007, same-seed top
# pose median 0.526 A (seed floor 1.105 A, kill bar 0.60 A). Page fold at 1000 MHz 17.39 -> 16.82 s with all four (kla).
# triatt_hifi2 stays out of normal: it is a HiFi2 fp32-dest matmul on Wormhole, the class that hung prod OpenDDE on 7-10 %
# of leases (`hifi2_allowed`), and dropping a fidelity cut only moves the stack toward the reference. OpenFold3 FAILED the
# same stack (DockQ -0.0066 [-0.0129, -0.0005], TM -0.0019 [-0.0039, -0.0003]) and keeps its set.
# OpenFold3 on Wormhole normal adds dit_kc + dit_mask16 (full k chunk, bf16 pair-bias mask in the DiT attention; the
# probe reads 0 wrong pixels). Grade dkg (2026-11-17), 9DBP 9LV4 9TY2 x 4 seeds, the three complexes that failed the
# bfp8 DiT stack: PASS, every CI covers 0, pLDDT -0.0000, same-seed top pose median 0.089 A (seed floor 0.587 A, kill
# bar 0.60 A), docking 12 -> 12/12. Page fold at 1000 MHz, off/on/on/off processes (dka): 15.42 -> 14.99 s (-2.8 %).
# dit_sigf32 on top read 14.74 s but FAILED (iRMSD +0.010 [+0.006, +0.017]); the bfp8 stack with dit_b8, dit_mask8 and
# triatt_ln_b8 FAILED too (dxg, DockQ -0.028 [-0.051, -0.005]).
WH_NORMAL_MODEL_LEVERS = {**NORMAL_MODEL_LEVERS,
                          "openfold3": NORMAL_MODEL_LEVERS["openfold3"] | {"dit_kc", "dit_mask16"},
                          "openbind": frozenset({"dit_fuse", "dit_l1", "dit_kl1", "apb_ln", "trimul_sig6"})}
# ws_lofi leaves Wormhole fast (LoFi hangs Wormhole chips, tenstorrent.lofi_allowed): with it OpenFold3 9PCQ hung in
# 3 of 3 processes, without it 48 of 48 folds clean (pcqc, 2026-10-20). It had saved 0.12 / 0.07 s at the page cell.
# trimul_t2cm leaves Wormhole fast too: plain T2 + reblock_permute_back is faster there at the page cell. Galaxy chip at
# 1000 MHz, 4 warm pairs after the compile pair, CIFs identical (t2cw, 2026-10-20): OpenFold3 -0.21 s, OpenBind-0
# -0.17 s mean without it.
WH_FAST_LEVERS = FAST_LEVERS - {"ws_lofi", "trimul_t2cm"} | {"apb_ln", "trimul_sig6", "trimul_bres", "triatt_hifi2", "dit_sigf32",
                                  "triatt_ln_b8", "ws_psilu", "dit_mask8"}

def kabsch_rmsd(pred_ca, gt_ca):
    """Optimal-superposition Cα-RMSD (Kabsch). pred_ca, gt_ca: [N, 3].

    Kept as a name because scripts/ and the gates import it; the maths is in
    ``tt_bio.align``, shared with pxdesign's structure writer.
    """
    return align.rmsd(pred_ca, gt_ca)


def load_pdb_ca(pdb_path):
    """Parse one Cα per residue from a PDB file -> [n_res, 3] float64."""
    pts, seen = [], set()
    with open(pdb_path) as f:
        for line in f:
            if not (line.startswith("ATOM") or line.startswith("HETATM")):
                continue
            if line[12:16].strip() != "CA":
                continue
            uid = (line[21].strip(), int(line[22:26].strip()))
            if uid in seen:
                continue
            seen.add(uid)
            pts.append((float(line[30:38]), float(line[38:46]), float(line[46:54])))
    return torch.tensor(pts, dtype=torch.float64)


# AF3 noise schedule (Page 24) and Algorithm 19 augmentation, replicated host-side
# so fold() can run a fresh rollout without the CPU reference package (the device env
# does not import openfold3). Bit-exact vs openfold3.core.model.structure.diffusion_module
# .create_noise_schedule and .augmentation.sample_rotations.

@dataclass
class OpenFold3FoldResult:
    """Confidence-ranked OF3 ensemble result."""

    samples: list[torch.Tensor]
    confidence: list[dict]
    best_index: int

    @property
    def coordinates(self) -> torch.Tensor:
        return self.samples[self.best_index]


def _disorder_score(atom_array, coordinates) -> float:
    """OF3 sample-ranking disorder term from predicted protein RASA."""
    import numpy as np
    import biotite.structure as struc

    from ._vendor.openfold3.core.data.resources.residues import (
        RESIDUE_SASA_SCALES, MoleculeType,
    )

    array = atom_array.copy()
    array.coord = coordinates.detach().cpu().numpy()
    protein = array[array.molecule_type_id == MoleculeType.PROTEIN]
    values = []
    scale = RESIDUE_SASA_SCALES["Sander"]
    for chain in struc.chain_iter(protein):
        atom_sasa = struc.sasa(chain, vdw_radii="ProtOr")
        residue_sasa = struc.apply_residue_wise(chain, atom_sasa, np.sum)
        _, names = struc.get_residues(chain)
        maximum = np.array([scale.get(name, 113.0) for name in names])
        rasa = np.clip(residue_sasa / maximum, 0, 1)
        half = 12
        smoothed = np.convolve(
            np.pad(rasa, (half, half), mode="reflect"), np.ones(25), mode="valid"
        ) / 25
        values.extend(smoothed)
    return float(np.mean(np.asarray(values) > 0.581)) if values else 0.0



def _has_clash(coordinates, atom_to_token_index, asym_id, atom_mask, polymer_mask) -> float:
    """AF3 inter-chain polymer clash indicator used by sample ranking."""
    atom_asym = asym_id.long()[atom_to_token_index.long()]
    chains = torch.unique(atom_asym[polymer_mask & atom_mask.bool()])
    for i, left in enumerate(chains):
        li = (atom_asym == left) & polymer_mask & atom_mask.bool()
        for right in chains[i + 1:]:
            ri = (atom_asym == right) & polymer_mask & atom_mask.bool()
            distances = torch.cdist(coordinates[li].float(), coordinates[ri].float())
            clashes = int((distances < 1.1).sum())
            if clashes > 100 or clashes / max(1, min(int(li.sum()), int(ri.sum()))) > 0.5:
                return 1.0
    return 0.0


def create_noise_schedule(no_rollout_steps, sigma_data, s_max, s_min, p, dtype=torch.float32):
    t = torch.arange(0, 1 + no_rollout_steps, dtype=dtype) / no_rollout_steps
    return sigma_data * (s_max ** (1 / p) + t * (s_min ** (1 / p) - s_max ** (1 / p))) ** p


def _quat_to_rot(q):
    # q: [4] normalized quaternion -> [3, 3]. Standard AF3 quat_to_rot via the
    # symmetric outer-product sum (equivalent to openfold3 ...rigid_utils.quat_to_rot).
    b, c, d, a = q[..., 0], q[..., 1], q[..., 2], q[..., 3]
    return torch.stack([
        a * a + b * b - c * c - d * d, 2 * (b * c - a * d), 2 * (b * d + a * c),
        2 * (b * c + a * d), a * a - b * b + c * c - d * d, 2 * (c * d - a * b),
        2 * (b * d - a * c), 2 * (c * d + a * b), a * a - b * b - c * c + d * d,
    ], dim=-1).reshape(*q.shape[:-1], 3, 3)


def sample_rotation(dtype=torch.float32):
    q = torch.randn(4, dtype=dtype)
    q = q / torch.linalg.norm(q)
    return _quat_to_rot(q)                      # [3, 3]


def _pae_bin_vectors(n_tok, asym_id, nb=64, max_a=32.0):
    """Every bin vector the confidence readings multiply softmax(pae) by: the bin centres (the
    PAE / PDE matrices) and the TM kernel at each token count pTM / ipTM and the chain reductions
    normalise on, built with the same expressions as `ConfidenceHead._ptm_iptm` and
    `_chain_confidence`, so `_BinProj` finds them by equality."""
    centers = (torch.arange(nb, dtype=torch.float32) + 0.5) * (max_a / nb)
    counts = {max(n_tok, 19)}
    if asym_id is not None:
        a = asym_id.long().reshape(-1)
        ids = [int(x) for x in torch.unique(a)]
        if a.numel() == n_tok and len(ids) > 1:
            for i, ci in enumerate(ids):
                counts.add(max(int((a == ci).sum()), 19))
                for cj in ids[i + 1:]:
                    counts.add(max(int(((a == ci) | (a == cj)).sum()), 19))
    vecs = [centers]
    for n in sorted(counts):
        d0 = 1.24 * (n - 15) ** (1.0 / 3.0) - 1.8
        vecs.append(1.0 / (1.0 + (centers / d0) ** 2))
    return vecs


class _BinProj:
    """Stands in for softmax(pae_logits) [N, N, 64] when the card returned only its products
    with `vecs`: `probs @ v` is answered from the matching column."""

    def __init__(self, proj, vecs):
        self.proj, self.vecs = proj, vecs

    def __matmul__(self, v):
        for i, u in enumerate(self.vecs):
            if u.shape == v.shape and torch.equal(u, v.float()):
                return self.proj[..., i]
        raise KeyError("this bin vector was not reduced on the card")


def build_dm_device_aux(dev, ft, *, cl0, plm0, atom_mask, atom_to_token_index,
                        npe_q_indices, npe_k_indices, zij_mask, key_block_idxs,
                        invalid_mask, mask_trunked, atom_to_token_mean,
                        token_mask, n_atom, n_token, nb, NP, n_tok_pad,
                        cl0_d=None, plm0_d=None):
    """Mirror the device DiffusionModule aux setup validated in
    tests/test_openfold3_sample_diffusion.py (the exact tensor shapes/dtypes the
    gated OF3DiffusionModule consumes), so fold() feeds the sampler identically.

    ``cl0_d``/``plm0_d`` take the atom-featurization output already on the card, from
    ``openfold3_host_prep.ref_atom_embed_device``; then ``cl0``/``plm0`` are unused and may be
    None. The device leg pads ``cl`` by padding its own inputs, so the two paths produce the
    same [1, NP, 128] with the same zeros in the pad rows.
    """
    if cl0_d is None:
        cl0_t = torch.zeros(1, NP, 128); cl0_t[0, :n_atom] = cl0.float()
        cl0_d = ft(cl0_t)
    if plm0_d is None:
        plm0_d = ft(plm0.unsqueeze(0))
    amc = torch.zeros(1, NP, 1); amc[0, :n_atom, 0] = atom_mask.float()
    amc_na = torch.zeros(1, n_atom, 1); amc_na[0, :, 0] = atom_mask.float()
    idx = torch.zeros(NP, dtype=torch.long); idx[:n_atom] = atom_to_token_index.long()
    idx_tt = ttnn.from_torch(idx.unsqueeze(0), layout=ttnn.ROW_MAJOR_LAYOUT,
                             device=dev, dtype=ttnn.uint32)
    flat = (npe_q_indices.unsqueeze(-1) * n_tok_pad + npe_k_indices.unsqueeze(1)).reshape(1, nb * 32 * 128)
    flat_tt = ttnn.from_torch(flat.to(torch.int32), layout=ttnn.ROW_MAJOR_LAYOUT,
                              device=dev, dtype=ttnn.uint32)
    kidx = key_block_idxs.reshape(1, nb * 128).to(torch.int32)
    kidx_tt = ttnn.from_torch(kidx, layout=ttnn.ROW_MAJOR_LAYOUT, device=dev, dtype=ttnn.uint32)
    valid = (~invalid_mask).float().reshape(1, nb, 128, 1)
    mask_bias = (1e9 * (mask_trunked - 1)).reshape(1, nb, 1, 32, 128)
    pair_mask_m = mask_trunked.reshape(1, nb, 32, 128, 1)
    tok_pad = torch.zeros(n_tok_pad, dtype=torch.float32); tok_pad[:n_token] = token_mask.float()

    def ft_col(x):
        # A trailing channel of 1 tile-pads 32x on the host (pm_d: ~40 MB of tilize for 1.3 MB
        # of mask); upload without it and add the unit dim on the card. Same values, same tiles.
        return ttnn.unsqueeze(ft(x.squeeze(-1)), -1)

    return dict(
        cl0_d=cl0_d, plm0_d=plm0_d,
        amc_d=ft(amc), amc_na_d=ft(amc_na),
        idx_tt=idx_tt, flat_tt=flat_tt,
        zij_mask_d=ft_col(zij_mask.unsqueeze(0).unsqueeze(-1)),
        kidx_tt=kidx_tt, valid_d=ft_col(valid), mb_d=ft(mask_bias), pm_d=ft_col(pair_mask_m),
        mean_d=ft(atom_to_token_mean.unsqueeze(0)),
        tok_pad_tt=ft(tok_pad.reshape(1, n_tok_pad)),
        tok_col_pad_tt=ft(tok_pad.reshape(1, n_tok_pad, 1)),
    )


class OpenFold3(Module):
    """End-to-end OpenFold3 ``fold()`` on device: trunk -> fresh-rollout SampleDiffusion
    -> atom coordinates.

    Assembles the gated device components into a single forward. The trunk
    (``OF3Trunk``, P10) runs fully on device; its ``(s_trunk, z_trunk)`` feed the
    gated device ``OF3SampleDiffusion`` (P9 leg 2), which runs a *fresh* EDM rollout
    (AF3 Algorithm 18) -- a real noise schedule + per-step random augmentation/noise
    drawn with the caller's seed, NOT a golden-replayed trajectory -- to denoise atom
    positions. Returns ``xl_final`` [n_atom, 3] on host.

    The atom-encoder and template feature preparation remain host-side; the input glue,
    MSA embedder, trunk, diffusion sampler, and confidence Pairformer run on device.
    A searched MSA is supplied as the post-subsample 34-channel ``msa_feat`` input.
    Confidence ranking follows the OF3 architecture score and preserves every sample
    in ``OpenFold3FoldResult`` for auditing.

    Args:
        sd: the full OF3 checkpoint state dict.
        compute_kernel_config: HiFi4 + fp32 dest acc.
        num_cycles: trunk recycle cycles (OF3 default 4 = num_recycles+1).
    """

    def __init__(self, sd, compute_kernel_config, num_cycles: int = 4, levers=None, model="openfold3"):
        """``levers``: the precision levers (``tenstorrent.LEVERS``) this model builds and folds
        under, active only inside its own build and fold, as for Protenix-v2. None takes the
        mode's set (``tenstorrent.model_levers``): ``NORMAL_LEVERS`` / ``FAST_LEVERS`` below (``WH_*`` on Wormhole),
        plus ``NORMAL_MODEL_LEVERS[model]`` (``WH_NORMAL_MODEL_LEVERS`` on Wormhole) in normal mode, and nothing
        else, the older bfp8 trunk is off inside the scope. ``model``: the family id the weights belong to (openfold3, openbind)."""
        wh = _T.is_wormhole()
        normal = (WH_NORMAL_LEVERS | WH_NORMAL_MODEL_LEVERS.get(model, frozenset()) if wh
                  else NORMAL_LEVERS | NORMAL_MODEL_LEVERS.get(model, frozenset()))
        self._levers = _T.model_levers(normal, WH_FAST_LEVERS if wh else FAST_LEVERS, spec=levers)
        with _T.lever_scope(self._levers):
            self._build(sd, compute_kernel_config, num_cycles)

    def _build(self, sd, compute_kernel_config, num_cycles):
        # The `lofi` / `acc_off` levers reach every stage through this one config.
        compute_kernel_config = _T.lpx_compute_kernel_config(compute_kernel_config)
        super().__init__(sd, compute_kernel_config)
        self.sd = sd
        self.ckc = compute_kernel_config
        self.input_glue = InputEmbedderGlue(
            _sub(sd, "input_embedder"), compute_kernel_config)
        # The trunk gets its own config (`trunk_hifi3`), which cannot reach the diffusion module.
        self.trunk = OF3Trunk(sd, _T.trunk_compute_kernel_config(compute_kernel_config),
                              num_cycles=num_cycles)
        self._confidence_sd = _sub(sd, "aux_heads")
        self.confidence_head = None
        fourier_w = sd["diffusion_module.diffusion_conditioning.fourier_emb.w"]
        fourier_b = sd["diffusion_module.diffusion_conditioning.fourier_emb.b"]
        # sigma_data lives under diffusion_module.diffusion_module in the checkpoint.
        sigma_data = float(sd.get("diffusion_module.diffusion_module.sigma_data", 16.0))
        self.sigma_data = sigma_data
        # The diffusion module (weights and activations) runs in fp32 on device by
        # default, matching the reference rollout's fp32 boundary — the same lever
        # that closed the Protenix HSA leg (PROTENIX_DIFFUSION_FP32_DEVICE, also
        # default-on). In bf16 the 9BK6 complex leg misses the all-atom noise floor
        # (X 1.889 > 1.821 threshold); in fp32 it passes (X 1.627, seeds 0-4:
        # 1.35-2.18 A). OF3_DIFFUSION_FP32_DEVICE=0 opts back out to bf16, and so does the
        # shared `diffusion_bf16` lever (fast mode), as it does for Protenix-v2.
        if env_flag("OF3_DIFFUSION_FP32_DEVICE", True) and not _T.lever("diffusion_bf16"):
            with device_dtype_override(ttnn.float32):
                self.sampler = OF3SampleDiffusion(_sub(sd, "diffusion_module"),
                                                  compute_kernel_config,
                                                  fourier_w, fourier_b, sigma_data)
        else:
            self.sampler = OF3SampleDiffusion(_sub(sd, "diffusion_module"), compute_kernel_config,
                                              fourier_w, fourier_b, sigma_data)
        self.device = self.trunk.device
        # AF3 sample_diffusion + noise_schedule defaults (OF3 model_config).
        self.gamma_0 = 0.8
        self.gamma_min = 1.0
        self.noise_scale = 1.003
        self.step_scale = 1.5
        self.ns_cfg = dict(sigma_data=sigma_data, s_max=160.0, s_min=4e-4, p=7)

    def _ft(self, x, dtype=ttnn.bfloat16):
        return _T.upload(x.float(), dtype, self.device)

    def _gen_rollout(self, noise_schedule, n_atom, seed):
        """Fresh per-step (rots, trans, noise, t, c_tau) + xl_init for one sample,
        matching AF3 Algorithm 18/19 RNG call order (rots -> trans -> noise)."""
        torch.manual_seed(seed)
        xl_init = noise_schedule[0] * torch.randn(n_atom, 3, dtype=torch.float32)
        rots_l, trans_l, noise_l, t_l, c_tau_l = [], [], [], [], []
        for tau in range(len(noise_schedule) - 1):
            c_tau = float(noise_schedule[tau + 1])
            gamma = self.gamma_0 if c_tau > self.gamma_min else 0
            t = float(noise_schedule[tau]) * (gamma + 1)
            rots = sample_rotation()                              # [3, 3]
            trans = 1.0 * torch.randn(3, dtype=torch.float32)     # [3]
            noise = self.noise_scale * math.sqrt(max(t * t - float(noise_schedule[tau]) ** 2, 0.0)) \
                * torch.randn(n_atom, 3, dtype=torch.float32)
            rots_l.append(rots); trans_l.append(trans); noise_l.append(noise)
            t_l.append(t); c_tau_l.append(c_tau)
        return xl_init, rots_l, trans_l, noise_l, t_l, c_tau_l

    def _confidence(self, sample, si_input, si_trunk, zij_trunk, aux, shared=None):
        if self.confidence_head is None:
            self.confidence_head = OF3ConfidenceHead(
                self._confidence_sd, self.device, self.ckc)
        if aux.get("repr_batch") is not None:
            # Reference rule (openfold3 get_token_representative_atoms): CB for
            # protein (CA for glycine), C4/C2 for purine/pyrimidine, first atom for
            # atomized ligands. The token_center_atom (CA/C1') convention shifts
            # representative distances by ~1.5 A on non-glycine residues, flipping
            # contact pairs across distance-bin edges and miscalibrating PAE/pLDDT.
            from ._vendor.openfold3.core.utils.atomize_utils import (
                get_token_representative_atoms)
            representative, _ = get_token_representative_atoms(
                batch=aux["repr_batch"], x=sample,
                atom_mask=aux["repr_batch"]["atom_mask"])
        else:
            representative = sample[aux["representative_atom_indices"].long()]
        n_tok = si_trunk.shape[0]
        vecs = _pae_bin_vectors(n_tok, aux.get("asym_id")) if _T.lever("conf_bins") else None
        out = self.confidence_head.forward(
            si_input=si_input.float(), si_trunk=si_trunk.float(),
            zij_trunk=None if zij_trunk is None else zij_trunk.float(), repr_x_pred=representative.float(),
            max_atom_per_token_mask=aux["max_atom_per_token_mask"].float(),
            use_zij_trunk_embedding=True, shared=shared,
            bin_vectors=None if vecs is None else torch.stack(vecs, -1),
        )
        if "pae_proj" in out:
            # The pae / pde heads were reduced on the card: every reading below is softmax(pae)
            # times one bin vector, so the [N, N, 64] logits never cross.
            out["pae_logits"] = torch.empty(n_tok, n_tok, 64, device="meta")
            pae_probs = _BinProj(out["pae_proj"], vecs)
        bins = (torch.arange(50, dtype=torch.float32) + 0.5) / 50
        plddt_atom = (torch.softmax(out["plddt_logits"].float(), -1) * bins).sum(-1)
        from .protenix import ConfidenceHead
        # pTM and ipTM are a max over ALIGNMENT FRAMES, not over tokens, and a token that
        # has no frame can win that max and set the score a user's structure is ranked by.
        # Upstream builds the mask from the predicted coordinates and zeroes the row
        # (`sample_ranking.py:60-70` -> `confidence.py:154`); `get_token_frame_atoms` is
        # the same vendored function it calls, so this is their rule and not a second one.
        # Every token of a structure built from standard residues has a frame, so the mask
        # is all-ones on a protein-only target and the reading does not move there; it is
        # ligands and modified residues, which arrive ATOMIZED and must clear an angle
        # constraint, that it is about.
        has_frame = None
        if aux.get("frame_batch") is not None:
            from ._vendor.openfold3.core.utils.atomize_utils import get_token_frame_atoms
            _, has_frame = get_token_frame_atoms(
                batch=aux["frame_batch"], x=sample.float(),
                atom_mask=aux["frame_batch"]["atom_mask"].float())
            has_frame = has_frame.bool()
        # One softmax over the [N, N, 64] PAE bins serves pTM/ipTM, the chain reductions and
        # the PAE matrix; on the host at 730 tokens each one costs ~0.2 s per sample.
        if "pae_proj" not in out:
            pae_probs = torch.softmax(out["pae_logits"].float(), -1)
        ptm, iptm = ConfidenceHead._ptm_iptm(
            out["pae_logits"], aux.get("asym_id"), has_frame=has_frame, probs=pae_probs)
        disorder = _disorder_score(aux["atom_array"], sample) if aux.get("atom_array") is not None else 0.0
        has_clash = 0.0
        if all(k in aux for k in ("asym_id", "atom_to_token_index", "atom_mask", "polymer_mask")):
            has_clash = _has_clash(
                sample, aux["atom_to_token_index"], aux["asym_id"],
                aux["atom_mask"], aux["polymer_mask"])
        ranking_score = rank.ranking_score(
            iptm=iptm, ptm=ptm, plddt=float(plddt_atom.mean()),
            disorder=disorder, has_clash=has_clash)
        # Full matrices as upstream's aggregate_confidence_ranking computes them: the expectation
        # over 64 bins on 0-32 Å. The distogram is the trunk's, the same for every sample.
        centers = (torch.arange(64, dtype=torch.float32) + 0.5) * 0.5
        return {
            # chain_ptm, chain_iptm and pair_chains_iptm, the same reduction Protenix and
            # OpenDDE report, over this head's logits and frame mask.
            **ConfidenceHead._chain_confidence(out["pae_logits"], aux.get("asym_id"),
                                               has_frame=has_frame, probs=pae_probs),
            "plddt": float(plddt_atom.mean()), "plddt_atom": plddt_atom,
            "ptm": ptm, "iptm": iptm, "disorder": disorder,
            "has_clash": has_clash, "ranking_score": ranking_score,
            "pae": (pae_probs @ centers if "pae_proj" in out else (pae_probs * centers).sum(-1)),
            "pde": (out["pde_proj"] if "pae_proj" in out
                    else (torch.softmax(out["pde_logits"].float(), -1) * centers).sum(-1)),
            "distogram": out["distogram_logits"],
        }

    @_T.under_lever_scope
    def fold(self, *, template_feat, msa_feat, s_input, relpos, token_bonds,
             token_mask, dm_aux_host, n_atom, n_token, no_rollout_steps, seed,
             no_samples=1, confidence_aux_host=None, progress_fn=None,
             template_slots=None, max_parallel_samples=None, distogram=True):
        """Run the device input glue + trunk and confidence-rank fresh rollouts.

        ``msa_feat`` is the searched, post-subsample 34-channel MSA input. The returned
        result keeps every sample and identifies ``coordinates`` / ``best_index`` using
        the OF3 sample-ranking score (0.8 ipTM + 0.2 pTM + 0.5 disorder - 100 clash).
        ``max_parallel_samples`` caps how many samples share one diffusion-module call
        (default ``protenix.DEFAULT_MAX_PARALLEL_SAMPLES``); it moves memory and time, not a
        sample's draws. ``distogram=False`` skips the trunk distogram (only ``--write_pae``
        reads it), which saves its [N, N, 64] fp32 read-back; the confidence reports None for it.
        """
        import torch.nn.functional as F
        from .token_axis import (TILE, bucket_enabled, bucket_multiple, bucketed_width,
                                 pad_amount, pad_poison, token_pad_masks_tt)
        ft = self._ft
        nb = dm_aux_host["nb"]; NP = dm_aux_host["NP"]
        n_tok_pad = bucketed_width(n_token, TILE)

        # Bucket the TRUNK's token axis. The diffusion half already runs at n_tok_pad behind a
        # real mask (openfold3_diffusion_module.py token_mask_pad_tt); the trunk was the half
        # still running the raw n_token, which is the whole of why openfold3 and openbind sat
        # IMMUNE -- correct only because every ragged call happened to land on ttnn.softmax,
        # which masks its own tail, and one refactor away from the 71-76x SDPA defect.
        #
        # openbind shares OF3Trunk, so it cannot carry a different multiple; assert that rather
        # than pick one of the two rows and hope.
        assert bucket_multiple("openbind") == bucket_multiple("openfold3"), \
            "openbind runs the same OF3Trunk, so the two BUCKET_MULTIPLE rows must agree"
        tok_pad = pad_amount(n_token, bucket_multiple("openfold3")) if bucket_enabled() else 0
        n_tok_trunk = n_token + tok_pad
        pair_mask_pad = attn_mask_pad = None

        s_input_d = ft(s_input.unsqueeze(0))
        if isinstance(relpos, tuple):
            # derive_relpos_codes: the device expands the one-hots, the host keeps them only to pad.
            relpos_dev = pair_lookup_device(*relpos, self.device)
            relpos = relpos[1][relpos[0].long()] if tok_pad else None
        else:
            relpos_dev = ft(relpos.unsqueeze(0))
        token_bonds_dev = ft(token_bonds.unsqueeze(0).unsqueeze(-1))
        if tok_pad:
            # Trunk-local padded copies. The sampler keeps the unpadded s_input / relpos it has
            # always had, so nothing on the diffusion path moves; these are freed after the trunk.
            # Every OF3 trunk feature is already an embedded float here (no index-valued
            # feature survives host prep), so all of them take the poison value.
            q = pad_poison()
            _pad2 = lambda t: F.pad(t, (0, 0, 0, tok_pad, 0, tok_pad), value=q)  # [..., N, N, c]
            s_input_t = ft(F.pad(s_input, (0, 0, 0, tok_pad), value=q).unsqueeze(0))
            relpos_t = ft(_pad2(relpos).unsqueeze(0))
            token_bonds_t = ft(F.pad(token_bonds, (0, tok_pad, 0, tok_pad), value=q)
                               .unsqueeze(0).unsqueeze(-1))
            tmpl_h = {k: _pad2(v) for k, v in template_feat.items()}
            msa_d = F.pad(msa_feat, (0, 0, 0, tok_pad), value=q).unsqueeze(0)
            _, pair_mask_pad, attn_mask_pad = token_pad_masks_tt(
                n_token, n_tok_trunk, self.device)
        else:
            s_input_t, relpos_t, token_bonds_t = s_input_d, relpos_dev, token_bonds_dev
            tmpl_h = template_feat
            msa_d = msa_feat.unsqueeze(0)
        s_init_d, z_init_d = self.input_glue(s_input_t, relpos_t, token_bonds_t)
        # The template features stay on the host like msa_d: the trunk uploads each one, folds
        # it into its projection and frees it (TemplatePairFeatureEmbedder.features).
        s_trunk_d, z_trunk_d = self.trunk(s_init_d, z_init_d, tmpl_h, msa_d, s_input_t,
                                          progress_fn=progress_fn,
                                          template_slots=template_slots,
                                          pair_mask=pair_mask_pad, attn_mask=attn_mask_pad)
        if tok_pad:
            # Slice both trunk outputs back: the sampler wants them at the real n_token.
            s_trunk_d = ttnn.slice(s_trunk_d, (0, 0, 0), (1, n_token, s_trunk_d.shape[2]))
            z_trunk_d = ttnn.slice(z_trunk_d, (0, 0, 0, 0),
                                   (1, n_token, n_token, z_trunk_d.shape[3]))
            # msa_d is NOT here: it stays on the host and the trunk's `msa_embed` uploads it,
            # whole or a depth chunk at a time, so it is never held across the trunk.
            for t in (s_input_t, relpos_t, token_bonds_t, pair_mask_pad, attn_mask_pad):
                ttnn.deallocate(t)
        si_trunk_d = s_trunk_d
        zij_trunk_d = z_trunk_d

        si_input_dev = s_input_d
        n_tok = token_mask.shape[0]
        pair_mask = (token_mask[:, None] * token_mask[None, :]).reshape(n_tok, n_tok, 1).unsqueeze(0)
        tok_mask = token_mask.reshape(n_tok, 1).unsqueeze(0)
        pair_mask_dev, tok_mask_dev = ft(pair_mask), ft(tok_mask)
        tm_dev = ft(token_mask.reshape(1, n_tok))

        aux = build_dm_device_aux(
            self.device, ft,
            cl0=dm_aux_host["cl0"], plm0=dm_aux_host["plm0"],
            atom_mask=dm_aux_host["atom_mask"],
            atom_to_token_index=dm_aux_host["atom_to_token_index"],
            npe_q_indices=dm_aux_host["npe_q_indices"],
            npe_k_indices=dm_aux_host["npe_k_indices"],
            zij_mask=dm_aux_host["zij_mask"],
            key_block_idxs=dm_aux_host["key_block_idxs"],
            invalid_mask=dm_aux_host["invalid_mask"],
            mask_trunked=dm_aux_host["mask_trunked"],
            atom_to_token_mean=dm_aux_host["atom_to_token_mean"],
            token_mask=token_mask, n_atom=n_atom, n_token=n_token, nb=nb, NP=NP,
            n_tok_pad=n_tok_pad,
            cl0_d=dm_aux_host.get("cl0_d"), plm0_d=dm_aux_host.get("plm0_d"))

        dram_peak("of3 diffusion entry")
        noise_schedule = create_noise_schedule(no_rollout_steps, **self.ns_cfg)
        # Every sample's draws up front, each from its own seed, so a sample's numbers do not
        # depend on how many run beside it; then all of them step together (the sampler's list
        # form), max_parallel_samples per diffusion-module call.
        rollouts = [self._gen_rollout(noise_schedule, n_atom, seed + k) for k in range(no_samples)]
        _, _, _, _, t_l, c_tau_l = rollouts[0]
        xl_init_devs = [ft(r[0].unsqueeze(0)) for r in rollouts]
        if max_parallel_samples is None:
            max_parallel_samples = DEFAULT_MAX_PARALLEL_SAMPLES
        xl_final_devs = self.sampler(
            xl_init_devs, si_trunk_d, si_input_dev, zij_trunk_d, relpos_dev,
            tm_dev, pair_mask_dev, tok_mask_dev,
            aux["cl0_d"], aux["plm0_d"], aux["amc_d"], aux["amc_na_d"],
            aux["idx_tt"], aux["flat_tt"], aux["zij_mask_d"], aux["kidx_tt"],
            aux["valid_d"], aux["mb_d"], aux["pm_d"], aux["mean_d"],
            aux["tok_pad_tt"], aux["tok_col_pad_tt"],
            n_atom, NP, nb, n_token, n_tok_pad,
            noise_schedule, [r[1] for r in rollouts], [r[2] for r in rollouts],
            [r[3] for r in rollouts], t_l, c_tau_l,
            self.step_scale, progress_fn=progress_fn, max_parallel_samples=max_parallel_samples)
        del rollouts
        samples = []
        for sample_index, (x0, xf) in enumerate(zip(xl_init_devs, xl_final_devs)):
            xl_final = torch.Tensor(ttnn.to_torch(xf)).float().reshape(n_atom, 3)
            ttnn.deallocate(x0)
            ttnn.deallocate(xf)
            samples.append(xl_final)
            print(f"  [fold] sample {sample_index}: xl_final std={float(xl_final.std()):.4f} "
                  f"range=[{float(xl_final.min()):.2f},{float(xl_final.max()):.2f}]")
        dram_peak("diffusion samples done")

        confidence = []
        if confidence_aux_host is not None:
            if progress_fn is not None:
                progress_fn("confidence", step=0, total=0)
            si_trunk = torch.Tensor(ttnn.to_torch(si_trunk_d)).float().reshape(n_token, -1)
            # Trunk terms, computed with the first sample; the device trunk pair lets the head
            # build each sample's pair embedding and the distogram on device, so the pair itself
            # never comes back (OF3ConfidenceHead._z_embed_device).
            shared = {"zij_trunk_d": zij_trunk_d}
            if not distogram:
                shared["distogram"] = None
            confidence = [
                self._confidence(sample, s_input, si_trunk, None, confidence_aux_host,
                                 shared)
                for sample in samples
            ]
            if "z_ij_d" in shared:
                li_d, lj_d, tables_d = shared["z_ij_d"]
                for t in (li_d, lj_d, *tables_d):
                    ttnn.deallocate(t)
            best_index = max(range(len(samples)), key=lambda i: confidence[i]["ranking_score"])
            dram_peak(f"confidence done [samples={len(samples)}]")
        else:
            best_index = 0
        return OpenFold3FoldResult(samples, confidence, best_index)
