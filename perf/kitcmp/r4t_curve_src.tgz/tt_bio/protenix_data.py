"""Protenix-v2 inference featurization (offline protein case) for tt-bio.

Builds the model-ready input_feature_dict that tt_bio.protenix.Protenix.fold consumes,
WITHOUT the protenix data package. The model already regenerates the derived features
(relp, d_lm/v_lm/mask_trunked) internally (tt_bio.protenix), so the featurizer only emits
base features:

  token-level (this module, exactly reproduced vs the reference -- see below):
    restype, profile, deletion_mean, msa, has_deletion, deletion_value, token_bonds,
    asym_id, residue_index, entity_id, token_index, sym_id
  atom-level (CCD residue templates; see protein_atom_features):
    ref_pos, ref_space_uid, ref_charge, ref_element, ref_atom_name_chars, ref_mask,
    atom_to_token_idx
  template-level (dummy_template_features -- always emitted, see below):
    template_aatype, template_distogram, template_pseudo_beta_mask, template_unit_vector,
    template_backbone_frame_mask

Offline = single protein chain, no external MSA (msa = the query row; profile = restype;
deletions = 0), matching the reference's use_msa=False inference path. restype uses the
standard AF order (A R N D C Q E G H I L K M F P S T W Y V).

Templates are NOT conditional on --use_template: upstream's model config runs the template
embedder unconditionally (protenix-v2 sets template_embedder.n_blocks=2), so even the
use_template=False path pads to max_templates=4 dummy slots whose aatype one-hot (gap for
slot 0, ALA for the zero-padded slots 1-3) is real trunk input every recycling cycle --
see dummy_template_features for the exact reproduction of TemplateFeatureAssemblyLine's
always-on padding.
"""

from __future__ import annotations

import functools
import gzip
import json
import math
import pickle

import torch
from pathlib import Path

# standard AlphaFold restype order (index -> one-letter); index 7=G, 15=S (matches v2 golden)
RESTYPE_ORDER = "ARNDCQEGHILKMFPSTWYV"
RESTYPE_DIM = 32  # protenix restype width (20 aa + X/gap/other slots)


def residue_atoms(res: str) -> list:
    """Heavy-atom names of a protein residue, in CCD order: the atom list every Protenix-family
    featurizer lays out. The 20 standard residues are Boltz's ``const.ref_atoms``. UNK, which
    is what `X` in a sequence becomes, follows upstream Protenix (``constants.py``, "UNK": N CA
    C O CB CG) and the CCD component rather than Boltz's table, which stops at CB. The bundled
    conformers carry the CCD ideal coordinates for exactly these atoms."""
    from .data import const
    return ["N", "CA", "C", "O", "CB", "CG"] if res == "UNK" else list(const.ref_atoms[res])
MOL_TYPE_IDS = {"protein": 0, "rna": 1, "dna": 2, "ligand": 3}  # per-token mol_type enum (build_complex_features -> feats["mol_type"])
_AA1_TO_IDX = {c: i for i, c in enumerate(RESTYPE_ORDER)}

# CCD formal charges on amino-acid atoms. Protenix reads the PDB chemical component
# dictionary straight through, so this table is the CCD own `_chem_comp_atom.charge`
# column. Across the 20 standard residues plus UNK and MSE exactly three atoms are
# non-zero: the guanidinium NH2, the ammonium NZ, and histidine ND1, because the CCD
# ideal HIS is the protonated imidazolium. Derived from components.cif, not from a
# golden: `~/protenix_ref_out.pkl`, which the golden `test_protein_atom_metadata_exact`
# scores against, contains no histidine, which is why ND1 was missing until the CCD
# itself was read and the PXDesign input path scored a target that has one. Agrees with
# both the protenix 0.5.5 and 2.0 captures (scripts/pxdesign_port/parity_artifacts).
# Keep it CCD-derived; `test_formal_charge_table_is_ccd_complete` pins the whole table.
_FORMAL_CHARGE = {("ARG", "NH2"): 1.0, ("LYS", "NZ"): 1.0, ("HIS", "ND1"): 1.0}


def aatype_from_sequence(seq: str) -> torch.Tensor:
    """One-letter protein sequence -> aatype indices (unknown -> 20)."""
    return torch.tensor([_AA1_TO_IDX.get(c.upper(), 20) for c in seq], dtype=torch.long)


# protenix STD_RESIDUES_WITH_GAP token names beyond protein: RNA 21-25, DNA 26-30, gap 31
_RNA_NAMES = ["A", "G", "C", "U", "N"]
_DNA_NAMES = ["DA", "DG", "DC", "DT", "DN"]


def restype_to_resname(idx: torch.Tensor) -> list:
    """Per-token restype index -> CCD residue name (protein 3-letter / RNA / DNA / UNK).
    Modality-agnostic; used by the structure writer to label residues for any entity type."""
    from .data import const
    l2r = {v: k for k, v in const.prot_token_to_letter.items()}
    out = []
    for i in idx.tolist():
        if i < 20:
            out.append(l2r[RESTYPE_ORDER[i]])
        elif i < 26:
            out.append("UNK" if i == 20 else _RNA_NAMES[i - 21])
        elif i < 31:
            out.append(_DNA_NAMES[i - 26])
        else:
            out.append("UNK")
    return out


def load_ref_conformers() -> dict:
    """Bundled standard-residue reference conformers (CCD ideal coordinates, in
    const.ref_atoms order). {3-letter resname: (n_atom, 3) tensor}."""
    import json
    import os
    path = os.path.join(os.path.dirname(__file__), "data", "protein_ref_conformers.json")
    return {k: torch.tensor(v, dtype=torch.float32) for k, v in json.load(open(path)).items()}


MSA_GAP_IDX = RESTYPE_DIM - 1  # protenix MSA vocab: gap '-' is the last class (31)
# The alignment pool every upstream of this featurizer assembles at inference, paired rows first
# and at most half of it: Protenix v2.0.0 `MSAFeaturizer(max_msa_size=16384)`
# (protenix/data/msa/msa_featurizer.py:171,253,272-274), OpenDDE 1.1.1 the same class
# (opendde/data/msa/msa_featurizer.py:42,124,145, `msa_pool_size` 16384) and Protenix v0.5.0
# `max_size` 16384 (configs/configs_data.py:202-205). Rows past it are rows upstream never reads.
MSA_POOL_ROWS = 16384


def dummy_template_features(n_token: int, max_templates: int = 4) -> dict:
    """Reproduce upstream's TemplateFeatureAssemblyLine(max_templates=4) output for the
    use_template=False path (zero real templates found for every chain).

    protenix-v2's config sets template_embedder.n_blocks=2 unconditionally
    (configs/configs_model_type.py), so the reference's template embedder always runs, even
    with no real templates -- TemplateFeatures.empty_template_features fills slot 0's aatype
    with the gap token (STD_RESIDUES_WITH_GAP["-"] == MSA_GAP_IDX == 31) over zero atom
    positions/mask; the assembly line's np.pad (default fill 0) then zero-pads the remaining
    max_templates-1 slots' aatype to index 0 (ALA). All-zero atom mask makes every
    position-derived feature (distogram, pseudo-beta mask, unit vector, backbone-frame mask)
    exactly zero for every slot, regardless of the aatype fill -- verified against protenix's
    TemplateFeatures.dgram_from_positions / compute_template_unit_vector: the unit-vector
    division-by-(norm+epsilon) path degenerates cleanly to 0 for all-zero positions (no NaN).
    So template_aatype's one-hot (gap vs ALA) is the entire template-embedder signal under
    use_template=False, and is independent of chain boundaries (concatenating per-chain
    empty/padded features is elementwise identical to filling directly over n_token).
    """
    aatype = torch.zeros(max_templates, n_token, dtype=torch.long)
    aatype[0] = MSA_GAP_IDX
    return {
        "template_aatype": aatype,
        "template_distogram": torch.zeros(max_templates, n_token, n_token, 39),
        "template_pseudo_beta_mask": torch.zeros(max_templates, n_token, n_token),
        "template_unit_vector": torch.zeros(max_templates, n_token, n_token, 3),
        "template_backbone_frame_mask": torch.zeros(max_templates, n_token, n_token),
    }


def _msa_token(c: str) -> int:
    """a3m residue char -> protenix MSA token: aa->0-19 (AF order), '-'->31, else->UNK(20)."""
    if c == "-":
        return MSA_GAP_IDX
    i = _AA1_TO_IDX.get(c.upper(), -1)
    return i if 0 <= i < 20 else 20


def _parse_a3m(a3m: str) -> list[str]:
    """a3m text -> list of aligned sequence strings (query first)."""
    seqs, buf = [], []
    for line in a3m.splitlines():
        if line.startswith(">"):
            if buf:
                seqs.append("".join(buf)); buf = []
        elif line:
            buf.append(line.strip())
    if buf:
        seqs.append("".join(buf))
    return seqs


def _parse_a3m_to_msa(a3m: str, query: str):
    """a3m aligned to `query` -> (msa_tokens (M,n) long, raw_deletions (M,n) float), deduped
    (query is row 0). Returns None if the a3m query isn't aligned to this exact sequence.
    a3m convention: uppercase = match columns, lowercase = insertions (deletions relative to
    the query), '-' = gap."""
    rows = _parse_a3m(a3m)
    if not rows:
        return None

    def featurize(seq: str):
        toks, dels, d = [], [], 0
        for ch in seq:
            if ch.islower():          # insertion relative to query
                d += 1
            else:                      # match column (uppercase residue or '-')
                toks.append(_msa_token(ch)); dels.append(d); d = 0
        return toks, dels

    n_tok = len(query)
    if len(featurize(rows[0])[0]) != n_tok:
        return None                    # a3m query not aligned to this exact sequence
    msa, delmat, seen = [], [], set()
    for seq in rows:
        if seq in seen:                # dedup identical alignment rows (incl. insertions)
            continue
        seen.add(seq)
        toks, dels = featurize(seq)
        if len(toks) != n_tok:
            continue
        msa.append(toks); delmat.append(dels)
    return torch.tensor(msa, dtype=torch.long), torch.tensor(delmat, dtype=torch.float32)


def _msa_on_tokens(raw, msa_col, restype_idx):
    """A per-RESIDUE alignment placed on a chain's TOKENS.

    Identity when the chain has no modified residue (msa_col is then 0..n-1). A modified
    residue is tokenized per atom and those atom tokens have no alignment column, so they
    take GAP in every row and the token's own restype in the query row -- the same thing a
    ligand's atom tokens already get from the query-only path below.
    """
    m, dm = raw
    keep = msa_col >= 0
    if bool(keep.all()):
        return m, dm
    cols = msa_col[keep]
    out = torch.full((m.shape[0], msa_col.shape[0]), MSA_GAP_IDX, dtype=torch.long)
    outd = torch.zeros((m.shape[0], msa_col.shape[0]))
    out[:, keep] = m[:, cols]
    outd[:, keep] = dm[:, cols]
    out[0, ~keep] = restype_idx[~keep]
    return out, outd


def _parse_paired_a3m_to_msa(a3m: str, query: str):
    """Species-paired a3m -> (msa (M,n) long, deletion (M,n) float), NO dedup, rows kept in
    input order so cross-chain row j aligns by species/genome (ColabFold's pair endpoint and
    the reference MSAPairingEngine.pair_chains_by_species both produce row-aligned per-chain
    blocks). Dedup would break that alignment -- e.g. a chain with no paired homolog for a
    genome (the antigen in an Ab-Ag complex) carries an all-GAP row that is identical across
    genomes and must NOT be collapsed. Rows whose match-column count != len(query) become
    all-GAP rows to preserve row alignment. Returns None if the a3m query is unaligned."""
    n_tok = len(query)
    rows = _parse_a3m(a3m)
    if not rows:
        return None

    def featurize(seq: str):
        toks, dels, d = [], [], 0
        for ch in seq:
            if ch.islower():
                d += 1
            else:
                toks.append(_msa_token(ch)); dels.append(d); d = 0
        return toks, dels

    if len(featurize(rows[0])[0]) != n_tok:
        return None                       # paired a3m query not aligned to this sequence
    gap_row = [MSA_GAP_IDX] * n_tok
    zero_row = [0] * n_tok
    msa, delmat = [], []
    for seq in rows:
        toks, dels = featurize(seq)
        if len(toks) != n_tok:
            msa.append(gap_row); delmat.append(zero_row)     # preserve cross-chain alignment
        else:
            msa.append(toks); delmat.append(dels)
    return torch.tensor(msa, dtype=torch.long), torch.tensor(delmat, dtype=torch.float32)


def _msa_to_features(M: torch.Tensor, DM: torch.Tensor) -> dict:
    """MSA tokens (M,N) + RAW deletion counts (M,N) -> protenix MSA features. Per protenix
    (data/msa/msa_featurizer.py): profile = per-column token frequency over 32 classes (incl.
    gap), deletion_value = arctan(deletions/3)*2/pi, has_deletion = clip(deletions,0,1),
    deletion_mean = raw column-mean deletions. Single source for the single- and multi-chain paths."""
    profile = torch.stack([(M == k).float().mean(0) for k in range(RESTYPE_DIM)], dim=-1)
    return {
        "msa": M,
        "has_deletion": DM.clamp(0.0, 1.0),
        "deletion_value": torch.atan(DM / 3.0) * (2.0 / math.pi),
        "profile": profile,
        "deletion_mean": DM.mean(0),
    }


def protein_msa_features(a3m: str, query: str) -> dict | None:
    """Single-chain protenix MSA features from an a3m aligned to `query` (None if unaligned)."""
    raw = _parse_a3m_to_msa(a3m, query)
    return _msa_to_features(*raw) if raw is not None else None


def build_protein_features(sequence: str, a3m: str | None = None) -> dict:
    """Single protein chain -> model-ready input_feature_dict. Thin wrapper over
    build_complex_features for the common one-chain case (back-compatible)."""
    return build_complex_features([(sequence, a3m)])


def _is_backbone_bond(mol_type: str, atom_a: str, atom_b: str) -> bool:
    """Upstream OpenDDE's _is_polymer_backbone_bond: a peptide C-N or a nucleic O3'-P link."""
    pair = {atom_a, atom_b}
    if mol_type == "protein":
        return pair == {"C", "N"}
    return mol_type in ("dna", "rna") and "P" in pair and bool(pair & {"O3'", "O3*", "O3T"})


def _resolve_bond_token(placement: dict, cid, res, atom) -> int:
    """Map a `bond` constraint endpoint (chain id, 1-indexed residue, atom name) to its
    global token index, using the per-chain placement recorded in build_complex_features.
    A standard polymer residue is one token, so its atom name does not pick the token; it is
    still checked against the residue's atoms, because SG named on an Asp is a wrong input and
    not a bond. A ligand and a MODIFIED residue are tokenized per atom, so there the atom name
    picks the token. Either way an unknown name is an error rather than a bond quietly
    landing on the wrong atom."""
    cid = str(cid)
    if cid not in placement:
        raise ValueError(f"bond constraint references chain '{cid}', which is not in the input.")
    p = placement[cid]
    start = p["start"]
    if p["mt"] == "ligand":
        # A one-residue ligand takes its atom by name whatever residue is given; a multi-CCD
        # ligand (glycan) needs the residue too, 1-indexed in component order.
        key = (1 if p["n"] == 1 else int(res), atom)
        if p["atoms"] is None or key not in p["atoms"]:
            where = f"residue {res} of ligand '{cid}'" if p["n"] > 1 else f"ligand '{cid}'"
            raise ValueError(f"bond constraint references atom '{atom}' on {where}, "
                             "which has no such atom.")
        return start + p["atoms"][key]
    res = int(res)
    if not (1 <= res <= p["n"]):
        raise ValueError(f"bond constraint references residue {res} on chain '{cid}', "
                         f"which has only {p['n']} residues.")
    mod_atoms = p["res_atoms"].get(res)
    if mod_atoms is not None:
        if atom not in mod_atoms:
            raise ValueError(f"bond constraint references atom '{atom}' on modified residue "
                             f"{res} of chain '{cid}', which has no such atom.")
        return start + mod_atoms[atom]
    from .data import const
    name = p["res_names"][res - 1]
    known = residue_atoms(name) if name in const.ref_atoms else []
    if atom not in known and atom not in ("OXT", "OP3"):
        raise ValueError(f"bond constraint references atom '{atom}' on residue {res} ({name}) "
                         f"of chain '{cid}', which has atoms {', '.join(known)}.")
    return start + p["res_tok"][res - 1]


def build_complex_features(chains: list, mol_dir: str | None = None,
                           chain_ids: list | None = None, bonds: list | None = None,
                           paired_a3ms: list | None = None, oxt: list | None = None,
                           modifications: list | None = None, templates: list | None = None,
                           template_dir: str | None = None, conformer_table: dict | None = None,
                           constraints: dict | None = None) -> dict:
    """Multi-chain biomolecular complex -> model-ready input_feature_dict.

    chains: list of (sequence, a3m_or_None[, mol_type]); mol_type is "protein" (default),
    "rna", "dna" or "ligand" (sequence carries 'CCD_<code>' or a SMILES string). Identical
    (mol_type, sequence) pairs share an entity_id and get distinct sym_ids (homomer copies);
    each chain gets its own asym_id. Polymer chains are tokenized per residue (atoms from
    bundled CCD protein conformers / CCD `mols` rdkit templates), ligands per atom (restype
    UNK, intra-ligand bonds in token_bonds). residue_index restarts per chain (so the
    relative-position encoding sees chain breaks; ligand atoms share residue_index 1);
    ref_space_uid is a global per-residue counter; token_index is global. The MSA is assembled
    BLOCK-DIAGONALLY the way the reference merges per-chain MSAs: each chain's alignment (query
    as row 0) is padded to the max chain depth with GAP and the per-chain arrays are concatenated
    column-wise into one (max_d, N_tot) tensor; profile and deletion_mean are computed per chain
    (over that chain's rows only) so a chain's column statistics are not diluted by other chains'
    GAP padding. NA/ligand chains contribute only the query row. The model regenerates relp /
    d_lm / v_lm / mask_trunked from these.

    paired_a3ms: optional list parallel to ``chains`` carrying a species-paired
    a3m per chain (rows aligned across chains by species/genome, e.g. ColabFold's
    pair endpoint or the reference ``MSAPairingEngine.pair_chains_by_species``).
    When supplied for a multi-chain complex the paired rows are column-concatenated
    into one block and stacked ON TOP of the unpaired block (the cross-chain
    co-evolution signal; matches the reference's ``merged[msa] = concat([msa_all_seq,
    msa], axis=0)``). Single-chain / all-None callers get byte-identical output to
    the unpaired-only path.

    chain_ids: per-chain id parallel to `chains`, needed only to resolve `bonds`.
    bonds: covalent `bond` constraints as ((chain, res, atom), (chain, res, atom)) pairs;
    each marks its two endpoint tokens as bonded in token_bonds (the only constraint signal
    the trunk reads).
    modifications: optional list parallel to `chains`, each the reader's
    `[{"position": 1-indexed, "ccd": CODE}]` for that chain or None. A modified residue is
    tokenized per atom from its CCD component (AF3 SI 2.6) by `polymer_chain_features`, so
    the chain gains tokens but not residues; None everywhere reproduces the per-residue path
    exactly.
    templates: optional list parallel to `chains`, each a `templates:` alignment npz for that
    protein chain or None, with the template coordinates under `template_dir`. Without one the
    template features are `dummy_template_features` -- all-gap, zero geometry -- which is what
    every fold got before, so an input with no templates is byte-identical.
    conformer_table: a model's own reference conformers ({CCD code: {atom name: xyz}},
    load_conformer_table). Atoms it names take its coordinates in place of the CCD ideal ones;
    None keeps the ideal ones. A table that carries topology also supplies the CCD codes the
    `mols` library lacks (ccd_mols).
    constraints: Mol-1-constraint SITE / CONTACT / EXCLUSION, as `mol1_constraint.parse` returns them; adds
    `constraint_pair`, their pair masks on the token axis. Needs chain_ids."""
    if constraints:
        if chain_ids is None:
            raise ValueError("Mol-1 constraints need chain ids")
        from .mol1_constraint import pair_channels
    norm = [(e[0], e[1], e[2] if len(e) > 2 else "protein") for e in chains]
    conformers = load_ref_conformers()
    # CCD codes needed from the `mols` library: nucleic-acid residues + CCD ligands.
    ccd_codes = {c for seq, _, mt in norm if mt in ("rna", "dna") for c in _na_res_codes(seq, mt)}
    ccd_codes |= {c for seq, _, mt in norm if mt == "ligand" and seq.startswith("CCD_") for c in _ccd_list(seq)}
    ccd_codes |= {str(m["ccd"]).upper() for ms in (modifications or []) if ms for m in ms}
    mols = ccd_mols(sorted(ccd_codes), mol_dir, conformer_table) if ccd_codes else {}
    if conformer_table is not None:
        conformers, mols = with_conformer_table(conformers, mols, conformer_table)

    entity_of = {}                                   # (mol_type, sequence) -> entity_id
    sym_counter = {}                                 # entity_id -> next copy index
    restype, asym, entity, sym, resid, mol_type = [], [], [], [], [], []
    atom_feats, block_bonds = [], []                 # per-chain atom features; (tok_off, local_bonds)
    tok_off, res_off = 0, 0                           # global token / residue-frame counters
    per_chain_msa = []                               # (start_col, n_tok, raw_msa|None, restype_idx, seq, msa_col)
    placement = {}                                    # chain_id -> how a bond endpoint resolves
    tpl_blocks = []                                   # (tok_off, msa_col, aatype, pos, mask)
    c_bonded = {(str(c), int(r)) for pair in (bonds or []) for c, r, a in pair if a == "C"}
    for ci, (seq, a3m, mt) in enumerate(norm):
        lig_names, res_tok, res_atoms = None, None, {}
        msa_col, mt_feat = None, mt
        if mt == "ligand" and seq.startswith("CCD_"):
            # One residue per CCD component (a glycan "NAG,NAG" is residues 1 and 2), each
            # tokenized per atom; the leaving atoms a covalent bond consumes are dropped.
            drops = _ccd_leaving_drops(seq, mols, chain_ids[ci] if chain_ids is not None else None,
                                       bonds)
            af, n, lbonds, lig_names, res_index, rt_idx, mt_feat = ccd_ligand_features(
                seq, mols, drops, conformers)
            n_res = int(res_index.max())
            block_bonds.append((tok_off, lbonds))
        elif mt == "ligand":
            af, n, lbonds, names = ligand_atom_features(_ligand_mol(seq, mols))
            lig_names = {(1, nm): i for i, nm in enumerate(names)}
            rt_idx = torch.full((n,), 20, dtype=torch.long)   # ligand atoms are restype UNK
            res_index = torch.ones(n, dtype=torch.long)       # all atoms share residue_index 1
            n_res = 1
            block_bonds.append((tok_off, lbonds))
        else:
            mods_ci = modifications[ci] if modifications else None
            oxt_ci = None if oxt is None else oxt[ci]
            if mt == "protein" and c_bonded and chain_ids is not None:
                # A bond on a residue's backbone C consumes its OXT, the CCD leaving group
                # upstream's remove_leaving_atoms drops. A cyclic peptide's closing amide
                # left it on, so the ring's carbon carried four heavy neighbours and the
                # N-C distance could not come below ~2.2 A.
                taken = {r for c, r in c_bonded if c == str(chain_ids[ci])}
                if taken:
                    n_seq = len("".join(str(seq).split()))
                    oxt_ci = [(bool(oxt_ci[k]) if oxt_ci is not None else k == n_seq - 1)
                              and k + 1 not in taken for k in range(n_seq)]
            af, rt_idx, res_index, mbonds, res_tok, res_atoms, msa_col = polymer_chain_features(
                seq, mt, mods_ci, conformers, mols, oxt=oxt_ci)
            n = rt_idx.shape[0]
            n_res = len(res_tok)
            if mbonds is not None:                            # modified residues: CCD bonds
                block_bonds.append((tok_off, mbonds))         # block-placed
        eid = entity_of.setdefault((mt, seq), len(entity_of))
        sid = sym_counter.get(eid, 0); sym_counter[eid] = sid + 1
        restype.append(torch.nn.functional.one_hot(rt_idx.clamp(max=RESTYPE_DIM - 1), RESTYPE_DIM).float())
        asym.append(torch.full((n,), ci, dtype=torch.long))
        entity.append(torch.full((n,), eid, dtype=torch.long))
        sym.append(torch.full((n,), sid, dtype=torch.long))
        resid.append(res_index)
        mol_type.append(torch.full((n,), MOL_TYPE_IDS[mt_feat], dtype=torch.long))
        af["atom_to_token_idx"] = af["atom_to_token_idx"] + tok_off
        af["ref_space_uid"] = af["ref_space_uid"] + res_off
        atom_feats.append(af)
        raw = _parse_a3m_to_msa(a3m, seq) if (mt == "protein" and a3m) else None
        if raw is not None and msa_col is not None:
            raw = _msa_on_tokens(raw, msa_col, rt_idx)
        per_chain_msa.append((tok_off, n, raw, rt_idx, seq, msa_col))
        tpl = templates[ci] if templates else None
        if tpl and mt == "protein":
            from .protenix_template import chain_template_arrays, read_alignment_entries
            entries = read_alignment_entries(tpl)
            if entries:
                cols = msa_col if msa_col is not None else torch.arange(n)
                tpl_blocks.append((tok_off, cols.tolist(),
                                   *chain_template_arrays(len("".join(str(seq).split())),
                                                          entries, template_dir)))
        if chain_ids is not None:
            placement[str(chain_ids[ci])] = {"start": tok_off, "mt": mt, "n": n_res, "tokens": n,
                                             "atoms": lig_names, "res_tok": res_tok,
                                             "res_atoms": res_atoms,
                                             "res_names": _res_names(seq, mt)}
        tok_off += n
        res_off += n_res
    N_tot = tok_off

    # Block-diagonal MSA, assembled the way the reference merges per-chain MSAs
    # (protenix/opendde data/msa/msa_featurizer.py + MSAPairingEngine.merge_chain_features):
    # each chain's own MSA (query as row 0) is padded to the max chain depth with GAP and the
    # per-chain arrays are concatenated COLUMN-WISE into one (max_d, N_tot) tensor -- one
    # horizontal slice per alignment index, not one full-width row per chain. profile and
    # deletion_mean are computed PER CHAIN (over that chain's rows only) and concatenated, so
    # a chain's column statistics are not diluted by the other chains' GAP padding. The prior
    # whole-MSA aggregate was a multi-chain bug: on 9dsg it diluted the Fab-heavy profile
    # (117 rows) to ~99.5% GAP and the antigen (12651 rows) to ~47% GAP. Single-chain behavior
    # is unchanged (max_d == m, per-chain == whole).
    GAP = MSA_GAP_IDX
    chain_msa, chain_del, prof_parts, delmean_parts = [], [], [], []
    for _start, n, raw, aatype, _seq, _col in per_chain_msa:
        if raw is None:
            m = aatype.unsqueeze(0).clone()                 # no MSA -> query only (1 row)
            dm = torch.zeros((1, n))
        else:
            m, dm = raw                                     # (m, n) incl. query row 0
        chain_msa.append(m); chain_del.append(dm)
        prof_parts.append(torch.stack([(m == k).float().mean(0) for k in range(RESTYPE_DIM)], dim=-1))
        delmean_parts.append(dm.mean(0))
    max_d = max(m.shape[0] for m in chain_msa)
    msa_full = torch.full((max_d, N_tot), GAP, dtype=torch.long)
    del_full = torch.zeros((max_d, N_tot))
    off = 0
    for m, dm in zip(chain_msa, chain_del):
        r = m.shape[0]; w = m.shape[1]
        msa_full[:r, off:off + w] = m
        del_full[:r, off:off + w] = dm
        off += w
    # Paired MSA block (cross-chain co-evolution signal). Per-chain paired a3ms --
    # species-aligned across chains, e.g. ColabFold's pair endpoint or the reference
    # MSAPairingEngine.pair_chains_by_species -- are column-concatenated into one
    # (max_pd, N_tot) tensor and stacked ON TOP of the unpaired block, matching the
    # reference's merged[msa] = concat([msa_all_seq, msa], axis=0) (opendde
    # data/msa/msa_featurizer.py step 6). The query (row 0 of each paired a3m) is
    # dropped here -- it is already row 0 of the unpaired block -- so the query is
    # not double-counted (the reference does the equivalent via
    # cleanup_unpaired_features). profile/deletion_mean stay per-chain over the
    # UNPAIRED block (the reference computes them before pairing). Single-chain or
    # no-paired-a3m callers (paired_a3ms is None / all-None, or every paired a3m is
    # query-only) get max_pd == 0 and byte-identical output to the unpaired-only path.
    paired_chain_msa = []
    pa_iter = iter(paired_a3ms) if paired_a3ms else None
    for _start, n, _raw, aatype, seq, col in per_chain_msa:
        pa3m = next(pa_iter) if pa_iter is not None else None
        praw = _parse_paired_a3m_to_msa(pa3m, seq) if pa3m else None
        if praw is not None and col is not None:
            praw = _msa_on_tokens(praw, col, aatype)
        if praw is not None and praw[0].shape[0] > 1:
            pm, pdm = praw                            # keep all rows (incl. query) for alignment
        else:
            pm = torch.empty((0, n), dtype=torch.long); pdm = torch.empty((0, n))
        paired_chain_msa.append((pm, pdm))
    # Truncate every chain's paired block to the MIN row count, then drop the query (row 0).
    # ColabFold's pair endpoint returns equal row counts per chain (row-aligned by genome);
    # the min-truncate is a robustness guard in case a chain's paired a3m is shorter. Dropping
    # the query avoids double-counting it (it is already row 0 of the unpaired block); the
    # reference does the equivalent via cleanup_unpaired_features.
    # Only protein chains pair (the reference's msa_featurizer pairs PROTEIN_CHAIN only); a
    # nucleic-acid or ligand chain keeps an empty block and reads as gaps in the paired rows.
    prot_pd = [pm.shape[0] for (pm, _), (_s, _a, mt) in zip(paired_chain_msa, norm) if mt == "protein"]
    if prot_pd and all(prot_pd):
        # Upstream keeps at most MSA_POOL_ROWS // 2 paired rows counting the query, which this
        # layout carries in the unpaired block instead.
        min_pd = min(min(prot_pd), MSA_POOL_ROWS // 2)
        paired_chain_msa = [(pm[1:min_pd], pdm[1:min_pd]) for pm, pdm in paired_chain_msa]
        max_pd = min_pd - 1
    else:
        max_pd = 0
    # Each chain's unpaired rows fill the pool after its paired ones (upstream step 4, first rows
    # kept). profile and deletion_mean above were taken before the crop, as upstream takes them.
    msa_full = msa_full[:MSA_POOL_ROWS - max_pd]
    del_full = del_full[:MSA_POOL_ROWS - max_pd]
    if max_pd > 0:
        paired_full = torch.full((max_pd, N_tot), GAP, dtype=torch.long)
        paired_del = torch.zeros((max_pd, N_tot))
        off = 0
        for pm, pdm in paired_chain_msa:
            r, w = pm.shape
            if r:
                paired_full[:r, off:off + w] = pm
                paired_del[:r, off:off + w] = pdm
            off += w
        msa_full = torch.cat([paired_full, msa_full], dim=0)
        del_full = torch.cat([paired_del, del_full], dim=0)
    msa_feats = {
        "msa": msa_full,
        "has_deletion": del_full.clamp(0.0, 1.0),
        "deletion_value": torch.atan(del_full / 3.0) * (2.0 / math.pi),
        "profile": torch.cat(prof_parts, 0),
        "deletion_mean": torch.cat(delmean_parts, 0),
    }

    token_bonds = torch.zeros(N_tot, N_tot)
    for off, lb in block_bonds:              # intra-ligand and modified-residue bonds
        token_bonds[off:off + lb.shape[0], off:off + lb.shape[1]] = lb

    # User covalent `bond` constraints (e.g. a covalent inhibitor, or a glycan/crosslink):
    # mark the two endpoint tokens as bonded, exactly like an intra-ligand bond. A polymer
    # endpoint resolves to its per-residue token (1-indexed res); a ligand endpoint to the
    # token of the named atom. token_bonds is the only constraint signal Protenix-v2 consumes
    # (the trunk has no constraint embedder), so pocket/contact are rejected upstream.
    # A bond that closes the chain's own backbone (a head-to-tail cyclic peptide's C-N) is also
    # a residue-graph edge for OpenDDE (opendde_data._residue_adjacency); kept only when one
    # exists, so every other input's feature dict is unchanged.
    backbone = []
    for (c1, r1, a1), (c2, r2, a2) in (bonds or []):
        t1 = _resolve_bond_token(placement, c1, r1, a1)
        t2 = _resolve_bond_token(placement, c2, r2, a2)
        token_bonds[t1, t2] = token_bonds[t2, t1] = 1.0
        if t1 != t2 and str(c1) == str(c2) and _is_backbone_bond(placement[str(c1)]["mt"], a1, a2):
            backbone.append(sorted((t1, t2)))

    feats = {
        "restype": torch.cat(restype, 0),
        "token_bonds": token_bonds,
        **({"constraint_pair": pair_channels(constraints, placement, N_tot)} if constraints else {}),
        "asym_id": torch.cat(asym, 0),
        "entity_id": torch.cat(entity, 0),
        "sym_id": torch.cat(sym, 0),
        "residue_index": torch.cat(resid, 0),
        "mol_type": torch.cat(mol_type, 0),
        "token_index": torch.arange(0, N_tot, dtype=torch.long),
        **msa_feats,
    }
    if backbone:
        feats["polymer_backbone_bonds"] = torch.tensor(backbone, dtype=torch.long)
    # concat atom features across chains (atom_to_token_idx / ref_space_uid already offset)
    for k in atom_feats[0]:
        feats[k] = torch.cat([af[k] for af in atom_feats], 0)
    if tpl_blocks:
        from .protenix_template import complex_template_features
        feats.update(complex_template_features(tpl_blocks, N_tot))
    else:
        feats.update(dummy_template_features(N_tot))
    return feats


class _CcdUnpickler(pickle.Unpickler):
    """Upstream's CCD pickle holds RDKit mols with numpy attributes and nothing else, so nothing else
    may be constructed while reading it."""
    _ALLOWED = {("rdkit.Chem.rdchem", "Mol"), ("numpy", "ndarray"), ("numpy", "dtype"),
                ("numpy._core.multiarray", "_reconstruct"), ("numpy.core.multiarray", "_reconstruct")}

    def find_class(self, module, name):
        if (module, name) not in self._ALLOWED:
            raise pickle.UnpicklingError(f"CCD pickle names {module}.{name}, which a conformer table never holds")
        if module == "numpy._core.multiarray":   # written by numpy 2; numpy 1 calls it numpy.core
            import numpy
            module = module if hasattr(numpy, "_core") else "numpy.core.multiarray"
        return super().find_class(module, name)


def write_conformer_table(pkl, out, codes=None) -> int:
    """Reduce an upstream CCD pickle ({code: RDKit mol}, components.cif.rdkit_mol.pkl) to the npz
    load_conformer_table reads: each code's conformer at mol.ref_conf_id, which is what upstream's
    get_ccd_ref_info uses, in the mol's atom order with its atom names, plus each atom's element and
    formal charge and the mol's bonds, so a code the `mols` library lacks can be built from it.
    ``codes`` keeps only those codes. Returns the code count."""
    import numpy as np
    import rdkit.Chem  # noqa: F401  (registers the Mol pickle support)
    with open(pkl, "rb") as fh:
        mols = _CcdUnpickler(fh).load()
    keep, counts, names, xyz, elements, charges, nbonds, bonds = [], [], [], [], [], [], [], []
    for code, mol in mols.items():
        n = mol.GetNumAtoms()
        if n == 0 or (codes is not None and code not in codes):
            continue
        inv = {i: a for a, i in mol.atom_map.items()}
        keep.append(code)
        counts.append(n)
        names += [inv[i] for i in range(n)]
        xyz.append(mol.GetConformer(mol.ref_conf_id).GetPositions().astype(np.float32))
        elements += [a.GetAtomicNum() for a in mol.GetAtoms()]
        charges += [a.GetFormalCharge() for a in mol.GetAtoms()]
        nbonds.append(mol.GetNumBonds())
        bonds += [(b.GetBeginAtomIdx(), b.GetEndAtomIdx()) for b in mol.GetBonds()]
    np.savez_compressed(out, codes=np.array(keep), counts=np.array(counts, np.int32), names=np.array(names),
                        xyz=np.concatenate(xyz), elements=np.array(elements, np.uint8),
                        charges=np.array(charges, np.int8), bond_counts=np.array(nbonds, np.int32),
                        bonds=np.array(bonds, np.int16).reshape(-1, 2))
    return len(keep)


class CcdTable(dict):
    """{CCD code: {atom name: (3,) float32 array}}, a model's own reference conformers. When the npz
    carries topology (write_conformer_table), ``mol(code)`` also builds the code's RDKit mol."""

    _topology = None                      # (index, elements, charges, atom offsets, bonds, bond offsets)

    def mol(self, code):
        """The code's mol shaped like a `mols` library entry: every atom (hydrogens too) with its
        CCD name, formal charge and leaving-atom flag, the table's conformer, the CCD bonds (only
        adjacency is read, so every bond is SINGLE). None when the table cannot build it."""
        if self._topology is None or code not in self._topology[0]:
            return None
        from rdkit import Chem
        from rdkit.Geometry import Point3D
        index, elements, charges, off, bonds, boff = self._topology
        i = index[code]
        leaving = set(_ccd_leaving_atoms().get(code, ()))
        mol = Chem.RWMol()
        conf = Chem.Conformer(int(off[i + 1] - off[i]))
        for k, ((name, xyz), z, q) in enumerate(zip(self[code].items(), elements[off[i]:off[i + 1]],
                                                    charges[off[i]:off[i + 1]])):
            atom = Chem.Atom(int(z))
            atom.SetFormalCharge(int(q))
            atom.SetProp("name", name)
            atom.SetBoolProp("leaving_atom", name in leaving)
            mol.AddAtom(atom)
            conf.SetAtomPosition(k, Point3D(*map(float, xyz)))
        for u, v in bonds[boff[i]:boff[i + 1]]:
            mol.AddBond(int(u), int(v), Chem.BondType.SINGLE)
        mol.AddConformer(conf, assignId=True)
        return mol.GetMol()


def load_conformer_table(path) -> CcdTable:
    """The CcdTable in an npz of codes / counts / names / xyz (and, from write_conformer_table,
    elements / charges / bond_counts / bonds), the layout written from an upstream CCD pickle."""
    import numpy as np
    with np.load(path) as z:    # each z[key] re-reads its array from the zip, so read every one once
        arrays = {k: z[k] for k in z.files}
    codes, counts, names, xyz = (arrays[k] for k in ("codes", "counts", "names", "xyz"))
    off = np.concatenate([[0], np.cumsum(counts)])
    table = CcdTable((str(c), dict(zip(map(str, names[off[i]:off[i + 1]]), xyz[off[i]:off[i + 1]])))
                     for i, c in enumerate(codes))
    if "bonds" in arrays:
        table._topology = ({str(c): i for i, c in enumerate(codes)}, arrays["elements"], arrays["charges"], off,
                           arrays["bonds"], np.concatenate([[0], np.cumsum(arrays["bond_counts"])]))
    return table


@functools.cache
def _ccd_leaving_atoms() -> dict:
    """CCD code -> the heavy atoms its `_chem_comp_atom.pdbx_leaving_atom_flag` marks, for the codes
    that have any. Extracted from the components.cif Mol-1 ships by scripts/mol1_io/leaving_atoms_table.py."""
    with gzip.open(Path(__file__).parent / "data" / "ccd_leaving_atoms.json.gz", "rt") as fh:
        return json.load(fh)


def ccd_mols(codes, mol_dir=None, table=None) -> dict:
    """Each CCD code's template mol: the `mols` library's, else the one the model's own CCD table
    builds (a component newer than the library). A code in neither is refused by name."""
    from .data.mol import load_molecules
    mol_dir = str(mol_dir or _default_mol_dir())
    out = {}
    for code in codes:
        try:
            out.update(load_molecules(mol_dir, [code]))
        except FileNotFoundError as e:
            mol = table.mol(code) if isinstance(table, CcdTable) else None
            if mol is None:                           # a typo'd ccd/modification code
                raise ValueError(
                    f"{code!r} is not a CCD component this build knows; check the code in the "
                    "input's `ligand:` or `modifications:` block.") from e
            out[code] = mol
    return out


def with_conformer_table(conformers: dict, mols: dict, table: dict):
    """The standard-residue conformers and CCD mols with every atom the table names moved to its
    coordinates. A residue conformer gains an OXT row when the table has one (protein_atom_features
    reads it there). The mols are copies; the shared library is left alone."""
    from rdkit import Chem
    from rdkit.Geometry import Point3D
    conformers = dict(conformers)
    for res, conf in list(conformers.items()):
        own = table.get(res)
        if not own:
            continue
        names = residue_atoms(res)
        conf = torch.as_tensor(conf, dtype=torch.float32).clone()[:len(names)]
        for k, nm in enumerate(names[:conf.shape[0]]):
            if nm in own:
                conf[k] = torch.as_tensor(own[nm])
        if "OXT" in own:
            conf = torch.cat([conf, torch.as_tensor(own["OXT"])[None]], 0)
        conformers[res] = conf
    out = {}
    for code, mol in mols.items():
        own = table.get(code)
        if own:
            mol = Chem.Mol(mol)
            c = mol.GetConformer()
            for a in mol.GetAtoms():
                nm = a.GetProp("name") if a.HasProp("name") else None
                if nm in own:
                    c.SetAtomPosition(a.GetIdx(), Point3D(*map(float, own[nm])))
        out[code] = mol
    return conformers, out


def protein_atom_features(aatype: torch.Tensor, conformers: dict, oxt=None) -> dict:
    """Atom-level features for a single offline protein chain.

    Reuses tt_bio.data.const.ref_atoms (per-residue atom names, in the canonical CCD order
    that matches the v2 reference exactly -- validated 20/20 residue types). Per-atom:
      ref_element  = one_hot(atomic_number - 1, 128)   (C->5, N->6, O->7, ... validated)
      ref_charge   = the CCD formal charge (_FORMAL_CHARGE; 0 on all but three atoms)
      ref_atom_name_chars = one_hot over 64 of (ord(c)-32) for 4 chars (space-padded)
      ref_mask     = 1
      atom_to_token_idx = residue index per atom; ref_space_uid = same (per-residue frame)
      ref_pos      = conformers[res] (a valid per-residue reference conformer; the reference
                     uses a STOCHASTIC RDKit conformer, so any valid one folds correctly).
    conformers: {3-letter resname: (n_atom, 3) local coords in ref_atoms order}.
    oxt: per-residue bool for the terminal carboxylate oxygen. None means the sequence-input
    default, OXT on the last residue only. A chain read out of a structure file passes the
    file's own answer instead, because a chain cropped mid-sequence has no C-terminus and
    the reference does not invent one there.
    """
    from .data import const
    letter_to_res = {v: k for k, v in const.prot_token_to_letter.items()}
    z_of = const.element_to_atomic_num  # symbol -> atomic number
    n_tok = aatype.shape[0]
    ref_pos, ref_charge, ref_mask, a2t, ruid = [], [], [], [], []
    elem_idx, name_chars, tokatom, disto_rep = [], [], [], []
    for t, aa in enumerate(aatype.tolist()):
        res = letter_to_res[RESTYPE_ORDER[aa]] if aa < len(RESTYPE_ORDER) else "UNK"
        atoms = residue_atoms(res)
        disto_atom = const.res_to_disto_atom.get(res, "CA")  # distogram rep atom (CB, or CA for GLY)
        conf = torch.as_tensor(conformers[res], dtype=torch.float32)
        if bool(oxt[t]) if oxt is not None else t == n_tok - 1:  # C-terminal carboxylate O
            # OXT from a conformer that carries it (one row past the residue's atoms), else the
            # carboxylate mirror of O through C (any valid ref conformer)
            c_i, o_i = atoms.index("C"), atoms.index("O")
            atoms = atoms + ["OXT"]
            if conf.shape[0] < len(atoms):
                conf = torch.cat([conf, (2 * conf[c_i] - conf[o_i])[None]], 0)
        conf = conf[:len(atoms)]
        for k, nm in enumerate(atoms):
            elem_idx.append(z_of[nm[0]] - 1)
            ref_charge.append(_FORMAL_CHARGE.get((res, nm), 0.0))
            ref_mask.append(1.0)
            a2t.append(t); ruid.append(t)
            tokatom.append(k)                       # index of this atom within its token
            disto_rep.append(1.0 if nm == disto_atom else 0.0)  # distogram rep atom (res_to_disto_atom)
            padded = (nm + "    ")[:4]
            name_chars.append([ord(c) - 32 for c in padded])
        ref_pos.append(conf)
    return _assemble_atom_features(torch.cat(ref_pos, 0), elem_idx, ref_charge, ref_mask,
                                   a2t, ruid, tokatom, disto_rep, name_chars)


def place_ref_conformers(feats: dict, seed=None) -> dict:
    """Upstream OpenDDE's Featurizer.get_reference_features: every reference conformer (one per
    ref_space_uid, ascending) is centred on its mean and, with a seed, given a random translation in
    [-1, 1) A per axis and then a random rotation (ref_pos_augment, on at inference). The draws come
    from a RandomState seeded like upstream's np.random.seed(seed), in upstream's order, so a seed
    gives upstream's rotations exactly. Returns a new dict; `feats` is not modified."""
    import numpy as np
    from scipy.spatial.transform import Rotation
    pos = feats["ref_pos"].numpy()
    uid = feats["ref_space_uid"].numpy()
    rs = None if seed is None else np.random.RandomState(seed)
    out = np.empty_like(pos)
    for u in np.unique(uid):
        m = uid == u
        p = pos[m] - pos[m].mean(axis=0)
        if rs is not None:
            t = rs.uniform(-1.0, 1.0, size=3)
            p = np.dot(p, Rotation.random(random_state=rs).as_matrix().T) + t
        out[m] = p
    return {**feats, "ref_pos": torch.as_tensor(out, dtype=torch.float32)}


def _assemble_atom_features(ref_pos, elem_idx, ref_charge, ref_mask, a2t, ruid,
                            tokatom, disto_rep, name_chars) -> dict:
    """Pack per-atom lists into the model-ready atom feature tensors (shared by every
    modality's atom-feature builder). elem_idx = atomic_number - 1 (one_hot over 128);
    name_chars = per-atom [4] of ord(c)-32; the rest are 1:1 per-atom annotations."""
    from .data import const
    F = torch.nn.functional
    return {
        "ref_pos": ref_pos,
        "ref_element": F.one_hot(torch.tensor(elem_idx), const.num_elements).float(),
        "ref_charge": torch.tensor(ref_charge),
        "ref_atom_name_chars": F.one_hot(torch.tensor(name_chars), 64).float(),
        "ref_mask": torch.tensor(ref_mask),
        "atom_to_token_idx": torch.tensor(a2t, dtype=torch.long),
        "ref_space_uid": torch.tensor(ruid, dtype=torch.long),
        "atom_to_tokatom_idx": torch.tensor(tokatom, dtype=torch.long),
        "distogram_rep_atom_mask": torch.tensor(disto_rep),
    }


# Nucleic-acid residue tokenization (v2 STD_RESIDUES: RNA 21-25, DNA 26-30; N/DN = unknown).
_RNA_LETTER_IDX = {"A": 21, "G": 22, "C": 23, "U": 24}
_DNA_LETTER_IDX = {"A": 26, "G": 27, "C": 28, "T": 29}
_NA_PURINES = {"A", "G", "DA", "DG"}
_NA_PYRIMIDINES = {"C", "U", "DC", "DT"}


def seq_to_restype(seq: str, mol_type: str = "protein") -> torch.Tensor:
    """One-letter sequence -> 32-class restype indices for the given modality
    (protein 0-20, RNA 21-25, DNA 26-30); unknown letters map to the modality's UNK.

    Whitespace is stripped first: a sequence pasted from a formatted source carries spaces/
    newlines, and without this each space would tokenize to UNK and silently add a residue,
    shifting the whole chain. Matches the Boltz and ESMFold parsers, which also strip. A
    whitespace-free sequence is unchanged, so this does not perturb the validated path."""
    seq = "".join(seq.split())
    if mol_type == "protein":
        return aatype_from_sequence(seq)
    table, unk = (_RNA_LETTER_IDX, 25) if mol_type == "rna" else (_DNA_LETTER_IDX, 30)
    return torch.tensor([table.get(c.upper(), unk) for c in seq], dtype=torch.long)


def _res_names(seq, mol_type: str) -> list:
    """Per-residue CCD code of a polymer chain, the key into const.ref_atoms (None for a ligand)."""
    from .data import const
    if mol_type == "ligand":
        return None
    seq = "".join(str(seq).split())
    if mol_type in ("rna", "dna"):
        return _na_res_codes(seq, mol_type)
    return [const.prot_letter_to_token.get(c.upper(), "UNK") for c in seq]


def _na_res_codes(seq: str, mol_type: str) -> list:
    """Per-residue CCD codes for a nucleic-acid sequence (RNA: A/G/C/U/N; DNA: DA/.../DN)."""
    if mol_type == "rna":
        return [c.upper() if c.upper() in ("A", "G", "C", "U") else "N" for c in seq]
    return [("D" + c.upper()) if c.upper() in ("A", "G", "C", "T") else "DN" for c in seq]


def na_atom_features(res_codes: list, mols: dict, first_res: bool = True) -> dict:
    """Atom-level features for one nucleic-acid chain (one CCD code per residue token).

    Mirrors protein_atom_features but sources heavy atoms (name / element / charge /
    reference-conformer coords) from the CCD rdkit Mol -- whose heavy-atom order matches
    the v2 reference RES_ATOMS_DICT exactly (validated). The 5'-terminal phosphate oxygen
    OP3 is kept only on the first residue and dropped from the rest (the reference's chain
    convention, analogous to protein OXT). Distogram rep atom: C4 for purines, C2 for
    pyrimidines, C1' for unknown (N/DN), per AF3 SI 4.4. ``first_res`` is False when this
    call builds a SEGMENT of a chain rather than its start (a chain split around a modified
    residue), so the 5'-terminal rule stays a property of the chain, not of the segment."""
    ref_pos, elem_idx, ref_charge, ref_mask = [], [], [], []
    a2t, ruid, tokatom, disto_rep, name_chars = [], [], [], [], []
    for t, code in enumerate(res_codes):
        mol = mols[code]
        conf = mol.GetConformer()
        disto = "C4" if code in _NA_PURINES else "C2" if code in _NA_PYRIMIDINES else "C1'"
        k = 0
        for a in mol.GetAtoms():
            if a.GetAtomicNum() <= 1:                     # skip hydrogens (heavy atoms only)
                continue
            nm = a.GetProp("name")
            if nm == "OP3" and not (first_res and t == 0):  # free 5'-phosphate O only on residue 1
                k += 1                                    # OP3 still occupies CCD slot 0 (atom_to_tokatom_idx)
                continue
            p = conf.GetAtomPosition(a.GetIdx())
            ref_pos.append([p.x, p.y, p.z])
            elem_idx.append(a.GetAtomicNum() - 1)
            ref_charge.append(float(a.GetFormalCharge()))
            ref_mask.append(1.0)
            a2t.append(t); ruid.append(t); tokatom.append(k)
            disto_rep.append(1.0 if nm == disto else 0.0)
            name_chars.append([ord(c) - 32 for c in (nm + "    ")[:4]])
            k += 1
    return _assemble_atom_features(torch.tensor(ref_pos, dtype=torch.float32), elem_idx,
                                   ref_charge, ref_mask, a2t, ruid, tokatom, disto_rep, name_chars)


@functools.cache
def _ccd_one_letter() -> dict:
    """CCD code -> its single-letter `_chem_comp.one_letter_code`, for the components that have one.

    Extracted from the components.cif Mol-1 / Protenix ship (common/components.cif); a code that
    is absent has no single-letter parent, which upstream maps to X (protein) or N (nucleic)."""
    return json.loads((Path(__file__).parent / "data" / "ccd_one_letter.json").read_text())


def parent_restype(ccd: str, mol_type: str) -> int:
    """The restype a modified residue's atom tokens carry: its CCD parent's, as upstream's
    `add_cano_seq_resname` assigns it (SEP -> SER, 2MG -> G, 6OG -> DG), else the modality's UNK."""
    letter = _ccd_one_letter().get(ccd.upper(), "X" if mol_type == "protein" else "N")
    return int(seq_to_restype(letter, mol_type)[0])


@functools.cache
def chem_comp_table() -> dict:
    """CCD code -> its `_chem_comp` type, name, pdbx_synonyms, formula, formula_weight, as biotite reads them.

    Reduced from the components.cif Mol-1 ships (common/components.cif, sha256 64f53e4d...), which upstream's writer
    parses whole (518 MB) for these five fields on every structure it writes. Built by scripts/mol1_io/chem_comp_table.py."""
    import gzip
    with gzip.open(Path(__file__).parent / "data" / "ccd_chem_comp.json.gz", "rt") as fh:
        return json.load(fh)


def ccd_mol_type(ccd: str) -> str:
    """A CCD component's molecule type from its `_chem_comp.type`, upstream's ``ccd.get_mol_type``:
    a peptide-linking type is protein (PEPTIDE-LIKE is not), DNA-linking dna, RNA-linking rna,
    anything else (and a code the table lacks) ligand."""
    row = chem_comp_table().get(ccd.upper())
    t = row[0].upper() if row else ""
    if "PEPTIDE" in t and t != "PEPTIDE-LIKE":
        return "protein"
    return "dna" if "DNA" in t else "rna" if "RNA" in t else "ligand"


def polymer_chain_features(seq: str, mt: str, mods: list | None, conformers: dict,
                           mols: dict, oxt=None):
    """One polymer chain's atom and token features, tokenizing a modified residue PER ATOM.

    AF3 gives a standard residue one token and a modified residue one token per atom
    (SI 2.6), the same rule it applies to a ligand. So a chain carrying ``modifications:``
    is its normal run of residue tokens with the CCD component's atom tokens spliced in at
    each modified position. The residue FRAME is untouched: every atom token of a modified
    residue shares one ``ref_space_uid`` and one ``residue_index``, so the relative-position
    encoding still sees one residue there and the chain's numbering does not shift.

    ``mods`` is the reader's ``[{"position": 1-indexed, "ccd": CODE}]`` or None; with None
    this is the plain per-residue path and returns byte-identical features to the
    protein_atom_features / na_atom_features call it replaces.

    Returns ``(af, restype_idx, residue_index, bonds, res_tok, res_atoms, msa_col)``:
      af           per-atom features, chain-local atom_to_token_idx / ref_space_uid
      restype_idx  (n_tok,) restype per token; a modified residue's atoms carry its CCD
                   parent's (parent_restype), as upstream Protenix and Mol-1 assign it
      residue_index(n_tok,) the 1-indexed residue each token belongs to
      bonds        (n_tok, n_tok) token adjacency, or None when the chain has no
                   modification: the CCD's own heavy-atom bonds. The backbone links to the
                   neighbouring residues are polymer-polymer bonds, which upstream leaves
                   out of token_bonds
      res_tok      1-indexed residue -> chain-local first token
      res_atoms    1-indexed residue -> {atom name: chain-local token}, modified residues only
      msa_col      (n_tok,) alignment column each token reads, -1 for an atom token
    """
    seq = "".join(str(seq).split())
    rt_all = seq_to_restype(seq, mt)
    n_res = len(seq)
    mod_ccd = {int(m["position"]): str(m["ccd"]).upper() for m in (mods or [])}
    if mt == "protein" and oxt is None and n_res > 1 and mod_ccd.get(n_res) == "NME":
        # upstream bonds a C-terminal NME only after the leaving atoms are gone, so the
        # residue before it keeps its OXT (json_parser._build_polymer_atom_array)
        oxt = [k >= n_res - 2 for k in range(n_res)]
    codes = _na_res_codes(seq, mt) if mt in ("rna", "dna") else None
    if mt == "protein":
        # The 20 standard residues and X have a bundled reference conformer; X is UNK, one
        # residue token with the CCD component's atoms, which is what upstream Protenix
        # builds for it. Any other letter (U, B, Z, O, J) names a residue this cannot guess:
        # a real one goes in through `mod_ccd`, which splices the CCD component's atoms in.
        # Undeclared, the conformer lookup below died on a bare KeyError("UNK") several
        # frames deep, naming neither the residue nor the fix.
        bad = [f"{i + 1}{c}" for i, c in enumerate(seq)
               if c.upper() not in _AA1_TO_IDX and c.upper() != "X" and i + 1 not in mod_ccd]
        if bad:
            shown = ", ".join(bad[:8]) + (f" (+{len(bad) - 8} more)" if len(bad) > 8 else "")
            raise ValueError(
                f"non-standard residue(s) at {shown}: only the 20 standard amino acids and X "
                "(unknown) have a reference conformer. Declare each one as a `modifications:` "
                "entry with its CCD code (SEC for selenocysteine, MSE for selenomethionine, "
                "SEP for phosphoserine), or substitute a standard residue.")

    def _standard(lo, hi):                       # residues [lo, hi) as one per-residue block
        if mt == "protein":
            run_oxt = torch.tensor([bool(oxt[k]) if oxt is not None else k == n_res - 1
                                    for k in range(lo, hi)])
            return protein_atom_features(rt_all[lo:hi], conformers, oxt=run_oxt)
        return na_atom_features(codes[lo:hi], mols, first_res=(lo == 0))

    parts, restype, resindex, msa_col = [], [], [], []
    res_tok: list[int] = []
    res_atoms: dict[int, dict] = {}
    local_bonds = []                             # (offset, intra-residue adjacency)
    tok = 0
    lo = 0
    for stop in sorted(mod_ccd) + [n_res + 1]:   # split the chain at each modified residue
        hi = stop - 1                            # residues [lo, hi) are standard
        if hi > lo:
            parts.append(_standard(lo, hi))
            for k in range(lo, hi):
                res_tok.append(tok)
                restype.append(int(rt_all[k])); resindex.append(k + 1); msa_col.append(k)
                tok += 1
        if stop > n_res:
            break
        code = mod_ccd[stop]
        # the leaving atoms the polymer bond consumes: a mid-chain residue has no free
        # C-terminal carboxylate O, and only the 5' residue keeps OP3
        if mt == "protein":
            keep_end = bool(oxt[stop - 1]) if oxt is not None else stop == n_res
            drop = () if keep_end else ("OXT", "HXT")
        else:
            drop = () if stop == 1 else ("OP3",)
        af, n_atom, adj, names = ligand_atom_features(mols[code], drop_atoms=drop)
        parts.append(af)
        local_bonds.append((tok, adj))
        res_tok.append(tok)
        res_atoms[stop] = {nm: tok + i for i, nm in enumerate(names)}
        restype += [parent_restype(code, mt)] * n_atom
        resindex += [stop] * n_atom
        msa_col += [-1] * n_atom
        tok += n_atom
        lo = stop

    n_tok = tok
    off = 0
    for af in parts:                             # splice the segments into one chain
        n_seg = int(af["atom_to_token_idx"].max()) + 1 if af["atom_to_token_idx"].numel() else 0
        af["atom_to_token_idx"] = af["atom_to_token_idx"] + off
        off += n_seg
    merged = {k: torch.cat([af[k] for af in parts], 0) for k in parts[0]}
    # ref_space_uid was written per segment (0-based within the segment for a standard run,
    # the residue ordinal for a modified one) -- rebuild it from the token each atom belongs
    # to so a residue frame is a residue frame across the whole chain.
    merged["ref_space_uid"] = torch.tensor(resindex, dtype=torch.long)[
        merged["atom_to_token_idx"]] - 1

    bonds = None
    if mod_ccd:
        bonds = torch.zeros(n_tok, n_tok)
        for start, adj in local_bonds:           # the CCD component's own heavy-atom bonds
            bonds[start:start + adj.shape[0], start:start + adj.shape[1]] = adj
        # Terminal caps are CCD non-polymers, so their link to the chain is a polymer-ligand
        # bond that token_bonds keeps: an N-terminal ACE's C to residue 2's N, residue n-1's C
        # to a C-terminal NME's N (upstream json_parser._add_bonds_to_terminal_residues; NH2
        # and every other cap get no bond there either).
        def _atom_tok(res, name):
            return res_atoms[res].get(name) if res in res_atoms else res_tok[res - 1]

        for (cap, cap_atom), (nbr, nbr_atom) in (((1, "C"), (2, "N")), ((n_res, "N"), (n_res - 1, "C"))):
            if n_res > 1 and mod_ccd.get(cap) == ("ACE" if cap == 1 else "NME"):
                t1, t2 = _atom_tok(cap, cap_atom), _atom_tok(nbr, nbr_atom)
                if t1 is not None and t2 is not None:
                    bonds[t1, t2] = bonds[t2, t1] = 1.0
    return (merged, torch.tensor(restype, dtype=torch.long),
            torch.tensor(resindex, dtype=torch.long), bonds, res_tok, res_atoms,
            torch.tensor(msa_col, dtype=torch.long))


def _default_mol_dir() -> str:
    """Best-effort location of the bundled CCD `mols` directory (CLI/worker pass mol_dir
    explicitly; this only backstops tests run from a checkout)."""
    import os
    from tt_bio import weights
    if (hit := weights.cached_path("mols")) is not None:
        return str(hit)
    for p in ("~/.boltz/mols", "~/.cache/tt_bio/mols"):
        ep = os.path.expanduser(p)
        if os.path.exists(ep):
            return ep
    return os.path.expanduser("~/.boltz/mols")


def _smiles_to_mol(smiles: str):
    """Build a 3D rdkit Mol from a SMILES string with deterministic geometry and per-element
    atom names (C1, C2, N1, ...), mirroring the v2 reference's SMILES ligand naming. Heavy
    atoms only after embedding (any valid conformer is acceptable -- ref_pos is geometry, not
    identity). Atom order is rdkit's own; ligand tokens carry no inherent order."""
    from collections import Counter
    from rdkit import Chem
    from rdkit.Chem import AllChem
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"could not parse SMILES ligand: {smiles!r}")
    mol = Chem.AddHs(mol)
    params = AllChem.ETKDGv3(); params.randomSeed = 0xF00D
    if AllChem.EmbedMolecule(mol, params) != 0:                  # fall back to random coords
        params.useRandomCoords = True
        AllChem.EmbedMolecule(mol, params)
    try:
        AllChem.MMFFOptimizeMolecule(mol)
    except Exception:                                            # geometry need only be valid
        pass
    mol = Chem.RemoveHs(mol)
    cnt = Counter()
    for a in mol.GetAtoms():
        s = a.GetSymbol().upper(); cnt[s] += 1
        a.SetProp("name", f"{s}{cnt[s]}")
    return mol


def _name_atoms(mol):
    """Upstream's ligand atom names: element + per-element ordinal over every atom in file
    order (``json_parser.rdkit_mol_to_atom_info``). Hydrogens count on their own 'H' tally, so a
    heavy atom's name does not depend on whether the file carries hydrogens."""
    from collections import Counter
    cnt = Counter()
    for a in mol.GetAtoms():
        s = a.GetSymbol().upper(); cnt[s] += 1
        a.SetProp("name", f"{s}{cnt[s]}")
    return mol


def _file_to_mol(path: str):
    """A ligand from a 3D file (upstream ``FILE_`` ligand, ``lig_file_to_atom_info``): .mol,
    .sdf (first record), .pdb or .mol2, read by RDKit as upstream reads it. Its own conformer is
    the reference conformer, so the file must carry 3D coordinates."""
    from rdkit import Chem
    p = str(path)
    readers = {".mol": Chem.MolFromMolFile, ".pdb": Chem.MolFromPDBFile, ".mol2": Chem.MolFromMol2File,
               ".sdf": lambda f: next(iter(Chem.SDMolSupplier(f)), None)}
    ext = Path(p).suffix.lower()
    if ext not in readers:
        raise ValueError(f"ligand file {p}: use one of .sdf, .mol, .mol2, .pdb")
    if not Path(p).is_file():
        raise ValueError(f"ligand file {p} does not exist")
    mol = readers[ext](p)
    if mol is None:
        raise ValueError(f"ligand file {p}: RDKit could not read a molecule from it")
    if mol.GetNumConformers() == 0 or not mol.GetConformer().Is3D():
        raise ValueError(f"ligand file {p} has no 3D coordinates")
    return _name_atoms(mol)


def _ligand_mol(spec: str, mols: dict):
    """Resolve a ligand spec to an rdkit Mol: 'CCD_<code>' -> the CCD template Mol,
    'FILE_<path>' -> the file's own molecule and conformer, otherwise a SMILES string -> a
    freshly embedded Mol."""
    if spec.startswith("CCD_"):
        return mols[spec[4:]]
    if spec.startswith("FILE_"):
        return _file_to_mol(spec[5:])
    return _smiles_to_mol(spec)


def _ccd_list(spec: str) -> list:
    """'CCD_NAG,NAG' (or the upstream JSON's 'CCD_NAG_NAG') -> ['NAG', 'NAG']."""
    body = spec[4:]
    return [c.strip().upper() for c in body.replace("_", ",").split(",") if c.strip()]


def ccd_leaving_groups(mol) -> dict | None:
    """Central atom name -> its leaving groups (lists of heavy-atom names), from the CCD's
    pdbx_leaving_atom_flag, as upstream's ``ccd._map_central_to_leaving_groups`` builds them:
    each leaving neighbour of a kept atom starts a group, grown through heavy-atom bonds without
    going back through that atom. A group that reaches a kept atom means the component's flags
    are not a clean leaving group, and then (as upstream) nothing is dropped from it."""
    heavy = {a.GetIdx(): a for a in mol.GetAtoms() if a.GetAtomicNum() > 1}
    leaving = {i: a.HasProp("leaving_atom") and bool(a.GetBoolProp("leaving_atom"))
               for i, a in heavy.items()}
    name = {i: a.GetProp("name") for i, a in heavy.items()}
    nbr = {i: [n.GetIdx() for n in a.GetNeighbors() if n.GetIdx() in heavy] for i, a in heavy.items()}
    out = {}
    for c in heavy:
        if leaving[c]:
            continue
        for l in nbr[c]:
            if not leaving[l]:
                continue
            seen, stack = {l}, [l]
            while stack:
                for k in nbr[stack.pop()]:
                    if k != c and k not in seen:
                        seen.add(k); stack.append(k)
            if not all(leaving[k] for k in seen):
                return None
            out.setdefault(name[c], []).append(sorted((name[k] for k in seen), key=lambda x: x))
    return out


def _ccd_leaving_drops(spec, mols, cid, bonds) -> dict:
    """Per 1-indexed residue of a CCD ligand chain, the atom names its covalent bonds consume.
    A bonded central atom loses one leaving group per bond (upstream ``remove_leaving_atoms``).
    Upstream picks WHICH group by ``random.sample`` when an atom has more than it needs; here the
    first ones in CCD order are taken, which is the same choice whenever there is only one."""
    codes = _ccd_list(spec)
    count = {}
    for pair in (bonds or []):
        for c, r, a in pair:
            if cid is not None and str(c) == str(cid):
                key = (1 if len(codes) == 1 else int(r), str(a))
                count[key] = count.get(key, 0) + 1
    drops = {}
    for (r, a), k in count.items():
        if not 1 <= r <= len(codes):
            continue
        groups = (ccd_leaving_groups(mols[codes[r - 1]]) or {}).get(a)
        for g in (groups or [])[:k]:
            drops.setdefault(r, set()).update(g)
    return drops


def ccd_ligand_features(spec: str, mols: dict, drops: dict | None = None, conformers: dict | None = None):
    """A CCD ligand chain of one or more components. Component k is residue k (upstream
    ``build_ligand`` gives each code of 'CCD_A_B' its own res_id) with its own ref_space_uid.

    Upstream types each component by its `_chem_comp.type` (``ccd_mol_type``), not by the entity
    it came in, and featurizes it as that molecule type: a peptide- or nucleotide-linking
    component's atom tokens carry its parent restype (8BA -> DN, SEP -> SER), and a standard
    residue (ALA, A, DA) is one residue token like in a chain. Everything else is one UNK token
    per heavy atom. Returns (af, n_token, token_bonds, {(res, atom_name): token}, residue_index,
    restype_idx, mol_type) with mol_type the type most of the chain's atoms have, as upstream
    reads a chain's is_ligand."""
    parts, names, res, restype, atom_mt = [], {}, [], [], []
    for r, code in enumerate(_ccd_list(spec), start=1):
        drop = (drops or {}).get(r, ())
        mt = ccd_mol_type(code)
        rt = parent_restype(code, mt) if mt != "ligand" else 20
        if mt != "ligand" and restype_to_resname(torch.tensor([rt]))[0] == code:
            af = polymer_chain_features(_ccd_one_letter()[code], mt, None, conformers, mols,
                                        oxt=["OXT" not in drop])[0] if mt == "protein" else \
                na_atom_features(_na_res_codes(_ccd_one_letter()[code], mt), mols, first_res="OP3" not in drop)
            n, b = 1, torch.zeros(1, 1)
            names.update({(r, nm): len(res) for nm in _atom_names(af)})
        else:
            af, n, b, nm = ligand_atom_features(mols[code], drop_atoms=drop)
            names.update({(r, x): len(res) + i for i, x in enumerate(nm)})
        parts.append((af, n, b))
        res += [r] * n
        restype += [rt] * n
        atom_mt += [mt] * af["atom_to_token_idx"].numel()
    n_tot = sum(n for _, n, _ in parts)
    bonds = torch.zeros(n_tot, n_tot)
    feats, off = [], 0
    for r, (af, n, b) in enumerate(parts):
        af = dict(af)
        af["atom_to_token_idx"] = af["atom_to_token_idx"] + off
        af["ref_space_uid"] = af["ref_space_uid"] + r
        bonds[off:off + n, off:off + n] = b
        feats.append(af)
        off += n
    af = {k: torch.cat([f[k] for f in feats], 0) for k in feats[0]}
    mol_type = max(MOL_TYPE_IDS, key=atom_mt.count)
    return (af, n_tot, bonds, names, torch.tensor(res, dtype=torch.long),
            torch.tensor(restype, dtype=torch.long), mol_type)


def _atom_names(af: dict) -> list:
    """Atom names back out of ref_atom_name_chars."""
    return ["".join(chr(int(c) + 32) for c in row).strip() for row in af["ref_atom_name_chars"].argmax(-1).tolist()]


def ligand_atom_features(mol, drop_atoms=()):
    """Atom-level features for one ligand, tokenized PER ATOM (AF3: each ligand atom is its
    own token). restype is UNK(20) per atom, distogram rep = every atom, atom_to_tokatom_idx
    = 0, ref_space_uid shared (one residue). Returns (af, n_token, token_bonds, names) where
    token_bonds is the (n_token, n_token) intra-ligand bond adjacency (heavy-atom bonds) and
    names is the per-token atom name (token order) used to resolve covalent `bond` constraints.

    ``drop_atoms`` names atoms to leave out. A free ligand drops none; a MODIFIED RESIDUE
    built from the same CCD component drops the leaving atoms the polymer bond consumes
    (OXT mid-chain, OP3 off the 5' end), the same convention protein_atom_features and
    na_atom_features already apply to standard residues."""
    conf = mol.GetConformer()
    ref_pos, elem_idx, ref_charge, ref_mask = [], [], [], []
    a2t, ruid, tokatom, disto_rep, name_chars, names = [], [], [], [], [], []
    idx_map = {}                                                 # rdkit atom idx -> token idx
    j = 0
    for a in mol.GetAtoms():
        if a.GetAtomicNum() <= 1:                                # heavy atoms only
            continue
        nm = a.GetProp("name") if a.HasProp("name") else (a.GetSymbol().upper() + str(j + 1))
        if nm in drop_atoms:
            continue
        p = conf.GetAtomPosition(a.GetIdx())
        ref_pos.append([p.x, p.y, p.z])
        elem_idx.append(a.GetAtomicNum() - 1)
        ref_charge.append(float(a.GetFormalCharge()))
        ref_mask.append(1.0)
        a2t.append(j); ruid.append(0); tokatom.append(0); disto_rep.append(1.0)
        name_chars.append([ord(c) - 32 for c in (nm + "    ")[:4]])
        names.append(nm)
        idx_map[a.GetIdx()] = j
        j += 1
    af = _assemble_atom_features(torch.tensor(ref_pos, dtype=torch.float32), elem_idx,
                                 ref_charge, ref_mask, a2t, ruid, tokatom, disto_rep, name_chars)
    bonds = torch.zeros(j, j)
    for b in mol.GetBonds():
        u, v = b.GetBeginAtomIdx(), b.GetEndAtomIdx()
        if u in idx_map and v in idx_map:
            bonds[idx_map[u], idx_map[v]] = bonds[idx_map[v], idx_map[u]] = 1.0
    return af, j, bonds, names


def protein_token_features(aatype: torch.Tensor) -> dict:
    """Token-level features for a single offline protein chain from aatype (N,).

    Exactly reproduces the v2 reference token features for the no-MSA / no-template
    inference path (validated vs golden, tests/test_protenix_data.py):
      restype = one_hot(aatype, 32); profile = restype; msa = aatype[None] (1 row);
      deletion_mean/has_deletion/deletion_value = 0; token_bonds = 0; single chain
      (asym/entity/sym = 0); residue_index = 1..N (1-based); token_index = 0..N-1.
    """
    N = aatype.shape[0]
    restype = torch.nn.functional.one_hot(aatype.clamp(max=RESTYPE_DIM - 1), RESTYPE_DIM).float()
    zeros_n = torch.zeros(N)
    return {
        "restype": restype,
        "profile": restype.clone(),
        "deletion_mean": zeros_n.clone(),
        "msa": aatype[None, :].long(),
        "has_deletion": torch.zeros(1, N),
        "deletion_value": torch.zeros(1, N),
        "token_bonds": torch.zeros(N, N),
        "asym_id": torch.zeros(N, dtype=torch.long),
        "entity_id": torch.zeros(N, dtype=torch.long),
        "sym_id": torch.zeros(N, dtype=torch.long),
        "residue_index": torch.arange(1, N + 1, dtype=torch.long),
        "token_index": torch.arange(0, N, dtype=torch.long),
    }


# ---------------------------------------------------------------------------
# Coordinate input: a structure file to per-token conditioning coordinates.
# ---------------------------------------------------------------------------

# AlphaFold3 SI 4.4 as protenix implements it (`parser.py:add_distogram_rep_atom_mask`):
# CB for protein and CA for glycine, C4 for purines, C2 for pyrimidines, C1' for the
# unknown nucleotides. Ligand tokens are single atoms and represent themselves.
_DISTO_REP_NA = {"DA": "C4", "DG": "C4", "A": "C4", "G": "C4",
                 "DC": "C2", "DT": "C2", "C": "C2", "U": "C2"}
_GEMMI_MOL_TYPE = {"PeptideL": "protein", "PeptideD": "protein", "Rna": "rna",
                   "Dna": "dna", "DnaRnaHybrid": "dna"}


def distogram_rep_atom(res_name: str, mol_type: str) -> str:
    """The atom whose coordinate stands for a whole token in the 64-bin distogram."""
    if mol_type == "protein":
        return "CA" if res_name == "GLY" else "CB"
    return _DISTO_REP_NA.get(res_name, "C1'")


def parse_crop_spec(spec) -> set | None:
    """A PXDesign crop spec to the set of label_seq numbers it keeps.

    `"1-116"`, `"1-10,20-30"`, `40`, a list of any of those, or None / `"all"` / `"full"`
    for no crop. Matches `pxdesign/utils/inputs.py:85-99` joining a YAML list with commas
    and `pxdesign/data/json_parser.py:140-154` expanding the ranges.
    """
    if spec is None:
        return None
    if isinstance(spec, (list, tuple)):
        spec = ",".join(str(x) for x in spec)
    spec = str(spec).replace(" ", "")
    if spec.lower() in ("", "all", "full"):
        return None
    keep = set()
    for part in spec.split(","):
        if "-" in part.lstrip("-"):
            s, e = part.split("-")
            keep.update(range(int(s), int(e) + 1))
        else:
            keep.add(int(part))
    return keep


def structure_token_coords(path, chains=None, crop=None) -> dict:
    """A structure file to per-token distogram-representative-atom coordinates.

    Reads CIF, PDB and the gzipped form of either. `chains` selects subchains by
    **label_asym_id**, which is what a PXDesign YAML's chain keys mean; None takes every
    polymer subchain. A PDB carries no label_asym_id, so an id that matches no subchain
    falls back to the auth chain name, which is the only chain key a PDB has. `crop` is a
    label_seq spec (see `parse_crop_spec`), either one spec for every chain or a
    `{chain_id: spec}` dict; residues of a PDB with no SEQRES have no label_seq either,
    and fall back to the author numbering the same way.

    Returns `{chain_id: {coord, res_name, mol_type, is_resolved, label_seq, has_oxt, ca,
    ca_mask, sequence}}`, each in label_seq order; `coord` is the (N_res, 3) distogram
    representative atom and `ca` the backbone atom a scorer aligns on.

    Waters, hydrogens and alternative conformations are dropped before any atom name is
    matched. That is the whole reason this function exists: PXDesign routes a user's CIF
    through protenix's distillation parser, which matches observed atoms against CCD atom
    names with no hydrogen filter in front, so a residue carrying at least as many
    hydrogens as heavy atoms is dropped and its token is conditioned on at the origin.
    `examples/5o45.cif` loses 61 of 116 residues that way.
    """
    import gemmi

    st = gemmi.read_structure(str(path))
    st.setup_entities()                    # subchains and entity types
    st.remove_alternative_conformations()
    st.remove_hydrogens()
    st.remove_waters()
    # Aligns the observed residues against the entity's SEQRES. A coordinates-only PDB
    # has no SEQRES, so there is nothing to align against and every label_seq stays None;
    # the per-residue fallback below covers that case.
    st.assign_label_seq_id()

    polymers = []                          # (label_asym_id, auth_chain_name, subchain, entity)
    for chain in st[0]:
        for sub in chain.subchains():
            ent = st.get_entity_of(sub)
            if ent is not None and ent.entity_type == gemmi.EntityType.Polymer:
                polymers.append((sub.subchain_id(), chain.name, sub, ent))
    by_label = {lab: (sub, ent) for lab, _, sub, ent in polymers}
    by_auth = {}
    for _, auth, sub, ent in polymers:                # ambiguous auth names resolve to None
        by_auth[auth] = None if auth in by_auth else (sub, ent)

    want = [str(c) for c in chains] if chains is not None else sorted(by_label)
    crops = crop if isinstance(crop, dict) else None
    out = {}
    for cid in want:
        hit = by_label.get(cid) or by_auth.get(cid)
        if hit is None:
            raise ValueError(f"structure_token_coords: {path} has no polymer chain with "
                             f"label_asym_id or chain name {cid}; found "
                             f"{sorted(by_label)} / {sorted(by_auth)}")
        sub, ent = hit
        mt = _GEMMI_MOL_TYPE.get(str(ent.polymer_type).split(".")[-1])
        if mt is None:
            raise ValueError(f"structure_token_coords: chain {cid} is a "
                             f"{ent.polymer_type} polymer, which has no protenix token "
                             f"representation")
        keep = parse_crop_spec(crops.get(cid) if crops is not None else crop)
        coord, res_name, resolved, label_seq, oxt = [], [], [], [], []
        ca, ca_mask = [], []
        for res in sub:
            # A PDB with no SEQRES comes back with no label_seq at all (gemmi cannot
            # assign one without a sequence to align to), and the author numbering is
            # then the only residue number that file shows -- so it is the only one a
            # user's crop or hotspot can possibly mean. Forcing a 1..N label_seq instead
            # would silently move every hotspot on any PDB not numbered from 1.
            seq = res.label_seq if res.label_seq is not None else res.seqid.num
            if keep is not None and seq not in keep:
                continue
            if not len(res):           # every atom filtered out: upstream drops the residue
                continue
            rep = distogram_rep_atom(res.name, mt)
            at = next((a for a in res if a.name == rep), None)
            bb = next((a for a in res if a.name == ("CA" if mt == "protein" else "C1'")),
                      None)
            ca.append([bb.pos.x, bb.pos.y, bb.pos.z] if bb else [0.0, 0.0, 0.0])
            ca_mask.append(bb is not None)
            coord.append([at.pos.x, at.pos.y, at.pos.z] if at else [0.0, 0.0, 0.0])
            res_name.append(res.name)
            resolved.append(at is not None)
            label_seq.append(int(seq))
            oxt.append(any(a.name == "OXT" for a in res))
        if not coord:
            raise ValueError(f"structure_token_coords: chain {cid} has no residues "
                             f"left after the crop {crops.get(cid) if crops else crop}")
        order = sorted(range(len(label_seq)), key=label_seq.__getitem__)
        out[cid] = {
            "coord": torch.tensor([coord[i] for i in order], dtype=torch.float32),
            "res_name": [res_name[i] for i in order],
            "mol_type": [mt] * len(order),
            "is_resolved": torch.tensor([resolved[i] for i in order]),
            "label_seq": [label_seq[i] for i in order],
            "has_oxt": [oxt[i] for i in order],
            # The backbone atom, for scoring: the conditioning uses `coord` (CB), while the
            # RMSDs a structure filter reports are CA on CA.
            "ca": torch.tensor([ca[i] for i in order], dtype=torch.float32),
            "ca_mask": torch.tensor([ca_mask[i] for i in order]),
            "sequence": res_names_to_sequence([res_name[i] for i in order], mt),
        }
    return out


def res_names_to_sequence(res_names, mol_type: str = "protein") -> str:
    """Per-residue CCD names to the one-letter sequence `build_complex_features` eats.
    A nucleotide outside the standard set becomes the unknown letter. A protein residue does
    only when the file itself calls it UNK: a named non-standard one (MSE, SEP) becomes "?",
    which the featurizer refuses by position, because folding it as UNK would drop the atoms
    the file actually has."""
    from .data import const
    if mol_type == "protein":
        return "".join(const.prot_token_to_letter.get(n, "?") for n in res_names)
    std = set("AGCU") if mol_type == "rna" else set("AGCT")
    letters = [n[1:] if mol_type == "dna" and n.startswith("D") else n for n in res_names]
    return "".join(c if c in std else "N" for c in letters)
