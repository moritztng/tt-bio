"""Boltz-2 structure prediction CLI."""

# Suppress noisy ttnn/loguru output before any import pulls in ttnn.
# These are defaults — --debug mode removes them so everything is visible.
import os as _os, sys as _sys
if "--debug" not in _sys.argv:
    _os.environ.setdefault("LOGURU_LEVEL", "WARNING")
    _os.environ.setdefault("TT_METAL_LOGGER_LEVEL", "FATAL")
    # tt-metal's Inspector (the tt-triage data source) defaults to ENABLED
    # upstream (rtoptions.hpp: InspectorSettings::enabled = true). It is a
    # debug facility, and it is not free on an inference path: ttnn calls it
    # once per device-op enqueue (device_operation.hpp::enqueue_mesh_workload),
    # where it builds the op name, copies a TensorSpec per tensor argument
    # (capture_tensor_specs also defaults on) and takes a mutex. It also opens
    # a log directory under the cwd and flushes a YAML line per program and
    # per mesh-workload create/destroy. A 20-aa esmfold2-fast fold issues
    # 13,234 device ops, so that is 13,234 visits per fold. Measured on qb2
    # (p300c, ttnn 0.68.0) the bare enqueue path costs 8.29 us/op with it on
    # and 8.05 us/op with it off. Turn it off by default and let --debug (which
    # skips this whole block) put it back for triage; setdefault so an explicit
    # TT_METAL_INSPECTOR=1 always wins. Must run before ttnn is imported.
    _os.environ.setdefault("TT_METAL_INSPECTOR", "0")

# torch+MKL can hit a threading-layer load race on large inputs, aborting the
# process at import with "Intel oneMKL FATAL ERROR: Cannot load libtorch_cpu.so"
# (observed intermittently at >=1408-residue predicts during the v0.2.0 release
# gate). Pinning the GNU threading layer avoids it; setdefault so an explicit
# user MKL_THREADING_LAYER always wins. Must run before torch is imported.
_os.environ.setdefault("MKL_THREADING_LAYER", "GNU")


def _ttnn_version() -> str:
    """Installed ttnn version, without importing the (heavy) package itself."""
    import importlib.metadata
    try:
        return importlib.metadata.version("ttnn")
    except importlib.metadata.PackageNotFoundError:
        return "unknown"


# tt-metal JIT-compiles every kernel binary on first use; the compiled ELF is
# cached on disk (default ~/.cache/tt-metal-cache) and reused by ANY later
# process on this host, so a cold `predict`/`embed` CLI call or a restarted
# serve worker skips recompiling shapes a prior process already built (measured
# ~2-3x wall-clock, ~9x compute-stage win for a from-empty vs warm cache; see
# docs/cold-start.md). Namespace by installed ttnn version so a version bump
# can never silently reuse a differently-built cache (belt-and-suspenders on
# top of tt-metal's own internal build-hash directory) -- setdefault so an
# operator-set TT_METAL_CACHE always wins. Must run before ttnn is imported.
_os.environ.setdefault(
    "TT_METAL_CACHE",
    _os.path.expanduser(f"~/.cache/tt-metal-cache-tt-bio/ttnn-{_ttnn_version()}"),
)


# `--debug` keeps the C-level stderr that tt-bio otherwise drops at exit (nanobind's report of
# the ttnn objects alive at shutdown; see runtime.end_after_teardown). It travels as an
# environment variable because a multiprocessing spawn re-execs python without our argv, and the
# spawned worker is exactly the process whose stderr `--debug` asked to see.
if "--debug" in _sys.argv:
    _os.environ["TT_BIO_DEBUG_STDERR"] = "1"


import base64
import hashlib
import importlib.util
import json
import math
import multiprocessing as mp
import os
import random
import signal
import shutil
import tempfile
import subprocess
import time
import uuid
import warnings
import fcntl
from contextlib import contextmanager
from dataclasses import replace
from pathlib import Path

import click
from click.core import ParameterSource
import numpy as np
import torch
from rdkit import Chem

from tt_bio import __version__, size_limits, weights
from tt_bio.data import const
from tt_bio.data.mol import load_molecules
from tt_bio.data.msa import run_mmseqs2
from tt_bio.cache import (EMPTY_MSA, cached, paired_msa_dir, publish_file, publish_text, seq_hash,
                          single_flight)
from tt_bio.data.parse import parse_a3m, parse_csv, parse_fasta, parse_yaml
from tt_bio.data.pdb import write_atom_array
from tt_bio.data.types import Coords, Input, Interface
from tt_bio.data.write import to_mmcif, to_pdb
from tt_bio.host_controller import (
    LEASE_S,
    MAX_LEASES,
    ControllerClient,
    ControllerServer,
    connect_controller,
    job_payloads,
    worker_payload,
)
from tt_bio.energy import DEFAULT_ENERGY_SAMPLE_HZ, PowerProfiler
from tt_bio.progress import DebugDisplay, NullDisplay, ProgressDisplay
from tt_bio.runtime import (
    P300_SUBSYSTEMS,
    bind_host_threads,
    build_local_workers,
    chip_summary,
    conflicting_mpi_env,
    mpi_env_warning,
    detect_tenstorrent_devices,
    discover_jobs,
)
from tt_bio.worker import (SHARED_OUTPUT_PREFIX, prefetch_msas, read_worker_capture,
                            run_worker_loop)

# Every weight and data artifact tt-bio downloads is one row in tt_bio.weights.
# ARTIFACTS: source, repo/URL, destination, licence and env override in one place,
# behind one fetch that stages, verifies and atomically renames. Re-exported here
# because these two repo ids are referenced from scripts and docs.
#
# The IPD checkpoints (RFD3 and its folding sibling RF3, Institute for Protein
# Design / UW) ship no HF repo; the registry points at the same files.ipd.uw.edu
# URLs RosettaCommons' `foundry install` reads from its checkpoint_registry.py, so
# users never need `rc-foundry` installed.

# Single source of truth for the predict output-folder prefix. Each supported
# --model maps to a model-named results folder; a model not listed falls back to
# the neutral, model-independent "results" prefix (never a hardcoded "boltz_"
# string). Add a new model here when you add it to the predict --model choice —
# PREDICT_MODELS below derives from these keys, so the CLI choice and every
# gate that imports PREDICT_MODELS (release_gate.py, perf_regression.py) stay
# in sync automatically instead of needing their own hand-copied list (the gap
# that let opendde-abag's diffusion_fp32 regression ship with no perf coverage
# — see tt-bio-shared-diffusion-global-env-default-regression).
_MODEL_RESULTS_PREFIX = {
    "boltz2": "boltz2_results",
    "esmfold2": "esmfold2_results",
    "esmfold2-fast": "esmfold2_results",
    "protenix-v1": "protenix_results",
    "protenix-v2": "protenix_results",
    "mol1": "mol1_results",
    "openfold3": "openfold3_results",
    "openbind": "openbind_results",
    "opendde": "opendde_results",
    "opendde-abag": "opendde_results",
    "rf3": "rf3_results",
    "af2ig": "af2ig_results",
}
PREDICT_MODELS = tuple(_MODEL_RESULTS_PREFIX)

# OpenFold3-preview2 and OpenBind-0 are ONE implementation with two checkpoints.
# Upstream ships both from aqlaboratory/openfold-3; OpenBind is tag v0.5.0, which
# hoists the diffusion transformer's pair LayerNorm out of its 24 blocks and moves
# the ending-node triangle bias onto the untransposed pair. That is the whole
# architectural delta, so the two share every module and differ only in what the
# checkpoint selects. They stay separate --model ids because they are separate
# weights with separate accuracy, and because the featurizer fixes v0.5.0 made
# cannot be applied to preview2 without shifting the input distribution its
# weights were trained on. Anything that means "either OF3 checkpoint" reads this.
OF3_FAMILY = ("openfold3", "openbind")

# Protenix: two ByteDance releases, one implementation. protenix-v1 is upstream's v0.5.0
# base checkpoint (c_z 128, 4 MSA blocks, no template pairformer stack, N_cycle 4);
# protenix-v2 is a later release at c_z 256 with a 2-block template stack and N_cycle 10.
# tt_bio.protenix reads every one of those off the weights -- Trunk._derive_c_z, n_blocks,
# trunk_recycles -- so the two ids share the whole model path and differ only in what the
# checkpoint says. Mol-1 (Molence, e6e64866) is a Protenix-v2 derivative: PairMixer blocks and
# pair-width adapters in the same Pairformer, also read off its weights. Anything that means
# "any Protenix-family checkpoint" reads this tuple.
PROTENIX_FAMILY = ("protenix-v1", "protenix-v2", "mol1")


def _upstream_search_options(f):
    """Upstream ``mol pred``'s template and RNA MSA search options (tt_bio.protenix_json.search), same names."""
    helps = {"hmmsearch_binary_path": "hmmsearch for template search (default: PATH)",
             "hmmbuild_binary_path": "hmmbuild for template search (default: PATH)",
             "seqres_database_path": "template search database (default: $MOL_ROOT_DIR/search_database/"
                                     "pdb_seqres_20261001.fasta)",
             "nhmmer_binary_path": "nhmmer for RNA MSA search (default: PATH)",
             "hmmalign_binary_path": "hmmalign for RNA MSA search (default: PATH)",
             "hmmbuild_rna_binary_path": "RNA hmmbuild (default: --hmmbuild_binary_path)",
             "ntrna_database_path": "NT-RNA database (default: under $MOL_ROOT_DIR/search_database)",
             "rfam_database_path": "Rfam database (default: under $MOL_ROOT_DIR/search_database)",
             "rna_central_database_path": "RNAcentral database (default: under $MOL_ROOT_DIR/search_database)"}
    f = click.option("--nhmmer_n_cpu", type=int, default=None, help="Upstream JSON input: nhmmer threads.")(f)
    for name, h in reversed(helps.items()):
        f = click.option(f"--{name}", default=None, type=click.Path(),
                         help=f"Upstream JSON input with --use_template/--use_rna_msa: {h}.")(f)
    return f

# Single source of truth for the other two model-choice CLI surfaces (`embed`,
# `saprot`), for the same reason: anything that needs "every model we ship"
# (perf gate coverage, docs, future audits) should import these instead of
# re-typing the list.
EMBED_MODELS = ("esmc-300m", "esmc-600m", "esmc-6b")
SAPROT_MODELS = ("saprot-35m", "saprot-650m", "saprot-1.3b")

# Single source of truth for the `design --model` choice, for the same reason
# as PREDICT_MODELS above: gates and docs derive the shipped design models from
# here instead of re-typing the list. boltzgen is the default (the full
# production binder-design pipeline, mirroring predict's boltz2 default); rfd3
# is the lighter single-shot all-atom diffusion designer; pxdesign generates binder
# backbones against a target structure, conditioned on a distogram of the target only.
DESIGN_MODELS = ("boltzgen", "rfd3", "pxdesign", "rfd4")

# `design --model rfd4 --recipe`: RFD4's shipped recycle schedules, which are its thinking
# budget. Spelled out here rather than imported so `--help` does not pull in torch;
# test_rfd4_cond_chem keeps the list equal to `tt_bio.rfd4.sampler.RECYCLE_SCHEDULES`.
_RFD4_RECIPES = ("high/flat", "high/front_loaded", "high/midpeak",
                 "low/flat", "low/front_loaded", "low/midpeak",
                 "medium/flat", "medium/front_loaded", "medium/midpeak",
                 "thinking_high", "thinking_low", "thinking_medium")

# `affinity --model`: scalar-output affinity predictors. Separate from PREDICT_MODELS
# because these fold nothing — no coordinates, no PAE, no confidence — so they do not
# ride the structure-writing scheduler path predict uses.
AFFINITY_MODELS = ("nesso1",)


def predict_results_dir_name(model: str, stem: str) -> str:
    """Predict output folder name: <model>_results_<stem> (e.g.
    protenix_results_prot, boltz2_results_trpcage). Single source of truth —
    every consumer (CLI, release gate, parity harness) derives the results-folder
    name from here so a new model gets a correct, model-named folder automatically
    and no generic output path ever hardcodes boltz_."""
    return f"{_MODEL_RESULTS_PREFIX.get(model, 'results')}_{stem}"


def ensure_rfd3_weights(cache: Path) -> Path:
    """TokenInitializer/DiffusionModule weights `tt-bio design --model rfd3` loads.

    Fetches and extracts the RFD3 checkpoint on first use, then discards it: only the
    extracted weights are ever read again. See tt_bio.weights for why the extraction
    is staged before the checkpoint is deleted."""
    return weights.fetch("rfd3", root=cache)


def download_mols(cache: Path) -> Path:
    """The CCD molecule library, extracted under cache/mols. Used by Boltz-2
    (ligands/affinity) and Protenix-v2 (nucleic-acid / ligand templates)."""
    return weights.fetch("mols", root=cache)


def download_all(cache: Path, model: str = "boltz2", checkpoint: str | None = None) -> None:
    """Fetch every artifact `model` needs, in the parent, before any worker starts.

    Fanning out first has N local workers each see the same multi-GB file missing and
    race to download it into one cache dir. Registry-driven, so a new model is covered
    without another special case here; the hand-written version covered protenix-v2 and
    rf3 only, and downloaded the 4.2 GB of Boltz-2 checkpoints for every model whether
    or not they were needed. A row tt-bio does not download (protenix-v2) is checked
    earlier, in `predict`, before the MSA search. A ``--checkpoint`` replaces the model's own
    row, so that one is not fetched."""
    for art in weights.artifacts_for(model):
        if art.source != "manual" and not (checkpoint and art.key == model):
            weights.fetch(art.key, root=cache)


def ensure_pxdesign_weights(cache: Path) -> Path:
    """The PXDesign-d generator checkpoint `tt-bio design --model pxdesign` loads.

    The AF2-IG parameters are NOT fetched here. They belong to the selection stage, which is
    not on the CLI, and they are a 4 GB archive; `tt-bio weights --download af2ig` gets them.
    """
    return weights.fetch("pxdesign", root=cache)


def compute_msa(seqs: dict[str, str], target_id: str, msa_dir: Path, url: str, strategy: str,
                username: str = None, password: str = None, api_key: str = None) -> None:
    """Generate Boltz-2 ``{seq_hash}.csv`` MSAs via the ColabFold server.

    ``seqs`` maps seq_hash -> sequence. Two or more sequences are one complex: their paired
    rows come from the shared paired search (:func:`_generate_paired_a3m`) and the CSVs are
    written to that complex's :func:`paired_msa_dir`, because the ``key`` column only means
    something against the partners it was searched with. One sequence writes
    ``msa_dir/{seq_hash}.csv`` with no paired rows, as before.
    """
    click.echo(f"MSA for {target_id} ({len(seqs)} sequences)")
    headers = {"Content-Type": "application/json", "X-API-Key": api_key} if api_key else None
    seqs_list = list(seqs.values())

    paired = _generate_paired_a3m(seqs, target_id, msa_dir, url, strategy,
                                  username, password, api_key) or {}
    out_dir = paired_msa_dir(msa_dir, seqs_list) or msa_dir

    unpaired = run_mmseqs2(seqs_list, _mmseqs_prefix(msa_dir, seqs_list, "unpaired"), use_env=True,
                          use_pairing=False, host_url=url, pairing_strategy=strategy,
                          msa_server_username=username, msa_server_password=password, auth_headers=headers)

    write_boltz_csvs(out_dir, paired, dict(zip(seqs, unpaired)))


def _mmseqs_prefix(msa_dir: Path, seqs, kind: str) -> Path:
    """``run_mmseqs2``'s working dir, keyed by the exact sequences searched.

    ``run_mmseqs2`` reuses an ``out.tar.gz`` it finds there, so a prefix keyed by the input
    file stem (which repeats: "target_1", "complex") hands one run's alignments to the next
    run under the same name. With the same number of queries nothing fails: each new sequence
    is cached with another protein's MSA. A content hash is still reused when the same
    sequences recur.
    """
    tag = hashlib.sha256("\n".join(seqs).encode()).hexdigest()[:16]
    return msa_dir / f"{tag}_{kind}_tmp"


def write_boltz_csvs(out_dir: Path, paired: dict[str, str], unpaired: dict[str, str]) -> None:
    """Write one Boltz-2 ``{seq_hash}.csv`` per sequence: its paired a3m rows keyed 0..n on top
    (row j of every chain is one genome), then its unpaired rows keyed -1. ``paired`` and
    ``unpaired`` map seq_hash -> a3m text; a sequence with no paired a3m gets unpaired rows only."""
    for name, text in unpaired.items():
        paired_seqs = [s for s in paired.get(name, "").strip().splitlines()[1::2][:const.max_paired_seqs] if s != "-" * len(s)]
        unpaired_seqs = text.strip().splitlines()[1::2][:const.max_msa_seqs - len(paired_seqs)]
        if paired_seqs:
            unpaired_seqs = unpaired_seqs[1:]
        keys = list(range(len(paired_seqs))) + [-1] * len(unpaired_seqs)
        lines = ["key,sequence"] + [f"{k},{s}" for k, s in zip(keys, paired_seqs + unpaired_seqs)]
        publish_text(out_dir / f"{name}.csv", "\n".join(lines))


_COLABFOLD_SEARCH_PATHS = [
    Path.home() / "localcolabfold" / ".pixi" / "envs" / "default" / "bin" / "colabfold_search",
]


def _find_colabfold_search() -> str:
    """Find colabfold_search binary on PATH or at common install locations."""
    found = shutil.which("colabfold_search")
    if found:
        return found
    for p in _COLABFOLD_SEARCH_PATHS:
        if p.is_file() and os.access(p, os.X_OK):
            return str(p)
    raise RuntimeError(
        "colabfold_search not found.\n"
        "Install localcolabfold and/or activate the environment that provides it:\n"
        "  https://github.com/YoshitakaMo/localcolabfold"
    )


_MMSEQS_SEARCH_PATHS = [
    Path.home() / "localcolabfold" / ".pixi" / "envs" / "default" / "bin" / "mmseqs",
]


def _find_pixi() -> str | None:
    """Find pixi binary on PATH or common install location."""
    found = shutil.which("pixi")
    if found:
        return found
    p = Path.home() / ".pixi" / "bin" / "pixi"
    if p.is_file() and os.access(p, os.X_OK):
        return str(p)
    return None


def _missing_offline_tools() -> list[str]:
    missing = []
    try:
        _find_mmseqs()
    except Exception:
        missing.append("mmseqs")
    try:
        _find_colabfold_search()
    except Exception:
        missing.append("colabfold_search")
    return missing


def _ensure_pixi() -> str:
    """Ensure pixi is installed and return its path."""
    pixi = _find_pixi()
    if pixi:
        return pixi
    if not shutil.which("curl"):
        raise RuntimeError("curl is required to auto-install pixi")
    click.echo("Installing pixi ...")
    subprocess.run(
        ["bash", "-lc", "curl -fsSL https://pixi.sh/install.sh | sh"],
        check=True,
    )
    pixi = _find_pixi()
    if not pixi:
        raise RuntimeError("pixi install finished but pixi binary was not found")
    return pixi


def _ensure_aria2(pixi: str) -> None:
    """Install aria2 via pixi if not already available."""
    if shutil.which("aria2c"):
        return
    click.echo("Installing aria2 for fast parallel downloads ...")
    subprocess.run([pixi, "global", "install", "aria2"], check=True)


def _ensure_pigz(pixi: str) -> None:
    """Install pigz via pixi if not already available."""
    if shutil.which("pigz"):
        return
    click.echo("Installing pigz for fast parallel extraction ...")
    subprocess.run([pixi, "global", "install", "pigz"], check=True)


def _ensure_offline_tools(install_tools: bool) -> None:
    """Ensure mmseqs + colabfold_search + aria2/pigz are available; optionally install them."""
    missing = _missing_offline_tools()
    need_aria2 = not shutil.which("aria2c")
    need_pigz = not shutil.which("pigz")

    if not missing and not need_aria2 and not need_pigz:
        return
    if not install_tools:
        all_missing = missing + (["aria2c"] if need_aria2 else []) + (["pigz"] if need_pigz else [])
        raise RuntimeError(
            "Missing offline MSA tools: " + ", ".join(all_missing) + "\n"
            "Rerun with: tt-bio msa --install-tools"
        )

    pixi = _ensure_pixi()
    # `pixi global install` puts aria2c and pigz in ~/.pixi/bin, which the pixi installer
    # adds to ~/.bashrc and so to the NEXT shell, never to this process. Without it on
    # PATH, the shutil.which() in the download and extract paths missed the tools this
    # function had just installed: on a fresh host the 107 GB UniRef30 tarball came down
    # over single-stream curl at 4 MB/s (~7 h) instead of aria2c at ~68 MB/s, and was
    # unpacked by single-threaded gzip instead of pigz.
    pixi_bin = str(Path(os.environ.get("PIXI_HOME", Path.home() / ".pixi")) / "bin")
    if pixi_bin not in os.environ.get("PATH", "").split(os.pathsep):
        os.environ["PATH"] = pixi_bin + os.pathsep + os.environ.get("PATH", "")
    _ensure_aria2(pixi)
    _ensure_pigz(pixi)

    if missing:
        click.echo("Missing offline MSA tools: " + ", ".join(missing))
        click.echo("Installing localcolabfold toolchain ...")

        if not shutil.which("git"):
            raise RuntimeError("git is required to auto-install localcolabfold")

        lc = Path.home() / "localcolabfold"
        if not lc.exists():
            subprocess.run(
                ["git", "clone", "https://github.com/YoshitakaMo/localcolabfold.git", str(lc)],
                check=True,
            )

        subprocess.run([pixi, "install"], cwd=str(lc), check=True)
        subprocess.run([pixi, "run", "setup"], cwd=str(lc), check=True)

        missing = _missing_offline_tools()
        if missing:
            raise RuntimeError(
                "localcolabfold setup completed but tools are still missing: "
                + ", ".join(missing)
            )


def _find_mmseqs(colabfold_bin: str | None = None) -> str | None:
    """Find an mmseqs binary, preferring the one bundled with the colabfold_search
    in use. colabfold invokes mmseqs with flags a mismatched system build rejects
    (e.g. Debian 13-45111 has no --prefilter-mode, breaking every offline MSA).
    """
    if colabfold_bin:
        sibling = Path(colabfold_bin).parent / "mmseqs"
        if sibling.is_file() and os.access(sibling, os.X_OK):
            return str(sibling)
    for p in _MMSEQS_SEARCH_PATHS:
        if p.is_file() and os.access(p, os.X_OK):
            return str(p)
    found = shutil.which("mmseqs")
    if found:
        return found
    return None


def _download_file(url: str, dest: Path) -> None:
    """Download an MSA database tarball. Routed through the shared weight-fetch path so
    an interrupted download cannot leave a truncated file that a later run treats as
    present: staged next to the destination, size-checked against the server's
    Content-Length, then renamed in. The structural archive check is skipped because
    these tarballs are hundreds of GB, too large to scan."""
    weights.fetch_file((url,), dest, check_archive=False)


def _recommended_threads() -> int:
    """Pick a conservative-but-fast thread count across machine sizes."""
    return max(1, int(os.cpu_count() or 1))


def _extract_tarball(tarball: Path, out_dir: Path) -> None:
    """Extract tar.gz, using pigz for parallel decompression if available."""
    threads = _recommended_threads()
    pigz = shutil.which("pigz")
    if pigz:
        # GNU tar supports --use-compress-program/-I with an argument string.
        cmd = ["tar", "-I", f"{pigz} -d -p {threads}", "-xf", str(tarball), "-C", str(out_dir)]
    else:
        cmd = ["tar", "-xzf", str(tarball), "-C", str(out_dir)]
    subprocess.run(cmd, check=True)


def _mmseqs_index_exists(db_dir: Path, db_name: str) -> bool:
    """Return True if MMseqs index for db_name already exists."""
    return (db_dir / f"{db_name}.idx").exists()


def _validate_offline_msa_db(db_path: Path, require_envdb: bool = False) -> None:
    """Validate local MSA DB layout and required ready markers."""
    db_path = db_path.expanduser()
    if not db_path.exists():
        raise RuntimeError(
            f"Offline MSA DB path does not exist: {db_path}\n"
            "Run: tt-bio msa --path <path>  (or use --use_msa_server)"
        )
    if not db_path.is_dir():
        raise RuntimeError(f"Offline MSA DB path must be a directory: {db_path}")

    uniref_ready = db_path / "UNIREF30_READY"
    if not uniref_ready.exists():
        raise RuntimeError(
            f"Offline MSA DB is incomplete at {db_path} (missing UNIREF30_READY).\n"
            "Run: tt-bio msa --db uniref30 --path "
            f"{db_path}  (or use --use_msa_server)"
        )

    if require_envdb and not (db_path / "COLABDB_READY").exists():
        raise RuntimeError(
            f"--use_envdb requested but EnvDB is not set up at {db_path}.\n"
            f"Run: tt-bio msa --db all --path {db_path}"
        )


def _lowest_priority() -> None:
    """A search's CPU time is what folds leave: host load slows a fold (158 s -> 262 s)."""
    os.nice(19)


# More align threads stop paying past here: 8 took a served search from 22.2 s to 13.0 s with
# the few-query align patch, a3m byte-identical at every thread count.
_SEARCH_MAX_THREADS = 8


def _search_threads() -> int:
    """Threads for one search: the worker's share, plus cores the host leaves idle.

    _spawn_worker_processes sets OMP_NUM_THREADS = cores // workers, 2 on a Galaxy, so
    concurrent searches never oversubscribe a host. The search is niced, so an idle core it
    borrows costs no fold anything. A plain CLI run leaves the env unset and gets every core.
    """
    cores = os.cpu_count() or 1
    share = int(os.environ.get("OMP_NUM_THREADS") or 0)
    if not share:
        return cores
    idle = cores - math.ceil(os.getloadavg()[0])
    return max(share, min(idle, _SEARCH_MAX_THREADS))


def compute_msa_offline(seqs: dict[str, str], target_id: str, msa_dir: Path,
                        db_path: str, use_env: bool = False,
                        pairing_strategy: str = "greedy", pair: bool = False,
                        chain_cache: Path | None = None) -> None:
    """Generate MSAs locally via colabfold_search against a local database.

    By default every sequence is searched on its own in one batched call: one unpaired
    ``{name}.a3m`` each. ``pair=True`` treats the sequences as one complex's chains and
    writes each chain's species-paired rows instead, row j of every ``{name}.a3m`` from the
    same genome, the shape the ColabFold server's pair endpoint returns.

    colabfold_search pairs only the chains of ONE record, joined by ``:``. ``pair=True``
    used to pass ``--pair-mode unpaired_paired`` over one record per chain, which pairs
    nothing: each chain's "paired" file was its own unpaired hits, at its own depth. OpenBind
    refused that (the depths differ), and ESMFold-2 and OpenDDE read row j of each as one
    genome.

    ``chain_cache`` lets a paired search reuse each chain's own search from an earlier complex
    (:func:`_paired_by_chain`); the output is the same bytes either way.
    """
    click.echo(f"MSA for {target_id} ({len(seqs)} sequences, offline, "
               f"pairing={pairing_strategy if pair else 'none'})")
    colabfold_bin = _find_colabfold_search()
    mmseqs_bin = _find_mmseqs(colabfold_bin)
    strategy_map = {"greedy": "0", "complete": "1"}
    strategy_val = strategy_map.get(pairing_strategy, pairing_strategy)
    # Unique per process AND thread so concurrent searches in one process (e.g.
    # the MSA server with max_concurrent > 1) don't share a scratch dir.
    import threading
    tmp = msa_dir / f"_offline_tmp_{os.getpid()}_{threading.get_ident()}"
    tmp.mkdir(parents=True, exist_ok=True)
    paired = pair and len(seqs) > 1
    try:
        fasta = tmp / "query.fasta"
        with open(fasta, "w") as f:
            if paired:
                f.write(">complex\n" + ":".join(seqs.values()) + "\n")
            else:
                for name, seq in seqs.items():
                    f.write(f">{name}\n{seq}\n")
        a3m_out = tmp / "a3m"
        a3m_out.mkdir(exist_ok=True)
        threads = _search_threads()
        if paired and chain_cache is not None:
            msa = _paired_by_chain(list(seqs.values()), Path(db_path), mmseqs_bin, colabfold_bin,
                                   tmp, Path(chain_cache), threads, strategy_val)
            if msa is not None:
                for name, text in zip(seqs, split_paired_a3m(msa, [len(q) for q in seqs.values()])):
                    publish_text(msa_dir / f"{name}.a3m", text)
                return
        cmd_base = [
            colabfold_bin, str(fasta), db_path, str(a3m_out),
            "--use-env", "1" if use_env else "0", "--use-templates", "0",
            "--db-load-mode", "2", "--threads", str(threads),
        ]
        if paired:
            cmd_base += ["--pair-mode", "paired", "--pairing_strategy", strategy_val]

        commands = []
        if mmseqs_bin:
            commands.append(cmd_base[:4] + ["--mmseqs", mmseqs_bin] + cmd_base[4:])
        commands.append(cmd_base)

        last_error = ""
        for idx, cmd in enumerate(commands):
            result = subprocess.run(cmd, capture_output=True, text=True,
                                    preexec_fn=_lowest_priority)
            if result.returncode == 0:
                last_error = ""
                break
            err = (result.stderr or result.stdout or "").strip()
            last_error = "\n".join(err.splitlines()[-20:]) if err else ""
            if idx < len(commands) - 1:
                click.echo("  colabfold_search failed with explicit --mmseqs, retrying with default lookup")
        if last_error:
            raise RuntimeError(
                f"colabfold_search failed (exit {result.returncode})\n{last_error}"
            )
        if paired:
            src = a3m_out / "complex.a3m"
            if not cached(src):
                raise RuntimeError(f"colabfold_search wrote no paired A3M for {target_id}")
            for name, text in zip(seqs, split_paired_a3m(src.read_text(),
                                                         [len(q) for q in seqs.values()])):
                publish_text(msa_dir / f"{name}.a3m", text)
            return
        for name in seqs:
            src = a3m_out / f"{name}.a3m"
            if cached(src):
                publish_file(src, msa_dir / f"{name}.a3m")
            else:
                click.echo(f"  warning: no A3M for {name}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


#: The colabfold release whose ``mmseqs_search_pair`` :func:`_paired_by_chain` re-runs step by
#: step. Any other release takes the stock colabfold_search path.
PAIRED_BY_CHAIN_COLABFOLD = "1.6.3"


def _colabfold_version(colabfold_bin: str) -> str | None:
    root = Path(colabfold_bin).resolve().parent.parent
    for d in root.glob("lib/python*/site-packages/colabfold-*.dist-info"):
        return d.name[len("colabfold-"):-len(".dist-info")]
    return None


def _mmseqs_run(mmseqs: str, *args) -> str:
    r = subprocess.run([mmseqs, *map(str, args)], capture_output=True, text=True,
                       preexec_fn=_lowest_priority)
    if r.returncode:
        raise RuntimeError(f"mmseqs {args[0]} failed: {(r.stderr or r.stdout)[-500:]}")
    return r.stdout


def pair_rows(paired: list[str], lengths: list[int]) -> str:
    """colabfold 1.6.3 ``msa_to_str(None, paired, ...)`` for unique chains: the length line,
    then row i of every chain's paired a3m joined (headers by tabs)."""
    rows = [""] * len(paired[0].splitlines())
    for n, text in enumerate(paired):
        for i, line in enumerate(text.splitlines()):
            rows[i] += line.replace(">", "\t", 1) if n and line.startswith(">") else line
    return "#" + ",".join(map(str, lengths)) + "\t" + ",".join("1" * len(lengths)) + "\n" + "\n".join(rows)


def _paired_by_chain(seqs: list[str], dbbase: Path, mmseqs: str | None, colabfold_bin: str,
                     tmp: Path, cache: Path, threads: int, strategy: str) -> str | None:
    """``colabfold_search --pair-mode paired`` of one complex, byte for byte, with each chain's
    search, expandaln and align cached by sequence.

    colabfold 1.6.3's ``mmseqs_search_pair`` is per query until ``pairaln``: a chain's profile
    search and its realigned expansion do not depend on its partners (graded byte-identical on
    the served DB, state/spd-bet-clientwall.md). A binder campaign folds one target against
    many binders, and stock re-searched the target every time, on one core per chain since
    ``align`` threads over queries: ~26 of a served OpenDDE job's ~30 s before its chip. Here
    only the chains not cached are searched, side by side, and the pairing runs on the merged
    per-chain results. Returns the complex a3m text, or None to fall back to colabfold_search
    (another colabfold, no index, an unexpected sequence, any mmseqs failure)."""
    db = dbbase / "uniref30_2302_db"
    if (not mmseqs or _colabfold_version(colabfold_bin) != PAIRED_BY_CHAIN_COLABFOLD
            or not Path(f"{db}.idx").is_file() or os.environ.get("MMSEQS_IGNORE_INDEX")
            or not all(s.isalpha() and s.isupper() for s in seqs)):
        return None
    try:
        version = _mmseqs_run(mmseqs, "version").strip()
        dbv = (dbbase / "VERSION").read_text().strip() if (dbbase / "VERSION").is_file() else ""
        tag = f"{PAIRED_BY_CHAIN_COLABFOLD}|{version}|{dbbase.resolve()}|{dbv}"
        keys = [hashlib.sha256(f"{tag}|{s}".encode()).hexdigest()[:24] for s in seqs]
        idx, load, thr = f"{db}.idx", ("--db-load-mode", "2"), ("--threads", threads)

        def chain(seq: str, key: str) -> Path:
            done = got = cache / key

            def run(_):
                nonlocal got
                got = search(seq, key, done)

            single_flight(cache, [key], lambda _: not (done / "ok").is_file(), run)
            return got

        def search(seq: str, key: str, done: Path) -> Path:
            c = tmp / f"chain_{key}"
            c.mkdir(parents=True)
            (c / "q.fas").write_text(f">101\n{seq}\n")
            _mmseqs_run(mmseqs, "createdb", c / "q.fas", c / "qdb", "--shuffle", "0", "--dbtype", "1")
            _mmseqs_run(mmseqs, "search", c / "qdb", db, c / "res", c / "tmp", *thr, "--num-iterations", "3",
                        *load, "-a", "-e", "0.1", "--max-seqs", "10000", "--prefilter-mode", "0",
                        "--k-score", "'seq:96,prof:80'")
            _mmseqs_run(mmseqs, "mvdb", c / "tmp/latest/profile_1", c / "prof")
            _mmseqs_run(mmseqs, "expandaln", c / "qdb", idx, c / "res", idx, c / "exp", *load, *thr,
                        "--expansion-mode", "0", "-e", "inf", "--expand-filter-clusters", "0",
                        "--max-seq-id", "0.95")
            _mmseqs_run(mmseqs, "align", c / "prof", idx, c / "exp", c / "ral", *load,
                        "--alignment-mode", "1", "-e", "0.001", "--max-accept", "1000000", *thr)
            keep = c / "keep"
            keep.mkdir()
            for f in [*c.glob("prof*"), *c.glob("ral*")]:
                f.rename(keep / f.name)
            (keep / "ok").touch()
            shutil.rmtree(done, ignore_errors=True)   # a half-pruned entry; we hold its lock
            try:
                keep.rename(done)
            except OSError:                            # an engine without the lock published it first
                return keep
            return done

        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(len(seqs)) as pool:
            dirs = list(pool.map(chain, seqs, keys))

        w = tmp / "pair"
        w.mkdir()
        (w / "query.fas").write_text("".join(f">{101 + j}\n{s}\n" for j, s in enumerate(seqs)))
        _mmseqs_run(mmseqs, "createdb", w / "query.fas", w / "qdb", "--shuffle", "0", "--dbtype", "1")
        (w / "qdb.lookup").write_text("".join(f"{j}\tcomplex\t0\n" for j in range(len(seqs))))
        # concatdbs keeps the first DB's keys and moves the second's past them, so chain j ends up
        # under key j, as in the joint query DB.
        for name in ("prof", "ral"):
            cur = dirs[0] / name
            for j, d in enumerate(dirs[1:], 1):
                _mmseqs_run(mmseqs, "concatdbs", cur, d / name, w / f"{name}{j}", "--threads", "1")
                cur = w / f"{name}{j}"
            _mmseqs_run(mmseqs, "cpdb" if len(dirs) == 1 else "mvdb", cur, w / name)
        _mmseqs_run(mmseqs, "lndb", w / "qdb_h", w / "prof_h")
        _mmseqs_run(mmseqs, "pairaln", w / "qdb", db, w / "ral", w / "pair", *load,
                    "--pairing-mode", strategy, "--pairing-dummy-mode", "0", *thr)
        _mmseqs_run(mmseqs, "align", w / "prof", idx, w / "pair", w / "pair_bt", *load, "-e", "inf", "-a", *thr)
        _mmseqs_run(mmseqs, "pairaln", w / "qdb", db, w / "pair_bt", w / "final", *load,
                    "--pairing-mode", strategy, "--pairing-dummy-mode", "1", *thr)
        _mmseqs_run(mmseqs, "result2msa", w / "qdb", idx, w / "final", w / "pair.a3m", *load,
                    "--msa-format-mode", "5", *thr, "--filter-msa", "0", "--filter-min-enable", "1000",
                    "--diff", "3000", "--qid", "0.2,0.4,0.6,0.8,1.0", "--qsc", "0", "--max-seq-id", "0.95")
        _mmseqs_run(mmseqs, "unpackdb", w / "pair.a3m", w / "out", "--unpack-name-mode", "0",
                    "--unpack-suffix", ".paired.a3m")
        return pair_rows([(w / "out" / f"{j}.paired.a3m").read_text() for j in range(len(seqs))],
                         [len(s) for s in seqs])
    except Exception as e:  # noqa: BLE001 -- the stock search below is always correct
        click.echo(f"  per-chain paired search failed ({e}); running colabfold_search")
        return None


def split_paired_a3m(text: str, lengths: list[int]) -> list[str]:
    """One chain's a3m per entry of ``lengths`` from colabfold_search's paired a3m of a complex.

    That file (``msa_to_str`` with ``pair_msa``'s paired-only branch) has a ``#len,...`` line,
    then each row's chains concatenated, query first. A chain's slice ends after its length in
    match columns (upper case or ``-``); lower-case insertions ride with the column before them.
    Row j of every chain stays row j, so the chains remain paired. Headers are tab-joined
    descriptions that contain tabs themselves, so each row is renamed ``>{j}``; no reader keys
    on a paired header (they pair by row index).
    """
    out = [[] for _ in lengths]
    rows = [l for l in text.splitlines() if l and not l.startswith(("#", ">"))]
    for j, row in enumerate(rows):
        pos, k, n = 0, 0, 0
        cuts = []
        for limit in lengths:
            n += limit
            while k < n:
                k += row[pos] == "-" or row[pos].isupper()
                pos += 1
            while pos < len(row) and row[pos].islower():
                pos += 1
            cuts.append(pos)
        if cuts[-1] != len(row):
            raise ValueError(f"paired a3m row {j} has {k} match columns past the "
                             f"{sum(lengths)} the chains add up to")
        for i, (a, b) in enumerate(zip([0] + cuts, cuts)):
            out[i] += [f">{j}", row[a:b]]
    return ["\n".join(chain) + "\n" for chain in out]


def search_boltz2_msas(prot, target_id, msa_dir, *, use_msa, msa_db_path, use_envdb,
                       msa_url, msa_strategy, msa_user, msa_pass, api_key):
    """Search what Boltz-2 will read for one complex and the cache lacks. ``prot`` maps
    seq_hash -> sequence for the protein chains the input left to the search. Returns the
    complex's paired directory the chains read their CSVs from, or None for the per-chain
    cache. Touches no device, so ``tt-bio predict`` runs it before any chip is leased
    (worker.prefetch_msas) and the fold's own call finds everything cached.

    A heteromer's CSVs carry pairing keys, which mean something only against the partners
    they were searched with, so the complex gets its own directory and is searched whole.
    Keyed per chain, a partner already cached from an earlier fold left the new chain to be
    searched alone, and nothing paired. A cache-only run reads the complex's CSVs when they
    are there; an offline run keeps the per-chain cache."""
    pdir = None if msa_db_path else paired_msa_dir(msa_dir, prot.values())
    if pdir is not None and not use_msa and not all(cached(pdir / f"{h}.csv") for h in prot):
        pdir = None
    if pdir is not None:
        to_gen = {} if all(cached(pdir / f"{h}.csv") for h in prot) else prot
    else:
        to_gen = {h: q for h, q in prot.items()
                  if not cached(msa_dir / f"{h}.a3m") and not cached(msa_dir / f"{h}.csv")}
    if to_gen:
        # One search per complex (paired) or per sequence across every worker sharing this
        # msa_dir: a second job waits for the first and reads its files (cache.single_flight).
        def search(todo):
            gen = prot if pdir is not None else {h: to_gen[h] for h in todo}
            if msa_db_path:
                compute_msa_offline(gen, target_id, msa_dir, msa_db_path,
                                    use_env=use_envdb, pairing_strategy=msa_strategy)
            elif use_msa:
                compute_msa(gen, target_id, msa_dir, msa_url, msa_strategy, msa_user, msa_pass, api_key)
            else:
                raise RuntimeError(
                    "No MSA for this target and no source to search one with. Use:\n"
                    "  --use_msa_server        the online ColabFold server\n"
                    "  --msa_db_path <dir>     a local ColabFold DB (`tt-bio msa` downloads one)\n"
                    "  --single_sequence       fold without an MSA, at a large accuracy cost"
                )

        if pdir is not None:
            single_flight(pdir.parent, [pdir.name],
                          lambda _: not all(cached(pdir / f"{h}.csv") for h in prot), search)
        else:
            single_flight(msa_dir, to_gen, lambda h: not cached(msa_dir / f"{h}.a3m")
                          and not cached(msa_dir / f"{h}.csv"), search)
    return pdir


def prepare_features(path, ccd, mol_dir, msa_dir, tokenizer, featurizer,
                     use_msa, msa_url, msa_strategy, msa_user, msa_pass, api_key,
                     max_msa, msa_db_path=None, use_envdb=False, method=None,
                     affinity=False, pred_structure=None, progress=None,
                     single_sequence=False):
    """Parse, resolve MSA, tokenize, featurize — all in memory.

    MSA files are cached in msa_dir by sequence hash — the same
    protein sequence is never searched twice across any input file or run.
    ``progress`` is an optional ``fn(stage)`` callback used to mark the
    transition from the MSA stage to featurization ("prep").
    Returns (features_dict, input_structure).
    """
    suffix = path.suffix.lower()
    if suffix in (".fa", ".fas", ".fasta"):
        target = parse_fasta(path, ccd, mol_dir, True)
    elif suffix in (".yml", ".yaml"):
        target = parse_yaml(path, ccd, mol_dir, True)
    else:
        raise ValueError(f"Unsupported format: {suffix}")

    record = target.record
    struct = pred_structure if pred_structure is not None else target.structure

    # Identify protein chains needing MSA, keyed by sequence hash for global caching
    to_gen = {}
    searched = []
    for chain in record.chains:
        # --single_sequence: fold every protein chain without an MSA (self-only),
        # skipping both cached alignments and any online/offline search.
        if single_sequence and chain.mol_type == const.chain_type_ids["PROTEIN"]:
            chain.msa_id = -1
            continue
        if chain.mol_type == const.chain_type_ids["PROTEIN"] and chain.msa_id == 0:
            searched.append(chain)
        elif chain.msa_id == 0:
            chain.msa_id = -1
    prot = {seq_hash(target.sequences[c.entity_id]): target.sequences[c.entity_id]
            for c in searched}
    pdir = search_boltz2_msas(prot, record.id, msa_dir, use_msa=use_msa, msa_db_path=msa_db_path,
                              use_envdb=use_envdb, msa_url=msa_url, msa_strategy=msa_strategy,
                              msa_user=msa_user, msa_pass=msa_pass, api_key=api_key)
    for chain in searched:
        h = seq_hash(target.sequences[chain.entity_id])
        a3m = msa_dir / f"{h}.a3m"
        if pdir is not None:
            chain.msa_id = str(pdir / f"{h}.csv")
        else:
            chain.msa_id = str(a3m) if cached(a3m) else str(msa_dir / f"{h}.csv")

    # Parse MSAs in memory (deduplicated by path)
    msa_cache = {}
    msas = {}
    for chain in record.chains:
        if chain.msa_id == -1:
            continue
        key = str(chain.msa_id)
        if key not in msa_cache:
            p = Path(key)
            msa_cache[key] = parse_a3m(p, None, max_msa) if p.suffix == ".a3m" else parse_csv(p, max_msa)
        msas[chain.chain_id] = msa_cache[key]

    # MSA resolution is done; the rest is featurization ("prep" stage).
    if progress:
        progress("prep")

    # Build Input and tokenize
    templates = target.templates if target.templates else None
    inp = Input(struct, msas, record=record, residue_constraints=target.residue_constraints,
                templates=templates, extra_mols=target.extra_mols)
    tok = tokenizer.tokenize(inp)

    # Affinity cropping
    if affinity:
        td, tb = tok.tokens, tok.bonds
        valid = td[td["resolved_mask"]]
        lig_coords = valid[valid["affinity_mask"]]["center_coords"]
        dists = np.min(np.sum((valid["center_coords"][:, None] - lig_coords[None])**2, -1)**0.5, axis=1)

        cropped, atoms, prot = set(), 0, set()
        lig_ids = set(valid[valid["mol_type"] == const.chain_type_ids["NONPOLYMER"]]["token_idx"])

        for idx in np.argsort(dists):
            token = valid[idx]
            chain_tokens = td[td["asym_id"] == token["asym_id"]]
            if len(chain_tokens) <= 10:
                neighbors = chain_tokens
            else:
                res_window = chain_tokens[(chain_tokens["res_idx"] >= token["res_idx"] - 10) &
                                         (chain_tokens["res_idx"] <= token["res_idx"] + 10)]
                neighbors = res_window[res_window["res_idx"] == token["res_idx"]]
                mi = ma = token["res_idx"]
                while neighbors.size < 10:
                    mi -= 1; ma += 1
                    neighbors = res_window[(res_window["res_idx"] >= mi) & (res_window["res_idx"] <= ma)]

            new_ids = set(neighbors["token_idx"]) - cropped
            new_atoms = np.sum(td[list(new_ids)]["atom_num"])
            if (len(new_ids) > 256 - len(cropped) or atoms + new_atoms > 2048 or
                len(prot | new_ids - lig_ids) > 200):
                break
            cropped.update(new_ids)
            atoms += new_atoms
            prot.update(new_ids - lig_ids)

        td = td[sorted(cropped)]
        tb = tb[np.isin(tb["token_1"], td["token_idx"]) & np.isin(tb["token_2"], td["token_idx"])]
        tok = replace(tok, tokens=td, bonds=tb)

    # Load molecules
    mols = {**ccd, **target.extra_mols}
    needed = set(tok.tokens["res_name"].tolist()) - set(mols)
    mols.update(load_molecules(mol_dir, needed))

    # Constraints
    opts = record.inference_options
    pocket, contact = (opts.pocket_constraints, opts.contact_constraints) if opts else (None, None)

    # Featurize
    feats = featurizer.process(
        tok, np.random.default_rng(42), mols, False, const.max_msa_seqs,
        pad_to_max_seqs=False, single_sequence_prop=0.0, compute_frames=True,
        inference_pocket_constraints=pocket, inference_contact_constraints=contact,
        compute_constraint_features=True, override_method=method, compute_affinity=affinity
    )
    feats["record"] = record
    return feats, target.structure


def to_batch(feats: dict, device: torch.device) -> dict:
    """Convert features to batch format on device."""
    skip = {"all_coords", "all_resolved_mask", "crop_to_all_atom_map", "chain_symmetries",
            "amino_acids_symmetries", "ligand_symmetries", "record", "affinity_mw"}
    batch = {}
    for k, v in feats.items():
        if k in skip:
            batch[k] = [v] if k == "record" else v
        elif hasattr(v, 'unsqueeze'):
            batch[k] = v.unsqueeze(0).to(device)
        else:
            batch[k] = v
    return batch


def _atomic_write(path: Path, content: str):
    """Write file atomically via tmp+rename to prevent corruption on crash."""
    tmp = path.with_name(f"{path.name}.{os.getpid()}.{time.time_ns()}.tmp")
    try:
        tmp.write_text(content)
        with open(tmp, "r+") as f:
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        if tmp.exists():
            tmp.unlink(missing_ok=True)


def write_result(pred, batch, input_struct, out_dir, fmt,
                 write_pae=False, write_pde=False, write_embeddings=False, contact_cutoff=8.0):
    """Write CIF/PDB structure files. Return (metrics_dict, best_structure).

    pLDDT embedded in B-factors. All confidence values returned in metrics dict.
    """
    if pred["exception"]:
        return None, None

    record = batch["record"][0]
    struct = input_struct.remove_invalid_chains()

    confidence = pred.get("confidence_score", torch.zeros(1))
    rank = {i.item(): r for r, i in enumerate(torch.argsort(confidence, descending=True))}
    mask_1d = pred["masks"].squeeze(0) if pred["masks"].dim() > 1 else pred["masks"]

    best_struct = None
    write_fn = to_pdb if fmt == "pdb" else to_mmcif

    for model_idx in range(pred["coords"].shape[0]):
        model_rank = rank.get(model_idx, model_idx)
        coords = pred["coords"][model_idx][mask_1d.bool()].cpu().numpy()

        atoms, residues = struct.atoms.copy(), struct.residues.copy()
        atoms["coords"], atoms["is_present"] = coords, True
        residues["is_present"] = True
        new_struct = replace(struct, atoms=atoms, residues=residues,
                            interfaces=np.array([], dtype=Interface),
                            coords=np.array([(x,) for x in coords], dtype=Coords))

        plddt = pred.get("plddt", [None] * (model_idx + 1))[model_idx]

        if model_rank == 0:
            best_struct = new_struct
            _atomic_write(out_dir / f"{record.id}.{fmt}", write_fn(new_struct, plddt, True))
        else:
            _atomic_write(out_dir / f"{record.id}_model_{model_rank}.{fmt}", write_fn(new_struct, plddt, True))

    best_idx = next(i for i, r in rank.items() if r == 0)
    num_samples = pred["coords"].shape[0]
    metrics = {}

    scalar_keys = ["confidence_score", "ptm", "iptm", "ligand_iptm", "protein_iptm",
                   "complex_plddt", "complex_iplddt", "complex_pde", "complex_ipde"]

    def _scalars(idx):
        m = {k: round(pred[k][idx].item(), 6) if k in pred else 0.0 for k in scalar_keys}
        # `plddt` is the key every other model reports the complex mean under: worker.py's `_row`
        # emits it for Protenix-v2 / OpenFold3 / OpenBind-0 / OpenDDE, and ESMFold2 and RF3 have
        # only it. Boltz-2 was the one model without it, so a reader asking for
        # metrics["plddt"] fell through to whatever fallback it carried -- for
        # perf/k10_p2/fold_cpu_ref.py that was confidence_score, which is 0.8*plDDT + 0.2*pTM and
        # so sat 0.008 above the CIF's plDDT column at 298 aa and 0.050 below it at 512 aa.
        # pred["plddt"] here is the per-residue vector, not a scalar, hence the mirror.
        m["plddt"] = m["complex_plddt"]
        return m

    def _pair_chains(idx):
        """Per-sample chain-pair ipTM / per-chain pTM. Same source as the winner-only block
        below; exposed per sample because for an antibody-antigen ranking dataset the
        antibody-vs-antigen chain-pair ipTM is more informative than the global ipTM, and a
        winner-only value cannot be used to rank the other samples (AbAg-XM audit 2026-07-27)."""
        if "pair_chains_iptm" not in pred:
            return {}
        pci = pred["pair_chains_iptm"]
        return {
            "pair_chains_iptm": {i: {j: round(pci[i][j][idx].item(), 6) for j in pci[i]}
                                 for i in pci},
            "chains_ptm": {i: round(pci[i][i][idx].item(), 6) for i in pci if i in pci[i]},
        }

    metrics.update(_scalars(best_idx))

    if "pair_chains_iptm" in pred:
        pci = pred["pair_chains_iptm"]
        metrics["pair_chains_iptm"] = {
            i: {j: round(pci[i][j][best_idx].item(), 6) for j in pci[i]}
            for i in pci
        }
        metrics["chains_ptm"] = {
            i: round(pci[i][i][best_idx].item(), 6) for i in pci if i in pci[i]
        }

    if num_samples > 1:
        idx_by_rank = sorted(rank, key=rank.get)
        metrics["all_runs"] = [{"rank": rank[i], **_scalars(i), **_pair_chains(i)}
                               for i in idx_by_rank]

    # Optional large outputs
    if write_pae and "pae" in pred:
        # Real tokens only: a bucketed batch pads the token axis, and a padded PAE no longer lines
        # up with the structure file it is meant to be read with.
        n_tok = pred["pae"].shape[-1]
        real = (batch["token_pad_mask"][0].bool().cpu().numpy() if "token_pad_mask" in batch
                else np.ones(n_tok, dtype=bool))

        def _arrays(idx):
            pae = pred["pae"][idx].cpu().numpy()[np.ix_(real, real)]
            return pae, (pred["plddt"][idx].cpu().numpy()[real] if "plddt" in pred else None)

        pae, plddt = _arrays(best_idx)
        from tt_bio import confidence_export
        dist = pred.get("pdistogram")             # [1, N, N, 1, bins]: one trunk, every sample
        confidence_export.write(out_dir, record.id, "boltz2", real=real, pae=pred["pae"][best_idx],
                                pde=pred["pde"][best_idx] if "pde" in pred else None,
                                distogram=None if dist is None else dist[0, :, :, 0],
                                cutoff=contact_cutoff)
        if plddt is not None:
            np.savez_compressed(out_dir / f"{record.id}_plddt.npz", plddt=plddt)
        if fmt == "cif" and len(struct.chains) > 1:
            from tt_bio import interface_scores
            name = {int(c["asym_id"]): str(c["name"]) for c in struct.chains}
            pci = pred.get("pair_chains_iptm") or {}

            def _score(idx):
                iptm = {name[int(i)]: {name[int(j)]: round(pci[i][j][idx].item(), 6)
                                       for j in pci[i] if int(j) != int(i)} for i in pci} or None
                r = rank[idx]
                cif = out_dir / (f"{record.id}.cif" if r == 0 else f"{record.id}_model_{r}.cif")
                return interface_scores.score_files(cif, *_arrays(idx), pair_iptm=iptm)

            # The top-ranked sample is the point value; every sample, in rank order, is the
            # distribution it is drawn from.
            samples = [_score(i) for i in sorted(rank, key=rank.get)]
            metrics["interface_scores"] = samples[0]
            metrics["interface_score_distribution"] = interface_scores.distribution(samples)
    if write_pde and "pde" in pred:
        pde = pred["pde"][best_idx].cpu().numpy()
        if "token_pad_mask" in batch:             # the same real-token crop as the PAE
            real = batch["token_pad_mask"][0].bool().cpu().numpy()
            pde = pde[np.ix_(real, real)]
        np.savez_compressed(out_dir / f"{record.id}_pde.npz", pde=pde)
    if write_embeddings and "s" in pred and "z" in pred:
        np.savez_compressed(out_dir / f"{record.id}_embeddings.npz",
                          s=pred["s"].cpu().numpy(), z=pred["z"].cpu().numpy())

    return metrics, best_struct


def _results_lock_path(path: Path) -> Path:
    return path.with_suffix(path.suffix + ".lock")


def _results_backup_path(path: Path) -> Path:
    return path.with_suffix(path.suffix + ".bak")


def _load_results_resilient(path: Path) -> list[dict]:
    """Load results.json safely; fall back to .bak if corrupted."""
    if not path.exists():
        return []

    try:
        data = json.loads(path.read_text())
        return data if isinstance(data, list) else []
    except Exception:
        # Keep a copy of the corrupted file for post-mortem debugging.
        ts = time.strftime("%Y%m%d-%H%M%S")
        corrupt_copy = path.with_suffix(path.suffix + f".corrupt-{ts}")
        try:
            shutil.copy2(path, corrupt_copy)
        except Exception:
            pass

        bak = _results_backup_path(path)
        if bak.exists():
            try:
                data = json.loads(bak.read_text())
                return data if isinstance(data, list) else []
            except Exception:
                pass
        return []


def _save_results_unlocked(results: list[dict], path: Path) -> None:
    """Write results.json with backup; caller must hold lock."""
    bak = _results_backup_path(path)
    if path.exists():
        try:
            shutil.copy2(path, bak)
        except Exception:
            pass
    _atomic_write(path, json.dumps(results, indent=2))


def _save_results(results: list[dict], path: Path) -> None:
    """Save results with inter-process lock, backup, and atomic replace."""
    lock_path = _results_lock_path(path)
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with open(lock_path, "a") as lock_f:
        fcntl.flock(lock_f.fileno(), fcntl.LOCK_EX)
        try:
            _save_results_unlocked(results, path)
        finally:
            fcntl.flock(lock_f.fileno(), fcntl.LOCK_UN)


def _detect_p300_devices() -> list[int]:
    """Return P300 TT device indices from kernel sysfs.

    This avoids importing ttnn in the parent process and avoids requiring tt-smi.
    The subsystem IDs are ``runtime.P300_SUBSYSTEMS``.
    """
    devices = []
    for entry in (Path("/sys/class/tenstorrent")).glob("tenstorrent!*"):
        try:
            device_id = int(entry.name.rsplit("!", 1)[1])
            subsystem_id = (entry / "device" / "subsystem_device").read_text().strip().lower()
        except Exception:
            continue
        if subsystem_id in P300_SUBSYSTEMS:
            devices.append(device_id)
    return sorted(devices)


def _find_ttnn_mesh_graph_descriptor(filename: str) -> str | None:
    """Locate a fabric mesh-graph descriptor shipped with the installed tt-metal.

    The pip wheel vendors these inside the ttnn package; a source build keeps them in the
    tt-metal checkout, with ttnn imported from ``<checkout>/ttnn/ttnn``. Searching only the
    wheel location returned None on every source build, and a lone P300 chip cannot open
    without a descriptor, so ``TT_VISIBLE_DEVICES=<one chip>`` failed outright with "Custom
    fabric mesh graph descriptor path must be specified for CUSTOM cluster type". That is
    the ordinary one-card-per-worker pinning, unusable on a source-built P300 host.
    """
    spec = importlib.util.find_spec("ttnn")
    if spec is None or not spec.submodule_search_locations:
        return None
    ttnn_root = Path(next(iter(spec.submodule_search_locations)))
    roots = [ttnn_root]                       # wheel: ttnn/tt_metal/fabric/...
    metal_home = os.environ.get("TT_METAL_HOME")
    if metal_home:
        roots.append(Path(metal_home))
    roots.extend(ttnn_root.parents[:2])       # source: <checkout>/ttnn/ttnn -> <checkout>
    for root in roots:
        descriptor = root / "tt_metal" / "fabric" / "mesh_graph_descriptors" / filename
        if descriptor.is_file():
            return str(descriptor)
    return None


def _visible_tt_devices() -> list[int]:
    """UMD indices a device open sees right now: ``TT_VISIBLE_DEVICES`` if set
    (index or PCI BDF tokens), else every card under /dev/tenstorrent."""
    visible = os.environ.get("TT_VISIBLE_DEVICES")
    if visible and visible.strip():
        from tt_bio.runtime import visible_device_indices
        return visible_device_indices(visible)
    return sorted(int(p.name) for p in Path("/dev/tenstorrent").glob("[0-9]*"))


def _pin_one_card(devices: str | None, model: str) -> None:
    """Make ``--devices N`` the only card this process can open, for a model that runs in-process
    on one card.

    get_device() opens and leases every visible chip, so choosing only which chip to compute on
    still held the whole host: ``design --model rfd4 --devices 1`` opened all four nodes of a
    4-card Blackhole box (issue #26). The id is validated against the cards present (and an
    ambient TT_VISIBLE_DEVICES) before anything opens; more than one id is refused, since one
    process runs on one card.
    """
    if not devices:
        return
    from tt_bio.runtime import detect_tenstorrent_devices

    if "," in devices.strip(", "):
        raise click.UsageError(f"--model {model} runs on one card per process; pass one id "
                               "(e.g. --devices 1) and start one process per card.")
    try:
        (card,) = detect_tenstorrent_devices(devices, 0, 1)
    except ValueError as e:
        raise click.UsageError(str(e))
    os.environ["TT_VISIBLE_DEVICES"] = str(card)


def _p300_mesh_descriptor(device: int | None = None) -> str | None:
    """The 1x1 mesh-graph descriptor a lone P300 chip needs to open, or None.

    A single P300 chip is a custom topology and ttnn refuses to open it without one
    ("Custom fabric mesh graph descriptor path must be specified for CUSTOM cluster
    type"). With more than one chip visible the descriptor must NOT be set: ttnn
    opens the board as a mesh, and a 1x1 graph then fails with "Physical chip id 0
    not found in control plane chip mapping" (issue #11). Pass ``device`` to ask
    about one chip rather than the visible set.
    """
    p300 = _detect_p300_devices()
    visible = [device] if device is not None else _visible_tt_devices()
    if len(visible) != 1 or visible[0] not in p300:
        return None
    return _find_ttnn_mesh_graph_descriptor("p150_mesh_graph_descriptor.textproto")


def ensure_p300_mesh_descriptor(env=None, device: int | None = None) -> str | None:
    """Set ``TT_MESH_GRAPH_DESC_PATH`` in ``env`` (default the process environment).

    Every path that opens a device itself needs this: the predict fanout sets it per
    worker, and the embed / saprot / design / gen commands and any direct
    ``ttnn.open_device`` caller open in-process with no shard to inherit it. An
    explicit ``TT_MESH_GRAPH_DESC_PATH`` always wins.
    """
    env = os.environ if env is None else env
    if env.get("TT_MESH_GRAPH_DESC_PATH"):
        return None
    mgd = _p300_mesh_descriptor(device)
    if mgd:
        env["TT_MESH_GRAPH_DESC_PATH"] = mgd
    return mgd


def _build_worker_device_assignments(devices: list[int]) -> dict[int, dict[str, object]]:
    """Build per-worker visibility/logical-device assignments.

    P300 chips are exposed one-at-a-time like other devices. Because a lone P300
    chip is a custom topology, those workers also get a 1x1 Blackhole MGD.
    """
    p300_devices = set(_detect_p300_devices())
    # Each worker is pinned to exactly one chip, so a P300 worker always needs the
    # 1x1 descriptor regardless of how many chips the parent can see.
    p300_mgd = (
        None
        if os.environ.get("TT_MESH_GRAPH_DESC_PATH") or not p300_devices
        else _find_ttnn_mesh_graph_descriptor("p150_mesh_graph_descriptor.textproto")
    )

    assignments: dict[int, dict[str, object]] = {}
    for device in devices:
        assignment: dict[str, object] = {"visible_devices": str(device), "logical_device_id": 0}
        if device in p300_devices and p300_mgd:
            assignment["mesh_graph_descriptor"] = p300_mgd
        assignments[device] = assignment
    return assignments


def _require_ttnn() -> None:
    """Clear error when Tenstorrent execution is requested without the ttnn wheel.

    ttnn is an optional dependency (the ``tenstorrent`` extra): it only publishes
    wheels for TT-supported platforms, so a CPU/GPU-only install omits it. Everything
    device-side funnels through here early enough to say so plainly instead of dying
    on a raw ModuleNotFoundError deep inside model load."""
    try:
        import ttnn  # noqa: F401
    except ImportError:
        raise click.UsageError(
            "Tenstorrent execution needs the ttnn wheel, which is not installed. "
            "Install it with: pip install 'tt-bio[tenstorrent]' (on a Tenstorrent "
            "host), or use --accelerator cpu/gpu."
        )


_MPI_WARNED = False


def _warn_conflicting_mpi_env() -> list[str]:
    """Say once per process if a host OpenMPI is set up to break the bundled one."""
    global _MPI_WARNED
    found = conflicting_mpi_env()
    if found and not _MPI_WARNED:
        _MPI_WARNED = True
        click.secho("warning: " + mpi_env_warning(found), fg="yellow", err=True)
    return found


def _local_workers(accelerator: str, num_devices: int, device_ids: str | None, max_workers: int) -> list:
    """Build a list of WorkerSlot objects covering this host's accelerators."""
    if accelerator != "tenstorrent":
        return build_local_workers(accelerator, [object()], [0])
    _require_ttnn()
    # Every local-worker path -- predict, design, controller, serve -- comes through here, so
    # this is the one place the check belongs.
    _warn_conflicting_mpi_env()
    devices = detect_tenstorrent_devices(device_ids, num_devices, max_workers=max_workers)
    if not devices:
        raise RuntimeError(
            "No Tenstorrent devices found. Use --accelerator cpu/gpu or check /dev/tenstorrent."
        )
    workers = build_local_workers("tenstorrent", [object()] * len(devices), devices)
    assigns = _build_worker_device_assignments([int(w.device_id) for w in workers])
    return [
        replace(
            w,
            visible_devices=str(assigns[int(w.device_id)]["visible_devices"]),
            logical_device_id=int(assigns[int(w.device_id)]["logical_device_id"]),
            mesh_graph_descriptor=assigns[int(w.device_id)].get("mesh_graph_descriptor"),
        )
        for w in workers
    ]


def _cap_worker_threads(n_workers: int, host_threads: int | None = None) -> None:
    """Cap each worker's host thread pools. Each worker's torch/OMP/BLAS pools
    otherwise default to ALL cores, so N co-resident workers spawn N*cores threads
    that thrash the CPU and collapse throughput on the host-side work
    (featurization, output, layout conversion) -- the multi-card slowdown. Size to
    host_threads/workers; spawned children inherit these.

    ``host_threads`` is this PROCESS's share of the host CPU, defaulting to every
    core. All-cores is right for one process driving the whole box, but wrong when an
    external launcher runs one single-card ``predict`` per chip: each process then
    sees n_workers == 1, sizes its pools to all cores, and N co-resident folds
    oversubscribe the host N-fold. Such a launcher passes ``--host_threads
    cores//concurrent_folds``. Explicit beats inherited: a passed value overrides a
    pre-set env var (the launcher knows how many siblings it started), while the
    default only fills in what the operator left unset."""
    from . import runtime

    os.environ.update(runtime.host_thread_cap_env(n_workers, host_threads))


def _spawn_worker_processes(controller_url: str, workers: list, debug: bool) -> list:
    """Spawn one process per worker slot, each connected to the controller."""
    ctx = mp.get_context("spawn")
    _cap_worker_threads(len(workers))
    # So orphaned workers self-terminate (see run_worker_loop): spawn children
    # inherit this; workers of a `tt-bio worker` pool never see it.
    from tt_bio.device_lease import orphan_guard_env
    os.environ.update(orphan_guard_env())
    procs = []
    for worker in workers:
        proc = ctx.Process(
            target=run_worker_loop,
            args=(controller_url, worker_payload(worker), debug),
        )
        proc.start()
        procs.append(proc)
    return procs


def _stop_worker_processes(procs: list) -> None:
    """Cleanly stop spawned worker processes, all at once.

    Every escalation step (SIGINT, SIGTERM, SIGKILL) goes to all live workers together and
    shares one deadline, so stopping N workers costs what stopping one does. Stopping them
    one after another made a 4-card run sit ~80 s after its last result was on disk.
    """
    def _escalate(send, grace: float) -> None:
        live = [p for p in procs if p.is_alive()]
        for proc in live:
            try:
                send(proc)
            except Exception:
                pass
        deadline = time.monotonic() + grace
        for proc in live:
            proc.join(timeout=max(0.0, deadline - time.monotonic()))

    _escalate(lambda p: os.kill(p.pid, signal.SIGINT), 12)
    _escalate(lambda p: p.terminate(), 8)
    _escalate(lambda p: p.kill(), 3)
    # A worker that exits through Python removes its own capture file; one we had to kill
    # cannot. By here the run is over and anything worth reading has already been read on
    # the all-dead or respawn path, so consume what is left rather than keep it in /tmp.
    for proc in procs:
        if proc.pid:
            read_worker_capture(proc.pid)


def _supervise_worker_processes(controller_url: str, workers: list, debug: bool,
                                *, poll: float = 3.0, max_restarts: int = 10,
                                restart_window: float = 600.0,
                                readmit_after: float = 600.0,
                                readmit_cap: float = 3600.0) -> None:
    """Spawn one process per worker slot and keep them alive.

    If a worker exits unexpectedly (crash, fatal device error), respawn it — a
    fresh process reopens its chip and rejoins the controller, so a transient
    failure self-heals instead of silently shrinking the fleet (the 31/32 drop).
    A per-slot budget (``max_restarts`` within ``restart_window``) parks a chip
    that is failing rather than crash-looping it, and parking is temporary: the
    slot is retried after ``readmit_after``, doubling up to ``readmit_cap``.

    Parking has to expire, because the budget cannot tell a dead chip from a busy
    one. A chip held by another process on the box fails to open in about a
    second, so ten respawns at a 3 s poll burn the whole budget inside a minute —
    and before this, that chip was gone until someone restarted the service.
    Measured on the Galaxy 2026-08-11: five slots dropped that way during a
    campaign, and the pool never got them back.

    Respawns happen one slot at a time, so they never re-trigger the
    concurrent-open contention of a bulk startup. Blocks until interrupted; SIGINT
    stops the whole fleet cleanly."""
    ctx = mp.get_context("spawn")
    _cap_worker_threads(len(workers))
    procs: dict = {}
    restarts: dict = {}
    parked: dict = {}       # slot -> monotonic time it may be retried
    park_backoff: dict = {}  # slot -> cool-off to use on its next parking
    all_down_logged = False

    def _spawn(i: int) -> None:
        proc = ctx.Process(
            target=run_worker_loop,
            args=(controller_url, worker_payload(workers[i]), debug),
        )
        proc.start()
        procs[i] = proc

    for i in range(len(workers)):
        _spawn(i)
    try:
        while True:
            time.sleep(poll)
            now = time.monotonic()
            for i, proc in list(procs.items()):
                label = getattr(workers[i], "label", f"worker {i}")
                if i in parked:
                    if now < parked[i]:
                        continue
                    del parked[i]
                    restarts.pop(i, None)
                    click.echo(f"[supervisor] {label} back off the bench — retrying "
                               f"the chip", err=True)
                    _spawn(i)
                    continue
                if proc.is_alive():
                    continue
                recent = [t for t in restarts.get(i, []) if now - t < restart_window]
                if len(recent) >= max_restarts:
                    cool = park_backoff.get(i, readmit_after)
                    parked[i] = now + cool
                    park_backoff[i] = min(cool * 2, readmit_cap)
                    click.echo(f"[supervisor] {label} exited {max_restarts}x in "
                               f"{int(restart_window)}s — benching it for "
                               f"{int(cool)}s (chip busy, or bad and needs a reset)",
                               err=True)
                    continue
                recent.append(now)
                restarts[i] = recent
                click.echo(f"[supervisor] {label} exited (code={proc.exitcode}); "
                           f"respawning [{len(recent)}/{max_restarts}]"
                           + _dead_worker_stderr([proc]), err=True)
                _spawn(i)
            # No slot holds a chip. Say so once, and keep retrying: the pool is the
            # only thing that would notice the chips coming back. Callers see the
            # truth through the controller — a worker registers only once its chip
            # is open, so `online_workers` is 0 here and the platform refuses jobs.
            if workers and len(parked) == len(workers):
                if not all_down_logged:
                    click.echo("[supervisor] no worker holds a chip — all slots "
                               "benched, still retrying", err=True)
                    all_down_logged = True
            elif all_down_logged:
                click.echo("[supervisor] a worker holds a chip again", err=True)
                all_down_logged = False
    except KeyboardInterrupt:
        click.echo("\nStopping workers...")
        _stop_worker_processes(list(procs.values()))


def _dead_worker_stderr(procs) -> str:
    """The captured fd-2 tail of each dead worker, ready to append to an error line.

    A worker silences itself to a capture file rather than /dev/null (see
    worker._silence_subprocess_output) precisely so the fatals that never reach Python --
    a tt-metal L1 circular-buffer overflow, an MPI_Init abort -- survive the process that
    hit them. Without this the launcher can only report an exit code.
    """
    tails = []
    for proc in procs:
        cap = read_worker_capture(proc.pid) if proc.pid else ""
        if cap:
            tails.append(f"--- {proc.name} (exit {proc.exitcode}) stderr tail ---\n{cap}"
                         + _l1_census_line(cap))
    return ("\n" + "\n\n".join(tails)) if tails else ""


def _l1_census_line(text: str) -> str:
    """The allocation census an L1 throw in `text` implies, or "".

    tt-metal reports an L1 failure as two raw addresses or as a byte count against a
    ceiling, which reads like "out of memory at N" and is not what it says.
    `describe_l1_clash` subtracts instead and names the grid, the shortfall and whether
    a resident tensor is implicated at all. Rendering it here is the difference between
    a user filing "it crashed" and filing the number we need.
    """
    if "L1 census:" in text:
        return ""      # the process that hit it already rendered one, in the same format
    try:
        from tt_bio.tenstorrent import describe_l1_clash, format_l1_census
    except Exception:                                          # no ttnn on this host
        return ""
    census = describe_l1_clash(text)
    if not census:
        return ""
    return "\n    " + format_l1_census(census)


def _stream_run(client: ControllerClient, run_id: str, total: int, n_workers: int,
                debug: bool, log: bool, results_path: Path | None = None,
                struct_dir: Path | None = None, model: str | None = None,
                local_procs: list | None = None) -> int:
    """Stream events from a controller and render progress; return failed count.

    On every done event we fetch that job's output files from the controller
    and write them under struct_dir, and merge its result row into
    results.json. Interrupted runs preserve every protein finished so far.

    ``local_procs`` are worker processes this CLI spawned itself. We own them, so
    their exit code is an exact signal rather than a heuristic, and with all of
    them gone no job will ever be leased -- polling on would be polling forever.
    Callers that stream a run served by workers they did not spawn pass nothing.
    """
    from queue import Queue as ThreadQueue

    pq = ThreadQueue()
    if debug:
        display = DebugDisplay(pq) if log else NullDisplay(pq)
    elif _sys.stderr.isatty():
        display = ProgressDisplay(pq, total=total, n_workers=n_workers, model=model)
    else:
        # Redirected output (fleet log, pipe): Rich Live renders nothing until
        # the final frame, leaving a 0-byte log for the whole run — and a
        # watchdog that reads log size can't tell a healthy fold from a hang.
        # Plain timestamped lines keep a redirected run observable.
        display = DebugDisplay(pq)
    display.start()
    # Optional headless event capture (TT_BIO_PROGRESS_CAPTURE=<path>): tee every
    # streamed event to a JSONL file so the UX-regression guard can assert the
    # live progress view advances through every real phase without scraping a
    # TTY. Same event stream the display reads above, so it observes real
    # behaviour. Off by default; no effect on a normal predict run.
    cap_path = os.environ.get("TT_BIO_PROGRESS_CAPTURE")
    cap_fh = open(cap_path, "a") if cap_path else None
    after = 0
    failed = 0
    all_dead_seen = False
    failures: dict[str, str] = {}  # this run's failures: job id -> error message
    aff_failures: dict[str, str] = {}  # structure ok, affinity leg raised
    rows_by_id: dict[str, dict] = {}
    if results_path is not None:
        rows_by_id = {r["id"]: r for r in _load_results_resilient(results_path)
                      if isinstance(r, dict) and "id" in r}
    if struct_dir is not None:
        struct_dir.mkdir(parents=True, exist_ok=True)
    try:
        while True:
            # A transient controller error (e.g. a store hiccup on a full shared disk) must
            # not kill an hours-long run. The retry lives in ControllerClient._request now,
            # so every reader has it rather than only this loop.
            snapshot = client.events(run_id, after)
            for ev in snapshot.get("events", []):
                after = max(after, int(ev.get("seq", after)))
                if ev.get("event") in ("run", "run_done"):
                    continue
                if ev.get("event") == "done":
                    row = ev.get("row")
                    if isinstance(row, dict) and "id" in row:
                        if row.get("status") == "failed":
                            failures[row["id"]] = row.get("error") or "failed"
                        elif row.get("affinity_error"):
                            aff_failures[row["id"]] = row["affinity_error"]
                        if results_path is not None:
                            rows_by_id[row["id"]] = row
                            try:
                                _save_results(list(rows_by_id.values()), results_path)
                            except Exception:
                                pass
                        if struct_dir is not None and row.get("status") == "ok":
                            _write_job_outputs(client, run_id, row["id"], struct_dir)
                pq.put(ev)
                if cap_fh is not None:
                    try:
                        cap_fh.write(json.dumps(ev, default=str) + "\n")
                        cap_fh.flush()
                    except Exception:
                        pass
            if snapshot.get("status") in ("ok", "failed", "canceled"):
                failed = int(snapshot.get("failed") or 0)
                break
            # A worker that cannot open its chip exits (worker.run_worker_loop), and
            # nothing respawns it on this path. With every local worker gone the run
            # stays "running" forever and this loop polls forever -- the predict CLI
            # hung for 7 h that way, and every OpenFold3 leg of both release gates
            # hung with it. Require two consecutive all-dead observations so a worker
            # exiting in the same tick the run finishes reads as a finish, not a
            # failure; that costs 0.5 s and needs no timeout.
            if local_procs and not any(proc.is_alive() for proc in local_procs):
                if all_dead_seen:
                    from tt_bio.device_lease import CONTENDED_EXIT_CODE, DeviceInUseError
                    codes = ", ".join(f"{proc.name} exit {proc.exitcode}"
                                      for proc in local_procs)
                    if any(proc.exitcode == CONTENDED_EXIT_CODE for proc in local_procs):
                        # A co-tenant held the card, so no worker opened a chip and there
                        # is nothing to score. Raise the lease error the workers actually
                        # died of, so the CLI group maps it to CONTENDED_EXIT_CODE: on a
                        # bare exit 1 a release-gate arm renders this as its own accuracy
                        # verdict, and six v0.7.0 legs reached the table through this line.
                        raise DeviceInUseError(
                            f"every local worker exited at device open ({codes}); the card "
                            "is leased by another process, so nothing ran")
                    # A worker fatal may never have reached Python at all: a C-level
                    # abort (an MPI_Init failure, a tt-metal L1 throw out of a device
                    # thread) writes to fd 2 and exits without unwinding, so
                    # _report_fatal never runs. fd 2 is captured to a file for exactly
                    # this moment (worker._silence_subprocess_output), so print the tail
                    # rather than telling the reader to re-run with --debug. With
                    # nothing captured, do not promise a traceback either: a worker
                    # stopped by a signal mid-job prints one line and no trace
                    # (worker.run_worker_loop KeyboardInterrupt arm), and rf3 at 1536
                    # tokens sent a reader looking for a traceback that was never
                    # written. Name what each code means instead.
                    raise RuntimeError(
                        f"every local worker exited before the run finished ({codes}); "
                        "no job can be served. Exit 130/143 means a signal stopped the "
                        "worker mid-job, 70 that it was orphaned, -9/137 that the host "
                        "OOM killer took it; any other code prints its own fatal above."
                        + _dead_worker_stderr(local_procs))
                all_dead_seen = True
            else:
                all_dead_seen = False
            time.sleep(0.5)
    finally:
        display.stop()
        if cap_fh is not None:
            try:
                cap_fh.close()
            except Exception:
                pass
    if failures:
        # The rolling log only had room for a one-line clip per job; print the
        # full message here so any actionable guidance (e.g. how to supply
        # MSAs) is readable once the live display is gone.
        click.echo(f"\n{len(failures)} failed:")
        # An allocator refusal reaches here as a TT_FATAL whose first line names a tt-metal
        # source file and the literal word "false", followed by twenty backtrace frames. The
        # headline a user needs is the one sentence in the middle, so render that and keep the
        # raw text for --debug. Every other failure prints exactly as before.
        from tt_bio import size_limits
        for job_id, error in failures.items():
            summary = size_limits.describe_device_oom(str(error))
            if summary and not debug:
                click.echo(f"  ✗ {job_id}: {summary}")
                click.echo("      Re-run with --debug for the allocator trace.")
                continue
            lines = str(error).splitlines() or [""]
            click.echo(f"  ✗ {job_id}: {summary or lines[0]}")
            for extra in (lines if summary else lines[1:]):
                click.echo(f"      {extra}")
    if aff_failures:
        click.echo(f"\n{len(aff_failures)} structure(s) folded but their affinity failed "
                   f"(no affinity keys in results.json, reason under affinity_error):")
        for job_id, error in aff_failures.items():
            click.echo(f"  ✗ {job_id}: {(str(error).splitlines() or [''])[0]}")
    return failed


def _dispatch_run(run_payload: dict, workers, *, total: int, results_path: Path,
                  struct_dir: Path, model: str, debug: bool, log: bool) -> int:
    """Run jobs through the scheduler, stream progress, persist results, and
    print the final summary. The single lifecycle shared by every predict
    path — keep it the one place so the paths can't drift apart. Returns the
    number of failed jobs.
    """
    with _scheduler_session(workers, debug) as (client, procs):
        _offer_shared_outputs(run_payload, struct_dir)
        try:
            run_id = client.create_run(run_payload)["run_id"]
            failed = _stream_run(client, run_id, total=total, n_workers=len(workers),
                                 debug=debug, log=log, results_path=results_path,
                                 struct_dir=struct_dir, model=model, local_procs=procs)
            _persist_run_results(client, run_id, results_path)
        finally:
            # a run that dies must not leave its scaffolding in the user's results
            _clear_shared_outputs(run_payload, struct_dir)
        # A shard that loses its device-open race (lease held by another run,
        # wedged card) exits its worker loop and the scheduler simply serves
        # every job to the survivors: the run completes "ok" on fewer cards
        # than --devices asked for, with the DeviceInUseError visible only
        # under --debug. Say so loudly — silent degradation turned a 4-card
        # scaling measurement into a 2-worker run twice in the audit.
        try:
            online = int(client.cluster().get("online_workers") or 0)
        except Exception:
            online = -1
        if 0 <= online < len(workers):
            click.echo(f"  ! run completed with only {online} of {len(workers)} requested "
                       f"workers online — results came from FEWER CARDS than --devices "
                       f"requested (shard device-open failures are visible with --debug).",
                       err=True)
    click.echo(f"\nDone: {total - failed} ok, {failed} failed — {results_path}")
    return failed


def _clear_shared_outputs(run_payload: dict, struct_dir: Path) -> None:
    """Remove the co-location nonce; it is scaffolding, not a result."""
    token = ((run_payload.get("config") or {}).get("shared_outputs") or {}).get("token")
    if token:
        try:
            (struct_dir / str(token)).unlink(missing_ok=True)
        except Exception:
            pass


def _offer_shared_outputs(run_payload: dict, struct_dir: Path) -> None:
    """Tell workers they may write results straight into ``struct_dir``, if they can.

    Results otherwise travel back as base64 inside JSON through the single controller
    process: a 1024-sequence esmc embed ships ~635 MB of per-residue arrays that way and
    the controller spends ~15 of the run's 27 seconds on it while every card idles.
    Workers that share this filesystem can skip the round trip entirely.

    Co-location has to be proven, not assumed -- a worker on another machine could
    create this same path locally and write into the void. So drop a nonce here and name
    it; only a worker that can see that exact file is really looking at this directory.
    A worker that cannot stays on base64, which is what every older worker does anyway.
    """
    try:
        struct_dir.mkdir(parents=True, exist_ok=True)
        token = f".tt-bio-share-{uuid.uuid4().hex[:16]}"
        (struct_dir / token).write_text("")
    except Exception:
        return  # can't prove anything -> leave every worker on base64
    cfg = run_payload.setdefault("config", {})
    cfg["shared_outputs"] = {"dir": str(struct_dir.resolve()), "token": token}


def _dispatch_to_controller(controller_url: str, run_payload: dict, *, total: int,
                            results_path: Path, struct_dir: Path, model: str,
                            debug: bool, log: bool, run_id: str | None = None) -> int:
    """Submit a run to an already-running controller and stream it to completion.

    Unlike ``_dispatch_run`` this starts no scheduler and spawns no local
    workers — the compute is provided by whatever workers are already connected
    to ``controller_url``, this host's persistent pool. Lets many independent
    ``predict`` invocations share one host's chips, which is how a platform
    fans concurrent users across a machine (docs/multi-host.md).
    """
    client = ControllerClient(controller_url)
    try:
        n_workers = int(client.cluster().get("online_workers") or 0)
    except Exception:
        n_workers = 0
    # A caller-supplied run id (the platform passes its job id) lets the run be
    # cancelled later via the controller; otherwise the controller assigns one.
    if run_id:
        run_payload["run_id"] = run_id
    _offer_shared_outputs(run_payload, struct_dir)
    try:
        run_id = client.create_run(run_payload)["run_id"]
        failed = _stream_run(client, run_id, total=total, n_workers=n_workers,
                             debug=debug, log=log, results_path=results_path,
                             struct_dir=struct_dir, model=model)
        _persist_run_results(client, run_id, results_path)
    finally:
        # a run that dies must not leave its scaffolding in the user's results
        _clear_shared_outputs(run_payload, struct_dir)
    click.echo(f"\nDone: {total - failed} ok, {failed} failed — {results_path}")
    return failed


def _refuse_unfoldable_jobs(jobs, model: str, results_path: Path, output_format=None):
    """Split ``jobs`` into the ones ``model`` can fold and the ones it refuses.

    A refused input is reported and recorded as a failed row in results.json, and the rest of
    the batch folds: one file with a key this model cannot honour used to abort a directory
    of fifty before the first fold. Returns ``(foldable, {job id: refusal})``.
    """
    from tt_bio.capabilities import check_capabilities

    keep, refused = [], {}
    for job in jobs:
        jp = Path(job.path)
        try:
            # af2ig takes a structure plus a binder sequence, so it reads its own input shape
            # (capabilities.CHAINS_ELSEWHERE) and the chain columns of its row are a record
            # rather than the enforcement. Its reader runs here for the same reason this
            # function exists: a malformed submission should be a sentence, not a stack trace
            # two minutes into a weights download.
            chains = None if model == "af2ig" else _read_bio_chains(jp, what=model)
            if model == "af2ig":
                from tt_bio.af2ig_input import read_af2ig_input

                read_af2ig_input(jp)
            check_capabilities(jp, chains, model, output_format=output_format)
            keep.append(job)
        except (RuntimeError, ValueError, click.ClickException) as e:
            refused[job.id] = e.message if isinstance(e, click.ClickException) else str(e)
    if refused and keep:
        click.secho(f"Skipping {len(refused)} of {len(jobs)} input(s) --model {model} "
                    f"refuses; folding the other {len(keep)}:", fg="red", err=True)
        for job_id, why in refused.items():
            click.secho(f"  ✗ {job_id}: {why}", fg="red", err=True)
    if refused:
        rows = {r["id"]: r for r in _load_results_resilient(results_path)
                if isinstance(r, dict) and "id" in r}
        rows.update({j: {"id": j, "status": "failed", "error": why}
                     for j, why in refused.items()})
        _save_results(list(rows.values()), results_path)
    return keep, refused


def _write_error_reports(results_path: Path) -> None:
    """``<results>/ERR/<job>.txt`` for every job results.json records as failed, as Mol-1 and
    Protenix write it: the reason a system could not be predicted, next to the outputs. A job
    that has since folded loses its report, and an empty ERR/ is removed."""
    err = results_path.parent / "ERR"
    for r in _load_results_resilient(results_path):
        if not (isinstance(r, dict) and "id" in r):
            continue
        report = err / f"{r['id']}.txt"
        if r.get("status") == "failed":
            err.mkdir(parents=True, exist_ok=True)
            report.write_text(f"{r.get('error') or 'failed'}\n")
        else:
            report.unlink(missing_ok=True)
    if err.is_dir() and not any(err.iterdir()):
        err.rmdir()


def _exit_for_failed_jobs(failed: int, total: int, results_path: Path | None = None) -> None:
    """Exit the CLI nonzero when a run lost targets: 1 when every job failed,
    2 when some succeeded and some failed. Callers (release gate, CI, fleet
    scripts) gate on the process exit status, so a run that lost targets must
    not report success. With ``results_path`` the failures also get an ERR/ report."""
    if results_path is not None:
        _write_error_reports(results_path)
    if failed <= 0:
        return
    raise SystemExit(1 if failed >= total else 2)


def _write_job_outputs(client: ControllerClient, run_id: str, job_id: str,
                       struct_dir: Path) -> None:
    """Fetch a completed job's output files and write them under struct_dir."""
    try:
        outputs = client.job_outputs(run_id, job_id) or {}
    except Exception:
        return
    for name, content_b64 in outputs.items():
        if not content_b64:
            continue
        rel = Path(name)
        if rel.is_absolute() or ".." in rel.parts:
            continue
        target = struct_dir / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        if content_b64.startswith(SHARED_OUTPUT_PREFIX):
            # A co-located worker wrote the file straight into struct_dir, so there is
            # nothing to decode — the value is a path, never bytes, and never one this
            # client follows. Confirm the file really landed where we expect instead of
            # taking the worker's word for it: the bytes are gone from the worker's
            # scratch dir by now, so a missing file here is a lost output, and it should
            # look like one rather than like a silent success.
            if not target.is_file():
                click.echo(f"  ! {job_id}: worker reported {rel.as_posix()} as written "
                           f"in place, but it is not there", err=True)
            continue
        try:
            target.write_bytes(base64.b64decode(content_b64))
        except Exception:
            pass
    from tt_bio.protenix_output import land
    land(struct_dir)    # Mol-1's upstream layout ships inside the job outputs; its place is beside struct_dir


@contextmanager
def _scheduler_session(workers: list, debug: bool):
    """Start an in-process scheduler on loopback, spawn local worker subprocesses
    against it, and yield (client, worker_procs) for the duration of the run.

    The scheduler keeps its SQLite state in a private temp directory and
    discards it on exit, so a run never leaves bookkeeping artifacts in the
    user's results directory.
    """
    tmpdir = Path(tempfile.mkdtemp(prefix="tt-bio-scheduler-"))
    server = ControllerServer(0, tmpdir / "controller.sqlite3")
    server.serve_in_background()
    url = f"http://127.0.0.1:{server.port}"
    procs = _spawn_worker_processes(url, workers, debug)
    try:
        yield ControllerClient(url), procs
    finally:
        _stop_worker_processes(procs)
        server.shutdown()
        shutil.rmtree(tmpdir, ignore_errors=True)


def _local_cards(device_ids: str | None, n_jobs: int) -> list[int]:
    """The cards a local run spreads ``n_jobs`` independent jobs over: ``--devices`` if given,
    else every card on this host, never more cards than jobs. The same rule `predict` uses."""
    from tt_bio.runtime import detect_tenstorrent_devices
    try:
        return detect_tenstorrent_devices(device_ids, 0, max_workers=max(int(n_jobs), 1))
    except ValueError as e:
        raise click.UsageError(str(e))


@contextmanager
def _local_controller(cards: list[int], debug: bool = False, *, ready_s: float = 900.0):
    """A loopback controller with one pinned worker per card; yields its URL.

    This is how a single-card model runs on several cards: the command takes its own
    ``--controller`` path against a private pool, exactly as it would against a fleet, so
    multi-card is one code path (the predict scheduler and the fleet workers), not a second
    fanout per model. Returns once at least one worker is online; the rest join as they open.
    """
    with _scheduler_session(_local_workers("tenstorrent", 0, ",".join(map(str, cards)),
                                           max_workers=len(cards)), debug) as (client, procs):
        deadline = time.time() + ready_s
        while int(client.cluster().get("online_workers") or 0) < 1:
            if not any(p.is_alive() for p in procs):
                raise click.ClickException(
                    f"no worker could open any of cards {cards}; rerun with --debug to see why.")
            if time.time() > deadline:
                raise click.ClickException(f"no worker came online on cards {cards} "
                                           f"within {ready_s:.0f} s.")
            time.sleep(1.0)
        click.echo(f"Fanning out across {len(cards)} card(s): {cards}")
        yield client.base_url


def _persist_run_results(client: ControllerClient, run_id: str, results_path: Path) -> None:
    """Merge per-run result rows from the controller into the local results.json."""
    try:
        new_rows = client.results(run_id)
    except Exception:
        return
    existing = _load_results_resilient(results_path)
    merged = {r["id"]: r for r in existing if isinstance(r, dict) and "id" in r}
    for row in new_rows:
        if isinstance(row, dict) and "id" in row:
            merged[row["id"]] = row
    _save_results(list(merged.values()), results_path)



class _Cli(click.Group):
    """The CLI group, with two jobs beyond click's.

    Device contention gets its own exit code. A co-tenant holding the card is not a result.
    Every command here can die of :class:`DeviceInUseError` after waiting out
    ``TT_BIO_LEASE_TIMEOUT``, and on a bare exit 1 a caller cannot tell that from the model
    being wrong -- the v0.7.0 release gate scored eleven such legs as accuracy failures
    across two passes. One reserved code, checked in one place.

    An unreachable or empty controller prints as an error, not a traceback. `embed
    --controller` already did this by raising ClickException itself; the three design paths
    raised a bare RuntimeError and showed the user a stack. Both now raise
    :class:`ControllerUnreachable` and land here.
    """

    # Commands loaded only when named, by dotted path. `train` pulls in the training
    # stack -- the tape, the optimizer, the loss set -- and none of that may be imported to
    # print `tt-bio --help` or to run `tt-bio predict`. Training is opt-in and inert when
    # off, and an eager import here would make the inference path pay for it. The path is
    # data rather than an import statement, which is also what keeps the opt-in invariant
    # test's census of training importers accurate.
    LAZY = {"train": "tt_bio.train.cli:train"}

    def list_commands(self, ctx):
        return sorted({*super().list_commands(ctx), *self.LAZY})

    def get_command(self, ctx, name):
        target = self.LAZY.get(name)
        if target is None:
            return super().get_command(ctx, name)
        import importlib
        mod, attr = target.split(":")
        return getattr(importlib.import_module(mod), attr)

    def invoke(self, ctx):
        from tt_bio.device_lease import CONTENDED_EXIT_CODE, DeviceInUseError
        from tt_bio.host_controller import ControllerUnreachable

        try:
            return super().invoke(ctx)
        except DeviceInUseError as exc:
            click.echo(f"device contention, nothing ran: {exc}", err=True)
            ctx.exit(CONTENDED_EXIT_CODE)
        except ControllerUnreachable as exc:
            raise click.ClickException(str(exc)) from exc


def _quiet_download_bars() -> None:
    """Silence huggingface_hub's tqdm bar when stderr is not a terminal.

    It is the one progress bar tt-bio does not own, and it writes carriage
    returns straight into a redirected log ("Fetching 6 files: 0%|..."), which is
    exactly what the rest of the CLI switches to plain timestamped lines to
    avoid. Set in the environment rather than through the library so the worker
    subprocesses that do the actual downloading inherit it. A terminal keeps its
    bar, and an explicit setting from the caller wins.
    """
    if not _sys.stderr.isatty():
        os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")


@click.group(cls=_Cli)
@click.version_option(__version__, "--version", "-V", prog_name="tt-bio")
def cli():
    """Run biomolecular prediction, design, and embedding on Tenstorrent."""
    # One place covers predict, design, embed and gen: if a gate driver or a parent
    # CLI spawned us, die with it instead of polling or holding a card after it is gone.
    from tt_bio.device_lease import arm_orphan_guard

    _quiet_download_bars()
    arm_orphan_guard()


def _run_boltzgen_cli(prog: str, args) -> None:
    """Forward args to the vendored BoltzGen pipeline CLI. The single shared
    path for `tt-bio design --model boltzgen` and the deprecated `tt-bio gen`
    alias. sys.argv is rewritten BEFORE the boltzgen module imports so its
    import-time --device_ids -> TT_VISIBLE_DEVICES scan sees the final argv."""
    import sys

    _require_ttnn()  # BoltzGen is Tenstorrent-only; fail clearly without the wheel
    sys.argv = [prog, *args]
    from tt_bio.boltzgen.cli.boltzgen import main as _bg_main

    ensure_p300_mesh_descriptor()

    try:
        _bg_main()
    except ValueError as exc:
        # BoltzGen's CLI raises ValueError for bad input: an unknown --config
        # key, an invalid step or protocol name, a budget below 1. Those reached
        # the user as a traceback. --debug still shows it.
        if "--debug" in sys.argv:
            raise
        raise click.ClickException(str(exc)) from exc


@cli.command(
    "gen",
    hidden=True,
    add_help_option=False,
    context_settings=dict(ignore_unknown_options=True, allow_extra_args=True),
    help=(
        "Deprecated alias for `tt-bio design --model boltzgen`. All remaining "
        "arguments are forwarded to BoltzGen's CLI."
    ),
)
@click.argument("args", nargs=-1, type=click.UNPROCESSED)
def gen(args):
    click.secho(
        "Deprecation warning: `tt-bio gen` is deprecated and will be removed in a "
        "future release. Use `tt-bio design --model boltzgen` instead (same "
        "pipeline; `gen run X --output out` becomes `design X --model boltzgen "
        "--out_dir out`).", fg="yellow", err=True)
    _run_boltzgen_cli("tt-bio gen", args)


@cli.command("score")
@click.argument("structure", type=click.Path(exists=True, dir_okay=False))
@click.argument("pae", type=click.Path(exists=True, dir_okay=False))
@click.option("--plddt", type=click.Path(exists=True, dir_okay=False), default=None,
              help="pLDDT .npz (key plddt, 0-1). Without it pDockQ and pDockQ2 sit at their floor, "
                   "as in the reference script.")
@click.option("--confidence", type=click.Path(exists=True, dir_okay=False), default=None,
              help="Confidence JSON with pair_chains_iptm, for the model's own chain-pair ipTM.")
@click.option("--pae_cutoff", default=None, type=float, help="Default: 15, the Nipah competition's.")
@click.option("--dist_cutoff", default=None, type=float, help="Default: 15, the Nipah competition's.")
def score(structure, pae, plddt, confidence, pae_cutoff, dist_cutoff):
    """Interface scores of an existing fold: ipSAE, ipTM, pDockQ2, interface pAE.

    Reads an mmCIF and its PAE .npz from tt-bio or from upstream Boltz, needs no device, and
    prints JSON. The definitions are those of Adaptyv's Nipah competition pipeline; see
    docs/interface-scores.md."""
    from tt_bio import interface_scores as isc
    out = isc.score_files(structure, pae, plddt, confidence,
                          isc.PAE_CUTOFF if pae_cutoff is None else pae_cutoff,
                          isc.DIST_CUTOFF if dist_cutoff is None else dist_cutoff)
    click.echo(json.dumps(out, indent=2))


@cli.command("evaluate")
@click.argument("inputs", type=click.Path(exists=True, file_okay=False))
@click.option("--model", type=click.Choice(["rfd4"]), default="rfd4", show_default=True,
              help="Whose evaluation to run. rfd4: RFD4-Proteina's `rfd4-evaluate`.")
@click.option("--metrics_tags", required=True,
              help="Comma-separated tags that switch metrics on, as upstream's `metrics_tags`, "
                   "e.g. design or design,ppi_refolding. Score two arms with the same tags.")
@click.option("--out_dir", required=True, type=click.Path(file_okay=False),
              help="Writes evaluation_metrics/per_example_metrics.csv here.")
@click.option("--task_csv", default=None, type=click.Path(exists=True, dir_okay=False),
              help="CSV mapping designed_structure_path to task. Without it every task is 'all'.")
@click.option("--job_id", default=None, type=int, help="Shard index, with --gen_njobs.")
@click.option("--gen_njobs", default=1, show_default=True, type=int, help="Number of shards.")
def evaluate_cmd(inputs, model, metrics_tags, out_dir, task_csv, job_id, gen_njobs):
    """Score existing designs the way upstream does, with no device.

    INPUTS is a directory of generated structures, searched recursively. The output is upstream's
    per-design CSV, same column names and rounding, so it can be diffed against a run of
    upstream's own tool. A tag that switches on a metric tt-bio does not compute yet is refused
    rather than silently left out; see docs/rfd4-evaluate.md for what is covered."""
    from tt_bio.rfd4.evaluate import evaluate
    try:
        path = evaluate(inputs, metrics_tags, out_dir, task_csv=task_csv, job_id=job_id,
                        gen_njobs=gen_njobs)
    except (ValueError, NotImplementedError) as e:
        raise click.ClickException(str(e))
    click.echo(f"Done — {path}")


@cli.command("install-deps")
def install_deps():
    """Install system dependencies that match the installed ttnn wheel."""
    _require_ttnn()
    from tt_bio.install_system_deps import main as install_system_deps

    install_system_deps()


@cli.command("preflight")
@click.argument("models", nargs=-1)
@click.option("--download", is_flag=True, help="Fetch whatever the named models are missing.")
@click.option("--cache", default=None, type=click.Path(),
              help="Weight cache directory (default: $TT_BIO_CACHE, $BOLTZ_CACHE, or ~/.boltz).")
def preflight_cmd(models, download, cache):
    """Can this machine run these models right now? Answer before submitting a job.

    \b
        tt-bio preflight                     every model: ready, or what it needs
        tt-bio preflight protenix-v1         one model
        tt-bio preflight protenix-v1 --download

    Exits non-zero when anything asked for is not ready, so it works in a script. With no
    MODELS, a model whose licence keeps its checkpoint off the internet is listed but does not
    fail the check. For
    a model that is missing weights it also measures whether the hosts those weights
    come from can be reached from HERE, which is the part that a job submitted anyway
    would have discovered ten minutes later.
    """
    root = Path(cache).expanduser() if cache else None
    names = list(models) or list(weights.models_known())
    unknown = [m for m in names if m not in weights.MODEL_ARTIFACTS]
    if unknown:
        raise click.ClickException(
            f"unknown model(s): {', '.join(unknown)}; known: "
            f"{', '.join(weights.models_known())}")

    cache_dir = weights.cache_root(root)
    free = shutil.disk_usage(cache_dir if cache_dir.exists() else Path.home()).free
    click.echo(f"cache {cache_dir}  ({free / (1 << 30):.0f} GiB free)")
    click.echo(f"chips {chip_summary()}")
    _warn_conflicting_mpi_env()
    click.echo()

    width = max(len(m) for m in names)
    missing_models, manual_models, sources = [], [], []
    for model in sorted(names):
        ready, stats = weights.model_ready(model, root)
        need = [s for s in stats if s.state != "present"]
        if ready:
            have = sum(s.on_disk for s in stats)
            click.echo(f"  {click.style('READY  ', fg='green')} {model:{width}s}  "
                       f"{have / (1 << 30):.1f} GiB cached")
            continue
        auto = [s for s in need if s.artifact.source != "manual"]
        want = sum(s.artifact.approx_bytes for s in need)
        if auto:
            missing_models.append(model)
            click.echo(f"  {click.style('MISSING', fg='yellow')} {model:{width}s}  "
                       f"{want / (1 << 30):.1f} GiB to fetch: "
                       f"{', '.join(s.artifact.key for s in need)}")
            # probe_urls, not sources: a Hugging Face row is fetched by the hub client
            # rather than by a URL of ours, and "can this machine reach huggingface.co"
            # is exactly as much the question.
            for s in auto:
                sources.extend(s.artifact.probe_urls)
        else:
            manual_models.append(model)
            click.echo(f"  {click.style('MANUAL ', fg='yellow')} {model:{width}s}  "
                       f"not downloadable ({need[0].artifact.licence}); put "
                       f"{need[0].artifact.filename} at {need[0].path} or set "
                       f"${need[0].artifact.env}")

    if set(names) & set(PROTENIX_FAMILY) and not shutil.which("kalign"):
        click.echo(f"  {click.style('note   ', fg='yellow')} --use_template with .a3m/.hhr hits needs kalign on "
                   "PATH, and there is none (it is optional otherwise)")

    if sources:
        click.echo()
        click.echo("can this machine reach the hosts those weights come from?")
        for url in dict.fromkeys(sources):
            r = weights.probe(url)
            if r["ok"]:
                got = f"{r['bytes'] >> 10} KiB" if r["bytes"] >= 1024 else f"{r['bytes']} B"
                click.echo(f"  {click.style('ok         ', fg='green')} {r['host']}  "
                           f"{got} in {r['seconds']}s ({r['mb_per_s']} MB/s)")
            else:
                click.echo(f"  {click.style('UNREACHABLE', fg='red')} {r['host']}  "
                           f"{r['error']} (after {r['seconds']}s)")

    if download and missing_models:
        click.echo()
        for model in missing_models:
            click.echo(f"fetching {model} ...")
            weights.fetch_models(model, root=root)
        missing_models = [m for m in missing_models if not weights.model_ready(m, root)[0]]

    click.echo()
    # A bare `tt-bio preflight` asks "is this machine ready", and a checkpoint whose licence
    # forbids redistribution is something only its owner can add, so it is shown but does not
    # fail the check. Naming the model asks about it, and then it does.
    optional = [] if models else manual_models
    if not missing_models and manual_models == optional:
        click.echo(f"{len(names) - len(optional)} model(s) ready."
                   + (f" Optional, bring your own checkpoint: {', '.join(optional)}." if optional else ""))
        return
    if missing_models:
        click.echo(f"{len(missing_models)} model(s) need weights. Fetch them with:")
        click.echo(f"  tt-bio preflight {' '.join(missing_models)} --download")
    if manual_models:
        click.echo(f"{len(manual_models)} model(s) need a checkpoint placed by hand "
                   f"(see above): {', '.join(manual_models)}")
    raise SystemExit(1)


@cli.command("weights")
@click.argument("models", nargs=-1)
@click.option("--download", is_flag=True,
              help="Fetch what is missing or corrupt (every model, or just MODELS).")
@click.option("--prune", is_flag=True,
              help="Reclaim disk: superseded Hugging Face revisions, staging leftovers, "
                   "and the artifacts of any MODELS listed.")
@click.option("--force", is_flag=True, help="With --download: re-fetch even if intact.")
@click.option("--yes", is_flag=True, help="With --prune: delete without confirming.")
@click.option("--cache", default=None, type=click.Path(),
              help="Weight cache directory (default: $TT_BIO_CACHE, $BOLTZ_CACHE, or ~/.boltz).")
def weights_cmd(models, download, prune, force, yes, cache):
    """List, download or prune the model weights.

    \b
        tt-bio weights                       what is on this host, and where
        tt-bio weights --download            fetch everything that is missing
        tt-bio weights --download boltz2     fetch one model's artifacts
        tt-bio weights --prune               reclaim superseded/leftover files

    Every artifact is verified, not just checked for existence, so a download killed
    mid-flight shows up as `corrupt` here and is re-fetched rather than loaded.
    """
    root = Path(cache).expanduser() if cache else None
    try:
        rows = weights.artifacts_for(*models)
    except KeyError as e:
        raise click.ClickException(str(e).strip("\"'"))

    if download:
        for art in rows:
            if art.source == "manual":
                click.echo(f"{art.key}: not downloadable ({art.licence}); "
                           f"set ${art.env} to your copy")
                continue
            weights.fetch(art.key, root=root, force=force)

    if prune:
        _prune_weights(rows if models else (), root, yes)
        return

    _print_weights_table(rows, root)


def _source_col(art) -> str:
    """Where this row is fetched from, for the table. The host, not the row kind: every
    flat row is a `file`, so printing that says nothing, while "huggingface.co" or
    "files.ipd.uw.edu" is the answer to the question a reader actually has."""
    if art.source == "manual":
        return "manual"
    if art.source == "hf-repo":
        return "huggingface.co"
    hosts = dict.fromkeys(weights.source_host(s) for s in art.sources)
    return ",".join(hosts) if len(hosts) == 1 else f"{next(iter(hosts))}+{len(hosts) - 1}"


def _print_weights_table(rows, root) -> None:
    """One line per artifact: what it is, whether this host has it, and what a fold
    would load. Every consumer of "the artifact list" reads the same registry, so this
    cannot drift from what the models actually fetch."""
    stats = [weights.status(a.key, root) for a in rows]
    colour = {"present": "green", "missing": "yellow", "corrupt": "red", "partial": "red"}
    width = max(len(s.artifact.key) for s in stats)
    src = {s.artifact.key: _source_col(s.artifact) for s in stats}
    swidth = max(len(v) for v in src.values())
    click.echo(f"{'ARTIFACT':{width}s}  {'MODEL':14s} {'SOURCE':{swidth}s} {'STATUS':8s} "
               f"{'SIZE':>8s}  PATH")
    for st in stats:
        a = st.artifact
        size = f"{st.on_disk / (1 << 30):.2f}G" if st.on_disk else "-"
        note = f"  ({st.extra})" if st.extra else ""
        if st.override:
            note += f"  [${st.override}]"
        click.echo(f"{a.key:{width}s}  {(a.models or ('-',))[0]:14s} {src[a.key]:{swidth}s} "
                   + click.style(f"{st.state:8s}", fg=colour.get(st.state))
                   + f" {size:>8s}  {st.path or '-'}{note}")

    have = sum(s.on_disk for s in stats)
    want = sum(s.artifact.approx_bytes for s in stats if s.state != "present")
    bad = [s for s in stats if s.state in ("corrupt", "partial")]
    click.echo(f"\n{sum(1 for s in stats if s.state == 'present')}/{len(stats)} present, "
               f"{have / (1 << 30):.1f} GiB on disk"
               + (f", {want / (1 << 30):.1f} GiB to fetch (tt-bio weights --download)" if want else ""))
    click.echo(f"cache root          {weights.cache_root(root)}")
    click.echo(f"hugging face cache  {_hf_cache_dir()}")
    click.echo("both move together with $TT_BIO_CACHE; every row also takes its own "
               "$TT_BIO_<ARTIFACT> override")
    if bad:
        click.secho(f"{len(bad)} artifact(s) failed verification and will be re-fetched "
                    f"on next use: {', '.join(s.artifact.key for s in bad)}", fg="red")

    junk = weights.unmanaged(root)
    repos = [(r, n) for r, n in weights.unmanaged_repos() if n > (1 << 26)]
    if junk or repos:
        click.echo("\nNot claimed by any model (left alone; the caches are shared):")
        for path, n in junk:
            click.echo(f"  {n / (1 << 30):6.2f}G  {path}")
        for repo, n in repos:
            click.echo(f"  {n / (1 << 30):6.2f}G  hf:{repo}")


def _hf_cache_dir() -> str:
    from huggingface_hub import constants

    return str(constants.HF_HUB_CACHE)


def _prune_weights(rows, root, yes: bool) -> None:
    """Reclaim disk. Superseded hub revisions and staging leftovers are always safe;
    a model's own artifacts go only when that model was named on the command line."""
    revs, rev_bytes = weights.superseded_revisions()
    staging = weights.stale_staging(root)
    files = [(p, n) for a in rows for p in weights.artifact_paths(a.key, root)
             for n in (weights._tree_bytes(p),)]
    total = rev_bytes + sum(n for _, n in staging) + sum(n for _, n in files)
    if not total:
        click.echo("Nothing to prune.")
        return

    if revs:
        click.echo(f"{rev_bytes / (1 << 30):6.2f}G  {len(revs)} superseded Hugging Face "
                   f"revision(s)")
    for path, n in staging:
        click.echo(f"{n / (1 << 30):6.2f}G  staging leftover {path}")
    for path, n in files:
        click.echo(f"{n / (1 << 30):6.2f}G  {path}")
    click.echo(f"{total / (1 << 30):6.2f}G  total")
    if not yes and not click.confirm("Delete these?", default=False):
        click.echo("Nothing deleted.")
        return

    freed = weights.delete_revisions(revs) if revs else 0
    for path, _n in staging + files:
        shutil.rmtree(path, ignore_errors=True) if path.is_dir() else path.unlink(missing_ok=True)
    freed += sum(n for _, n in staging + files)
    click.echo(f"Freed {freed / (1 << 30):.2f} GiB")


@cli.command("worker")
@click.option("--connect", required=True, help="This host's controller, e.g. http://127.0.0.1:8765")
@click.option("--accelerator", type=click.Choice(["gpu", "cpu", "tenstorrent"]), default="tenstorrent")
@click.option("--num_devices", default=0, type=int, help="Number of TT devices to use (0=all available)")
@click.option("--device_ids", default=None, type=str, help="Comma-separated TT device IDs to use")
@click.option("--debug", is_flag=True, help="Do not suppress worker output")
def worker_cmd(connect, accelerator, num_devices, device_ids, debug):
    """Serve a controller with a worker per local chip, respawning any that dies."""
    workers = _local_workers(accelerator, num_devices, device_ids, max_workers=10_000)
    click.echo(f"Connecting {len(workers)} worker{'s' if len(workers) != 1 else ''} to {connect}")
    if accelerator == "tenstorrent":
        click.echo(f"  Devices: {[int(w.device_id) for w in workers]}")
    for worker in workers:
        click.echo(f"  {worker.label}")

    _supervise_worker_processes(connect, workers, debug)


@cli.command("controller")
@click.option("--port", default=8765, type=int, show_default=True,
              help="Port on 127.0.0.1 to serve on. The controller never binds another interface.")
@click.option("--lease-s", "lease_s", default=LEASE_S, type=float, show_default=True,
              help="Seconds a job stays with a worker that stops heartbeating before it is "
                   "handed to another. Workers heartbeat every 1/12 of it.")
@click.option("--max-leases", "max_leases", default=MAX_LEASES, type=int, show_default=True,
              help="Workers a job is handed to before a lapsed lease fails it instead.")
@click.option("--accelerator", type=click.Choice(["gpu", "cpu", "tenstorrent"]), default="tenstorrent")
@click.option("--num_devices", default=0, type=int, help="Local devices to serve with (0=all). Ignored with --no-local-workers.")
@click.option("--device_ids", default=None, type=str, help="Comma-separated TT device IDs to use locally")
@click.option("--no-local-workers", "no_local_workers", is_flag=True,
              help="Start no workers; the caller starts them with `tt-bio worker --connect`, "
                   "for example to own each chip's worker itself.")
@click.option("--state-dir", default=None, type=click.Path(),
              help="Where to keep the controller's SQLite state (default: a temp dir, discarded on exit).")
@click.option("--debug", is_flag=True, help="Do not suppress local worker output")
def controller_cmd(port, lease_s, max_leases, accelerator, num_devices, device_ids, no_local_workers, state_dir, debug):
    """Run a persistent controller for this host's chips.

    Starts the scheduler on 127.0.0.1 and, unless --no-local-workers, a worker
    per local device, then serves any number of `tt-bio predict --controller URL`
    runs. Work across several machines is a scheduler's job on top of this one;
    see docs/multi-host.md. Ctrl-C to stop.

    \b
    Example:
        tt-bio controller --port 8765
        tt-bio predict ./proteins --controller http://127.0.0.1:8765 --use_msa_server
    """
    if state_dir:
        state_path = Path(state_dir).expanduser()
        state_path.mkdir(parents=True, exist_ok=True)
        db_path = state_path / "controller.sqlite3"
        tmpdir = None
    else:
        tmpdir = Path(tempfile.mkdtemp(prefix="tt-bio-controller-"))
        db_path = tmpdir / "controller.sqlite3"

    server = ControllerServer(port, db_path, lease_s, max_leases)
    server.serve_in_background()
    url = f"http://127.0.0.1:{server.port}"

    workers, procs = [], []
    if not no_local_workers:
        try:
            workers = _local_workers(accelerator, num_devices, device_ids, max_workers=10_000)
        except RuntimeError as exc:
            click.secho(f"No local workers ({exc}); coordinator-only.", fg="yellow")
        if workers:
            procs = _spawn_worker_processes(url, workers, debug)

    click.echo(f"Controller listening on {url} (lease {lease_s:g} s)")
    click.echo(f"  local workers: {len(workers)}"
               + (f" (devices {[int(w.device_id) for w in workers]})" if workers and accelerator == 'tenstorrent' else ""))
    click.echo(f"  add workers:   tt-bio worker --connect {url}")
    click.echo(f"  submit work:   tt-bio predict <data> --controller {url}")
    click.echo("Ctrl-C to stop.")
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        click.echo("\nStopping controller...")
    finally:
        _stop_worker_processes(procs)
        server.shutdown()
        if tmpdir is not None:
            shutil.rmtree(tmpdir, ignore_errors=True)


_MSA_DBS = {
    "uniref30": {
        "url": "https://opendata.mmseqs.org/colabfold/uniref30_2302.db.tar.gz",
        "name": "uniref30_2302_db",
        "ready": "UNIREF30_READY",
    },
    "envdb": {
        "url": "https://opendata.mmseqs.org/colabfold/colabfold_envdb_202108.db.tar.gz",
        "name": "colabfold_envdb_202108_db",
        "ready": "COLABDB_READY",
    },
}


@cli.command()
@click.option("--db", type=click.Choice(["uniref30", "envdb", "all"]), default="uniref30",
              help="Database to download: uniref30 (~500GB), envdb (~800GB), or all (~1.3TB)")
@click.option("--path", default=None, type=click.Path(),
              help="Database location (default: ~/.boltz/msa_db)")
@click.option("--install-tools/--no-install-tools", default=True,
              help="Auto-install missing mmseqs/colabfold_search via localcolabfold")
def msa(db, path, install_tools):
    """Download MSA databases for offline structure prediction.

    \b
    After setup, predictions auto-detect the database:
        tt-bio msa
        tt-bio predict input.yaml
    """
    cache = Path(os.environ.get("BOLTZ_CACHE", str(Path("~/.boltz").expanduser())))
    db_dir = Path(path).expanduser() if path else cache / "msa_db"
    db_dir.mkdir(parents=True, exist_ok=True)
    _ensure_offline_tools(install_tools=install_tools)
    mmseqs = _find_mmseqs()
    dbs_to_setup = ["uniref30", "envdb"] if db == "all" else [db]

    for name in dbs_to_setup:
        info = _MSA_DBS[name]
        ready = db_dir / info["ready"]
        if ready.exists():
            click.echo(f"{name}: already set up")
            continue

        click.echo(f"\n{name}: downloading")
        tarball = db_dir / Path(info["url"]).name
        if tarball.exists() and tarball.stat().st_size > 0:
            click.echo(f"  Reusing existing tarball: {tarball.name}")
        else:
            _download_file(info["url"], tarball)

        click.echo(f"{name}: extracting")
        _extract_tarball(tarball, db_dir)

        if _mmseqs_index_exists(db_dir, info["name"]):
            click.echo(f"{name}: index already present")
        else:
            threads = _recommended_threads()
            click.echo(f"{name}: building index (this takes a while)")
            subprocess.run(
                [mmseqs, "createindex", str(db_dir / info["name"]),
                 str(db_dir / f"tmp_{name}"), "--remove-tmp-files", "1",
                 "--threads", str(threads)],
                check=True)

        if name == "uniref30":
            tax_url = "https://opendata.mmseqs.org/colabfold/uniref30_2302_newtaxonomy.tar.gz"
            tax_tar = db_dir / "uniref30_2302_newtaxonomy.tar.gz"
            _download_file(tax_url, tax_tar)
            subprocess.run(["tar", "-xzf", str(tax_tar), "-C", str(db_dir)], check=True)
            mapping = db_dir / "uniref30_2302_db_mapping"
            if mapping.exists():
                subprocess.run(
                    [mmseqs, "createbintaxmapping", str(mapping), str(mapping) + ".bin"],
                    check=False)
                bin_path = Path(str(mapping) + ".bin")
                if bin_path.exists():
                    bin_path.rename(mapping)
            for suffix in ("mapping", "taxonomy"):
                src = db_dir / f"uniref30_2302_db_{suffix}"
                link = db_dir / f"uniref30_2302_db.idx_{suffix}"
                if src.exists() and not link.exists():
                    link.symlink_to(src.name)
            tax_tar.unlink(missing_ok=True)

        tarball.unlink(missing_ok=True)
        ready.touch()
        click.echo(f"{name}: ready")

    click.echo(f"\nDatabases: {db_dir}")
    click.echo("Predictions will auto-detect this database, or pass explicitly:")
    click.echo(f"  tt-bio predict input.yaml --msa_db_path {db_dir}")


@cli.command("json")
@click.argument("input_path", metavar="INPUT", type=click.Path(exists=True))
@click.option("--out_dir", default="./output", type=click.Path(file_okay=False), show_default=True)
@click.option("--altloc", default="first", show_default=True,
              help="Alternate locations: the first of each residue, or a letter (A, B, ...).")
@click.option("--assembly_id", default=None, help="Expand to this biological assembly (default: the asymmetric unit).")
@click.option("--include_discont_poly_poly_bonds", is_flag=True,
              help="Also write bonds between non-consecutive polymer residues (disulfides, cyclic peptides).")
@click.option("--cache", default=None, type=click.Path(), help="Weight cache (default: $TT_BIO_CACHE or ~/.boltz).")
def json_cmd(input_path, out_dir, altloc, assembly_id, include_discont_poly_poly_bonds, cache):
    """Turn PDB / mmCIF structures into Protenix / Mol-1 job JSON (upstream's `mol json`).

    \b
        tt-bio json 7r6r.cif                 writes output/7r6r.json
        tt-bio json structures/ --assembly_id 1

    INPUT is a file or a directory searched for .pdb and .cif files. Each becomes one job:
    every protein, DNA and RNA entity with its copy count and modified residues, ligands and
    ions by CCD code, and the covalent bonds that attach them. Water, hydrogens and
    crystallisation aids are dropped. This is upstream's converter, so the JSON is the one
    Mol-1 writes. The first run downloads the Chemical Component Dictionary (520 MB)."""
    from tt_bio import mol1_json

    try:
        comp = weights.fetch("mol1-components", root=Path(cache).expanduser() if cache else None)
        written = mol1_json.convert(Path(input_path), Path(out_dir), comp, altloc=altloc, assembly_id=assembly_id,
                                    include_discont_poly_poly_bonds=include_discont_poly_poly_bonds)
    except (ValueError, RuntimeError) as e:
        raise click.ClickException(str(e))
    click.echo(f"Done: {len(written)} job JSON file(s) in {out_dir}")


@cli.command("prep")
@click.argument("input_path", metavar="INPUT", type=click.Path(exists=True, dir_okay=False))
@click.option("--out_dir", default="./output", type=click.Path(file_okay=False), show_default=True,
              help="Where the alignments go.")
@click.option("--msa_db_path", default=None, type=click.Path(exists=True),
              help="Search this local ColabFold DB instead of the ColabFold server.")
@click.option("--use_envdb", is_flag=True, help="Also search the environmental DB (with --msa_db_path).")
@click.option("--msa_endpoint", default=None, help="Fetch unpaired MSAs from a `tt-bio msa-server` at this URL.")
@click.option("--msa_server_url", default="https://api.colabfold.com", show_default=True)
@click.option("--msa_pairing_strategy", default="greedy", show_default=True)
@click.option("--use_template", is_flag=True,
              help="JSON input: also search templates for each protein chain (needs hmmer and the seqres database).")
@click.option("--use_rna_msa", is_flag=True,
              help="JSON input: also search MSAs for RNA chains that have none (needs hmmer and the RNA databases).")
@_upstream_search_options
def prep_cmd(input_path, out_dir, msa_db_path, use_envdb, msa_endpoint, msa_server_url, msa_pairing_strategy,
             use_template, use_rna_msa, **search_tools):
    """Search the MSAs (and templates) of a Protenix / Mol-1 job JSON or a FASTA ahead of the fold.

    \b
        tt-bio prep jobs.json                  writes jobs-update-msa.json beside it
        tt-bio prep jobs.json --use_template   writes jobs-final-updated.json beside it
        tt-bio prep seqs.fasta                 one directory per record + msa_index.json

    A JSON job's protein chains without an MSA are searched and the updated JSON names the
    files (upstream's `mol msa`); `tt-bio predict jobs-update-msa.json --model mol1` then folds
    with them and searches nothing. --use_template and --use_rna_msa add upstream's template and
    RNA MSA searches, which is what `mol prep` does. A FASTA's records are searched as one complex,
    so several records also get a species-paired MSA. The ColabFold server is used unless
    --msa_db_path or --msa_endpoint names another source. Needs no device."""
    from tt_bio import protenix_json, protenix_prep

    cfg = {"use_msa_server": not (msa_db_path or msa_endpoint), "msa_db_path": msa_db_path,
           "use_envdb": use_envdb, "msa_endpoint": msa_endpoint, "msa_server_url": msa_server_url,
           "msa_pairing_strategy": msa_pairing_strategy}
    src, out = Path(input_path), Path(out_dir)
    try:
        if src.suffix.lower() in (".fasta", ".fa", ".faa"):
            if use_template or use_rna_msa:
                raise ValueError(f"{src}: template and RNA MSA search take a .json job list, as upstream's prep does")
            dest = protenix_prep.prep_fasta(src, out, cfg)
        elif src.suffix.lower() == ".json":
            dest = protenix_prep.prep_json(src, out, cfg)
            cur = dest or src
            final = protenix_json.search(cur, out, use_template, use_rna_msa, **search_tools)
            if final != cur:  # upstream writes <stem>-final-updated.json beside the MSA-updated JSON
                dest = final.replace(cur.resolve().parent / final.name)
        else:
            raise ValueError(f"{src}: tt-bio prep reads a .json job list or a .fasta")
    except (ValueError, KeyError, AssertionError, FileNotFoundError, RuntimeError) as e:
        raise click.ClickException(str(e))
    click.echo(f"Done: {dest}" if dest else f"Every chain in {src} already has what was asked; nothing to search.")


@cli.command("msa-server")
@click.option("--listen", default="8765", help="PORT or HOST:PORT to bind (default 8765).")
@click.option("--msa_db_path", default=None, type=click.Path(),
              help="Local ColabFold DB to search (default: auto-detect ~/.boltz/msa_db).")
@click.option("--cache", "cache_dir", default=None, type=click.Path(),
              help="a3m cache directory (default: <cache>/msa_server_cache).")
@click.option("--use_envdb", is_flag=True, help="Also search the environmental DB (requires envdb).")
@click.option("--max_concurrent", default=1, type=int,
              help="Max simultaneous colabfold_search runs (each already uses many cores).")
@click.option("--token", default=None, help="Require this bearer token on requests.")
def msa_server_cmd(listen, msa_db_path, cache_dir, use_envdb, max_concurrent, token):
    """Serve offline MSA over HTTP so other machines need not host the database.

    \b
    One machine with the DB:
        tt-bio msa-server --listen 0.0.0.0:8765
    Every other machine / the web portal then fetches MSAs from it:
        tt-bio predict input.yaml --model protenix-v2 --msa_endpoint http://HOST:8765
    """
    cache = Path(os.environ.get("BOLTZ_CACHE", str(Path("~/.boltz").expanduser())))
    db_dir = Path(msa_db_path).expanduser() if msa_db_path else cache / "msa_db"
    _validate_offline_msa_db(db_dir, require_envdb=use_envdb)
    cache_path = Path(cache_dir).expanduser() if cache_dir else cache / "msa_server_cache"

    host, _, port = listen.rpartition(":")
    host, port = (host or "0.0.0.0"), int(port or listen)

    from tt_bio.msa_server import run_server
    run_server(host, port, str(db_dir), cache_path,
               use_env=use_envdb, max_concurrent=max_concurrent, token=token)


# ---------------------------------------------------------------------------
# ESMFold2 (--model esmfold2): protein / DNA / RNA / ligand, no MSA required, on-device ttnn.
# ---------------------------------------------------------------------------
def _chain_label(n: int) -> str:
    """Chain id for the n-th chain (0-indexed): A..Z, then AA, AB, ... (bijective base-26).
    Identical to the old ``chr(65 + n)`` for n < 26, but never collides or runs past 'Z' for a
    larger complex — an index-mod-26 or bare ``chr()`` scheme produced duplicate or non-alphabetic
    chain ids there, silently corrupting the written structure."""
    s = ""
    n += 1
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s


_NA_HEADER_TYPES = {"rna": "rna", "rnasequence": "rna", "dna": "dna", "dnasequence": "dna"}

#: Keys the YAML input language defines. A key outside these sets is a typo, and a typo used
#: to cost a whole chain or a whole constraint block without a word: `protien:` folded the
#: complex one chain short, `constrains:` folded without the covalent bond, both status=ok.
#: What a MODEL does with a key it cannot honour is a separate question, answered by the one
#: table in tt_bio/capabilities.py.
_DOC_KEYS = frozenset({"version", "sequences", "constraints", "properties", "templates", "constraint"})
_ENTRY_KEYS = frozenset({"protein", "rna", "dna", "ligand"})
_POLYMER_KEYS = frozenset({"id", "sequence", "msa", "modifications", "cyclic", "templates"})
_LIGAND_KEYS = frozenset({"id", "ccd", "smiles", "file"})


def _check_yaml_keys(doc: dict, path) -> None:
    """Refuse an unrecognized key instead of dropping it."""
    def bad(what, keys, allowed):
        extra = sorted(set(keys) - allowed)
        if extra:
            raise click.ClickException(
                f"{path.name}: unrecognized {what} {', '.join(repr(k) for k in extra)}. "
                f"Accepted: {', '.join(sorted(allowed))}.")

    bad("top-level key(s)", doc, _DOC_KEYS)
    for entry in doc.get("sequences") or []:
        if not isinstance(entry, dict):
            continue
        bad("entity key(s)", entry, _ENTRY_KEYS)
        for key, sub in entry.items():
            if isinstance(sub, dict):
                bad(f"key(s) on a {key} entity", sub,
                    _LIGAND_KEYS if key == "ligand" else _POLYMER_KEYS)


def _read_bio_chains(path, what="input"):
    """Read a FASTA/YAML complex as [(chain_id, sequence, msa_spec, mol_type, modifications)].

    The ONE input reader for every model that folds a complex from a file — Protenix,
    OpenFold3, OpenDDE, OpenBind and ESMFold2. ESMFold2 had a second, protein-only copy
    of this that silently dropped every non-protein record, so
    a cocrystal YAML folded as bare protein and reported success; there is now one parser
    and one set of accepted keys.

    The FASTA type field and the YAML entry key select the modality; protein keeps its
    MSA, nucleic-acid and ligand chains are single-sequence (``msa_spec=None``). Polymer
    sequences are uppercased here, once, because RF3's tokenizer rejects lowercase. A ligand
    carries its spec in the ``sequence`` slot: ``CCD_<code>`` for a CCD component (comma
    separated for a multi-residue ligand chain) or a raw SMILES string. ``modifications``
    is the polymer's ``[{"position": N, "ccd": CODE}]`` list (1-indexed, Boltz
    convention) or None; positions are validated here against the sequence length so a
    typo fails at read time rather than deep inside a featurizer.

    ``what`` names the model in the "unsupported input" error only.
    """
    suffix = path.suffix.lower()
    chains: list[tuple[str, str, str | None, str, list | None]] = []
    if suffix in (".fa", ".fas", ".fasta"):
        cid, buf, msa, mt = None, [], None, "protein"
        def flush():
            # cid is None for a skipped/unknown record; a blank id ("") is a real chain whose id
            # we auto-assign below — gate on `is not None` so it isn't silently dropped.
            if cid is not None and buf:
                seq = "".join(buf)
                # ccd code -> CCD_ spec; a polymer is case-insensitive, a SMILES is not
                seq = "CCD_" + seq.upper() if mt == "_ccd" else seq if mt == "ligand" else seq.upper()
                mtype = "ligand" if mt in ("_ccd", "ligand") else mt
                for c in cid.split(","):
                    chains.append((c.strip() or _chain_label(len(chains)), seq, msa, mtype, None))
        for line in path.read_text().splitlines():
            line = line.strip()
            if line.startswith(">"):
                flush()
                parts = line[1:].split("|")
                typ = parts[1].strip().lower() if len(parts) > 1 else "protein"
                if typ in ("", "protein"):
                    cid, buf, mt = parts[0].strip(), [], "protein"
                    m = parts[2].strip() if len(parts) > 2 else ""
                    msa = EMPTY_MSA if m.lower() == EMPTY_MSA else (m or None)
                elif typ in _NA_HEADER_TYPES:
                    cid, buf, mt, msa = parts[0].strip(), [], _NA_HEADER_TYPES[typ], None
                elif typ in ("ccd", "ion", "smiles", "ligand"):
                    cid, buf, msa = parts[0].strip(), [], None
                    mt = "_ccd" if typ in ("ccd", "ion") else "ligand"
                else:
                    # Refused, not skipped: skipping folded the rest of the complex without
                    # this chain and reported success, and a UniProt header
                    # (>sp|P69905|HBA_HUMAN) on a single-chain file ended in "no sequences".
                    from tt_bio.data.parse import fasta_header_error
                    raise click.ClickException(fasta_header_error(line[1:], path.name))
            elif line and cid is not None:
                buf.append(line)
        flush()
    elif suffix in (".yml", ".yaml"):
        import yaml
        doc = yaml.safe_load(path.read_text()) or {}
        _check_yaml_keys(doc, path)
        for entry in doc.get("sequences", []):
            if not isinstance(entry, dict):
                continue
            for key, mt in (("protein", "protein"), ("rna", "rna"), ("dna", "dna")):
                sub = entry.get(key)
                if not isinstance(sub, dict):
                    # an empty `sequence:` still reaches the blank check below, which names the
                    # chain; skipping it here folded the rest of the complex without it
                    continue
                m = sub.get("msa") if mt == "protein" else None
                m = str(m).strip() if m else None
                m = EMPTY_MSA if m and m.lower() == EMPTY_MSA else (m or None)
                mods = _read_modifications(sub, key)
                ids = sub.get("id", "A")
                id_list = ([str(x) for x in ids] if isinstance(ids, (list, tuple))
                           else str(ids).split(","))
                for c in id_list:
                    chains.append((c.strip(), str(sub.get("sequence") or "").upper(), m, mt, mods))
            lig = entry.get("ligand")                       # {ccd: CODE|[CODE, ...]}, {smiles: STR} or {file: PATH}
            if isinstance(lig, dict) and (lig.get("ccd") or lig.get("smiles") or lig.get("file")):
                if lig.get("ccd"):
                    codes = lig["ccd"] if isinstance(lig["ccd"], (list, tuple)) else [lig["ccd"]]
                    spec = "CCD_" + ",".join(str(x).strip().upper() for x in codes)
                elif lig.get("file"):                       # a 3D .sdf/.mol/.mol2/.pdb, relative to the input
                    f = Path(str(lig["file"])).expanduser()
                    spec = "FILE_" + str(f if f.is_absolute() else (path.parent / f).resolve())
                else:
                    spec = str(lig["smiles"])
                ids = lig.get("id", "L")
                id_list = ([str(x) for x in ids] if isinstance(ids, (list, tuple))
                           else str(ids).split(","))
                for c in id_list:
                    chains.append((c.strip(), spec, None, "ligand", None))
    else:
        raise click.ClickException(f"Unsupported input for {what}: {path.name}")
    ids = [cid for cid, *_r in chains]
    repeated = sorted({cid for cid in ids if ids.count(cid) > 1})
    if repeated:
        # every model folded two chains under one id as one merged chain, or crashed on it
        raise click.ClickException(
            f"{path.name}: chain id(s) {', '.join(map(repr, repeated))} are used more than "
            f"once; every chain needs its own id (an entry without `id:` is A for a polymer, "
            f"L for a ligand).")
    blank = [cid for cid, cseq, _sp, _mt, _mods in chains if not cseq or not cseq.strip()]
    if blank:
        raise click.ClickException(
            f"{path.name}: chain(s) {', '.join(blank)} have empty/whitespace-only "
            f"sequences (a ligand carries its CCD/SMILES spec in the same slot).")
    # A digit or symbol in a polymer folded as an extra residue on the models that map an
    # unknown letter to UNK. Whitespace is layout, not a residue.
    for cid, cseq, _sp, mt, _mods in chains:
        bad = [f"{i + 1}{c}" for i, c in enumerate("".join(cseq.split())) if not c.isalpha()]
        if mt != "ligand" and bad:
            raise click.ClickException(
                f"{path.name}: chain {cid} has non-letter character(s) at "
                f"{', '.join(bad[:8])}; a {mt} sequence is one letter per residue.")
    return chains


def _read_modifications(sub: dict, key: str):
    """Validate and copy a polymer entry's ``modifications:`` list, or None if absent.

    Positions are 1-indexed over the chain's own sequence (the Boltz YAML convention);
    a position outside it, or a missing ccd code, is a user error worth naming here
    rather than a wrong structure later.
    """
    mods = sub.get("modifications")
    if not mods:
        return None
    seq_len = len("".join(str(sub.get("sequence") or "").split()))
    for mod in mods:
        pos = mod.get("position") if isinstance(mod, dict) else None
        if not isinstance(pos, int) or not (1 <= pos <= seq_len) or not mod.get("ccd"):
            raise click.ClickException(
                f"modification {mod!r} on {key} chain {sub.get('id', 'A')} needs a "
                f"1-indexed position within the sequence (length {seq_len}) and a ccd code.")
    return [dict(mod) for mod in mods]


def _read_bio_constraint(path):
    """The input's top-level ``constraint:`` block (OpenDDE 1.2.0 guided sampling), or None.
    Its content is upstream's JSON ``constraint`` field unchanged; tt_bio.tfg.features
    validates it."""
    if path.suffix.lower() not in (".yml", ".yaml"):
        return None
    import yaml
    return (yaml.safe_load(path.read_text()) or {}).get("constraint")


def _read_bio_constraints(path):
    """Parse the `constraints:` block of a Protenix/bio input into covalent bonds.

    Returns ``[((chain, res, atom), (chain, res, atom)), ...]`` for every `bond`
    constraint (covalent inhibitor, glycan, crosslink). `pocket`/`contact` binding
    constraints are rejected with clear guidance: no Protenix checkpoint has a
    constraint embedder, so the only constraint signal they can honour is the covalent
    bond graph (token_bonds) — pocket/contact need Boltz-2. Silently folding without
    them would return a confidently wrong structure, so we refuse instead."""
    if path.suffix.lower() not in (".yml", ".yaml"):
        return []
    import yaml
    doc = yaml.safe_load(path.read_text()) or {}
    bonds = []
    for c in doc.get("constraints", []) or []:
        if not isinstance(c, dict):
            continue
        if "bond" in c:
            b = c["bond"] or {}
            a1, a2 = b.get("atom1"), b.get("atom2")
            if not (isinstance(a1, (list, tuple)) and len(a1) == 3
                    and isinstance(a2, (list, tuple)) and len(a2) == 3):
                raise click.ClickException(
                    "Bond constraint needs atom1 and atom2 as [chain, residue, atom].")
            bonds.append(((str(a1[0]), int(a1[1]), str(a1[2])),
                          (str(a2[0]), int(a2[1]), str(a2[2]))))
        elif _is_mol1_condition(c):
            continue                      # Mol-1-constraint, read by _read_mol1_constraints
        elif "pocket" in c or "contact" in c:
            kind = "pocket" if "pocket" in c else "contact"
            raise click.ClickException(
                f"Protenix-v2 does not support '{kind}' (pocket/contact) binding "
                "constraints — use --model boltz2 for those. Covalent 'bond' "
                "constraints are supported.")
        else:
            raise click.ClickException(f"Unsupported constraint for Protenix: {c}")
    return bonds


def _is_mol1_condition(item) -> bool:
    """A `constraints:` list item in Mol-1-constraint's shape: `site`, `exclusion`, or a `contact` given as
    `pairs` / `token_pairs` (a Boltz contact names token1 / token2 instead)."""
    if "site" in item or "exclusion" in item:
        return True
    c = item.get("contact")
    return isinstance(c, dict) and bool({"pairs", "token_pairs"} & set(c))


def _read_mol1_constraints(path) -> dict | None:
    """The input's Mol-1-constraint conditions (SITE / CONTACT / EXCLUSION), parsed by upstream's rules
    (`mol1_constraint.parse`), or None when it names none. Each kind is one list item, as in upstream's
    `constraints` object; an upstream JSON input is converted to the same items."""
    if path.suffix.lower() not in (".yml", ".yaml"):
        return None
    import yaml
    from tt_bio import mol1_constraint
    doc = yaml.safe_load(path.read_text()) or {}
    merged = {}
    for c in doc.get("constraints", []) or []:
        if isinstance(c, dict) and _is_mol1_condition(c):
            for k, v in c.items():
                if k in merged:
                    raise click.ClickException(f"Give one '{k}' constraint per input; list all its residues in it.")
                merged[k] = v
    try:
        return mol1_constraint.parse(merged or None)
    except ValueError as e:
        raise click.ClickException(str(e))


def _read_cyclic(path) -> list[str]:
    """Chain ids whose entry says ``cyclic: true`` (the Boltz YAML flag), in input order."""
    if path.suffix.lower() not in (".yml", ".yaml"):
        return []
    import yaml
    doc = yaml.safe_load(path.read_text()) or {}
    out = []
    for entry in doc.get("sequences") or []:
        for sub in (entry or {}).values():
            if isinstance(sub, dict) and sub.get("cyclic"):
                ids = sub.get("id", "A")
                out += ([str(x) for x in ids] if isinstance(ids, (list, tuple))
                        else [c.strip() for c in str(ids).split(",")])
    return out


def _read_bio_bonds(path, chains):
    """Every covalent bond a token-bond model has to see: the `bond` constraints plus, for
    each ``cyclic: true`` protein, the head-to-tail amide that closes it (C of the last
    residue to N of the first).

    That amide is how upstream Protenix expresses a cyclic peptide (its
    docs/infer_json_format.md), and Protenix and OpenDDE have no other cyclic signal: no
    relpos wrap, no cyclic flag. Models that do have one (Boltz-2, RF3, the OF3 family) read
    ``_read_cyclic`` directly instead. A nucleic-acid ring would need an O3'-P link the
    featurizer does not place, so it is refused rather than folded open.
    """
    bonds = _read_bio_constraints(path)
    cyclic = set(_read_cyclic(path))
    for cid, seq, _sp, mt, _mods in chains:
        if cid not in cyclic:
            continue
        if mt != "protein":
            raise click.ClickException(
                f"{path.name}: `cyclic: true` on {mt} chain {cid}: this model closes a ring "
                "as a peptide bond, so only a protein chain can be cyclic. Use --model boltz2.")
        bonds.append(((cid, len("".join(seq.split())), "C"), (cid, 1, "N")))
    return bonds


def cap_a3m_text(text, max_seqs):
    """``text`` truncated to its first ``max_seqs`` alignment records (the query is record 0).

    The ONE place ``--max_msa_seqs`` is applied to an a3m, so protenix-v1/v2, opendde and
    rf3 cap depth the same way and the same way boltz2 already does it in
    ``data/parse.py::_parse_a3m`` (rows counted from the top, query included). Returns
    ``text`` unchanged when no cap was asked for or the file already fits, so an uncapped
    run reads byte-identical input to before.
    """
    if not text or not max_seqs or max_seqs <= 0:
        return text
    out, kept = [], 0
    for line in text.splitlines(keepends=True):
        if line.startswith(">"):
            kept += 1
            if kept > max_seqs:
                break
        out.append(line)
    return text if kept <= max_seqs else "".join(out)


def cap_a3m_file(path, max_seqs, tmp_dir):
    """A capped copy of the a3m at ``path`` under ``tmp_dir``, or ``path`` itself when it
    already fits. For the callers that hand a PATH to a featurizer (rf3's per-component
    ``msa_path``) rather than text."""
    if not max_seqs or max_seqs <= 0:
        return path
    path = Path(path)
    text = path.read_text()
    capped = cap_a3m_text(text, max_seqs)
    if capped is text:                                  # already under the cap
        return path
    out = Path(tmp_dir) / f"{path.stem}.cap{max_seqs}.a3m"
    publish_text(out, capped)
    return out


def _resolve_a3m_path(msa_spec, sequence, msa_dir):
    """Return the a3m file for a chain, or None for single-sequence folding. Tries an
    explicit a3m path (``msa_spec``), then the shared ``{sha256(seq)[:16]}.a3m`` cache in
    ``msa_dir`` (written by the same MSA generation ESMFold2/Boltz-2 use). Mirrors
    resolve_msa's candidate order."""
    if msa_spec == EMPTY_MSA:
        return None
    candidates = []
    if msa_spec:
        candidates.append(Path(msa_spec).expanduser())
    if msa_dir:
        candidates.append(Path(msa_dir) / f"{seq_hash(sequence)}.a3m")
    for p in candidates:
        if cached(p) and p.suffix != ".csv":
            return p
    return None


def _resolve_a3m_text(msa_spec, sequence, msa_dir, max_seqs=None):
    """The same resolution, as text: what the protenix featurizer takes. RF3's takes a
    path (`msa_path` per component), which is why the path half is separate.

    ``max_seqs`` is the user's ``--max_msa_seqs``, applied here so protenix-v1/v2 and
    opendde cap depth in the one place they already share."""
    p = _resolve_a3m_path(msa_spec, sequence, msa_dir)
    return cap_a3m_text(p.read_text(), max_seqs) if p else None


def _write_protenix_structure(coords, feats, aatype, outpath, output_format, b_factors=None,
                              mod_names=None, chain_ids=None, mirror_carboxylates=False):
    """Write a Protenix-v2 prediction as PDB/mmCIF via biotite: `protenix_atom_array` plus atom_site only."""
    import biotite.structure.io.pdbx as _pdbx
    outpath = Path(outpath)
    arr = protenix_atom_array(coords, feats, outpath, b_factors=b_factors, mod_names=mod_names, chain_ids=chain_ids,
                              mirror_carboxylates=mirror_carboxylates)
    if output_format == "pdb":
        write_atom_array(arr, outpath)
    else:
        from tt_bio import cif_text
        cf = _pdbx.CIFFile(); _pdbx.set_structure(cf, arr); cif_text.write(cf, str(outpath))


def protenix_atom_array(coords, feats, outpath, b_factors=None, mod_names=None, chain_ids=None,
                        mirror_carboxylates=False):
    """A Protenix-v2 prediction (coords + atom metadata) as a biotite AtomArray.

    Reconstructed entirely from the feature dict so it is modality- and chain-agnostic
    (proteins, complexes, nucleic acids, ligands): atom name from ref_atom_name_chars,
    element from ref_element, chain letter from asym_id, residue number from residue_index,
    residue name from restype. `aatype` is accepted for back-compat but unused. `b_factors`
    (per-atom, e.g. pLDDT*100) is written to the B-factor column when given.

    `mod_names` maps (asym_id, residue_index) -> the CCD code for a token whose restype
    cannot name it: a `modifications:` residue or a CCD ligand chain. Both are tokenized
    per atom and carry restype UNK, so without it the writer names them "LIG" and a user
    who asked for SEP reads back a ligand, or who asked for ATP reads back an unnamed
    one.

    `chain_ids` is the reader's chain list, one id per asym_id in order. Without it the chains
    are written A, B, C..., so a ligand submitted as L came back as B and any script selecting
    a chain by the id it submitted read the wrong one.

    A protein chain's terminal OXT that fails OpenDDE's geometry gates is rebuilt from the
    CCD ideal carboxylate before writing (tt_bio.oxt), on a copy of `coords`. `mirror_carboxylates` applies
    Mol-1's unconditional O/OXT mirror instead (tt_bio.oxt.mirror_terminal_carboxylates), as its writer does.
    `outpath` only names the file in an OXT repair warning."""
    import biotite.structure as struc
    import numpy as np

    from tt_bio.data import const
    from tt_bio.protenix_data import restype_to_resname

    a2t = feats["atom_to_token_idx"].tolist()
    znum = (feats["ref_element"].argmax(-1) + 1).tolist()
    z2sym = {z: s for s, z in const.element_to_atomic_num.items()}
    rt = feats["restype"].argmax(-1)
    resname = restype_to_resname(rt)                                  # per-token 3-letter name
    asym = feats["asym_id"].tolist(); resid = feats["residue_index"].tolist()
    rt = rt.tolist()
    # ligand atom-tokens are restype UNK(20) with a single atom in the token (no standard
    # residue is single-atom) -> write them as HETATM "LIG" rather than a polymer "UNK".
    tok_atom_count = [0] * len(rt)
    for t in a2t:
        tok_atom_count[t] += 1
    is_lig_tok = [rt[t] == 20 and tok_atom_count[t] == 1 for t in range(len(rt))]
    # decode 4-char atom names from the one-hot ref_atom_name_chars (idx -> chr(idx+32))
    name_idx = feats["ref_atom_name_chars"].argmax(-1).tolist()        # (N_atom, 4)
    names = ["".join(chr(c + 32) for c in chars).strip() for chars in name_idx]

    arr = struc.AtomArray(coords.shape[0])
    arr.coord = coords.numpy().astype("float32")
    arr.add_annotation("occupancy", float); arr.occupancy[:] = 1.0
    arr.add_annotation("b_factor", float)
    arr.b_factor[:] = b_factors.numpy().astype("float32") if b_factors is not None else 0.0
    label = (lambda n: str(chain_ids[n])) if chain_ids else _chain_label
    # set, not assigned per atom: the default chain_id dtype is <U4 and truncates a longer id
    arr.set_annotation("chain_id", np.array([label(int(asym[t])) for t in a2t]))
    # per token, then gathered to atoms (a per-atom loop cost ~0.5 s a fold at 1024 tokens, 10 calls)
    mods = [(mod_names or {}).get((int(asym[t]), int(resid[t]))) for t in range(len(rt))]
    tok_name = [m or ("LIG" if lig else n) for m, lig, n in zip(mods, is_lig_tok, resname)]
    tok_het = [lig or m is not None for m, lig in zip(mods, is_lig_tok)]
    a2t = np.asarray(a2t, dtype=np.int64)
    arr.res_id[:] = np.asarray(resid, dtype=np.int64)[a2t]
    arr.res_name[:] = np.array(tok_name)[a2t]
    arr.atom_name[:] = names
    arr.element[:] = [z2sym.get(int(z), "C") for z in znum]
    arr.hetero[:] = np.array(tok_het, dtype=bool)[a2t]
    # an OXT the diffusion left on O/C or detached is rebuilt from the CCD geometry
    # (OpenDDE 6685cef); arr.coord is already a copy, the caller's coords are untouched
    from tt_bio.oxt import mirror_terminal_carboxylates, repair_terminal_oxt_from_feats
    if mirror_carboxylates:
        arr.coord = mirror_terminal_carboxylates(arr.coord, arr.atom_name, arr.chain_id, arr.res_id)
    else:
        arr.coord, _ = repair_terminal_oxt_from_feats(arr.coord, feats, arr.atom_name, arr.res_name,
                                                      where=outpath)
    return arr


def _write_structure(complex_obj, outpath, output_format):
    """Write a folded complex as mmCIF, or as PDB via the mmCIF the model already builds.

    There is no ``to_pdb`` shortcut. The one that used to sit here called
    ``complex_obj.to_pdb()`` with no arguments, which no class in the tree accepts (the ESM
    ``ProteinComplex`` method takes a path and returns None), and it would have skipped the
    column fitting below anyway.
    """
    cif_text = complex_obj.to_mmcif()
    if output_format == "cif":
        outpath.write_text(cif_text)
        return
    import io
    import biotite.structure.io.pdbx as _pdbx
    # extra_fields is required: without it get_structure drops the b_factor column,
    # and the PDB then carries 0.00 for every atom — the per-residue pLDDT the CIF
    # just wrote is silently lost (measured on esmfold2-fast, 2026-08-16 sweep).
    arr = _pdbx.get_structure(_pdbx.CIFFile.read(io.StringIO(cif_text)), model=1,
                              extra_fields=["b_factor", "occupancy"])
    write_atom_array(arr, outpath)


def _generate_esmfold2_a3m(seqs, target_id, msa_dir, msa_db_path, use_envdb,
                           msa_url, msa_strategy, msa_user, msa_pass, api_key,
                           msa_endpoint=None):
    """Write a cached ``{seq_hash}.a3m`` for each sequence (MSA server, local DB,
    or ColabFold API).

    ``seqs`` maps seq_hash -> sequence. A tt-bio MSA server (``msa_endpoint``) is
    preferred when given; otherwise local-DB search (``compute_msa_offline``)
    already writes ``{hash}.a3m``, and the ColabFold API path runs an unpaired
    mmseqs2 search and writes its a3m text directly (the esm MSA reader wants
    a3m, unlike the Boltz CSV path). ESMFold2/Protenix use unpaired per-chain a3m,
    so the local search runs with pair=False (one batched call, no wasted paired
    search).
    """
    if msa_endpoint:
        from tt_bio.msa_server import fetch_msa

        fetch_msa(seqs, msa_dir, msa_endpoint)
        return
    if msa_db_path:
        # ESMFold2 / Protenix consume unpaired per-chain a3m only (block-diagonal
        # assembly), never paired alignments — so search independently (pair=False)
        # in one batched colabfold_search call instead of paying the paired-mode
        # cost for every multi-chain offline run.
        compute_msa_offline(seqs, target_id, msa_dir, msa_db_path,
                            use_env=use_envdb, pairing_strategy=msa_strategy, pair=False)
        return
    headers = {"Content-Type": "application/json", "X-API-Key": api_key} if api_key else None
    res = run_mmseqs2(list(seqs.values()), _mmseqs_prefix(msa_dir, seqs.values(), "esm"), use_env=use_envdb,
                      use_pairing=False, host_url=msa_url, pairing_strategy=msa_strategy,
                      msa_server_username=msa_user, msa_server_password=msa_pass, auth_headers=headers)
    for i, h in enumerate(seqs):
        publish_text(msa_dir / f"{h}.a3m", res[i])


def _generate_paired_a3m(seqs, target_id, msa_dir, msa_server_url,
                         msa_pairing_strategy, msa_server_username,
                         msa_server_password, api_key_value,
                         msa_db_path=None, use_envdb=False, search=True):
    """The species-paired MSA of one complex: ``{seq_hash: a3m_text}`` for ``seqs``
    (``seq_hash -> sequence``, the complex's unique protein sequences), or None when the
    complex does not pair or nothing is cached and ``search`` is False.

    Each a3m has the chain's own query as row 0 and row j of every chain comes from the
    same genome. The ColabFold pair endpoint (``ticket/pair``) does the species pairing
    server-side; it is the source OpenFold3's upstream MSA client writes
    ``colabfold_paired.a3m`` from, and the one Boltz-2's ``compute_msa`` reads its paired
    keys from. With ``msa_db_path`` a local ColabFold DB is searched instead.

    Cached under :func:`tt_bio.cache.paired_msa_dir`, one directory per set of sequences.
    It used to be ``paired/{seq_hash}.a3m``, which handed chain A the rows it had been
    paired with against its FIRST partner in every later complex, out of step with the new
    partner's rows.
    """
    pdir = paired_msa_dir(msa_dir, seqs.values())
    if pdir is None:
        return None
    if not all(cached(pdir / f"{k}.a3m") for k in seqs):
        if not search:
            return None
        def search_complex(_):
            pdir.mkdir(parents=True, exist_ok=True)
            if msa_db_path:
                compute_msa_offline(seqs, target_id, pdir, msa_db_path, use_env=use_envdb,
                                    pairing_strategy=msa_pairing_strategy, pair=True,
                                    chain_cache=Path(msa_dir) / "paired-chain-v1")
                return
            headers = ({"Content-Type": "application/json", "X-API-Key": api_key_value}
                       if api_key_value else None)
            keys = sorted(seqs, key=seqs.get)   # one order per complex, whatever the chain order
            res = run_mmseqs2([seqs[k] for k in keys], _mmseqs_prefix(msa_dir, [seqs[k] for k in keys], "paired"),
                              use_env=True, use_pairing=True, host_url=msa_server_url,
                              pairing_strategy=msa_pairing_strategy,
                              msa_server_username=msa_server_username,
                              msa_server_password=msa_server_password, auth_headers=headers)
            for i, k in enumerate(keys):
                publish_text(pdir / f"{k}.a3m", res[i])

        single_flight(pdir.parent, [pdir.name],
                      lambda _: not all(cached(pdir / f"{k}.a3m") for k in seqs), search_complex)
    return {k: (pdir / f"{k}.a3m").read_text() for k in seqs}


#: Per-model default trunk-recycling count. A TABLE, not a set literal: the count is a
#: property of the checkpoint, so a new port that is missing here must not silently inherit
#: another model's number. Anything absent falls back to RECYCLING_STEPS_DEFAULT.
#:
#: protenix-v1 is 4, which is upstream v0.5.0's own `configs/configs_base.py::model.N_cycle`.
#: `configs_inference.py` does not override it and `runner/inference.py::update_inference_configs`
#: only touches `skip_amp`, so 4 is what that checkpoint ships with. protenix-v2 is a different
#: release with its own 10. Giving v1 v2's 10 would run 2.5x the trunk the model was trained for.
#: mol1 is 20, Mol-1's `model.N_cycle` and its `mol pred -c` default.
#: opendde/opendde-abag keep 10. esmfold2/esmfold2-fast use 10, the ESMFold2 paper's benchmark
#: protocol (A.2.10: "For all benchmark results ... ESMFold2 uses 10 loops"). rf3 uses 10, its own
#: inference default (rf3.featurize DEFAULTS n_recycles), and the count is not free-standing
#: there: the featurizer draws one i.i.d. MSA sample per recycle, so it also sets how many MSA
#: samples the trunk sees. boltz2 uses the Boltz-2/AF3 convention of 3, and openfold3 also uses 3 --
#: its trunk runs recycles+1 = 4 cycles, the OF3 upstream default.
#:
#: protenix.Trunk derives the same default from the checkpoint when called outside the CLI
#: (protenix.trunk_recycles), and the two must agree; tests/test_protenix_template_gate.py pins it.
RECYCLING_STEPS = {
    "protenix-v1": 4,
    "protenix-v2": 10,
    "mol1": 20,
    "opendde": 10,
    "opendde-abag": 10,
    "esmfold2": 10,
    "esmfold2-fast": 10,
    "rf3": 10,
}
RECYCLING_STEPS_DEFAULT = 3

#: Models whose trunk runs --recycling_steps + 1 cycles rather than exactly N. Measured
#: off the live progress stream, not asserted: esmfold2 shows "Trunk 0/11" at its default
#: of 10, openfold3 "Trunk 0/4" at 3, while rf3 and opendde show 10/10 at 10. The help is
#: built from this, because it used to name openfold3 alone.
TRUNK_CYCLES_PLUS_ONE = ("boltz2", "esmfold2", "esmfold2-fast", "openfold3", "openbind")


def _check_recycling_steps(recycling_steps, model):
    """Refuse a --recycling_steps that would run no trunk.

    Models outside TRUNK_CYCLES_PLUS_ONE count trunk cycles, not recycles after a first pass,
    so 0 asks for no trunk at all: protenix folded one from the input embedding alone and rf3
    silently ran its default of 10 instead (recycle ladder, 2026-09-23).
    """
    if recycling_steps is not None and recycling_steps < (0 if model in TRUNK_CYCLES_PLUS_ONE else 1):
        raise click.BadParameter(
            f"--recycling_steps counts trunk cycles for {model}, so the smallest is 1 "
            f"(got {recycling_steps}). " + ", ".join(TRUNK_CYCLES_PLUS_ONE)
            + " count recycles after a first pass and accept 0.")


#: Requested diffusion-sampling steps per model, and what the request executes where the
#: two differ (see _resolve_sampling_steps for why). The help is built from this: it used
#: to say "every other model 200" while rf3 has shipped 50 since its port.
SAMPLING_STEPS = {"esmfold2": 100, "esmfold2-fast": 100, "rf3": 50}
SAMPLING_STEPS_DEFAULT = 200
SAMPLING_STEPS_EXECUTED = {100: 68, 50: 49}

#: Structures per fold when --diffusion_samples is unset. mol1 is 5, `mol pred -e`'s default, so a
#: plain `tt-bio predict --model mol1` writes the same five ranked samples upstream does.
DIFFUSION_SAMPLES = {"mol1": 5}
DIFFUSION_SAMPLES_DEFAULT = 1


def _grouped_defaults(table, default, models):
    """Render a per-model default table as "V: a, b; W: c", commonest value last."""
    groups = {}
    for m in models:
        groups.setdefault(table.get(m, default), []).append(m)
    ordered = sorted(groups.items(), key=lambda kv: (len(kv[1]), kv[0]))
    return "; ".join(f"{v} for {', '.join(ms)}" for v, ms in ordered)


def _resolve_recycling_steps(recycling_steps, model):
    """Per-model default trunk-recycling count when --recycling_steps is unset (None).

    Reads RECYCLING_STEPS. An explicit --recycling_steps is honored verbatim for every model.
    Running protenix-v2 at 3 under-recycles its trunk; running protenix-v1 at 10 over-recycles it.
    """
    if recycling_steps is not None:
        return recycling_steps
    return RECYCLING_STEPS.get(model, RECYCLING_STEPS_DEFAULT)


def _resolve_sampling_steps(sampling_steps, model):
    """Per-model default REQUESTED diffusion-sampling steps when --sampling_steps is unset.

    esmfold2/esmfold2-fast request 100, the ESMFold2 paper's benchmark protocol (A.2.11:
    "We use N = 100 which reduces to 68 sampling steps"): the sampler clips the Karras
    schedule at sigma_max=256, so requesting 100 executes 68 denoise steps. Requested is
    not executed for esmfold2: passing 68 literally would execute only 46.

    rf3 requests 50, which is what upstream's inference entry point ships. foundry
    `models/rf3/configs/inference_engine/rf3.yaml` sets `num_steps: 50` alongside
    `n_recycles: 10`, and the engine passes it into the sampler as `num_timesteps`. The
    checkpoint's own `train_cfg.model.net.inference_sampler.num_timesteps` reads 200, but
    that is the training-side value the inference engine overrides, so 200 is not a
    configuration RF3 ships for inference, and every RF3 parity and perf result in this
    repo was produced at 50. The schedule holds `num_steps` entries and the rollout
    consumes consecutive pairs, so 50 executes 49 denoise calls.

    Every other model keeps 200. An explicit --sampling_steps is honored verbatim for
    every model.
    """
    if sampling_steps is not None:
        return sampling_steps
    return SAMPLING_STEPS.get(model, SAMPLING_STEPS_DEFAULT)


# The structure models that degrade sharply folded single-sequence, so `predict` resolves an
# MSA source for them by default rather than silently folding without one (see
# _resolve_msa_default). esmfold2 / esmfold2-fast are deliberately absent: esmfold2 is
# single-sequence with an OPTIONAL MSA and esmfold2-fast ships no MSA encoder at all.
# scripts/release_gate.py reads this so the accuracy gate folds each model the way it is
# actually used, instead of hand-listing the same set a second time.
MSA_DEFAULT_MODELS = ("boltz2", "protenix-v1", "protenix-v2", "mol1", "openfold3", "openbind", "opendde", "opendde-abag",
                     "rf3")

# The models whose worker path actually passes --msa_endpoint to its MSA search
# (grep msa_endpoint in worker.py: _predict_esmfold2_one, _predict_opendde_one,
# _protenix_inputs, _predict_rf3_one, _predict_openfold3_one). boltz2 resolves
# MSAs through main.py's own path, which has no endpoint client. The option help
# is built from this tuple so the two cannot drift: the help used to omit rf3,
# and passing the flag with --model boltz2 was accepted and then died mid-run
# with "Missing MSAs", blaming the user for supplying no source.
MSA_ENDPOINT_MODELS = ("esmfold2", "esmfold2-fast", "protenix-v1", "protenix-v2", "mol1",
                       "openfold3", "openbind", "opendde", "opendde-abag", "rf3")


def _resolve_msa_default(model, use_msa_server, msa_db_path, msa_endpoint,
                         single_sequence, cache, controller, msa_server_url,
                         msa_cache_only=False, msa_dir=None):
    """Resolve the MSA source for MSA-dependent structure models.

    These models degrade sharply folded single-sequence, so ``predict`` must
    never do so silently. Precedence:
      1. ``--single_sequence``: explicit opt-out — fold single-seq, no network.
      2. ``--msa_cache_only``: ``--msa_dir``'s cache is the source; never search.
      3. An explicit source (``--use_msa_server`` / ``--msa_db_path`` /
         ``--msa_endpoint``): use it as given.
      4. A local ColabFold DB auto-detected at ``<cache>/msa_db``: use it, no network.
      5. Otherwise enable the online MSA server, with a one-line notice naming the
         server the sequences are sent to (a privacy concern for e.g. pharma).

    Note on (2): a populated ``--msa_dir`` is NOT by itself a source here, and cannot be
    one — this runs before any input is parsed, so whether every chain is cached is not yet
    knowable. Without the explicit flag a fully-cached offline run therefore falls through
    to (5) and enables the online server, which in turn switches on the multi-chain paired
    search in ``worker.py`` (gated on the same ``want_msa``). That silently deepened a
    benchmark run's MSA by 35-45% over its nominal depth, and made it network-dependent.
    The flag exists so a reproducible run can say "the cache, or fail".

    esmfold2 / esmfold2-fast are single-sequence by design and pass through
    unchanged. Returns the resolved ``(use_msa_server, msa_db_path)``.
    """
    if msa_endpoint and model not in MSA_ENDPOINT_MODELS:
        raise click.BadParameter(
            f"--msa_endpoint is not read by --model {model}; it applies to "
            f"{', '.join(MSA_ENDPOINT_MODELS)}. Use --msa_db_path for a local "
            "ColabFold DB or --use_msa_server for the online one.")
    if model not in MSA_DEFAULT_MODELS:
        return use_msa_server, msa_db_path

    explicit = use_msa_server or msa_db_path or msa_endpoint
    if msa_cache_only:
        if explicit:
            raise click.BadParameter(
                "--msa_cache_only cannot be combined with --use_msa_server / "
                "--msa_db_path / --msa_endpoint: it means the --msa_dir cache is the "
                "only source and nothing is searched.")
        if single_sequence:
            raise click.BadParameter(
                "--msa_cache_only cannot be combined with --single_sequence")
        return False, None
    if single_sequence:
        if explicit:
            raise click.BadParameter(
                "--single_sequence cannot be combined with --use_msa_server / "
                "--msa_db_path / --msa_endpoint")
        return use_msa_server, msa_db_path
    if explicit:
        return use_msa_server, msa_db_path

    # No source given. Prefer a host-local DB, else fall back online. With a controller on
    # this host too: since 66e39622b the submitting process searches every MSA before a chip
    # is leased (worker.prefetch_msas), so skipping the local DB there sent every sequence of
    # a `--controller http://127.0.0.1:...` run to the online server on a host that had
    # UniRef30 installed, and said so only in a notice. A controller on another host keeps
    # the old rule: its workers may not have this path.
    from urllib.parse import urlparse
    local_controller = (not controller
                        or urlparse(controller).hostname in ("127.0.0.1", "localhost", "::1"))
    default_db = Path(cache).expanduser() / "msa_db"
    if local_controller and (default_db / "UNIREF30_READY").exists():
        return use_msa_server, str(default_db)
    if msa_dir:
        # A cached chain is never sent anywhere, so the unconditional notice reads as a
        # privacy claim the run does not make. Say what is actually true: the server is a
        # fallback for whatever --msa_dir does not already hold. Which chains those are is
        # not knowable here (no input has been parsed yet), which is what --msa_cache_only
        # is for.
        click.secho(
            f"MSA: --msa_dir {msa_dir} is the first source; any chain it does not already "
            f"hold is sent to the online MSA server ({msa_server_url}). Use "
            f"--msa_cache_only to fail on a cache miss instead of searching.", fg="yellow")
    else:
        click.secho(
            f"MSA: no local database found; sending input sequences to the online MSA "
            f"server ({msa_server_url}). Use --msa_db_path for an offline database, or "
            f"--single_sequence to fold without an MSA.", fg="yellow")
    return True, msa_db_path


@cli.command()
@click.argument("data", type=click.Path(exists=True))
@click.option("--out_dir", default="./")
@click.option("--cache", default=lambda: os.environ.get("BOLTZ_CACHE", str(Path("~/.boltz").expanduser())))
@click.option("--checkpoint", type=click.Path(exists=True, dir_okay=False), default=None,
              help="Weights to fold with instead of the shipped ones (boltz2, openfold3, "
                   "openbind, protenix-v1/v2, mol1). For openfold3 this can be a checkpoint "
                   "`tt-bio train` wrote.")
@click.option("--accelerator", type=click.Choice(["gpu", "cpu", "tenstorrent"]), default="tenstorrent")
@click.option("--recycling_steps", default=None, type=int,
              help="Trunk recycling iterations. Default: "
                   + _grouped_defaults(RECYCLING_STEPS, RECYCLING_STEPS_DEFAULT, PREDICT_MODELS)
                   + ". " + ", ".join(TRUNK_CYCLES_PLUS_ONE)
                   + " run one more trunk cycle than they are asked for (N recycles = N+1 cycles), "
                     "which is the count the progress view shows.")
@click.option("--sampling_steps", default=None, type=int,
              help="Requested diffusion sampling steps. Default: "
                   + _grouped_defaults(SAMPLING_STEPS, SAMPLING_STEPS_DEFAULT, PREDICT_MODELS)
                   + ". A request of 100 executes 68 (the sigma_max=256 schedule clip) and 50 "
                     "executes 49 (the rollout consumes consecutive schedule pairs). Explicit "
                     "values are honored verbatim.")
@click.option("--diffusion_samples", default=None, type=int,
              help="Structures to generate. Default: "
                   + _grouped_defaults(DIFFUSION_SAMPLES, DIFFUSION_SAMPLES_DEFAULT, PREDICT_MODELS)
                   + ". Samples are denoised in chunks, so device memory stops "
                   "growing once the count passes the chunk width and time grows linearly. See "
                   "docs/sample-scaling.md.")
@click.option("--partial_t", default=0, type=int,
              help="RF3 only. Start the diffusion rollout at schedule index N instead of "
                   "from pure noise, so the rollout refines --partial_structure rather than "
                   "building from scratch. 0 is a normal fold; higher stays closer to the "
                   "input structure. Requires --partial_structure.")
@click.option("--partial_structure", default=None,
              type=click.Path(exists=True, dir_okay=False),
              help="RF3 only. The .cif/.pdb/.json structure --partial_t noises. RF3 reads "
                   "its sequences and coordinates from this file, so it defines the system; "
                   "no MSA is attached to it.")
@click.option("--early_stop_plddt", default=None, type=float,
              help="RF3 only. After the first trunk recycle, score mean pLDDT with the "
                   "confidence head and abandon the target if it is below this. Writes no "
                   "structure and reports early_stopped in the metrics.")
@click.option("--max_parallel_samples", default=5, type=int,   # protenix.DEFAULT_MAX_PARALLEL_SAMPLES
              help="Diffusion samples denoised in one batched forward by boltz2, protenix-v1/v2, "
                   "opendde and opendde-abag; the other models pick their own width. Device memory "
                   "grows linearly in it; if the chip refuses a batch, it halves on its own, down "
                   "to one sample.")
@click.option("--step_scale", default=None, type=float)
@click.option("--output_format", type=click.Choice(["pdb", "cif"]), default="cif")
@click.option("--override", is_flag=True)
@click.option("--seed", default=None, type=int,
              help="Random seed for the diffusion sampler. Default: 0 (101 for an upstream Protenix/Mol-1 JSON "
                   "input, upstream's default).")
@click.option("--use_seeds_in_json", is_flag=True,
              help="Upstream Protenix/Mol-1 JSON input: run every seed in each job's `modelSeeds` instead of "
                   "--seed, one result per seed (upstream's flag of the same name).")
@click.option("--use_template", is_flag=True,
              help="Upstream Protenix/Mol-1 JSON input: use each protein chain's `templatesPath` (.a3m, .hhr or "
                   ".json hits; kalign on PATH for .a3m/.hhr; mmCIFs under $MOL_ROOT_DIR/mmcif, fetched from PDBe "
                   "when missing). Upstream's flag of the same name, off by default.")
@click.option("--use_rna_msa", is_flag=True,
              help="Upstream Protenix/Mol-1 JSON input: use each RNA chain's `unpairedMsa`/`unpairedMsaPath` "
                   "(upstream's flag of the same name; off, an RNA chain is its query row only).")
@_upstream_search_options
@click.option("--use_msa_server", is_flag=True, help="Generate MSAs via ColabFold API (requires internet)")
@click.option("--msa_db_path", default=None, type=click.Path(exists=True), help="Local ColabFold DB for offline MSA (default: auto-detect ~/.boltz/msa_db)")
@click.option("--msa_dir", "msa_dir_opt", default=None, type=click.Path(),
              help="MSA cache directory (default: <out_dir>/msa). Point at a persistent shared "
                   "path to reuse {seq_hash}.a3m across runs and hosts (never re-search a sequence).")
@click.option("--msa_cache_only", is_flag=True,
              help="Treat --msa_dir as the ONLY MSA source: never search (online or local), and "
                   "fail rather than fold a chain single-sequence when its a3m is not cached. Use "
                   "for reproducible benchmark runs, where an unnoticed search changes MSA depth.")
@click.option("--use_envdb", is_flag=True, help="Also search ColabFold environmental database (requires envdb)")
@click.option("--single_sequence", is_flag=True,
              help="Fold single-sequence: skip MSA entirely for boltz2/protenix-v1/protenix-v2/openfold3/"
                   "opendde (no local DB, no online server). Explicit opt-out for batch-screening "
                   "orphan sequences.")
@click.option("--msa_endpoint", default=None, help="tt-bio MSA server URL (http://HOST:PORT) to fetch unpaired a3m from instead of searching locally (see `tt-bio msa-server`). Applies to --model " + "/".join(MSA_ENDPOINT_MODELS) + ".")
@click.option("--msa_server_url", default="https://api.colabfold.com")
@click.option("--msa_pairing_strategy", default="greedy")
@click.option("--msa_server_username", default=None)
@click.option("--msa_server_password", default=None)
@click.option("--api_key_value", default=None)
@click.option("--use_potentials", is_flag=True)
@click.option("--method", default=None)
@click.option("--max_msa_seqs", default=8192, type=int)
@click.option("--subsample_msa", is_flag=True)
@click.option("--num_subsampled_msa", default=1024, type=int)
@click.option("--no_kernels", is_flag=True)
@click.option("--trace/--no_trace", default=None,
              help="Replay a captured ttnn trace of the per-step diffusion device "
                   "stream (lossless; collapses per-step host dispatch). protenix-v1, "
                   "protenix-v2 and opendde. Default on for protenix-v1/v2 on Blackhole, "
                   "off elsewhere; reserves 0.2-0.3 GB of device memory.")
@click.option("--diffusion_trace/--no_diffusion_trace", default=None,
              help="Replay a captured ttnn trace of the per-step diffusion DiT device "
                   "stream (lossless; collapses per-step host dispatch). boltz2 only. "
                   "Default on for Blackhole, off elsewhere; reserves 0.2 GB of device memory.")
@click.option("--use_tfg_guidance", is_flag=True,
              help="opendde and opendde-abag. Guided sampling (OpenDDE 1.2.0): apply the input's "
                   "`constraint:` block (contact pairs or an epitope) by moving the movable "
                   "chains as a rigid body during diffusion, plus physics restraints on every "
                   "step. See docs/constraint-guidance.md.")
@click.option("--trunk_cache", type=click.Path(file_okay=False), default=None,
              help="opendde and opendde-abag. Directory that keeps each fold's trunk output, so "
                   "inputs that differ only in their `constraint:` compute the trunk once.")
@click.option("--write_pae", is_flag=True,
              help="Write <name>_pae.npz per target: the full PAE matrix, PDE and contact "
                   "probabilities wherever the model's heads compute them, with a "
                   "<name>_pae.json sidecar naming every array (docs/confidence-outputs.md)")
@click.option("--contact_cutoff", default=8.0, type=float, show_default=True,
              help="Distance in Angstrom under which --write_pae counts two tokens in contact. "
                   "The written cutoff is the largest distogram bin edge at or below it")
@click.option("--write_pde", is_flag=True, help="Write PDE matrix per target")
@click.option("--write_embeddings", is_flag=True, help="Write s/z embeddings per target")
@click.option("--head", "heads", multiple=True, metavar="FILE.py:NAME",
              help="Run your own output head on each fold's trunk outputs and write what it "
                   "returns to <name>_<NAME>.npz. Repeatable. boltz2 and esmfold2; "
                   "docs/extending.md.")
@click.option("--affinity_mw_correction", is_flag=True)
@click.option("--sampling_steps_affinity", default=200, type=int)
@click.option("--diffusion_samples_affinity", default=5, type=int)
@click.option("--affinity_checkpoint", type=click.Path(exists=True), default=None)
@click.option("--num_devices", default=0, type=int, help="Number of TT devices to use (0=all available)")
@click.option("--devices", "--device_ids", "device_ids", default=None, type=str,
              help="Comma-separated physical TT card ids to fan the folding jobs across, "
                   "e.g. '0,1,2,3' (data-parallel: one pinned worker per card, each an "
                   "untouched single-card fold), the same pattern `tt-bio embed` uses. "
                   "Default: every card on this machine -- unlike `tt-bio embed`, which "
                   "defaults to one, because a fold is big enough to be worth a card.")
@click.option("--host_threads", default=None, type=int,
              help="CPU threads this process may use in total, split across its cards "
                   "(default: all cores). Set this when you run several single-card "
                   "predicts side by side on one host — each would otherwise size its "
                   "thread pools to every core and they would fight for the CPU. Use "
                   "cores//concurrent-predicts.")
@click.option("--fast", is_flag=True, help="Use block-fp8 for some operations (slightly lower precision, faster)")
@click.option("--diffusion_precision", type=click.Choice(["fp32", "bf16"]), default=None,
              help="(Protenix) Precision of the diffusion module. fp32 (default) matches the "
                   "reference; bf16 is ~9%% faster per fold on Wormhole but can pick a different binding "
                   "mode where fp32 is uncertain "
                   "(docs/protenix-diffusion-precision.md).")
@click.option("--debug", is_flag=True, help="Debug mode: no Rich display, no output suppression")
@click.option("--log", is_flag=True, help="With --debug: print per-device stage progress")
@click.option("--report-energy", "report_energy", is_flag=True, help="Report TT device energy and write a power-vs-time plot (single-device TT runs)")
@click.option("--energy-sample-hz", "energy_sample_hz", default=DEFAULT_ENERGY_SAMPLE_HZ, type=float, show_default=True, help="Sampling rate in Hz for power reporting")
@click.option("--energy-metric", "energy_metric", default="both", type=click.Choice(["both", "tdp", "input"]), show_default=True, help="Which power channel(s) to measure")
@click.option("--controller", default=None, help="Submit to a running `tt-bio controller` at URL (e.g. http://127.0.0.1:8765) instead of starting a scheduler for this run. Compute comes from its workers.")
@click.option("--run-id", "run_id", default=None, help="Use this run id on the controller (lets the submitter cancel the run later). Requires --controller.")
@click.option("--owner", "owner", default=None, help="Opaque fairness key (e.g. a hashed session id) the controller uses to fair-share devices across users. Requires --controller.")
@click.option("--model", type=click.Choice(list(PREDICT_MODELS)), default="boltz2", show_default=True,
              help="Structure model. boltz2: MSA + Pairformer (MSA-dependent; MSA on by default). "
                   "esmfold2: ESMC-6B + 48-block trunk + diffusion (single-sequence; optional MSA). "
                   "esmfold2-fast: lighter 24-block checkpoint (single-sequence, no MSA encoder). "
                   "protenix-v1: ByteDance Protenix v0.5.0, AF3-family (Pairformer trunk + atom diffusion), MSA-dependent (MSA on by default). "
                   "protenix-v2: the later Protenix release on the same stack, wider pair track. "
                   "openfold3: OpenFold3 (AF3-family; MSA + template embedder + atom diffusion), "
                   "MSA on by default; polymer chains only, no template search; weights via OF3_CKPT. "
                   "openbind: OpenBind-0, the same stack on the upstream v0.5.0 checkpoint, "
                   "tuned for protein-ligand co-folding; weights via TT_BIO_OPENBIND. "
                   "opendde / opendde-abag: AF3-family co-folding (Protenix-v2 stack + structural-token expander); "
                   "opendde-abag selects the antibody-antigen checkpoint. "
                   "rf3: RoseTTAFold3 (AF3-family; MSA + template embedder + 48-block Pairformer "
                   "+ atom diffusion), MSA on by default; proteins, nucleic acids and ligands. "
                   "af2ig: AlphaFold2 initial-guess, the binder-design selection filter. It takes a "
                   "designed complex (a structure carrying the target and the binder backbone) plus "
                   "the binder sequence, and returns pLDDT, pTM, ipTM, pAE and interface pAE; "
                   "single-sequence, no diffusion, no seed. "
                   "All run on-device via the ttnn pipeline; ligand / affinity options apply to boltz2 only.")
@torch.no_grad()
def predict(data, out_dir, cache, checkpoint, accelerator, recycling_steps, sampling_steps,
            diffusion_samples, partial_t, partial_structure, early_stop_plddt,
            max_parallel_samples, step_scale, output_format, override,
            seed, use_seeds_in_json, use_template, use_rna_msa, use_msa_server, msa_db_path, msa_dir_opt, msa_cache_only, use_envdb, single_sequence, msa_endpoint, msa_server_url, msa_pairing_strategy,
            msa_server_username, msa_server_password, api_key_value, use_potentials,
            method, max_msa_seqs, subsample_msa, num_subsampled_msa, no_kernels, trace, diffusion_trace,
            use_tfg_guidance, trunk_cache, write_pae, contact_cutoff, write_pde, write_embeddings, heads, affinity_mw_correction,
            sampling_steps_affinity, diffusion_samples_affinity, affinity_checkpoint,
            num_devices, device_ids, host_threads, fast, diffusion_precision, debug, log,
            report_energy, energy_sample_hz, energy_metric, controller, run_id, owner, model, **search_tools):
    """Run structure prediction.

    DATA is a YAML/FASTA file or a directory of them.

    The default Boltz-2 path runs an in-process scheduler that dispatches jobs
    to local workers, one per card. With
    --model esmfold2 it instead runs the on-device ttnn ESMFold2 pipeline
    (single-sequence, protein-only) and writes the same output layout.

    \b
    MSA: boltz2, protenix-v1/v2, openfold3 and opendde are MSA-dependent and use an
    MSA by default — a local ColabFold DB (~/.boltz/msa_db) if present, else the
    online ColabFold server (input sequences leave the machine; a notice is
    printed). Pass --msa_db_path for a private offline DB, or --single_sequence
    to skip the MSA. esmfold2 / esmfold2-fast are single-sequence by design.

    \b
    Output:
        msa/                # MSA cache (keyed by sequence hash)
        <model>_results_<name>/   # e.g. protenix_results_prot, boltz2_results_trpcage
            structures/     # one CIF per complex (pLDDT in B-factors)
            results.json    # confidence metrics + affinity

    \b
    Exit status:
        0   every target folded
        1   every target failed
        2   some targets failed, some folded
    """
    # Refuse a size this model is MEASURED not to fold, before anything opens a device. Placed
    # ahead of the model branch so both routes are covered by one call: past this point predict
    # forks into the scheduler path and the Boltz-2 path, and guarding each separately is how one
    # of them ends up unguarded. Only measured ceilings refuse — see tt_bio/size_limits.py.
    # Upstream Protenix / Mol-1 JSON (a list of jobs) is expanded into one YAML input per job, plus a sidecar for
    # what YAML cannot say, before anything else reads `data`: every route below then sees a directory of inputs.
    # Like upstream's -i, `data` may also be a directory of such JSONs; its other inputs fold beside them.
    from tt_bio import protenix_json
    src = Path(data).expanduser()
    lists = [src] if protenix_json.is_job_list(src) else (
        sorted(p for p in src.iterdir() if protenix_json.is_job_list(p)) if src.is_dir() else [])
    if lists:
        staged = Path(out_dir).expanduser() / ".upstream_inputs" / src.stem
        seen = set()
        for f in lists:
            try:
                names = {j.name for j in protenix_json.read_jobs(f)}
                if names & seen:
                    raise ValueError(f"job names {sorted(names & seen)} repeat across the directory's JSON files")
                seen |= names
                f = protenix_json.search(f, staged, use_template, use_rna_msa, **search_tools)
                if use_template:
                    protenix_json.check_template_tools(f)
                protenix_json.stage(f, staged, seeds=[seed] if seed is not None else None,
                                    use_seeds_in_json=use_seeds_in_json)
            except (ValueError, KeyError, AssertionError, FileNotFoundError, RuntimeError) as e:
                raise click.ClickException(f"{f.name}: {e}") from e
        if src.is_dir():
            for p in src.iterdir():
                if p.is_file() and p.suffix.lower() != ".json" and not (staged / p.name).exists():
                    (staged / p.name).symlink_to(p.resolve())
        data = str(staged)
    size_limits.check_input(data, model)

    # These are counts of things to generate; <1 crashes deep in the model
    # (e.g. "reshape tensor of 0 elements" / "Dimension size must be
    # non-negative"). Reject up front with a clear message.
    if diffusion_samples is None:
        diffusion_samples = DIFFUSION_SAMPLES.get(model, DIFFUSION_SAMPLES_DEFAULT)
    if diffusion_samples < 1:
        raise click.BadParameter("--diffusion_samples must be at least 1")
    if partial_t < 0:
        raise click.BadParameter("--partial_t must be >= 0")
    if bool(partial_t) != bool(partial_structure):
        raise click.BadParameter(
            "--partial_t and --partial_structure go together: N>0 needs the structure to "
            "noise, and the structure does nothing without N>0")
    if (partial_t or early_stop_plddt is not None) and model != "rf3":
        raise click.BadParameter(
            "--partial_t and --early_stop_plddt are rf3-only; got --model " + str(model))
    if diffusion_samples_affinity < 1:
        raise click.BadParameter("--diffusion_samples_affinity must be at least 1")
    if max_parallel_samples < 1:
        raise click.BadParameter("--max_parallel_samples must be at least 1")
    _check_recycling_steps(recycling_steps, model)
    if heads:
        # A head is the user's own code, so it runs where they run tt-bio and nowhere else.
        from tt_bio.capabilities import FLAG_READERS
        from tt_bio.heads import resolve as resolve_head

        if model not in FLAG_READERS["--head"]:
            raise click.BadParameter(f"--head is not available for --model {model}: only "
                                     f"{', '.join(FLAG_READERS['--head'])} hands its trunk "
                                     "outputs to the host. See docs/extending.md.")
        if controller:
            raise click.BadParameter("--head runs your code in a local worker; it cannot be "
                                     "sent to a --controller")
        try:
            heads = [resolve_head(h) for h in heads]
        except (ValueError, FileNotFoundError) as e:
            raise click.BadParameter(str(e))

    # Per-model trunk-recycling default (see RECYCLING_STEPS): protenix-v2/opendde/esmfold2/rf3
    # -> 10, protenix-v1 -> 4, boltz2/openfold3 -> 3; --recycling_steps overrides any of them.
    recycling_steps = _resolve_recycling_steps(recycling_steps, model)
    # Per-model requested diffusion steps (see _resolve_sampling_steps): esmfold2 requests
    # 100 (68 executed after the sigma-clip), rf3 50 (upstream's shipped inference
    # engine config), everything else 200.
    sampling_steps = _resolve_sampling_steps(sampling_steps, model)

    use_tt = accelerator == "tenstorrent"
    if fast and not use_tt:
        click.echo("Note: --fast is only used with --accelerator tenstorrent; ignoring.")
    warnings.filterwarnings("ignore", ".*Tensor Cores.*")
    torch.set_float32_matmul_precision("highest")
    Chem.SetDefaultPickleProperties(Chem.PropertyPickleOptions.AllProps)

    if seed is not None:
        random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)

    # A checkpoint tt-bio does not download is checked before the MSA search, so a host
    # without one is told in a second why not and what to use instead.
    if not controller:
        for art in weights.artifacts_for(model):
            if art.source == "manual" and not (checkpoint and art.key == model):
                try:
                    weights.fetch(art.key, root=Path(cache).expanduser())
                except (FileNotFoundError, RuntimeError) as e:
                    raise click.ClickException(str(e))

    # MSA-dependent models (boltz2, protenix-v1/v2, opendde, opendde-abag) must never
    # silently fold single-sequence: resolve a source now (explicit flag > local DB >
    # online fallback) or honor an explicit --single_sequence opt-out. esmfold2 /
    # esmfold2-fast are single-sequence by design and pass through untouched.
    use_msa_server, msa_db_path = _resolve_msa_default(
        model, use_msa_server, msa_db_path, msa_endpoint, single_sequence, cache,
        controller, msa_server_url, msa_cache_only, msa_dir_opt)

    from tt_bio.capabilities import unread_flags

    if model in ("esmfold2", "esmfold2-fast", *PROTENIX_FAMILY, "openfold3", "openbind", "opendde",
                 "opendde-abag", "rf3", "af2ig"):
        # ESMFold2, Protenix, OpenFold3, OpenDDE and RF3 ride the SAME scheduler / worker /
        # progress path as Boltz-2: build a run config, then fan jobs across devices via
        # _local_workers + _dispatch_run (or submit to a running --controller). Only the
        # per-model config differs.
        #
        # Every model on this branch is a ttnn-only port: load_model imports ttnn and opens a
        # chip, with no torch fallback. Passing "tenstorrent" below regardless of --accelerator
        # meant `--accelerator cpu` was accepted and then silently folded ON THE CARD. That is
        # how scripts/full_parity_gate.py's "CPU references" for protenix-v2 and opendde became
        # device folds: fp32 and bf16 references are then the same computation, the integration
        # envelope denominator collapses to 0 and every device residual reads as a false GAP
        # (2026-08-11: a --accelerator cpu regen fold was observed holding /dev/tenstorrent/0
        # open, and its fp32/bf16 references agreed to six decimals). Refuse instead, before
        # any download, job discovery, or controller submission.
        if not use_tt:
            raise click.UsageError(
                f"--model {model} runs on Tenstorrent only (tt-bio has no torch/CPU path for "
                f"it), so --accelerator {accelerator} cannot be honored. Drop the flag to fold "
                f"on the card; --model boltz2 is the one model with a CPU/GPU path."
            )
        for n, on in [("--use_potentials", use_potentials),
                      ("--checkpoint", bool(checkpoint) and model not in (*OF3_FAMILY, *PROTENIX_FAMILY))]:
            if on:
                click.secho(f"Note: --model {model} does not read {n}; ignoring it", fg="yellow")
        # --max_msa_seqs left at its default means "the depth this model already uses", not
        # 8192: protenix-v1/v2, opendde, rf3 and the OF3 family fold the resolved alignment
        # whole, so applying the boltz2/esmfold2 default to them would quietly change every
        # fold they have ever produced. The cap travels only when the user asked for one, and
        # that same signal is what decides whether the "does not read it" note fires.
        msa_cap = (max_msa_seqs if click.get_current_context()
                   .get_parameter_source("max_msa_seqs") is not ParameterSource.DEFAULT
                   else None)
        # Output and limit flags this model does not read, from the one table. --write_pae was
        # already called out for the OF3 family and was a silent no-op everywhere else it is
        # unread: esmfold2 and rf3 accepted it and wrote nothing, --write_pde did nothing on
        # protenix (--write_pae writes both).
        # --contact_cutoff only when it was given: keyed on --write_pae it told every
        # `--write_pae` Protenix user that a flag they never passed was ignored.
        cutoff_given = (click.get_current_context().get_parameter_source("contact_cutoff")
                        is not ParameterSource.DEFAULT)
        for note in unread_flags(model, {"--write_pae": write_pae, "--contact_cutoff": cutoff_given,
                                         "--write_pde": write_pde,
                                         "--write_embeddings": write_embeddings,
                                         "--max_msa_seqs": msa_cap is not None,
                                         "--diffusion_precision": diffusion_precision is not None,
                                         "--use_tfg_guidance": use_tfg_guidance,
                                         "--trunk_cache": trunk_cache is not None}):
            click.secho(note, fg="yellow")
        # On Wormhole ESMFold2's ESMC-6B is block-fp8 in both modes (esmfold2_runtime.load_ttnn_esmfold2):
        # in bf16 it alone needs ~12.8 GB of a chip's 12 GiB. --fast still picks the fold's lever set.
        # AF2-IG is single-sequence on both chains by construction (ColabDesign's binder
        # protocol builds `msa_feat` from the one sequence, and the extra-MSA mask is all
        # zeros), and it samples nothing: no diffusion, no seed, the same input gives the
        # same structure. Say so rather than accept a knob that changes nothing.
        if model == "af2ig":
            src = click.get_current_context().get_parameter_source
            unread = [f"--{n}" for n, on in (("sampling_steps", sampling_steps),
                                             ("diffusion_samples", diffusion_samples))
                      if src(n) is not ParameterSource.DEFAULT]
            if use_msa_server or msa_db_path or msa_endpoint:
                unread.append("the MSA options")
            if unread:
                click.secho(f"Note: --model af2ig does not read {', '.join(unread)}: it folds "
                            f"one sequence per chain and draws no samples.", fg="yellow")
        if model == "esmfold2-fast" and (use_msa_server or msa_db_path):
            click.echo()
            click.secho("Note: --model esmfold2-fast has no MSA encoder; folding single-sequence "
                        "(use --model esmfold2 to use the MSA).", fg="yellow")
        # Protenix-v2 and OpenDDE are MSA-dependent; _resolve_msa_default guarantees a
        # source (local DB or online) is set above unless the user passed
        # --single_sequence, so single-sequence folding here is always an explicit choice.
        data = Path(data).expanduser()
        out_dir_path = Path(out_dir).expanduser()
        out = out_dir_path / predict_results_dir_name(model, data.stem)
        msa_dir = Path(msa_dir_opt).expanduser() if msa_dir_opt else out_dir_path / "msa"
        struct_dir = out / "structures"
        msa_dir.mkdir(parents=True, exist_ok=True)
        struct_dir.mkdir(parents=True, exist_ok=True)

        jobs = discover_jobs(data, struct_dir, output_format, override)
        if not jobs:
            done = discover_jobs(data, struct_dir, output_format, override=True)
            click.echo("All predictions complete" if done else "No input files found")
            return

        # Mol-1 inputs that name a site / contact / exclusion fold on the Mol-1-constraint weights, as upstream's
        # `mol cpred` does. The run takes one checkpoint, so an unconstrained input beside them folds on those weights
        # too, with the conditions all zero; --checkpoint overrides the choice.
        if model == "mol1" and not checkpoint and any(_read_mol1_constraints(j.path) for j in jobs):
            checkpoint = str(weights.fetch("mol1-constraint", root=Path(cache).expanduser() if cache else None))
            click.echo("Inputs carry Mol-1 constraints: folding with the Mol-1-constraint weights.")

        # Read every input NOW and refuse what this model cannot honour, before the weights
        # download and the first device open. The worker checks again -- that is the
        # authoritative point, because the platform submits jobs straight to the controller
        # and never comes through here -- but a user typing a command should not wait two
        # minutes for a model load to be told the yaml key is unsupported.
        results_path = out / "results.json"
        total = len(jobs)
        jobs, refused = _refuse_unfoldable_jobs(jobs, model, results_path, output_format)
        if not jobs:
            _write_error_reports(results_path)
            raise click.ClickException("\n".join(refused.values()))

        # MSA is optional here (single-sequence folding when no source is given), so
        # unlike Boltz-2 it never errors out.
        worker_cfg = {
            "model": model, "fast": fast, "output_format": output_format,
            "diffusion_precision": diffusion_precision,
            "recycling_steps": recycling_steps, "sampling_steps": sampling_steps,
            "diffusion_samples": diffusion_samples, "seed": seed or 0, "trace": trace,
            "use_rna_msa": use_rna_msa, "use_template": use_template,
            "partial_t": partial_t, "partial_structure": partial_structure,
            "early_stop_plddt": early_stop_plddt,
            # Without this key --max_parallel_samples is a silent no-op for every model that
            # rides this config (protenix-v2 / opendde / esmfold2): the worker reads it with
            # cfg.get(), so it saw None on every fold and fell back to the engine default.
            # boltz2 carries it separately, via conf_kwargs["predict_args"], which is why the
            # flag looked plumbed. Lowering it to fit a large target did nothing.
            "max_parallel_samples": max_parallel_samples,
            "msa_dir": str(msa_dir), "struct_dir": str(struct_dir),
            "use_msa_server": use_msa_server, "msa_db_path": msa_db_path, "use_envdb": use_envdb,
            "msa_endpoint": msa_endpoint, "single_sequence": single_sequence,
            "msa_server_url": msa_server_url, "msa_pairing_strategy": msa_pairing_strategy,
            "msa_server_username": msa_server_username, "msa_server_password": msa_server_password,
            "api_key_value": api_key_value, "max_msa_seqs": max_msa_seqs,
            # The cap the USER asked for, None when the flag was left alone. esmfold2,
            # protenix, opendde, rf3 and the OF3 family read this one, so leaving the flag alone
            # folds the depth each model's upstream reads.
            "msa_cap": msa_cap,
            "msa_cache_only": msa_cache_only,
            "write_pae": write_pae, "contact_cutoff": contact_cutoff,
            "use_tfg_guidance": use_tfg_guidance,
            "trunk_cache": str(Path(trunk_cache).expanduser().resolve()) if trunk_cache else None,
            "checkpoint": str(Path(checkpoint).resolve()) if checkpoint else None,
            "heads": list(heads),
        }
        run_payload = {"data": str(data), "out_dir": str(out_dir_path), "result_dir": str(out),
                       "jobs": job_payloads(jobs), "config": worker_cfg, "owner": owner}
        # The search is CPU and database work, so it runs here, before any chip is leased.
        prefetch_msas(model, [j.path for j in jobs], worker_cfg)
        # Fetch this model's weights ONCE here, before fanning out. Skipped in
        # --controller mode: the controller's workers fetch their own.
        if not controller:
            download_all(Path(cache).expanduser(), model, checkpoint)
        if controller:
            failed = _dispatch_to_controller(controller, run_payload, total=len(jobs), results_path=results_path,
                                             struct_dir=struct_dir, model=model, debug=debug, log=log, run_id=run_id)
            _exit_for_failed_jobs(failed + len(refused), total, results_path)
            return
        workers = _local_workers("tenstorrent", num_devices, device_ids, max_workers=max(len(jobs), 1))
        _cap_worker_threads(len(workers), host_threads)
        failed = _dispatch_run(run_payload, workers, total=len(jobs), results_path=results_path,
                               struct_dir=struct_dir, model=model, debug=debug, log=log)
        _exit_for_failed_jobs(failed + len(refused), total, results_path)
        return

    os.environ.setdefault("CUEQ_DEFAULT_CONFIG", "1")
    os.environ.setdefault("CUEQ_DISABLE_AOT_TUNING", "1")

    cache = Path(cache).expanduser()
    cache.mkdir(parents=True, exist_ok=True)
    # In --controller mode this process is a thin client: it never loads a model
    # or touches a device, so skip downloading checkpoints and validating the
    # local MSA DB — the connected workers resolve checkpoints and MSAs on their
    # own hosts. msa_db_path (if given) is passed through for the workers to use.
    if not controller:
        download_all(cache, model)
        if use_envdb and not use_msa_server and not msa_db_path:
            raise RuntimeError(
                "--use_envdb requires offline MSA DB setup.\n"
                "Run: tt-bio msa --db all  (or use --use_msa_server)"
            )
        if msa_db_path and not use_msa_server:
            _validate_offline_msa_db(Path(msa_db_path), require_envdb=use_envdb)

    if use_envdb and use_msa_server:
        click.echo("Note: --use_envdb is only used with offline MSA; ignored with --use_msa_server")

    if use_msa_server:
        msa_server_username = msa_server_username or os.environ.get("BOLTZ_MSA_USERNAME")
        msa_server_password = msa_server_password or os.environ.get("BOLTZ_MSA_PASSWORD")
        api_key_value = api_key_value or os.environ.get("MSA_API_KEY_VALUE")

    data = Path(data).expanduser()
    out_dir_path = Path(out_dir).expanduser()
    out = out_dir_path / predict_results_dir_name(model, data.stem)
    msa_dir = Path(msa_dir_opt).expanduser() if msa_dir_opt else out_dir_path / "msa"
    struct_dir = out / "structures"
    msa_dir.mkdir(parents=True, exist_ok=True)
    struct_dir.mkdir(parents=True, exist_ok=True)
    mol_dir = cache / "mols"

    jobs = discover_jobs(data, struct_dir, output_format, override)
    if not jobs:
        all_jobs = discover_jobs(data, struct_dir, output_format, override=True)
        click.echo("All predictions complete" if all_jobs else "No input files found")
        return

    if method and method.lower() not in const.method_types_ids:
        raise ValueError(f"Unknown method: {method}")

    _diffusion = {"step_scale": step_scale or 1.5, "gamma_0": 0.8, "gamma_min": 1.0,
                  "noise_scale": 1.003, "rho": 7, "sigma_min": 0.0001, "sigma_max": 160.0,
                  "sigma_data": 16.0, "P_mean": -1.2, "P_std": 1.5,
                  "coordinate_augmentation": True, "alignment_reverse_diff": True,
                  "synchronize_sigmas": True}
    _pairformer = {"num_blocks": 64, "num_heads": 16, "dropout": 0.0, "v2": True}
    _msa = {"subsample_msa": subsample_msa, "num_subsampled_msa": num_subsampled_msa,
            "use_paired_feature": True,
            # Required by the non-tenstorrent (PyTorch reference) MSAModule path; the
            # tenstorrent path builds tenstorrent.MSAModule(n_blocks=4,...) and ignores
            # this dict, so adding these keys is a no-op for device runs. Values mirror
            # the boltz2_conf/aff checkpoint hparams so the CPU/host path matches the
            # reference implementation exactly.
            "msa_s": 64, "msa_blocks": 4, "msa_dropout": 0.15, "z_dropout": 0.25,
            "pairwise_head_width": 32, "pairwise_num_heads": 4,
            "activation_checkpointing": True}
    conf_kwargs = dict(
        predict_args={"recycling_steps": recycling_steps, "sampling_steps": sampling_steps,
                      "diffusion_samples": diffusion_samples, "max_parallel_samples": max_parallel_samples,
                      # Boltz's own hook for keeping a forward output: the distogram the
                      # contact probabilities are read from, held only when they are written.
                      **({"keys_dict_out": ["pdistogram"]} if write_pae else {})},
        diffusion_process_args=_diffusion, pairformer_args=_pairformer, msa_args=_msa,
        steering_args={"fk_steering": use_potentials, "physical_guidance_update": use_potentials,
                       "contact_guidance_update": True, "num_particles": 3, "fk_lambda": 4.0,
                       "fk_resampling_interval": 3, "num_gd_steps": 20},
        use_kernels=not no_kernels and accelerator == "gpu", use_tenstorrent=use_tt, trace=bool(trace),
        diffusion_trace=diffusion_trace,
    )
    aff_kwargs = dict(
        predict_args={"recycling_steps": 5, "sampling_steps": sampling_steps_affinity,
                      "diffusion_samples": diffusion_samples_affinity, "max_parallel_samples": 1},
        diffusion_process_args=_diffusion, pairformer_args=_pairformer, msa_args=_msa,
        steering_args={"fk_steering": False, "physical_guidance_update": False,
                       "contact_guidance_update": False, "num_particles": 3, "fk_lambda": 4.0,
                       "fk_resampling_interval": 3, "num_gd_steps": 20},
        affinity_mw_correction=affinity_mw_correction, use_tenstorrent=use_tt, trace=bool(trace),
        diffusion_trace=diffusion_trace,
    )

    results_path = out / "results.json"

    worker_cfg = {
        "conf_ckpt": str(checkpoint or cache / "boltz2_conf.ckpt"),
        "aff_ckpt": str(affinity_checkpoint or cache / "boltz2_aff.ckpt"),
        "conf_kwargs": conf_kwargs, "aff_kwargs": aff_kwargs,
        "mol_dir": str(mol_dir), "msa_dir": str(msa_dir), "struct_dir": str(struct_dir),
        "method": method, "output_format": output_format,
        "write_pae": write_pae, "write_pde": write_pde, "write_embeddings": write_embeddings,
        "heads": list(heads),
        "contact_cutoff": contact_cutoff,
        "use_msa_server": use_msa_server, "msa_db_path": msa_db_path, "use_envdb": use_envdb,
        "msa_server_url": msa_server_url, "msa_pairing_strategy": msa_pairing_strategy,
        "msa_server_username": msa_server_username, "msa_server_password": msa_server_password,
        "api_key_value": api_key_value, "max_msa_seqs": max_msa_seqs,
        "fast": fast, "single_sequence": single_sequence,
        # Seed the spawned worker's RNG (mp.get_context("spawn") does NOT inherit
        # the controller's torch.manual_seed). Without this the boltz-2 diffusion
        # ``torch.randn`` draws are unseeded, so same-seed device runs disagree by
        # the full stochastic spread (measured 1.73 A CA-RMSD on ubiquitin seed 0),
        # which the doc's same-seed diagonal test cannot distinguish from "systematic
        # bf16" -- it is the mp-spawn-worker-unseeded-rng-pattern. worker.py re-seeds
        # once before predict_step (structure -> affinity from one stream, matching
        # the reference's single seed_everything).
        "seed": seed or 0,
    }
    run_payload = {
        "data": str(data),
        "out_dir": str(out_dir_path),
        "result_dir": str(out),
        "jobs": job_payloads(jobs),
        "config": worker_cfg,
        "owner": owner,
    }
    prefetch_msas("boltz2", [j.path for j in jobs], worker_cfg)

    if controller:
        # Thin client: submit to the shared cluster and stream; no local workers,
        # no devices, no energy profiling on this host.
        if report_energy:
            click.echo("Energy profiling is unavailable in --controller mode (no local device); skipping")
        failed = _dispatch_to_controller(controller, run_payload, total=len(jobs), results_path=results_path,
                                         struct_dir=struct_dir, model=model, debug=debug, log=log, run_id=run_id)
        _exit_for_failed_jobs(failed, len(jobs), results_path)
        return

    workers = _local_workers(
        "tenstorrent" if use_tt else accelerator,
        num_devices, device_ids, max_workers=max(len(jobs), 1),
    )
    devices = [int(w.device_id) for w in workers if w.accelerator == "tenstorrent"]
    _cap_worker_threads(len(workers), host_threads)

    energy_profiler = None
    if report_energy:
        if not use_tt:
            click.echo("Energy profiling currently requires --accelerator=tenstorrent; skipping")
        elif len(devices) != 1:
            click.echo("Energy profiling currently supports one TT device only; skipping")
        else:
            try:
                energy_profiler = PowerProfiler(
                    device_id=devices[0],
                    sample_hz=energy_sample_hz,
                    input_sample_hz=energy_sample_hz,
                    metric_mode=energy_metric,
                )
                energy_profiler.start()
                click.echo(
                    f"Energy profiler: device={devices[0]} metric={energy_metric} hz={energy_sample_hz:.2f}"
                )
            except Exception as e:
                click.echo(f"Energy profiler unavailable: {e}")
                energy_profiler = None

    failed = _dispatch_run(run_payload, workers, total=len(jobs), results_path=results_path,
                           struct_dir=struct_dir, model=model, debug=debug, log=log)

    if energy_profiler is not None:
        energy_profiler.stop()
        summary = energy_profiler.summarize()
        energy_csv_path = out / "power_profile.csv"
        energy_plot_path = out / "power_profile.png"
        energy_profiler.write_csv(energy_csv_path)
        click.echo("\nEnergy summary (one TT device)")
        click.echo(f"  device_id:      {devices[0]}")
        if summary.energy_j is not None:
            click.echo("  tdp_metric:")
            click.echo(f"    samples:      {summary.samples}")
            click.echo(f"    duration_s:   {summary.duration_s:.3f}")
            click.echo(f"    energy_j:     {summary.energy_j:.3f}")
            click.echo(f"    energy_wh:    {summary.energy_wh:.6f}")
            click.echo(f"    avg_power_w:  {summary.avg_w:.3f}")
            click.echo(f"    peak_power_w: {summary.peak_w:.3f}")
            click.echo(f"    min_power_w:  {summary.min_w:.3f}")
            click.echo(f"    source:       {energy_profiler.source}")
        if summary.input_energy_j is not None:
            click.echo("  input_power_metric:")
            click.echo(f"    samples:      {summary.input_samples}")
            click.echo(f"    duration_s:   {summary.input_duration_s:.3f}")
            click.echo(f"    energy_j:     {summary.input_energy_j:.3f}")
            click.echo(f"    energy_wh:    {summary.input_energy_wh:.6f}")
            click.echo(f"    avg_power_w:  {summary.input_avg_w:.3f}")
            click.echo(f"    peak_power_w: {summary.input_peak_w:.3f}")
            click.echo(f"    min_power_w:  {summary.input_min_w:.3f}")
            click.echo(f"    source:       {energy_profiler.input_power_source}")
        if energy_profiler.input_power_note:
            click.echo(f"  input_power:    {energy_profiler.input_power_note}")
        click.echo(f"  power_csv:      {energy_csv_path}")
        if energy_profiler.error:
            click.echo(f"  sampler_note:   {energy_profiler.error}")
        wrote_plot = energy_profiler.write_plot(
            energy_plot_path,
            title=f"TT device {devices[0]} power vs time",
        )
        click.echo(f"  power_plot:     {energy_plot_path}" if wrote_plot else "  power_plot:     failed (matplotlib not available)")

    _exit_for_failed_jobs(failed, len(jobs), results_path)


@cli.command()
@click.option("--max_seq", default=1024, type=int, help="Maximum sequence length to warm up")
@click.option("--max_msa", default=16384, type=int, help="Maximum MSA depth to warm up")
@click.option("--n_samples", default=1, type=int, help="Diffusion batch (multiplicity)")
@click.option("--cache", default=lambda: os.environ.get("BOLTZ_CACHE", str(Path("~/.boltz").expanduser())))
@torch.no_grad()
def warmup(max_seq, max_msa, n_samples, cache):
    """Pre-compile all ttnn kernels for Boltz-2 inference."""
    import gc

    _require_ttnn()
    from tt_bio.tenstorrent import (
        WeightScope, PairformerModule, MSAModule, DiffusionModule,
        PAIRFORMER_PAD_MULTIPLE as SEQ_PAD, MSA_PAD_MULTIPLE as MSA_PAD,
        MAX_ATOMS_PER_TOKEN,
    )
    from tt_bio.token_axis import msa_ladder
    from tt_bio.boltz2 import get_indexing_matrix

    seq_bk = list(range(SEQ_PAD, max_seq + 1, SEQ_PAD))
    # The depth axis pads to a ladder below MSA_PAD and to multiples of it above, so warm both:
    # a rung this loop skips is a rung the first real fold pays the compile for.
    ladder = msa_ladder()
    msa_bk = [d for d in ladder if d <= max_msa] + list(range(2 * MSA_PAD, max_msa + 1, MSA_PAD))

    click.echo(f"seq  buckets ({SEQ_PAD}): {seq_bk}")
    click.echo(f"msa  buckets (ladder {list(ladder)}, then multiples of {MSA_PAD}): {msa_bk}")
    click.echo("Loading checkpoint …")

    state = torch.load(
        Path(cache) / "boltz2_conf.ckpt",
        map_location="cpu", mmap=True, weights_only=False,
    )["state_dict"]

    total = time.time()

    click.echo(f"\n[1/4] Pairformer (z=128) — {len(seq_bk)} buckets")
    pf = PairformerModule(1, 32, 4, 24, 16, True)
    pf.load_state_dict(WeightScope.wrap(state).child("pairformer_module").as_dict(), strict=False)
    for seq in seq_bk:
        t = time.time()
        pf.reset_static_cache()
        actual = seq - 1
        pf(torch.randn(1, actual, 384),
           torch.randn(1, actual, actual, 128),
           mask=torch.ones(1, actual))
        click.echo(f"  seq={actual:>5}→{seq:>5}  {time.time()-t:5.1f}s")
    del pf; gc.collect()

    click.echo(f"\n[2/4] Template Pairformer (z=64) — {len(seq_bk)} buckets")
    pf_tpl = PairformerModule(1, 32, 4, None, None, False)
    pf_tpl.load_state_dict(WeightScope.wrap(state).child("template_module.pairformer").as_dict(), strict=False)
    for seq in seq_bk:
        t = time.time()
        pf_tpl.reset_static_cache()
        actual = seq - 1
        pf_tpl(None, torch.randn(1, actual, actual, 64))
        click.echo(f"  seq={actual:>5}→{seq:>5}  {time.time()-t:5.1f}s")
    del pf_tpl; gc.collect()

    n = len(seq_bk) * len(msa_bk)
    click.echo(f"\n[3/4] MSA — {n} combos ({len(seq_bk)} seq × {len(msa_bk)} msa)")
    msa_mod = MSAModule(1, 32, 8, 32, 4)
    msa_mod.load_state_dict(WeightScope.wrap(state).child("msa_module").as_dict(), strict=False)
    for seq in seq_bk:
        actual_seq = seq - 1
        for n_msa_val in msa_bk:
            actual_msa = n_msa_val - 1
            t = time.time()
            msa_mod.reset_static_cache()
            try:
                feats = {
                    "msa": torch.randint(33, (1, actual_msa, actual_seq)),
                    "has_deletion": torch.zeros(1, actual_msa, actual_seq, dtype=torch.bool),
                    "deletion_value": torch.zeros(1, actual_msa, actual_seq),
                    "msa_paired": torch.zeros(1, actual_msa, actual_seq),
                    "msa_mask": torch.ones(1, actual_msa, actual_seq),
                    "token_pad_mask": torch.ones(1, actual_seq),
                }
                msa_mod(torch.randn(1, actual_seq, actual_seq, 128),
                        torch.ones(1, actual_seq, 384), feats)
                click.echo(f"  seq={actual_seq:>5}→{seq:>5} msa={actual_msa:>5}→{n_msa_val:>5}  {time.time()-t:5.1f}s")
            except Exception as e:
                click.echo(f"  seq={actual_seq:>5}→{seq:>5} msa={actual_msa:>5}→{n_msa_val:>5}  SKIP ({type(e).__name__})")
    del msa_mod; gc.collect()

    B = n_samples
    W, H = 32, 128
    diff_sd = WeightScope.wrap(state).child("structure_module.score_model").as_dict()
    click.echo(f"\n[4/4] Diffusion — {len(seq_bk)} buckets (n_samples={B})")
    for seq in seq_bk:
        actual_seq = seq - 1
        N = seq * MAX_ATOMS_PER_TOKEN
        NW = N // W
        t = time.time()
        try:
            diff = DiffusionModule()
            diff.load_state_dict(diff_sd, strict=False)
            diff(
                torch.randn(B, N, 3), torch.randn(B),
                torch.randn(1, actual_seq, 384), torch.randn(1, actual_seq, 384),
                torch.randn(1, N, 128), torch.randn(1, N, 128),
                torch.randn(1, NW, W, H, 12),
                torch.randn(1, actual_seq, actual_seq, 384),
                torch.randn(1, NW, W, H, 12),
                get_indexing_matrix(NW, W, H, "cpu"),
                torch.ones(1, N), torch.ones(1, N, actual_seq),
            )
            click.echo(f"  seq={actual_seq:>5}→{seq:>5} atoms={N:>6}  {time.time()-t:5.1f}s")
        except Exception as e:
            click.echo(f"  seq={actual_seq:>5}→{seq:>5} atoms={N:>6}  SKIP ({type(e).__name__})")
        del diff; gc.collect()

    click.echo(f"\nDone — {time.time()-total:.0f}s total")


def _dispatch_embed_to_controller(controller_url: str, sequences: dict, *, model: str,
                                  out: Path, out_format: str, pool: str, return_logits: bool,
                                  fast: bool, batch_size: int, owner: str | None,
                                  logits_shape: str | None = None) -> None:
    """Shard ``sequences`` across whatever workers are already connected to
    ``controller_url`` and reassemble their embeddings under ``out``.

    Rides the exact same run/lease/stream machinery as predict/design
    (``_dispatch_to_controller``) — a worker keeps its ESMC model resident
    across leases (see ``worker._WorkerState``), so a warm fleet serves this
    call with no weight reload, unlike the per-call subprocess ``--devices``
    fanout (``esmc.embed_multicard``).
    """
    import yaml

    from tt_bio import esmc

    client, online = connect_controller(controller_url)

    items = list(sequences.items())
    # SaProt's payload is an (aa, 3di) pair, ESMC's a bare string. Sort on the AA
    # length either way, and dump the pair as a 2-list: yaml.safe_dump cannot
    # represent a tuple, and the worker reads it back with saprot.read_shard_yaml.
    paired = any(not isinstance(v, str) for v in sequences.values())
    key = (lambda it: len(it[1][0])) if paired else (lambda it: len(it[1]))
    shards = esmc._shard_by_length(items, max(1, min(online, len(items))), key=key)
    jobs = [
        {"id": f"shard_{i}", "name": f"shard_{i}.yaml",
         "input_b64": base64.b64encode(yaml.safe_dump(
             {k: (list(v) if not isinstance(v, str) else v) for k, v in shard}).encode()).decode()}
        for i, shard in enumerate(shards) if shard
    ]
    worker_cfg = {"model": model, "fast": fast, "pool": pool,
                  "return_logits": return_logits, "batch_size": batch_size,
                  "output_format": out_format}
    results_path = out / "results.json"
    run_payload = {"data": f"{len(items)} sequence(s)", "out_dir": str(out), "result_dir": str(out),
                  "jobs": jobs, "config": worker_cfg, "owner": owner}
    click.echo(f"Dispatching {len(jobs)} shard(s) covering {len(items)} sequence(s) "
              f"{'(fast) ' if fast else ''}to {online} worker(s) at {controller_url}")
    _dispatch_to_controller(controller_url, run_payload, total=len(jobs), results_path=results_path,
                            struct_dir=out, model=model, debug=False, log=False)

    rows = [r for r in _load_results_resilient(results_path) if r.get("status") == "ok"]
    if not rows:
        raise click.ClickException("Every embed shard failed — see the errors above.")

    if out_format == "parquet":
        import pandas as pd

        frames = [pd.read_parquet(out / f"{r['id']}.parquet") for r in rows]
        pd.concat(frames, ignore_index=True).to_parquet(out / "embeddings.parquet")
        for r in rows:
            (out / f"{r['id']}.parquet").unlink(missing_ok=True)
        click.echo(f"Wrote {out / 'embeddings.parquet'}")

    id_lengths = [pair for r in rows for pair in zip(r["ids"], r["lengths"])]
    d_model = next((r["d_model"] for r in rows if r.get("d_model")), 0)
    esmc.write_manifest_for(id_lengths, d_model, out / "manifest.json", model=model, pool=pool,
                           fast=fast, out_format=out_format, return_logits=return_logits,
                           logits_shape=logits_shape or esmc.LOGITS_SHAPE)
    click.echo(f"Done — {sum(r['n_sequences'] for r in rows)} sequence(s), d_model={d_model} "
               f"→ {out} (see manifest.json)")


@cli.command("embed")
@click.argument("data")
@click.option("--model", type=click.Choice(list(EMBED_MODELS)),
              default="esmc-600m", show_default=True,
              help="ESMC protein-LM variant (sequence embeddings via the LM trunk alone).")
@click.option("--out_dir", default="./embeddings", show_default=True)
@click.option("--format", "out_format", type=click.Choice(["npz", "parquet"]),
              default="npz", show_default=True,
              help="npz: one <id>.npz per sequence (per-residue + pooled [+logits]). "
                   "parquet: a single embeddings.parquet of the pooled vectors.")
@click.option("--pool", type=click.Choice(["mean", "max", "cls"]), default="mean",
              show_default=True, help="Pooling for the fixed-size per-sequence vector.")
@click.option("--logits", "return_logits", is_flag=True,
              help="Also write per-residue sequence-head logits (esmc-300m/600m only).")
@click.option("--fast", is_flag=True,
              help="Use block-fp8 weights (faster, slightly lower precision).")
@click.option("--batch_size", default=8, show_default=True,
              help="Sequences per device forward (300M/600M). Larger values amortise "
                   "compile/dispatch over more sequences. Padding is masked, so a "
                   "sequence's embedding does not depend on what it shares a batch with, "
                   "but the batch's bucketed length does set the bf16 reduction order: a "
                   "37-residue sequence batched with a 200-residue one moves by 3.1e-2, "
                   "PCC 0.9987. Batch it alone for a bit-exact rerun.")
@click.option("--devices", default=None,
              help="Comma-separated physical TT card ids to shard the sequences across, "
                   "e.g. '0,1,2,3'. Runs one pinned subprocess per card (data-parallel); "
                   "results are reassembled in input order. Default: ONE card, because each "
                   "card spends about 9 s starting up, so fanning out only pays from a few "
                   "hundred sequences: on a 4x p150a, ESMC-6B took 1024 sequences from 139 s "
                   "to 78 s, but 64 sequences from 37 s to 39 s. Ignored with --controller.")
@click.option("--controller", default=None,
              help="Submit to a running `tt-bio controller` instead of spawning local "
                   "subprocess shards. Workers keep the ESMC model resident across calls, so repeated embed runs against the same "
                   "controller skip the weight reload that otherwise dominates wall-clock for "
                   "large models.")
@click.option("--owner", default=None,
              help="Opaque fairness key the controller uses to fair-share workers across users. "
                   "Requires --controller.")
@torch.no_grad()
def embed_cmd(data, model, out_dir, out_format, pool, return_logits, fast, batch_size, devices,
              controller, owner):
    """Compute ESMC protein-language-model embeddings for protein sequences.

    DATA is a FASTA file, a directory of them, a YAML file (a flat
    ``{id: sequence}`` mapping), or a single bare protein sequence string.
    Runs the ESMC LM trunk alone (no folding head, no MSA) on this machine's
    TT device and writes per-residue and pooled embeddings.

    \b
    Output (--out_dir, default ./embeddings):
        <id>.npz            # per-residue [L,d] + pooled [d] (+ logits) — one per sequence
        embeddings.parquet  # pooled vectors, one row per sequence (--format parquet)
        manifest.json       # model/pool/shapes/dtype + which file holds each sequence
    """
    # Before _require_ttnn and before any device open: esmc-6b has a measured DRAM ceiling
    # (its 6B weights nearly fill the chip), so an oversized sequence is refused here rather
    # than OOMing after the weights are resident.
    size_limits.check_input(data, model, fast=fast)
    _require_ttnn()  # ESMC runs on the TT device only; fail clearly without the wheel
    if devices and "TT_VISIBLE_DEVICES" not in os.environ:
        _ids = [x for x in str(devices).split(",") if x.strip()]
        if len(_ids) == 1:
            # Pin visibility BEFORE importing esmc (ttnn binds TT_VISIBLE_DEVICES
            # at import, and esmc imports ttnn at module scope). Without this,
            # ``embed --devices 2`` silently runs on card 0 (get_device defaults
            # to logical 0); setting TT_BIO_LOGICAL_DEVICE_ID instead would leave
            # the full cluster visible, and two concurrent single-card embeds
            # deadlock on UMD CHIP_IN_USE mutexes during cluster discovery.
            os.environ["TT_VISIBLE_DEVICES"] = _ids[0]
    from tt_bio import esmc

    try:
        seqs = esmc.load_sequences(data)
    except ValueError as e:
        raise click.ClickException(str(e))

    if return_logits and model == "esmc-6b":
        click.secho("Note: --logits is unavailable for esmc-6b (no sequence head); ignoring.",
                    fg="yellow")
        return_logits = False

    out = Path(out_dir).expanduser()
    out.mkdir(parents=True, exist_ok=True)

    if controller:
        if devices:
            click.secho("Note: --devices is ignored with --controller (device topology comes "
                        "from connected workers).", fg="yellow")
        _dispatch_embed_to_controller(controller, seqs, model=model, out=out, out_format=out_format,
                                      pool=pool, return_logits=return_logits, fast=fast,
                                      batch_size=batch_size, owner=owner)
        return

    device_list = None
    if devices:
        from tt_bio import runtime
        device_list = runtime.detect_tenstorrent_devices(devices, 0, len(seqs))

    try:
        if device_list and len(device_list) > 1:
            click.echo(f"Sharding {len(seqs)} sequence(s) across cards "
                       f"{device_list}{' (fast)' if fast else ''} → {out}")
            results = esmc.embed(seqs, model=model, devices=device_list, fast=fast,
                                 return_logits=return_logits, pool=pool, batch_size=batch_size)
        else:
            ensure_p300_mesh_descriptor()
            click.echo(f"Loading {model}{' (fast)' if fast else ''} …")
            # A trace region is reserved only where a captured trace could be replayed. It comes
            # off every DRAM bank -- see esmc.trace_pays.
            m = esmc.load_esmc(model, fast=fast, trace=esmc.trace_pays(seqs))
            click.echo(f"Embedding {len(seqs)} sequence(s) → {out}")
            results = esmc.embed_sequences(m, seqs, return_logits=return_logits, pool=pool,
                                           batch_size=batch_size)
    except ValueError as e:
        raise click.ClickException(str(e))

    if out_format == "npz":
        esmc.write_npz_many(results, out)
    if out_format == "parquet":
        esmc.write_parquet(results, out / "embeddings.parquet")
        click.echo(f"Wrote {out / 'embeddings.parquet'}")
    esmc.write_manifest(results, out / "manifest.json", model=model, pool=pool, fast=fast,
                        out_format=out_format, return_logits=return_logits)
    click.echo(f"Done — {len(results)} sequence(s), d_model={results[0].pooled.shape[0]} "
               f"→ {out} (see manifest.json)")


@cli.command("affinity")
@click.argument("data", type=click.Path(exists=True, path_type=Path))
@click.option("--model", type=click.Choice(list(AFFINITY_MODELS)), default="nesso1",
              show_default=True,
              help="nesso1: coarse-grained protein-ligand affinity. No coordinates — "
                   "it predicts a soft distogram and reads the affinity off that.")
@click.option("--out_dir", default="./affinity", show_default=True, type=click.Path(path_type=Path))
@click.option("--accelerator", type=click.Choice(["tenstorrent", "cpu"]), default="tenstorrent",
              show_default=True, help="cpu runs the torch reference; it is ~5x slower.")
@click.option("--trunk", type=click.Choice(["fp32", "bf16"]), default="bf16", show_default=True,
              help="Precision of the 48-block trunk. bf16 is ~6x faster and no less accurate "
                   "from 276 tokens up; fp32 is the more faithful arm below ~150 tokens and "
                   "runs out of DRAM at 1044. See docs/nesso1.md.")
@click.option("--recycling_steps", default=5, show_default=True,
              help="Trunk recycling iterations; the shipped checkpoint uses 5 (6 passes).")
@click.option("--tokens_budget", default=256, show_default=True,
              help="Pocket crop budget. The crop runs after the first trunk pass and pins "
                   "the token count for the remaining passes; it is load-bearing for "
                   "correctness on large targets, not just for speed.")
@click.option("--num_workers", default=0, show_default=True,
              help="Processes for YAML parsing; 0 parses inline. Inline is the default because "
                   "it is the reproducible one: RDKit takes its conformer embedding seed from "
                   "the process RNG state, so a pool changes the ligand geometry. Parsing is "
                   "milliseconds against a multi-second forward, so the pool buys nothing here.")
@click.option("--seed", default=None, type=int,
              help="Featurization seed. Defaults to a fixed value so a screen is repeatable; "
                   "the featurizer applies a random roto-translation per conformer, which is "
                   "why upstream is not reproducible run to run. Pass -1 for that behaviour.")
@click.option("--ccd", default=None, type=click.Path(path_type=Path),
              help="Path to ccd.pkl. Auto-discovered next to the checkpoint if omitted.")
@click.option("--cache", default=None, type=click.Path(path_type=Path),
              help="HuggingFace cache dir for the checkpoint and the ESM-2 encoder.")
@click.option("--devices", "--device_ids", "devices", default=None,
              help="Comma-separated physical TT card ids to spread a screen across, e.g. "
                   "'0,1,2,3'. Default: every card on this machine, never more cards than inputs.")
@click.option("--host_threads", default=None, type=int,
              help="CPU threads this process may use (default: all cores, split evenly between "
                   "the cards of a multi-card screen).")
@click.option("--shard", default=None, hidden=True,
              help="I/N: score every N-th input from the I-th (one card of a multi-card screen).")
@torch.no_grad()
def affinity_cmd(data, model, out_dir, accelerator, trunk, recycling_steps, tokens_budget,
                 num_workers, seed, ccd, cache, devices, host_threads, shard):
    """Predict protein-ligand binding affinity without folding a structure.

    DATA is a YAML file or a directory of them. Each needs ``version: 1``, at least one
    protein and one ligand, and a ``properties.affinity.binder`` naming the ligand to
    score. A directory is a screen: the model loads once and stays resident, so many
    ligands against one target pay the weight load and the kernel compile a single time.
    A screen spreads over every card on the machine, one process per card (--devices).

    \b
    Output (--out_dir, default ./affinity):
        <id>_affinity.json  # the scalars for one input
        affinity.csv        # one row per input, for a screen
        processed/          # parsed structures, conformers and ESM-2 embeddings
    """
    size_limits.check_input(data, model)
    # The affinity yaml is the Boltz-2 one, so it can carry blocks Nesso-1 does not read.
    # It already warns about protein keys it drops; a `constraints:` block was the one that
    # went by in silence. Same table as predict, same wording, one line.
    from tt_bio.capabilities import check_capabilities
    from tt_bio.nesso1_input import find_yamls

    yamls = find_yamls(Path(data))
    for yp in yamls:
        check_capabilities(yp, None, model)
    out = Path(out_dir).expanduser()
    cards = _local_cards(devices, len(yamls)) if accelerator == "tenstorrent" and not shard else []
    if len(cards) > 1:
        _affinity_across_cards(click.get_current_context(), data, yamls, out, cards)
        return
    _pin_one_card(",".join(map(str, cards)) or devices, "nesso1")
    _cap_worker_threads(1, host_threads)
    bind_host_threads()
    use_tt = accelerator == "tenstorrent"
    if use_tt:
        _require_ttnn()
        ensure_p300_mesh_descriptor()
    from tt_bio.nesso1 import DEFAULT_SEED, REPORTED_SCALARS, screen

    # --trunk picks the device pairformer; the torch path is fp32 whatever it says.
    click.echo(f"Loading {model} ({f'tenstorrent, trunk {trunk}' if use_tt else 'cpu, fp32'}) …")
    try:
        rows = screen(
            data, out,
            use_tenstorrent=use_tt,
            trunk_fp32=trunk == "fp32",
            recycling_steps=recycling_steps,
            tokens_budget=tokens_budget,
            num_workers=num_workers,
            ccd_pkl=ccd,
            cache=cache,
            seed=None if seed == -1 else (DEFAULT_SEED if seed is None else seed),
            shard=tuple(map(int, shard.split("/"))) if shard else (0, 1),
            progress=lambda r: click.echo(
                f"  {r['id']}: affinity {r['affinity_pred_value']:.3f} "
                f"p(binder) {r['affinity_probability_binary']:.3f} "
                f"({r['n_tokens']} tokens, {r['seconds']:.1f}s)"
                if "affinity_pred_value" in r else f"  {r['id']}: {r.get('error')}"),
        )
    except (FileNotFoundError, ValueError) as e:
        raise click.ClickException(str(e))

    _write_affinity_csv(out, rows)


def _write_affinity_csv(out: Path, rows: list[dict]) -> None:
    """affinity.csv for a screen, one row per input; exits 1 when any input failed."""
    import csv

    from tt_bio.nesso1 import REPORTED_SCALARS

    csv_path = out / "affinity.csv"
    cols = ["id", "n_tokens", "seconds", *REPORTED_SCALARS]
    with csv_path.open("w", newline="") as fh:
        # csv quotes an error message's commas; a plain join split them into extra columns.
        w = csv.writer(fh)
        w.writerow([*cols, "error"])
        for r in rows:
            w.writerow([r.get(c, "") for c in cols] + [r.get("error", "")])
    ok = [r for r in rows if not r.get("error")]
    click.echo(f"Done — {len(ok)}/{len(rows)} scored → {csv_path}")
    if len(ok) != len(rows):
        raise SystemExit(1)


def _affinity_across_cards(ctx, data, yamls: list[Path], out: Path, cards: list[int]) -> None:
    """One affinity process per card, each scoring every len(cards)-th input, merged into one
    out_dir. Same as running one screen per card by hand, which is what users did before."""
    import csv
    import subprocess

    n = len(cards)
    click.echo(f"Screening {len(yamls)} input(s) across cards {cards} → {out}")
    argv = []
    for p in ctx.command.params:  # forward every option the user gave, except the card split
        v = ctx.params[p.name]
        if (p.name in ("data", "devices", "out_dir", "shard", "host_threads")
                or ctx.get_parameter_source(p.name).name == "DEFAULT"):
            continue
        argv += [p.opts[0]] if v is True else [p.opts[0], str(v)]
    threads = ctx.params["host_threads"] or max(1, (os.cpu_count() or n) // n)
    parts = [out / f".card{c}" for c in cards]
    procs = [subprocess.Popen([_sys.executable, "-m", "tt_bio.main", "affinity", str(data), *argv,
                               "--devices", str(c), "--shard", f"{i}/{n}", "--out_dir", str(d),
                               "--host_threads", str(threads)])
             for i, (c, d) in enumerate(zip(cards, parts))]
    rcs = [p.wait() for p in procs]
    rows, order = [], {y.stem: i for i, y in enumerate(yamls)}
    for c, d, rc in zip(cards, parts, rcs):
        if not (d / "affinity.csv").exists():
            raise click.ClickException(f"card {c} failed (exit {rc}) before scoring anything; "
                                       f"its files are in {d}")
        # rc 1 is "some input failed"; those rows carry their error and are merged like any other.
        with (d / "affinity.csv").open() as fh:
            rows += list(csv.DictReader(fh))
        for f in d.glob("*_affinity.json"):
            f.replace(out / f.name)
        if (d / "processed").exists():
            (out / "processed").mkdir(parents=True, exist_ok=True)
            (d / "processed").replace(out / "processed" / f"card{c}")
        shutil.rmtree(d, ignore_errors=True)
    _write_affinity_csv(out, sorted(rows, key=lambda r: order.get(r["id"], len(order))))


@cli.command("saprot")
@click.argument("data")
@click.option("--model", type=click.Choice(list(SAPROT_MODELS)),
              default="saprot-650m", show_default=True,
              help="SaProt structure-aware protein-LM variant (ESM-2 over a fused "
                   "AA+Foldseek-3Di vocabulary).")
@click.option("--structure", default=None,
              help="PDB/cif file or a directory of <id>.pdb/.cif files for the 3Di "
                   "structural tokens. Residues the structure does not resolve get '#', "
                   "and a structure of a different sequence is refused. Omit for "
                   "sequence-only mode (3Di = '#', lower accuracy for 35M/650M; the 1.3B "
                   "works sequence-only).")
@click.option("--foldseek", "foldseek_bin", default=None,
              help="Path to the foldseek binary that computes the 3Di tokens for "
                   "--structure. Default: $FOLDSEEK_BIN, else foldseek on PATH.")
@click.option("--out_dir", default="./embeddings", show_default=True)
@click.option("--format", "out_format", type=click.Choice(["npz", "parquet"]),
              default="npz", show_default=True,
              help="npz: one <id>.npz per sequence (per-residue + pooled [+logits]). "
                   "parquet: a single embeddings.parquet of the pooled vectors.")
@click.option("--pool", type=click.Choice(["mean", "max", "cls"]), default="mean",
              show_default=True, help="Pooling for the fixed-size per-sequence vector.")
@click.option("--logits", "return_logits", is_flag=True,
              help="Also write per-residue MLM logits [L, 446].")
@click.option("--fast", is_flag=True,
              help="Use block-fp8 weights (faster, slightly lower precision).")
@click.option("--batch_size", default=8, show_default=True,
              help="Sequences per device forward. Padding is masked, so a sequence's "
                   "embedding does not depend on what it shares a batch with, but the "
                   "batch's bucketed length sets the bf16 reduction order (same as "
                   "`tt-bio embed`). Batch it alone for a bit-exact rerun.")
@click.option("--devices", default=None,
              help="Comma-separated physical TT card ids to shard the sequences across, "
                   "e.g. '0,1,2,3'. Runs one pinned subprocess per card (data-parallel); "
                   "results are reassembled in input order. Default: ONE card, because each "
                   "card spends about 9 s starting up, so fanning out only pays from a few "
                   "hundred sequences: on a 4x p150a, ESMC-6B took 1024 sequences from 139 s "
                   "to 78 s, but 64 sequences from 37 s to 39 s. Ignored with --controller.")
@click.option("--controller", default=None,
              help="Submit to a running `tt-bio controller` instead of spawning local "
                   "subprocess shards. Sequence-only "
                   "in this path (structures never leave the submitting client). Workers keep "
                   "the SaProt model resident across calls, so repeated runs against the same "
                   "controller skip the weight reload.")
@click.option("--owner", default=None,
              help="Opaque fairness key the controller uses to fair-share workers across users. "
                   "Requires --controller.")
@torch.no_grad()
def saprot_cmd(data, model, structure, foldseek_bin, out_dir, out_format, pool,
               return_logits, fast, batch_size, devices, controller, owner):
    """Compute SaProt structure-aware protein-language-model embeddings.

    SaProt is an ESM-2 encoder over a fused amino-acid + Foldseek-3Di
    vocabulary (446 tokens): each residue is one of 20 AA x 21 3Di states. DATA
    is a FASTA file, a directory of FASTA files, or a single bare protein
    sequence. With ``--structure``, foldseek computes the 3Di tokens from the
    structure (PDB/cif); without it, SaProt runs sequence-only (3Di = '#').

    \b
    Output (--out_dir, default ./embeddings):
        <id>.npz            # per-residue [L,d] + pooled [d] (+ logits) — one per sequence
        embeddings.parquet  # pooled vectors, one row per sequence (--format parquet)
        manifest.json       # model/pool/shapes/dtype + which file holds each sequence
    """
    size_limits.check_input(data, model, fast=fast)
    _require_ttnn()  # SaProt runs on the TT device only; fail clearly without the wheel
    from tt_bio import saprot, esmc

    if controller and structure:
        raise click.ClickException(
            "--controller runs are sequence-only (structures stay on the submitting "
            "client and are never shipped to workers). Drop --structure or run locally.")
    try:
        seqs = saprot.load_sequences_with_structure(data, structure, foldseek_bin)
    except ValueError as e:
        raise click.ClickException(str(e))

    out = Path(out_dir).expanduser()
    out.mkdir(parents=True, exist_ok=True)

    if controller:
        if devices:
            click.secho("Note: --devices is ignored with --controller (device topology comes "
                        "from connected workers).", fg="yellow")
        # Sequence-only fleet path: strip the (empty) 3Di strings to bare
        # sequences — the worker's saprot branch embeds {id: aa} directly.
        bare = {sid: (v[0] if isinstance(v, (list, tuple)) else v) for sid, v in seqs.items()}
        _dispatch_embed_to_controller(controller, bare, model=model, out=out,
                                      out_format=out_format, pool=pool,
                                      return_logits=return_logits, fast=fast,
                                      batch_size=batch_size, owner=owner,
                                      logits_shape=esmc.SAPROT_LOGITS_SHAPE)
        return

    device_list = None
    if devices:
        from tt_bio import runtime
        device_list = runtime.detect_tenstorrent_devices(devices, 0, len(seqs))

    try:
        if device_list and len(device_list) > 1:
            click.echo(f"Sharding {len(seqs)} sequence(s) across cards "
                       f"{device_list}{' (fast)' if fast else ''} → {out}")
            results = saprot.embed(seqs, model=model, devices=device_list, fast=fast,
                                  return_logits=return_logits, pool=pool, batch_size=batch_size)
        else:
            ensure_p300_mesh_descriptor()
            click.echo(f"Loading {model}{' (fast)' if fast else ''} …")
            m = saprot.load_saprot(model, fast=fast)
            click.echo(f"Embedding {len(seqs)} sequence(s) → {out}")
            results = saprot.embed_sequences(m, seqs, return_logits=return_logits, pool=pool,
                                             batch_size=batch_size)
    except ValueError as e:
        raise click.ClickException(str(e))

    if out_format == "npz":
        esmc.write_npz_many(results, out)
    if out_format == "parquet":
        esmc.write_parquet(results, out / "embeddings.parquet")
        click.echo(f"Wrote {out / 'embeddings.parquet'}")
    esmc.write_manifest(results, out / "manifest.json", model=model, pool=pool, fast=fast,
                         out_format=out_format, return_logits=return_logits,
                         logits_shape=esmc.SAPROT_LOGITS_SHAPE)
    click.echo(f"Done — {len(results)} sequence(s), d_model={results[0].pooled.shape[0]} "
               f"→ {out} (see manifest.json)")


def _run_pxdesign_cli(inputs: Path, out_dir, cache, num_designs, n_step, seed) -> None:
    """`tt-bio design --model pxdesign`: a target YAML to designed binder backbones.

    Deliberately not a call into scripts/pxdesign_port/design_e2e.py. That harness scores against
    committed captures and reads its target out of a capture directory; the shipped path builds
    everything from the user's own structure file.
    """
    from tt_bio.pxdesign.design import run_design

    out_dir = out_dir or "./designs"
    num_designs = num_designs if num_designs is not None else 1
    try:
        rows = run_design(inputs, out_dir, cache, num_designs, n_step, seed)
    except (ValueError, FileNotFoundError) as e:
        raise click.ClickException(str(e))

    click.echo(f"Done — {len(rows)} design(s) → {out_dir}")
    for r in rows:
        click.echo(f"  {Path(r['cif']).name}: {r['binder_residues']} residues, "
                   f"{r['binder_atoms']} atoms; target fit {r['fit_rmsd']:.2f} A "
                   f"over {r['conditioned_tokens']} conditioned tokens")


def _rfd4_mode(sampling: dict) -> str:
    """How a run that does not start from pure noise is reported on the first line."""
    if sampling.get("inverse_folding"):
        return "inverse folding (backbone held, sequence designed)"
    frac = sampling.get("partial_trajectory_fraction_steps")
    if frac is not None:
        return f"partial diffusion from {frac:.4g} of the schedule"
    bb, lat = sampling.get("partial_t_backbone"), sampling.get("partial_t_latent")
    return f"partial diffusion from t_backbone={bb}, t_latent={lat}"


def _rfd4_sampling(partial_fraction, partial_t_backbone, partial_t_latent, couple_partial_t,
                   inverse_folding) -> dict:
    """The partial-diffusion / inverse-folding arguments, absent when the run is from noise.

    Upstream's own mutual exclusions are enforced in the sampler, which is where they are graded;
    this only decides whether there is anything to pass at all.
    """
    args = {"partial_trajectory_fraction_steps": partial_fraction,
            "partial_t_backbone": partial_t_backbone, "partial_t_latent": partial_t_latent,
            "couple_partial_t": couple_partial_t, "inverse_folding": inverse_folding}
    return args if any(v not in (None, False) for v in args.values()) else {}


def _run_rfd4_cli(inputs: Path, out_dir, num_designs, backend, recipe, lora, nsteps, seed,
                  spec_subset, annotated_cif: bool, validate: bool, fast: bool = False,
                  controller: str | None = None, run_id: str | None = None, owner: str | None = None,
                  sampling: dict | None = None, tsr_k: float | None = None,
                  save_trajectory_every: int = 0, shards: int | None = None) -> None:
    """`tt-bio design --model rfd4`: a design spec to annotated-CIF designs.

    The host path is RFD4's own (tt_bio/_vendor/rfd4_prep): the spec is built into an
    annotated CIF per design, which is kept beside the output because it IS the model's
    input, and a design that came out wrong is usually a spec that selected the wrong
    atoms. `tt_bio.rfd4.design()` is this same call from Python.
    """
    from tt_bio import rfd4

    only = [s.strip() for s in spec_subset.split(",") if s.strip()] if spec_subset else None
    if annotated_cif and only:
        raise click.UsageError("--spec selects designs from a spec file; "
                               "--annotated_cif takes the CIF itself")
    sampling = sampling or {}
    click.echo(f"{Path(inputs).name}, seed {seed}"
               + (f", {_rfd4_mode(sampling)}" if sampling else ""))
    out_dir = Path(out_dir or "./designs")
    if controller and (sampling or tsr_k is not None or save_trajectory_every):
        raise click.UsageError(
            "a fleet job carries the spec, the recipe and the seed; the sampling flags "
            "(--partial*, --inverse_folding, --tsr_k, --save_trajectory_every) are a local run.")
    if controller and lora:
        raise click.UsageError(
            "--lora is a local run: the adapter is not shipped to fleet workers. Merge it into a "
            "checkpoint the workers can load, or drop --controller.")
    if controller:
        # The designs are split into one batched slice per card; the inputs are built here so a
        # worker needs no view of this filesystem (tt_bio/rfd4/fleet.py).
        from tt_bio.rfd4.fleet import design_via_controller

        try:
            design_via_controller(inputs, out_dir,
                                  controller_url=controller, num_designs=num_designs,
                                  shards=shards,
                                  backend=backend,
                                  recipe=recipe, nsteps=nsteps, seed=seed, only=only,
                                  validate=validate, annotated_cif=annotated_cif, fast=fast,
                                  run_id=run_id, owner=owner)
        except NotImplementedError as e:
            raise click.ClickException(str(e))
        except (ValueError, KeyError, FileNotFoundError) as e:
            raise click.ClickException(f"{type(e).__name__}: {e}")
        return
    from tt_bio.tenstorrent import set_fast_mode

    set_fast_mode(fast)   # the trunk picks its lever set (rfd4.trunk.FAST_LEVERS) when it is built
    click.echo(f"Designing {Path(inputs).name} × {num_designs} design(s) → {out_dir} (seed {seed})")
    try:
        written = rfd4.design(inputs, out_dir, num_designs=num_designs, backend=backend,
                              recipe=recipe, adapter=lora, tsr_k=tsr_k, nsteps=nsteps, seed=seed,
                              only=only, validate=validate, annotated_cif=annotated_cif,
                              sampling=sampling,
                              save_trajectory_every=save_trajectory_every,
                              on_design=lambda example_id, tokens, cif: click.echo(
                                  f"  {example_id}: {tokens} tokens <- {cif}"),
                              on_write=lambda path: click.echo(f"    -> {path}"))
    except NotImplementedError as e:
        raise click.ClickException(str(e))
    except (ValueError, KeyError, FileNotFoundError) as e:
        raise click.ClickException(f"{type(e).__name__}: {e}")
    click.echo(f"Done — {len(written)} design(s) → {out_dir}")


@cli.command("design")
@click.argument("inputs", type=click.Path(exists=True, dir_okay=False))
@click.option("--model", type=click.Choice(list(DESIGN_MODELS)), default="boltzgen", show_default=True,
              help="Design model. boltzgen: the full BoltzGen binder-design pipeline "
                   "(design → inverse folding → refolding → analysis → filtering; mirrors "
                   "predict's boltz2 default). rfd3: RFdiffusion3, a lighter single-shot "
                   "all-atom diffusion designer (one CIF per spec). pxdesign: binder "
                   "backbones against a target structure, conditioned on a distogram of the "
                   "target. rfd4: RFD4-Proteina, all-atom flow matching over the same design "
                   "spec RFD4 itself takes (motifs, hotspots, burial, hydrogen bonds, contigs); "
                   "see below. Options marked for a model apply to that "
                   "model only.")
@click.option("--out_dir", default=None,
              help="Output directory. Default: ./<input name>/ (boltzgen, writes "
                   "final_ranked_designs/ under it) or ./designs (rfd3, one "
                   "<spec_id>.cif per design; pxdesign, one <input stem>.cif per design).")
@click.option("--cache", default=lambda: os.environ.get("BOLTZ_CACHE", str(Path("~/.boltz").expanduser())),
              show_default=False, help="Weight cache directory (default: $BOLTZ_CACHE or ~/.boltz). "
                   "Both models auto-download their checkpoints here on first use.")
@click.option("--num_designs", default=None, type=int,
              help="Designs to generate. Default: 10000 in total (boltzgen), 1 per spec "
                   "(rfd3; each design gets noise seed --seed + design_idx, written as "
                   "<spec_id>.cif when 1 else <spec_id>_<i>.cif), or 1 (pxdesign, where it is "
                   "also the batch axis: every requested design comes from one batched "
                   "diffusion trajectory, and the gain per design grows with the batch and "
                   "shrinks with the target: 2.7x at 8 against a 256-residue target, 1.5x at "
                   "a 512-residue one, and flat from 16 up rather than turning back).")
@click.option("--devices", "--device_ids", "devices", default=None,
              help="Comma-separated physical TT card ids to fan the designs across, e.g. "
                   "'0,1,2,3' (data-parallel, the same pattern `tt-bio predict` uses). "
                   "Default: every card on this machine, never more cards than designs.")
# ---- rfd3-scoped options ----
@click.option("--checkpoint", "checkpoint", default=None, metavar="DIR",
              help="rfd3 only. Directory of extracted RFD3 device weights. Default: "
                   "auto-download the checkpoint and extract it into --cache on first "
                   "run (~2.5 GiB download).")
@click.option("--golden_dir", "golden_dir", default=None, hidden=True)
@click.option("--num_timesteps", default=4, show_default=True,
              help="rfd3 only. Diffusion denoising timesteps (low for a fast smoke; "
                   "upstream default 200).")
@click.option("--seed", default=42, show_default=True,
              help="Random seed. The same inputs and seed give the same designs. "
                   "boltzgen draws fresh each run unless --seed is given.")
@click.option("--partial_t", default=None, type=float,
              help="rfd3 only. Partial-diffusion noise in Angstroms (per-spec partial_t "
                   "overrides this).")
@click.option("--fp32_residual", is_flag=True,
              help="rfd3 only. Opt in the RFD3_FP32_RESIDUAL precision lever (fp32 residual "
                   "stream across the DiT + encoder + DiffusionTokenEncoder; default off = bf16).")
@click.option("--spec", "spec_subset", default=None,
              help="rfd3 only. Comma-separated subset of spec ids from the inputs file to run.")
@click.option("--from_pdb", is_flag=True,
              help="rfd3 only. Featurize each spec's `input` PDB + contig on the host — the "
                   "standard path for real inputs (protein-binder, motif-scaffolding, and "
                   "nucleic-acid-binder specs; ligand/enzyme and symmetry specs raise "
                   "NotImplementedError). Without it, features come from a captured fixture "
                   "in --checkpoint (dev/test only).")
@click.option("--batch_size", default=8, show_default=True, type=click.IntRange(min=1),
              help="rfd3 only. Maximum designs from one spec evaluated in each device forward. "
                   "The runtime shrinks it so a batch cannot exhaust device memory; each design "
                   "keeps its own seeded RNG stream and the forward is bit-identical to running "
                   "the designs one at a time.")
@click.option("--n_step", default=400, show_default=True, type=click.IntRange(min=1),
              help="pxdesign only. Diffusion denoising steps. 400 is what an upstream run "
                   "uses; lower is a fast smoke and moves the coordinates.")
# ---- rfd4-scoped options ----
@click.option("--backend", default="native", show_default=True,
              help="rfd4 only. Inference backend, upstream's `inference_backend`. `native` runs "
                   "the model on Tenstorrent. `bioir` is NVIDIA BioNeMo-IR and is declined here; "
                   "it is CUDA-only and produces the same designs.")
@click.option("--lora", "lora", default=None, type=click.Path(exists=True, file_okay=False),
              help="rfd4 only. A PEFT LoRA adapter directory (adapter_config.json plus "
                   "adapter_model.safetensors) merged into the weights at load, so a fine-tune "
                   "costs nothing per design. Local runs only: an adapter is not shipped to "
                   "fleet workers.")
@click.option("--recipe", default=None, type=click.Choice(_RFD4_RECIPES),
              help="rfd4 only. Thinking budget: how many trunk passes the trajectory spends and "
                   "where. `thinking_low|medium|high` are the released recipes (medium is the "
                   "default, 180 passes); `low|medium|high` crossed with "
                   "`flat|front_loaded|midpeak` are upstream's per-family schedules, and "
                   "upstream prescribes one per design task: medium/front_loaded for protein "
                   "binders, medium/midpeak for enzymes, motifs and small-molecule binders, "
                   "high/front_loaded for VHH, medium/flat for inverse folding and "
                   "medium/front_loaded for DNA binders. More passes is more accuracy and more "
                   "time.")
@click.option("--nsteps", default=60, show_default=True, type=click.IntRange(min=1),
              help="rfd4 only. Flow-matching integration steps (upstream's `generation.args."
                   "nsteps` default).")
@click.option("--annotated_cif", is_flag=True,
              help="rfd4 only. INPUTS is already an annotated CIF (RFD4's `input_as_annotated_cif` "
                   "form, e.g. one written by an earlier run), not a design spec, so it is "
                   "featurized directly.")
@click.option("--no_validate", is_flag=True,
              help="rfd4 only. Skip the pre-save checks on each built structure. They are the "
                   "slow part of preparing a large spec and they are what catches a selection "
                   "that matched nothing.")
@click.option("--tsr_k", default=None, type=float,
              help="rfd4 only. Sequence temperature (upstream's local_latents tsr_k, default 4). "
                   "Lower is hotter and gives more sequence diversity; mostly used with "
                   "--inverse_folding.")
@click.option("--partial", "partial_fraction", default=None, type=click.FloatRange(0, 1, min_open=True),
              help="rfd4 only. Partial diffusion: re-noise INPUTS part-way and run that fraction "
                   "of the step schedule, to refine or diversify a design you already have. "
                   "0.42 is upstream's antibody refinement setting (25 of 60 steps). INPUTS "
                   "should be a generated annotated CIF, which carries its own conditioning.")
@click.option("--partial_t_backbone", default=None, type=float,
              help="rfd4 only. Partial diffusion by explicit corruption time for the backbone, "
                   "instead of --partial. Give --partial_t_latent too, or --couple_partial_t.")
@click.option("--partial_t_latent", default=None, type=float,
              help="rfd4 only. The same for the sequence latents.")
@click.option("--couple_partial_t", is_flag=True,
              help="rfd4 only. Derive the modality time you did not give from the one you did, "
                   "by step index on a dense schedule.")
@click.option("--inverse_folding", is_flag=True,
              help="rfd4 only. Keep INPUTS' backbone exactly as given and design only the "
                   "sequence. Excludes the partial-diffusion options.")
@click.option("--save_trajectory_every", default=0, type=int, show_default=True,
              help="rfd4 only. Write every Nth step of each design's trajectory to "
                   "<out_dir>/<design>_trajectory.cif, CA only, one model per saved step. "
                   "0 writes none.")
@click.option("--host_threads", default=None, type=int,
              help="rfd3 only. Total host CPU threads this process may use, split across its "
                   "cards. Defaults to every core, which is right when this is the only tt-bio "
                   "process on the box. Pass cores//concurrent_processes when an external "
                   "launcher runs several designs side by side, so they do not oversubscribe "
                   "the host.")
# ---- boltzgen-scoped options ----
@click.option("--protocol", default=None,
              help="boltzgen only. Protocol for the binder type (protein-anything, "
                   "peptide-anything, nanobody-anything, antibody-anything, "
                   "protein-small_molecule, protein-redesign). Default: protein-anything.")
@click.option("--steps", default=None, metavar="LIST",
              help="boltzgen only. Comma-separated pipeline steps to run instead of the full "
                   "pipeline (design,inverse_folding,design_folding,folding,affinity,analysis,"
                   "filtering), e.g. --steps design or --steps analysis,filtering.")
@click.option("--config", "configs", nargs=2, multiple=True, metavar="STEP KEY=VAL",
              help="boltzgen only. Override a pipeline step's configuration, e.g. "
                   "--config design sampling_steps=200. Repeatable.")
@click.option("--budget", default=None, type=int,
              help="boltzgen only. How many designs the filtering step keeps in the final "
                   "diversity-optimized set. Default: 30.")
@click.option("--reuse", is_flag=True,
              help="boltzgen only. Reuse existing results in --out_dir and generate only as "
                   "many new designs as --num_designs still needs.")
@click.option("--fast", is_flag=True,
              help="boltzgen, rfd3 and rfd4. Faster, slightly lower-precision kernels (boltzgen: "
                   "block-fp8 for some operations; rfd3: fused atom attention; rfd4: block-fp8 "
                   "pair-track matmuls).")
@click.option("--diffusion_trace/--no_diffusion_trace", default=None,
              help="boltzgen only. Replay a captured ttnn trace of the per-step diffusion "
                   "DiT device stream (lossless; collapses per-step host dispatch; reserves "
                   "0.2-0.3 GB of device memory). Default: on for Blackhole normal mode, else off.")
@click.option("--debug", is_flag=True,
              help="boltzgen only. Debug mode: no Rich display, no output suppression.")
@click.option("--log", is_flag=True,
              help="boltzgen only. With --debug: print per-stage progress lines.")
# ---- fleet dispatch (both models) ----
@click.option("--controller", default=None,
              help="Submit to an existing controller at URL (e.g. http://HOST:8765) instead of "
                   "running locally; compute comes from that cluster's workers. boltzgen: the "
                   "pipeline's own fleet path (merge + filter here). rfd3: one shard per spec, "
                   "each worker runs its shard in-process on its own card and ships CIFs back. "
                   "rfd4: one job per design (spec entries times --num_designs), each carrying "
                   "its own prepared input, with a metrics.json collecting what landed.")
@click.option("--run-id", "run_id", default=None,
              help="Use this run id on the controller (lets the submitter cancel the run later). "
                   "Requires --controller.")
@click.option("--owner", default=None,
              help="Opaque fairness key (e.g. a hashed session id) the controller uses to "
                   "fair-share devices across users. Requires --controller.")
@torch.no_grad()
def design_cmd(inputs, model, out_dir, cache, num_designs, devices,
               checkpoint, golden_dir, num_timesteps, seed, partial_t, fp32_residual,
               spec_subset, from_pdb, batch_size, n_step, backend, recipe, lora, nsteps,
               annotated_cif, no_validate, tsr_k, partial_fraction, partial_t_backbone,
               partial_t_latent, couple_partial_t, inverse_folding, save_trajectory_every,
               host_threads,
               protocol, steps, configs, budget, reuse, fast, diffusion_trace, debug, log,
               controller, run_id, owner):
    """Run structure design on Tenstorrent: generate new protein binders, scaffolds,
    or sequences from a specification instead of folding an existing one.

    \b
    --model boltzgen (default): the BoltzGen binder-design pipeline. INPUTS is a
    design-spec YAML (a designed chain plus a target structure). Runs design →
    inverse folding → refolding → analysis → filtering and writes the top-ranked
    binders to <out_dir>/final_ranked_designs/. See docs/boltzgen-designability.md.

    \b
    --model rfd3: RFdiffusion3 all-atom diffusion design. INPUTS is a JSON or YAML
    file of InputSpecifications (each top-level key is one independent design), e.g.:

    \b
    {
      "binder-1": {"input": "target.pdb", "contig": "A1-100,70", "length": "70"},
      "scaffold-1": {"input": "motif.pdb", "contig": "A10-20,40,A30-40"}
    }

    Writes one CIF per spec to --out_dir. Protein-binder, motif-scaffolding, and
    nucleic-acid-binder specs are supported end to end from a real input structure
    (pass --from_pdb). See docs/rfd3-design.md for the contig grammar and current
    limitations.

    \b
    --model pxdesign: PXDesign-d binder generation. INPUTS is a target YAML naming a
    structure file, the chains to condition on (with optional per-chain crop and
    hotspots) and a binder_length:

    \b
    target:
      file: PDL1.cif
      chains:
        A: {hotspots: [54, 56, 121]}
    binder_length: 80

    Writes one CIF per design to --out_dir, each the designed backbone placed in the
    target structure's own frame, so it opens alongside the input file. The binder is
    written as GLY: PXDesign generates a backbone with no sequence, and inventing side
    chains it did not produce would be worse than saying so. Selecting designs (the
    Protenix and AF2-IG filters) is not on the CLI yet.

    \b
    --model rfd4: RFD4-Proteina all-atom flow-matching design. INPUTS is a condition
    spec, the same YAML or JSON RFD4 takes: each top-level key is one design, naming
    input structures, a contig and conditions:

    \b
    binder-1:
      input: target.cif
      contig: "60-60, /0, A17-131"
      conditions:
        C_CRDGRP: {1: [{select: "sel('A/*/*/[N,CA,C,O]')"}]}
        C_HOT: {true: [{select: "sel('A/*/56/[CG,OH]')"}]}

    Each design is built into an annotated CIF under <out_dir>/inputs/ -- the model's
    actual input, kept because a design that comes out wrong is usually a selection that
    matched the wrong atoms -- then featurized and designed. --recipe sets the thinking
    budget, --lora loads a fine-tune, and docs/rfd4-design.md has the conditions a spec
    can set with what each family costs.

    A spec's designs fan across a fleet with --controller: every design becomes one job,
    each shipping the input this host built for it, and <out_dir>/metrics.json collects
    what landed. That is tt-bio's answer to upstream's SLURM --njobs sweeps.

    All four models auto-download their checkpoints on first use.
    """
    # rfd3 and pxdesign carry measured ceilings in DIFFERENT denominators (motif+designed vs
    # target residues); size_limits sizes each spec in its own and refuses before any device open.
    size_limits.check_input(inputs, model)

    ctx = click.get_current_context()

    def _explicit(name: str) -> bool:
        return ctx.get_parameter_source(name) == ParameterSource.COMMANDLINE

    if model == "boltzgen":
        for flag, name in (("--checkpoint", "checkpoint"), ("--golden_dir", "golden_dir"),
                           ("--num_timesteps", "num_timesteps"),
                           ("--partial_t", "partial_t"), ("--fp32_residual", "fp32_residual"),
                           ("--spec", "spec_subset"), ("--from_pdb", "from_pdb"),
                           ("--batch_size", "batch_size"), ("--host_threads", "host_threads"),
                           ("--n_step", "n_step"),
                           ("--backend", "backend"), ("--recipe", "recipe"), ("--lora", "lora"),
                           ("--nsteps", "nsteps"), ("--annotated_cif", "annotated_cif"),
                           ("--no_validate", "no_validate"),
                           ("--tsr_k", "tsr_k"), ("--partial", "partial_fraction"),
                           ("--partial_t_backbone", "partial_t_backbone"),
                           ("--partial_t_latent", "partial_t_latent"),
                           ("--couple_partial_t", "couple_partial_t"),
                           ("--inverse_folding", "inverse_folding"),
                           ("--save_trajectory_every", "save_trajectory_every")):
            if _explicit(name):
                click.secho(f"Note: --model boltzgen does not use {flag}; ignoring.", fg="yellow")
        argv = ["run", str(inputs)]
        if out_dir:
            argv += ["--output", out_dir]
        if num_designs is not None:
            argv += ["--num_designs", str(num_designs)]
        if devices:
            argv += ["--device_ids", devices]
        if protocol:
            argv += ["--protocol", protocol]
        if steps:
            argv += ["--steps", *[s.strip() for s in steps.split(",") if s.strip()]]
        for step, kv in configs:
            argv += ["--config", step, kv]
        if budget is not None:
            argv += ["--budget", str(budget)]
        # Only an explicit --seed: its default belongs to rfd3/pxdesign, and an
        # unseeded boltzgen run stays a fresh draw.
        if _explicit("seed"):
            argv += ["--seed", str(seed)]
        if _explicit("cache"):
            argv += ["--cache", cache]
        for flag, on in (("--reuse", reuse), ("--fast", fast), ("--debug", debug),
                         ("--log", log)):
            if on:
                argv.append(flag)
        if diffusion_trace is not None:
            argv.append("--diffusion_trace" if diffusion_trace else "--no-diffusion_trace")
        if controller:
            argv += ["--controller", controller]
            if run_id:
                argv += ["--run-id", run_id]
            if owner:
                argv += ["--owner", owner]
        _run_boltzgen_cli("tt-bio design", argv)
        return

    cards: list[int] = []
    if model in ("pxdesign", "rfd4"):
        # Every design is an independent job. Several of them on a multi-card host run through
        # the same controller path a fleet uses, against a private pool of one worker per card;
        # one design (or a run only a local process can do) opens exactly one card.
        if not controller:
            local_only = model == "rfd4" and bool(
                lora or tsr_k is not None or save_trajectory_every
                or _rfd4_sampling(partial_fraction, partial_t_backbone, partial_t_latent,
                                  couple_partial_t, inverse_folding))
            cards = [] if local_only else _local_cards(devices, num_designs or 1)
            if len(cards) > 1:
                controller = click.get_current_context().with_resource(_local_controller(cards))
            else:
                _pin_one_card(devices, model)
        elif _explicit("devices"):
            click.secho("Note: with --controller the fleet's workers pick the cards; "
                        "ignoring --devices.", fg="yellow")

    if model == "pxdesign":
        for flag, name in (("--protocol", "protocol"), ("--steps", "steps"),
                           ("--config", "configs"), ("--budget", "budget"),
                           ("--reuse", "reuse"), ("--fast", "fast"),
                           ("--diffusion_trace", "diffusion_trace"), ("--debug", "debug"),
                           ("--log", "log"), ("--checkpoint", "checkpoint"),
                           ("--golden_dir", "golden_dir"), ("--num_timesteps", "num_timesteps"),
                           ("--partial_t", "partial_t"), ("--fp32_residual", "fp32_residual"),
                           ("--spec", "spec_subset"), ("--from_pdb", "from_pdb"),
                           ("--batch_size", "batch_size"), ("--host_threads", "host_threads"),
                           ("--backend", "backend"), ("--recipe", "recipe"), ("--lora", "lora"),
                           ("--nsteps", "nsteps"), ("--annotated_cif", "annotated_cif"),
                           ("--no_validate", "no_validate"),
                           ("--tsr_k", "tsr_k"), ("--partial", "partial_fraction"),
                           ("--partial_t_backbone", "partial_t_backbone"),
                           ("--partial_t_latent", "partial_t_latent"),
                           ("--couple_partial_t", "couple_partial_t"),
                           ("--inverse_folding", "inverse_folding"),
                           ("--save_trajectory_every", "save_trajectory_every")):
            if _explicit(name):
                click.secho(f"Note: --model pxdesign does not use {flag}; ignoring.", fg="yellow")
        if controller:
            # Fleet path. Without this the flag was accepted and silently dropped, and
            # the run cold-opened a device of its own — which on a serving box means
            # colliding with the resident workers that already hold every chip.
            from tt_bio.pxdesign.design import run_design_via_controller
            # Same input errors as the local path below, so a bad target YAML reads the
            # same either way. Without this the fleet path showed the user a traceback.
            try:
                rows = run_design_via_controller(
                    Path(inputs), out_dir or "./designs", controller_url=controller,
                    num_designs=num_designs if num_designs is not None else 1,
                    n_step=n_step, seed=seed, run_id=run_id, owner=owner,
                    shards=len(cards) or None)
            except (ValueError, FileNotFoundError) as e:
                raise click.ClickException(str(e))
            click.echo(f"Done — {len(rows)} design(s) → {out_dir or './designs'}")
            for r in rows:
                fit = r.get("fit_rmsd")
                click.echo(f"  {Path(r['cif']).name}: {r.get('binder_residues')} residues, "
                           f"{r.get('binder_atoms')} atoms"
                           + (f"; target fit {fit:.2f} A" if isinstance(fit, (int, float)) else ""))
            return
        _run_pxdesign_cli(Path(inputs), out_dir, cache, num_designs, n_step, seed)
        return

    if model == "rfd4":
        for flag, name in (("--protocol", "protocol"), ("--steps", "steps"),
                           ("--config", "configs"), ("--budget", "budget"),
                           ("--reuse", "reuse"),
                           ("--diffusion_trace", "diffusion_trace"), ("--debug", "debug"),
                           ("--log", "log"), ("--checkpoint", "checkpoint"),
                           ("--golden_dir", "golden_dir"), ("--num_timesteps", "num_timesteps"),
                           ("--partial_t", "partial_t"), ("--fp32_residual", "fp32_residual"),
                           ("--from_pdb", "from_pdb"), ("--batch_size", "batch_size"),
                           ("--host_threads", "host_threads"), ("--n_step", "n_step"),
                           ("--cache", "cache")):
            if _explicit(name):
                click.secho(f"Note: --model rfd4 does not use {flag}; ignoring.", fg="yellow")
        _run_rfd4_cli(Path(inputs), out_dir,
                      num_designs if num_designs is not None else 1,
                      backend, recipe, lora, nsteps, seed, spec_subset, annotated_cif,
                      not no_validate, fast,
                      controller=controller, run_id=run_id, owner=owner,
                      sampling=_rfd4_sampling(partial_fraction, partial_t_backbone,
                                              partial_t_latent, couple_partial_t,
                                              inverse_folding),
                      tsr_k=tsr_k, save_trajectory_every=save_trajectory_every,
                      shards=len(cards) or None)
        return

    # --model rfd3
    for flag, name in (("--protocol", "protocol"), ("--steps", "steps"),
                       ("--config", "configs"), ("--budget", "budget"),
                       ("--reuse", "reuse"),
                       ("--diffusion_trace", "diffusion_trace"), ("--debug", "debug"),
                       ("--log", "log"), ("--n_step", "n_step"),
                       ("--backend", "backend"), ("--recipe", "recipe"), ("--lora", "lora"),
                       ("--nsteps", "nsteps"), ("--annotated_cif", "annotated_cif"),
                       ("--no_validate", "no_validate"),
                       ("--tsr_k", "tsr_k"), ("--partial", "partial_fraction"),
                       ("--partial_t_backbone", "partial_t_backbone"),
                       ("--partial_t_latent", "partial_t_latent"),
                       ("--couple_partial_t", "couple_partial_t"),
                       ("--inverse_folding", "inverse_folding"),
                       ("--save_trajectory_every", "save_trajectory_every")):
        if _explicit(name):
            click.secho(f"Note: --model rfd3 does not use {flag}; ignoring.", fg="yellow")
    if golden_dir is not None:
        click.secho("Deprecation warning: --golden_dir is deprecated; use --checkpoint.",
                    fg="yellow", err=True)
        if checkpoint is not None:
            raise click.UsageError("--checkpoint and --golden_dir are the same option; pass one.")
        checkpoint = golden_dir

    import json as _json
    import yaml as _yaml
    from tt_bio.rfd3 import design as _rfd3

    num_designs = num_designs if num_designs is not None else 1
    out_dir = out_dir or "./designs"

    src = Path(inputs).expanduser()
    text = src.read_text()
    try:
        if src.suffix in (".json",):
            specs = _json.loads(text)
        else:
            specs = _yaml.safe_load(text)
    except Exception as e:
        raise click.ClickException(f"could not parse {src}: {e}")
    if not isinstance(specs, dict) or not specs:
        raise click.ClickException("inputs file must be a non-empty mapping of spec_id -> spec")
    if spec_subset:
        keep = {s.strip() for s in spec_subset.split(",")}
        specs = {k: v for k, v in specs.items() if k in keep}
        if not specs:
            raise click.ClickException(f"no spec ids in --spec matched {list(keep)}")

    if controller:
        if not from_pdb:
            raise click.ClickException(
                "--controller runs need --from_pdb (the golden-bridge fixture is a local "
                "dev/test path and is never shipped to workers).")
        click.echo(f"Designing {len(specs)} spec(s) × {num_designs} design(s) → {out_dir} "
                   f"via the fleet at {controller} ({num_timesteps} steps)")
        try:
            results = _rfd3.run_design_via_controller(
                specs, out_dir, controller_url=controller, num_timesteps=num_timesteps,
                seed=seed, partial_t=partial_t, fp32_residual=fp32_residual,
                num_designs=num_designs, batch_size=batch_size,
                run_id=run_id, owner=owner, fast=fast, verbose=True,
            )
        except (ValueError, TypeError, RuntimeError, NotImplementedError) as e:
            raise click.ClickException(str(e))
        click.echo(f"Done — {len(results)} design(s) → {out_dir}")
        return

    if checkpoint is None:
        gdir = str(ensure_rfd3_weights(Path(cache).expanduser()))
    else:
        gdir = checkpoint
        if not Path(gdir).exists():
            raise click.ClickException(f"checkpoint not found: {gdir}")

    # Every card on the machine by default, never more cards than designs. rfd3's own fan-out
    # shards the (spec, design) jobs across pinned subprocesses, and each card still batches its
    # share -- which is why rfd3 keeps this path instead of the per-job controller one that
    # rfd4 and pxdesign use.
    device_list = _local_cards(devices, len(specs) * num_designs) or None

    ensure_p300_mesh_descriptor()

    click.echo(f"Designing {len(specs)} spec(s) × {num_designs} design(s) → {out_dir} "
               f"(checkpoint={gdir}, from_pdb={from_pdb}, {num_timesteps} steps, batch={batch_size}"
               f"{f', devices={device_list}' if device_list and len(device_list) > 1 else ''})")
    try:
        results = _rfd3.run_design(
            specs, out_dir, checkpoint_dir=gdir, from_pdb=from_pdb, num_timesteps=num_timesteps,
            seed=seed, partial_t=partial_t, fp32_residual=fp32_residual, num_designs=num_designs,
            batch_size=batch_size, devices=device_list, host_threads=host_threads,
            fast=fast, verbose=True,
        )
    except (ValueError, TypeError, NotImplementedError) as e:
        # RFD3 refuses a spec it cannot featurize with NotImplementedError, naming
        # the condition. That is an answer about the input, not a crash, so it reads
        # as one line like every other refusal.
        raise click.ClickException(str(e))
    click.echo(f"Done — {len(results)} design(s) → {out_dir}")
    for r in results:
        click.echo(f"  {r.spec_id}#{r.design_idx}: {r.out_path} ({r.n_atoms} atoms)")


if __name__ == "__main__":
    cli()
