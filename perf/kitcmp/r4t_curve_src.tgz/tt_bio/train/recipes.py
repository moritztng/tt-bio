"""Every Tier-1 body, importable, and ``source(name)`` returning its text.

**This module IS the escape hatch, and the hatch is a mechanism with a test rather than a
promise.** r4's central finding is that everyone ships a hatch and almost nobody ships one
that still works a year later, because the tier above quietly grows a dependency on something
the tier below cannot reach. The durable form of the lesson, worth keeping where it will be
read: *an escape hatch is only real if the tier above is expressible in the tier below's
public API, and it only stays real if a test asserts it.*

So the arrangement here is deliberately rigid.

* ``tt_bio.train.finetune`` does not implement a loop. It looks a recipe up in this module and
  calls it. There is exactly one code path, so "the hatch reproduces the Tier-1 result" is
  identity rather than a claim about two implementations agreeing.
* Every function here is written against ``tt_bio.train``'s public Tier-2 names ONLY. The
  tuple ``tt_bio.train.TIER2`` is the whole permitted vocabulary, plus builtins and the
  recipe's own arguments. The imports below are from the submodules rather than the package
  so there is no import cycle, and the test checks them by IDENTITY against ``TIER2`` -- an
  import that reached a private helper would resolve to an object that is not in the tuple.
* ``source(name)`` returns the text, and ``tests/test_train_interface.py`` execs it in a
  namespace containing nothing but ``TIER2`` and asserts the resulting function's bytecode is
  identical to the shipped one. A recipe that reaches for a private helper fails that exec,
  and then the helper becomes public or the recipe changes. There is no third option and no
  way to satisfy the test with a docstring.

The bodies read as a user would write them, because that is the point: what you get from
``source()`` is a starting file, not a generated shim.
"""

from __future__ import annotations

import inspect
from typing import Callable, Dict

from . import launcher, objectives, provenance
from ..autograd import backward, exact_training_ops, install, release_pins, uninstall
from .sharding import batches
from .checkpoint import Checkpointer, load_adapter
from .lora import LoraConfig, attach, trainable
from .mesh import Mesh
from .optim import AdamW, af3_lr
from .parity import GradientCoverage, zero_or_missing
from .dryrun import plan
from .tensors import to_device, to_host

__all__ = ["source", "names", "recipe", "train_loop"]


def train_loop(forward, dataset, *, out_dir, global_batch, steps, objective="af3",
               train="adapters", mesh=None, lora=None, seed=0, lr=3e-4, warmup_steps=1000,
               betas=(0.9, 0.95), weight_decay=0.0, plateau_until=50000, checkpoint_every=100,
               tokens=None, weights=None, model=None, on_step=None,
               displacement_band=None, resume=False, coverage_steps=5):
    """Fine-tune or pre-train a shipped forward. The Tier-1 default, and a Tier-2 program.

    ``train`` is what the optimizer owns, and it is a NAME for the same reason ``objective``
    is: it decides the memory arithmetic, so Tier 0 has to be able to check it before a
    device opens. ``"adapters"`` trains a LoRA factor pair beside each site on a frozen
    trunk. ``"weights"`` trains the model's own weights at those same sites, which is what a
    pre-training run does. Nothing else in this function changes between them -- the loop,
    the objective, the optimizer, the checkpointer and the data-parallel axis are the same
    code, which is why going from a fine-tune to a pre-training run is one argument and not a
    rewrite.

    ``forward(batch) -> {name: device tensor}`` is the SHIPPED forward, handed in rather than
    constructed here: the training path calls the same forward inference calls, and the way to
    guarantee that is to not have a second one to call.

    ``model`` is the built model object, and passing it is strongly preferred: discovery
    then WALKS it, so the optimizer owns every device weight the model reaches rather than the
    weights its routed ``ops.linear`` call sites pass. Leave it out and discovery is the
    call-site census, which cannot see a weight a module fused in its own ``__init__`` --
    measured at 2119 of 2531 on OpenFold3's trunk.

    ``coverage_steps`` is how many of a run's first steps the every-parameter-trains guard
    intersects before it decides. Five is the floor the guard enforces, and the reason it is
    not one is upstream's zero-initialised residual branches: they make a first-step reading
    name parameters that are training normally by step 2.

    ``betas``, ``weight_decay`` and ``plateau_until`` are where the AlphaFold-family recipes
    disagree with each other and with the optimizer's own library defaults, so they are
    arguments rather than constants. The values here are OpenFold3's: its
    ``configure_optimizers`` builds a plain ``torch.optim.Adam`` at
    ``betas=(beta1, beta2)`` with no decay at all (``runner.py:855-860``), its config sets
    ``beta2: 0.95`` against Adam's usual 0.999 (``model_config.py:143-146``), and its
    ``AlphaFoldLRScheduler`` holds the rate flat until ``start_decay_after_n_steps`` where
    Protenix starts decaying from step zero. ``plateau_until=None`` selects Protenix's family.
    One argument each, not a per-model branch -- see :func:`tt_bio.train.optim.af3_lr` for the
    two closed forms.

    None of the three could be left to a default. ``beta2`` is the sharpest: 0.999 against
    0.95 is a second-moment horizon twenty times longer, it moves no gradient and no loss
    curve, and over twenty steps it was the whole of a 0.9 % uniform excess in the update.

    ``displacement_band`` is the step control's band, ``None`` for the optimizer's own. It is
    an argument because a run can legitimately sit under it: at a rate whose step is below the
    device dtype's spacing every update rounds away by design, and a grading arm needs to
    RECORD that ratio rather than be stopped by it. Widening it is a pre-registration, not a
    workaround -- the ratio is in the provenance either way.

    ``on_step(record)`` is called with each step's history row as soon as it exists, before
    the checkpoint. It is how a long run survives its own death: ``history`` is returned at
    the end and a run killed at step 90 of 100 returns nothing, so a caller that wants the
    curve writes it out from here rather than waiting for it.

    ``resume=True`` continues from the newest checkpoint in ``out_dir`` when there is one:
    weights, both Adam moments and the schedule are loaded and the batch plan picks up at the
    step after it, which is the order an uninterrupted run would have seen.

    ``dataset`` needs ``__len__`` and ``batch(indices) -> dict`` carrying the labels the
    objective row names. No featurizer is imposed -- per-model featurisation is the one thing
    the campaign refused to generalise, because each family's cropping and MSA handling is
    exactly the part that is genuinely different.

    A data-parallel axis wider than one chip is one process per chip, and this function is one
    process. So it hands the run to :mod:`tt_bio.train.launcher`, which re-runs the calling
    program once per chip and comes back with the aggregate; inside each of those processes
    this same function runs, takes its own shard and hands its own gradient to ``step()``.
    Two lines below know about it -- which shard is read, and that ``step()`` is given
    something to reduce -- and the loop is otherwise the loop it was on one chip.
    """
    # The driver of a data-parallel run computes nothing, so it hands off before anything
    # below can open a card. Asking a forward for its `model` builds it, and building it
    # opens the device, which the launcher then refuses: a rank would be a second opener.
    dp = (mesh or Mesh({"dp": [0]})).axis("dp")
    if dp.width > 1 and launcher.driving():
        return launcher.drive(dp, out_dir=out_dir, steps=steps)
    # An adapter that BUILDS the model owns it, so it should not also have to be handed
    # back through every caller. `model=` still wins when it is passed; without it the
    # forward is asked. This is what makes discovery a WALK by default rather than the
    # call-site census, and the census is blind to every weight a module fuses in its own
    # `__init__` -- 2119 of 2531 on OpenFold3's trunk, silently.
    model = model if model is not None else getattr(forward, "model", None)
    dp_rank, dp = launcher.rank(), launcher.reducer(dp)
    # `None` here means "train the weights themselves", and it is the only line that reads
    # `train`. Everything downstream branches on `cfg is None` or not at all.
    cfg = (lora or LoraConfig()) if train == "adapters" else None
    row = objectives.objective(objective)

    fit = plan(tokens=tokens or dataset.tokens, chips=dp.width,
               global_batch=global_batch, frozen_trunk=cfg is not None)
    if fit.verdict == "refused":
        raise RuntimeError(f"refusing to start: {fit}")

    install()
    try:
        # One census pass on a real batch discovers the trainable sites. It costs an
        # inference, and it is how the parameter set comes from the forward instead of from a
        # list somebody maintains by hand. The same pass serves both modes.
        plan_order = batches(len(dataset), global_batch=global_batch, steps=steps, seed=seed,
                             data_parallel=dp)
        first = next(plan_order)
        # The seed reaches the ADAPTER INIT, not just the batch order. A is random and B is
        # zero, so without it every rank of a data-parallel run starts from different weights
        # and trains a different model -- which the launcher's master-hash check catches at
        # the end of the run rather than at the start of it. Training the weights themselves
        # initialises nothing, so there the seed reaches the batch order only.
        # `model` is the BUILT model, and handing it over is what makes the parameter set
        # every weight it reaches instead of the weights its four routed `ops.linear` call
        # sites happen to pass. Without it discovery falls back to the call-site census, which
        # is blind to every weight a module fuses in its own `__init__`.
        installed, params = trainable(forward, cfg, dataset.device,
                                      dataset.batch([first.per_chip[dp_rank][0]]),
                                      model=model, rng=seed)
        opt = AdamW(params, lr=lr, data_parallel=dp, betas=betas, weight_decay=weight_decay,
                    schedule=lambda s: af3_lr(s, lr, warmup_steps=warmup_steps,
                                              plateau_until=plateau_until))
        # A weights run trains the checkpoint's parameters, so elements the build filled with
        # constants (the k and v thirds of a fused bias whose checkpoint has a q bias only)
        # stay put. Otherwise they train a parameter the model lacks and weights.pt cannot
        # carry the run.
        if cfg is None and hasattr(forward, "unsourced"):
            opt.hold(forward.unsourced())
        # Rank 0 owns out_dir and the others get a subdirectory of it. The masters are
        # bit-identical across ranks, so one copy is the run's checkpoint; the reason not to
        # let them share the path is that two writers make a truncated safetensors file.
        ckpt = Checkpointer(launcher.out_dir(out_dir), every=checkpoint_every, metric="loss")
        history, last, start, coverage = [], None, 0, None
        if resume and (latest := ckpt.latest()) is not None:
            start = load_adapter(latest, params, dataset.device, opt=opt)["step"] + 1
            params.rebind()

        with provenance.during(seed=seed, config={
                "objective": objective, "global_batch": global_batch, "steps": steps,
                "lr": lr, "train": train, "chips": dp.width,
                "rank": cfg.rank if cfg else None, "alpha": cfg.alpha if cfg else None,
                "dp_rank": dp_rank, "rollout": row.rollout, "sites": sorted(params),
                "exact_ops": list(exact_training_ops())}) as prov:
            with attach(installed, cfg):
                for batch in [first, *plan_order]:
                    if batch.step < start:
                        continue
                    # ONE SAMPLE AT A TIME. Upstream clips each sample before accumulating it
                    # (`per_sample_clipping: True` at `clip_val 10.0` is OpenFold3's shipped
                    # default), and per-sample clipping is a different ALGORITHM from clipping
                    # the batch once, not a different constant: it changes the direction of
                    # the accumulated update. The loop owns what a sample is, because only the
                    # loop knows; `step()` owns the arithmetic on what it summed.
                    shard = batch.per_chip[dp_rank]
                    total, breakdown = 0.0, {}
                    for index in shard:
                        data = dataset.batch([index])
                        outputs = forward(data)
                        loss, terms, seeds = row(
                            data, {k: to_host(v.value) for k, v in outputs.items()},
                            weights=weights)
                        # One backward over the union of the seeded roots' ancestors. Calling
                        # Tensor.backward once per root would replay every shared ancestor
                        # once per root and land the fan-in sums partial.
                        backward([outputs[k] for k in seeds],
                                 [to_device(g, dataset.device) for g in seeds.values()])
                        # Every checkpointed block PINNED its own input across its untaped
                        # forward, and the backward that consumed the pin cannot drop it:
                        # `checkpoint` takes the pin precisely because the recompute happens
                        # inside the backward, so the owner of the release is the loop. This
                        # is that loop, and it is the only one in the tree that runs many
                        # steps in one process -- `bindcraft2` releases at all four of its
                        # boundaries and `perf/of3t_stepfloor/fullstep.py` releases per rep,
                        # which is why neither leaks and this did.
                        #
                        # Measured on the OpenFold3 training composition at crop 384: 120
                        # pins a step (48 pairformer blocks and 24 DiT blocks, inputs held
                        # twice where a block publishes two), of which ~69 hold a live DRAM
                        # buffer, 1.02 GB. Six steps of that is 8.1 GB standing under a
                        # backward whose own transient is ~23 GB, and the seventh step was
                        # refused a 906 MB buffer with 61.3 MB of contiguous space left.
                        release_pins()
                        # Clip THIS sample and add it to the accumulator, then clear the tape
                        # so the next sample's backward starts from nothing. Clearing it also
                        # leaves `replicas()` empty at the step, which is correct: under
                        # per-sample clipping the axis reduces the accumulator, not the tape.
                        opt.clip_and_accumulate()
                        opt.zero_grad()
                        total = total + loss / len(shard)
                        # A term is a ROW, not a number: `af3_loss` reports
                        # `{value, weight, contribution}` per term and `{value: None,
                        # skipped: ...}` for one it could not run. Averaging the row field by
                        # field keeps the skip reason legible and keeps `contribution`
                        # summing to the loss; averaging the row itself was a `dict / int`
                        # TypeError the first time a real objective met this loop.
                        for term, row_ in terms.items():
                            if not isinstance(row_, dict):
                                breakdown[term] = (breakdown.get(term, 0.0)
                                                   + row_ / len(shard))
                                continue
                            acc = breakdown.setdefault(term, {})
                            for k, v in row_.items():
                                if isinstance(v, bool) or not isinstance(v, (int, float)):
                                    acc[k] = v
                                else:
                                    acc[k] = acc.get(k, 0.0) + v / len(shard)
                    # EVERY PARAMETER MUST TRAIN, and the accumulator is where that is
                    # knowable: a name missing from it, or carrying an identically zero
                    # gradient, received nothing from any sample of this step. The set is
                    # intersected across the first steps rather than read at step 1, because
                    # upstream initialisations zero each residual branch's output projection
                    # and the weights behind it are legitimately zero until one update
                    # switches the branch on (measured on RFD4's own blocks: 36 of 174 at
                    # step 1, all alive at step 2). Nothing aggregate sees a dead parameter --
                    # ABB3 ran 1,388 steps with 356 of 436 of them dead behind a healthy loss,
                    # a plausible grad_norm and a digest that changed every step -- so the
                    # check is per parameter, and it refuses rather than warns.
                    if coverage is None:
                        coverage = GradientCoverage(sorted(opt.master), steps=coverage_steps)
                    coverage.observe(zero_or_missing(
                        {name: opt.accum.get(name) for name in opt.master}))
                    # The accumulated, per-sample-clipped gradient, summed across the axis
                    # inside step() together with the participation counts it divides by.
                    opt.step(replicas=launcher.replicas(params))
                    # The optimizer replaced each leaf's value with a new device tensor; this
                    # puts those tensors back where the walk found them, so the next forward
                    # reads what the optimizer moved. A no-op for a call-site census, whose
                    # hook hands the forward the leaf itself.
                    params.rebind()
                    # A rank's `total` is the mean over its own shard. The row reports the
                    # global batch's, so a two-chip run reads the same loss as one chip does.
                    if dp.width > 1:
                        total = dp.sum_scalars([total * len(shard)])[0] / global_batch
                    last = {"step": batch.step, "loss": total, "breakdown": breakdown,
                            "grad_norm": opt.last_grad_norm, "lr": opt.last_lr,
                            "s": launcher.tick()}
                    history.append(last)
                    if on_step is not None:
                        on_step(last)
                    ckpt.save(batch.step, opt, metrics={"loss": total},
                              provenance=prov.as_dict())
            if last is not None:
                ckpt.save(last["step"], opt, metrics={"loss": last["loss"]},
                          provenance=prov.as_dict(), force=True)
                # The trained weights in the model's own checkpoint format, which is what
                # `tt-bio predict --checkpoint` folds with. One rank writes it: the masters
                # are bit-identical across the axis.
                if train == "weights" and dp_rank == 0 and hasattr(forward, "write_weights"):
                    forward.write_weights(opt.master, ckpt.weights)
        # The step control, on the cumulative ratio over the whole run. Raises rather than
        # warns: a run whose updates never reached the weight the forward reads produced
        # nothing, and it produced nothing while every number above looked healthy.
        prov.config["displacement"] = (opt.check_displacement()
                                       if displacement_band is None else
                                       opt.check_displacement(band=displacement_band))
        # A rank's result leaves with the rank. The driver has no device and no optimizer, so
        # the masters it compares for divergence only exist inside this process. No-op when
        # nothing launched us as a rank.
        launcher.report(opt, params, history, ckpt, prov, plan=fit)
    finally:
        uninstall()
    return {"history": history, "params": params, "optimizer": opt,
            "checkpointer": ckpt, "provenance": prov, "plan": fit,
            "displacement": prov.config["displacement"]}


# One body, both modes. `train=` selects what the optimizer owns; there is no second
# recipe to drift from this one, and no pair of implementations to keep agreeing.
_RECIPES: Dict[str, Callable] = {"default": train_loop}


def recipe(name: str) -> Callable:
    try:
        return _RECIPES[name]
    except KeyError:
        raise KeyError(f"no recipe {name!r}; recipes are {sorted(_RECIPES)}") from None


def names() -> list:
    return sorted(_RECIPES)


def source(name: str) -> str:
    """The recipe's text, ready to paste into a file and edit.

    ``inspect.getsource`` of the same object :func:`recipe` returns, so what you read is what
    ran. A hand-written copy kept beside the implementation would be a second implementation,
    and the whole argument of this module is that a second one drifts.
    """
    return inspect.getsource(recipe(name))
