"""OpenFold3's training adapter: one registration, the shipped forward, upstream's featuriser.

This is the first entry in ``tt_bio.train.catalogue``, and it is deliberately thin. The
catalogue's contract is ``adapter(path, tokens=None) -> (forward, dataset)`` and nothing here
widens it: the forward composes the SHIPPED device modules, the featuriser is upstream's own,
and the loss is the registered ``af3`` objective. There is no second OpenFold3 forward and no
second loss.

What the forward is, and why it is not ``OpenFold3.fold()`` under a tape
-----------------------------------------------------------------------

Upstream's training forward runs the diffusion rollout under ``torch.no_grad()``
(``of3pkg043/openfold3/projects/of3_all_atom/model.py:381``), and in training it is the MINI
rollout (``no_mini_rollout_steps``, ``model.py:360``). Its coordinates feed ``aux_heads``,
which is where the gradient starts. ``OF3ConfidenceHead.distance_onehot`` says the same thing
from our side: *the confidence head is trained on a rolled-out structure that upstream
detaches*.

The shipped sampler agrees by construction. ``OF3SampleDiffusion.__call__`` reads the denoised
coordinates back to host inside the rollout loop and does the EDM update there
(``openfold3_sample_diffusion.py:171``), so no tape survives the recursion whatever the tape
does. That is consistent with upstream rather than a defect, and it is why a training forward
composes the modules rather than wrapping ``fold()``.

So one forward is:

  trunk (taped)
    -> rollout (no_grad, the shipped sampler, unchanged)
    -> one-step denoise of the noised ground truth (taped; what trains the diffusion module)
    -> confidence heads on the rolled-out structure (taped)

and ``OF3ConfidenceHead.forward_device`` -- which its own docstring calls "the training entry
point" -- returns five of the objective's seven outputs, distogram included.

What a batch can actually score
-------------------------------

``objectives.af3_loss`` keys eight terms off seven outputs and SKIPS a term whose inputs are
absent or whose weight is zero, recording it as skipped. Two are skipped here and neither is a
property of this model:

``plddt``   ``_TERMS["plddt"]`` reads ``per_atom_lddt`` and ``per_atom_weight`` from the BATCH,
            and both are functions of the PREDICTION -- upstream builds them inside the loss
            under ``no_grad`` and ``losses.atom_bespoke_lddt`` is the same function. A
            featuriser cannot emit them. The objective's contract assumes every label is
            batch-side and pLDDT's is not.

``bond``    reads ``pred_dist`` from the one-step denoise arm like ``mse`` and
            ``smooth_lddt``, which fire, but its weight is 0 in upstream's
            ``initial_training`` stage, so the objective skips it there by weight.

Both are visible in the objective's own breakdown, which is the designed behaviour: a zero for
a missing term moves the weighted sum and is how a run reports a healthy loss while training on
half its terms.
"""

from __future__ import annotations

import contextlib
import math
from pathlib import Path
from typing import Optional

import numpy as np
import torch

from . import catalogue, lineage, losses
from ..taped_ttnn import shim_scope

__all__ = ["adapter", "OpenFold3Dataset", "OpenFold3Forward", "MODEL", "denoise_draw",
           "sample_data", "trained_state_dict"]

MODEL = "openfold3"

#: Upstream stores the diffusion module twice (`sample_diffusion.diffusion_module.*` holds the
#: values of `diffusion_module.*`) and keeps the Fourier noise embedding as a fixed buffer. The
#: remaining 4170 of the checkpoint's 4935 keys are the parameters the step trains, which is the
#: float64 reference's gradient count.
_ALIAS = "sample_diffusion."
_FROZEN = ("diffusion_module.diffusion_conditioning.fourier_emb.",)


def _canonical_key(k: str) -> str:
    return k[len(_ALIAS):] if k.startswith(_ALIAS) else k

#: The objective's output names this forward produces today, in the order it produces them.
OUTPUTS = ("pred_xyz", "pred_dist", "distogram_logits", "plddt_logits", "pde_logits",
           "pae_logits", "resolved_logits")

#: Labels the af3 objective reads out of the batch, and what each one is for.
LABELS = ("true_xyz", "coord_mask", "true_dist", "lddt_pair_mask", "bond_mask",
          "frame_atom_index", "is_dna", "is_rna", "is_ligand")


# ------------------------------------------------------------------------------- dataset

def _one(v, i: int = 0):
    """One sample out of a leading batch axis. Upstream collates with a leading 1."""
    if torch.is_tensor(v):
        return v[i]
    if isinstance(v, dict):
        return {k: _one(x, i) for k, x in v.items()}
    if isinstance(v, (list, tuple)) and len(v) > i:
        return v[i]
    return v


def _frame_atom_index(n_token: int) -> np.ndarray:
    """The token triple ``(i-1, i, i+1)``, clamped at the ends.

    Upstream's alignment frame for a polymer token, and the convention the campaign's own
    census records for the frozen batch (``perf/of3t_gradients/coverage_census.json``:
    *"frames": the token triple (i-1, i, i+1), clamped at the ends*).
    """
    i = np.arange(n_token)
    return np.stack([np.clip(i - 1, 0, n_token - 1), i,
                     np.clip(i + 1, 0, n_token - 1)], axis=-1)


#: The crop OpenFold3's first training stage uses (`initial_training`).
CROP = 384


class OpenFold3Dataset:
    """Upstream's own featuriser output, one sample per index, plus the af3 labels.

    ``path`` is either

    * upstream's training-set directory: ``pdb_training_set/`` plus one
      ``training_cache*.json`` datapoint cache, the layout upstream's preprocessing writes and the public
      ``openfold3-data`` bucket serves. Each sample is featurised when it is asked for, by
      upstream's own ``WeightedPDBDataset`` and collator: index ``i`` draws a datapoint from
      the cache's ``datapoint_probabilities`` and crops it, both under a seed fixed by
      ``(seed, i)``, so a resumed or data-parallel run sees the same sample at the same step.
    * a ``.pt`` file holding a batch upstream's featuriser produced, or a directory of them.

    Featurisation is NOT generalised here and that is the catalogue's own position: each
    family's cropping and MSA handling is the part that is genuinely different, so a model
    arrives with its featuriser rather than with a shared data layer.

    Four members, no base class: ``__len__``, ``tokens``, ``device``, ``batch``. ``device`` is
    resolved lazily on first use, because a data-parallel run is one process per chip and the
    process that spawns the ranks has to reach the launcher holding no card.
    """

    def __init__(self, path, *, tokens: Optional[int] = None, seed: int = 0):
        path = Path(path)
        self._device = None
        self._cache: dict[int, dict] = {}
        self._tokens = tokens
        self.seed = int(seed)
        self.upstream = _Upstream(path, tokens or CROP) if _Upstream.holds(path) else None
        if self.upstream and tokens is None:
            self._tokens = CROP
        self.paths = ([] if self.upstream else
                      sorted(path.glob("*.pt")) if path.is_dir() else [path])
        if not (self.upstream or self.paths):
            raise FileNotFoundError(
                f"{path} is not OpenFold3 training data. Expected upstream's training-set "
                f"layout (a pdb_training_set/ directory beside one training_cache*.json) or "
                f"featurised .pt batches; see docs/training.md#data")

    def __len__(self) -> int:
        return len(self.upstream) if self.upstream else len(self.paths)

    @property
    def tokens(self) -> int:
        if self._tokens is None:
            self._tokens = int(self._features(0)["token_mask"].shape[0])
        return self._tokens

    @property
    def device(self):
        if self._device is None:
            from ..tenstorrent import get_device
            self._device = get_device()
        return self._device

    def _features(self, index: int) -> dict:
        if index not in self._cache:
            if self.upstream:
                # One sample is ~0.8 GB of features, so only the last is kept: the census
                # pass and the first step ask for the same index back to back.
                self._cache.clear()
                raw = self.upstream.sample(index, self.seed)
            else:
                raw = torch.load(self.paths[index], map_location="cpu", weights_only=False)
            self._cache[index] = {k: _one(v) for k, v in raw.items()}
        return self._cache[index]

    def batch(self, indices) -> dict:
        """One sample as ``{features, labels...}``. More than one index is refused.

        The loop accumulates per sample and clips per sample -- upstream's
        ``per_sample_clipping: True`` is a different ALGORITHM from clipping the batch once,
        not a different constant -- so it never asks for more than one, and collating an OF3
        batch on the token axis would be a second featuriser.
        """
        indices = list(indices)
        if len(indices) != 1:
            raise ValueError(f"OpenFold3 batches one sample at a time; got {indices}. The "
                             f"loop clips per sample, which is upstream's own shipped "
                             f"default, so it never needs more than one")
        f = self._features(indices[0])
        gt = f.get("ground_truth", {})
        tok = f["token_mask"].float()
        n = int(tok.shape[0])

        # Token scope, one representative atom per token: upstream's own convention for this
        # batch is `ground_truth.start_atom_index`, each token's first atom.
        #
        # THE TWO AXES ARE DIFFERENT LENGTHS and conflating them is the whole of this
        # function's risk. The features are the CROP -- 384 tokens on the pinned batch, of
        # which `token_mask` marks 56 real -- while `ground_truth` is the real tokens only,
        # 56 of them. Every label has to be scattered onto the crop's axis, because that is
        # the axis the model's outputs live on; a label built at the ground truth's length
        # would silently score the first 56 logits against all 56 labels and read healthy.
        rep = gt["start_atom_index"].long() if "start_atom_index" in gt \
            else f["start_atom_index"].long()
        xyz = gt["atom_positions"].float()
        resolved = gt.get("atom_resolved_mask", gt.get("atom_mask")).float()
        real = np.flatnonzero(tok.numpy() > 0)

        # THE CROP IS A SUBSET OF THE GROUND TRUTH, and for anything bigger than the token
        # budget it is a strict one. Upstream crops the FEATURES and hands back the whole
        # deposited structure: 4ky2 arrives as 384 cropped tokens against 480 ground-truth
        # ones and 2wig as 384 against 2512. Lining them up by POSITION would score the
        # crop's labels against the structure's first 384 tokens, which are not the same
        # tokens; taking only the targets whose count happens to match would train on the
        # ones that fit, which is the small pool.
        #
        # `token_index` is the join and is carried on both sides: it is each token's index in
        # the UNCROPPED structure, so `f["token_index"][real]` is a subset of
        # `gt["token_index"]` and matching the values is exact. On a target that fits, the
        # permutation is the identity and this is a no-op, which is why it runs
        # unconditionally rather than only on the mismatch -- a join that is only taken on
        # the hard case is a join nobody tests.
        if "token_index" in gt:
            gt_tok = gt["token_index"].long().numpy().reshape(-1)
            crop_tok = f["token_index"].long().numpy().reshape(-1)[real]
            where = {int(t): i for i, t in enumerate(gt_tok)}
            absent = [int(t) for t in crop_tok if int(t) not in where]
            if absent:
                raise ValueError(
                    f"{len(absent)} cropped tokens are not in ground_truth by token_index "
                    f"(first {absent[:5]}); the crop is not a subset of the structure it is "
                    f"scored against")
            sel = np.fromiter((where[int(t)] for t in crop_tok), np.int64, len(crop_tok))
            rep = rep[sel]
        elif len(real) != int(rep.shape[0]):
            raise ValueError(
                f"{int(tok.sum())} real tokens on the crop axis but {int(rep.shape[0])} in "
                f"ground_truth, and ground_truth carries no token_index to join them on; the "
                f"scatter below would put a label on the wrong token")
        if len(real) != int(rep.shape[0]):
            raise ValueError(
                f"{int(tok.sum())} real tokens on the crop axis but {int(rep.shape[0])} "
                f"representative atoms after the token_index join")
        true_xyz = np.zeros((n, 3), np.float64)
        coord_mask = np.zeros(n, np.float64)
        true_xyz[real] = xyz[rep].numpy().astype(np.float64)
        coord_mask[real] = resolved[rep].numpy().astype(np.float64)

        true_dist = losses._pdist(true_xyz)
        pair = coord_mask[:, None] * coord_mask[None, :]
        is_dna = f["is_dna"].float().numpy().astype(np.float64)
        is_rna = f["is_rna"].float().numpy().astype(np.float64)
        is_ligand = f["is_ligand"].float().numpy().astype(np.float64)
        lddt_pair_mask = losses.lddt_mask(true_dist, pair, is_dna + is_rna)

        bonds = f["token_bonds"].float().numpy().astype(np.float64)
        return {
            "features": f,
            "true_xyz": true_xyz,
            "coord_mask": coord_mask,
            # Upstream's `batch["atom_mask"]` at token scope: the representative atom exists,
            # which is every real token. The resolved term averages over it, not over the crop.
            "atom_mask": tok.numpy().astype(np.float64),
            "true_dist": true_dist,
            "lddt_pair_mask": lddt_pair_mask,
            "bond_mask": bonds * pair,
            "frame_atom_index": _frame_atom_index(n),
            "is_dna": is_dna, "is_rna": is_rna, "is_ligand": is_ligand,
            # `af3` is OpenFold3's and Protenix-v2's mol_type convention. Naming it is what
            # keeps an unresolved dna/rna split from being a silent weighting error.
            "mol_type_convention": "af3",
            "pdb_id": f.get("pdb_id"),
        }


class _Upstream:
    """Upstream's ``WeightedPDBDataset`` over a training-set directory, one collated sample
    per call. The paths are the ones upstream's own ``pdb_subset_helpers`` writes into its
    runner config; the crop mix and template count are its ``initial_training`` stage."""

    ROOT = "pdb_training_set"

    @classmethod
    def holds(cls, path: Path) -> bool:
        return path.is_dir() and (path / cls.ROOT).is_dir()

    def __init__(self, path: Path, crop: int):
        caches = sorted(path.glob("training_cache*.json"))
        if len(caches) != 1:
            raise FileNotFoundError(
                f"{path} needs exactly one datapoint cache, training_cache*.json, beside "
                f"{self.ROOT}/; found {[c.name for c in caches] or 'none'}")
        try:
            from .._vendor.openfold3.core.data.framework.data_module import \
                openfold_batch_collator
            from .._vendor.openfold3.core.data.framework.single_datasets import pdb
            from .._vendor.openfold3.projects.of3_all_atom.config import dataset_configs
        except ModuleNotFoundError as exc:
            raise ModuleNotFoundError(
                f"OpenFold3's training featuriser needs {exc.name!r}: pip install "
                f"'tt-bio[train]'") from exc
        root, std = path / self.ROOT, path / self.ROOT / "preprocessed_pdb_data" / "standard"
        paths = dataset_configs.TrainingDatasetPaths(
            dataset_cache_file=str(caches[0]),
            alignment_array_directory=str(root / "alignment_arrays"),
            target_structures_directory=str(std / "structure_files"),
            target_structure_file_format="npz",
            reference_molecule_directory=str(std / "reference_mols"),
            template_cache_directory=str(root / "templates" / "train_template_cache"),
            template_structure_array_directory=str(
                root / "templates" / "template_structure_arrays"),
            template_file_format="npz")
        # Upstream's `register_dataset_config` returns None, so the registry is the only way
        # to reach the config class.
        cfg = dataset_configs.DATASET_CONFIG_REGISTRY.get("WeightedPDBDataset")(
            name="weighted-pdb", debug_mode=True, dataset_paths=paths,
            template={"n_templates": 4, "take_top_k": False},
            crop={"token_crop": {"enabled": True, "token_budget": crop,
                                 "crop_weights": {"contiguous": 0.2, "spatial": 0.4,
                                                  "spatial_interface": 0.4}},
                  "chain_crop": {"enabled": True}},
            sample_in_order=True, loss={"loss_weights": {}})
        self.dataset = pdb.WeightedPDBDataset(cfg)
        self.collate = openfold_batch_collator
        dc = self.dataset.datapoint_cache
        w = (np.asarray(dc["datapoint_probabilities"], np.float64)
             if "datapoint_probabilities" in dc.columns else np.ones(len(dc)))
        self.p = w / w.sum()

    def __len__(self) -> int:
        return len(self.p)

    def sample(self, index: int, seed: int) -> dict:
        """Draw, crop and collate sample ``index``; global RNGs are restored afterwards."""
        import random
        rng = np.random.default_rng([seed, index])
        dp = int(rng.choice(len(self.p), p=self.p))
        state = random.getstate(), np.random.get_state(), torch.get_rng_state()
        try:
            s = int(rng.integers(2**31))
            random.seed(s), np.random.seed(s), torch.manual_seed(s)
            return self.collate([self.dataset[dp]])
        finally:
            random.setstate(state[0]), np.random.set_state(state[1])
            torch.set_rng_state(state[2])


#: Upstream's public training-set bucket, and where the 8-structure sample is cached.
SAMPLE_BUCKET = "https://openfold3-data.s3.amazonaws.com/"
SAMPLE_DIR = "openfold3-train-sample"


def sample_data(root=None, *, quiet: bool = False) -> Path:
    """Upstream's 8-structure training sample, fetched once into the weight cache.

    The eight are the ones upstream's own ``sample_subset_cache`` draws at seed 42 (1kvu 1wyc
    1xbs 210l 2wig 3wnm 4ky2 5ron, 292 datapoints). The datapoint cache for them and the list
    of files with their sha256 ship in ``tt_bio/data``; the files themselves come from the
    public bucket and are checked against it. About 73 MB.
    """
    import json
    import shutil
    from concurrent.futures import ThreadPoolExecutor
    from .. import weights

    data = Path(__file__).resolve().parent.parent / "data"
    dest = weights.cache_root(root) / SAMPLE_DIR
    files = json.loads((data / "openfold3_train_sample_files.json").read_text())
    todo = [(rel, sha) for rel, sha in files.items()
            if not (dest / _Upstream.ROOT / rel).is_file()]
    if todo:
        if not quiet:
            print(f"fetching upstream's OpenFold3 training sample, {len(todo)} files, to {dest}",
                  flush=True)
        def one(item):
            rel, sha = item
            weights.fetch_file((f"{SAMPLE_BUCKET}{_Upstream.ROOT}/{rel}",),
                               dest / _Upstream.ROOT / rel, sha256=sha, quiet=True,
                               check_archive=False)
        with ThreadPoolExecutor(max_workers=16) as pool:
            list(pool.map(one, todo))
    cache = dest / "training_cache_with_templates_subset_8.json"
    if not cache.is_file():
        shutil.copyfile(data / "openfold3_train_sample.json", cache)
    return dest


# ------------------------------------------------------------------------------- forward

class OpenFold3Forward:
    """The objective's outputs from an OF3 batch, on device, on the tape.

    Holds the built model, so ``recipes.train_loop`` can take the parameter set from a WALK of
    it rather than from the call-site census -- the census cannot see a weight a module fuses
    in its own ``__init__``, which is 2119 of 2531 on this trunk.
    """

    def __init__(self, checkpoint, *, device=None, num_cycles: int = 1, rollout: int = 20,
                 seed: int = 0, exact_scope: str = "all"):
        self.checkpoint = Path(checkpoint)
        self.rollout = int(rollout)
        self.num_cycles = int(num_cycles)
        self.seed = int(seed)
        #: Where an enclosing `exact_training` run is allowed to reach. ``"all"`` is the whole
        #: differentiated forward. ``"trunk"`` keeps it to the taped trunk -- which is the
        #: section the campaign's pre-registered tensor clause was measured on -- and runs the
        #: diffusion half device-native in BOTH arms. It exists because the instrument cannot
        #: run the diffusion decoder today: the exact ops replace `ttnn.layer_norm` globally,
        #: an earlier norm in the module hands back a host-built tensor, and
        #: `openfold3_diffusion_decoder.py:99` then norms a buffer its own `pad_dim` path has
        #: already deallocated (`TT_FATAL ... tensor.is_allocated()`, four arms, ~400 s in).
        if exact_scope not in ("all", "trunk"):
            raise ValueError(f"exact_scope is 'all' or 'trunk', not {exact_scope!r}")
        self.exact_scope = exact_scope
        self._device = device
        self._model = None
        self._registered = False
        #: Token-scope coordinates to hand the confidence heads INSTEAD of running the
        #: rollout. `None` runs it. The only switch on this forward, and it exists because
        #: `diffusion_rollout` is a coverage path: a path is covered when a parameter
        #: gradient moves against an arm with it OFF.
        self.repr_coords_in = None
        self.rollout_ran = None
        #: Run upstream's one-step denoise arm -- what puts a gradient on the diffusion
        #: module and what `mse`, `smooth_lddt` and `bond` are seeded off. On by default.
        #: It was off while three `sampler.dc.w_lin_*` gradients came back non-finite; that
        #: was `ttnn.matmul(transpose_a=True)` on an fp32 activation and a bf16 cotangent
        #: (D257, `autograd._matmul`), not the diffusion backward.
        self.denoise = True
        self.denoise_sigma = None

    @property
    def device(self):
        if self._device is None:
            from ..tenstorrent import get_device
            self._device = get_device()
        return self._device

    @property
    def model(self):
        """The shipped ``OpenFold3`` module, built once on first use."""
        if self._model is None:
            self._record()
        return self._model

    def _record(self, *, differentiable: bool = False):
        """Build the model under a lineage recording. Returns what ``trained_state_dict`` needs:
        the checkpoint as loaded, the ``Lineage``, the walk and ``{path: (keys, host)}``."""
        import ttnn
        from ..tenstorrent import walk_device_weights
        dev = self.device
        sd = _load_state_dict(self.checkpoint)
        ckc = ttnn.init_device_compute_kernel_config(
            dev.arch(), math_fidelity=ttnn.MathFidelity.HiFi4,
            fp32_dest_acc_en=True, packer_l1_acc=True)
        with lineage.recording(sd, _canonical_key, differentiable=differentiable) as (traced,
                                                                                      lin):
            self._build(traced, ckc)
        walked = list(walk_device_weights(self._model))
        uploads = lin.by_path(walked, hosts=True)
        self._lineage = {p: keys for p, (keys, _h) in uploads.items()}
        self._claimed = {k for k in map(_canonical_key, sd) if not k.startswith(_FROZEN)}
        return sd, lin, walked, uploads

    def unsourced(self) -> dict:
        """``{walk path: bool mask}`` of device-weight elements no checkpoint value reaches.

        Builds a second copy of the model with a differentiable lineage; it is gone on return.
        """
        fwd = OpenFold3Forward(self.checkpoint, device=self.device)
        _sd, lin, _walked, uploads = fwd._record(differentiable=True)
        return lineage.unsourced(lin, uploads, _canonical_key)

    def write_weights(self, masters: dict, path) -> Path:
        """Write ``masters`` as an OpenFold3 checkpoint in the shipped format, atomically."""
        import os
        path = Path(path)
        tmp = path.with_suffix(".part")
        torch.save(trained_state_dict(masters, self.checkpoint, device=self.device), tmp)
        os.replace(tmp, path)
        return path

    def _build(self, sd, ckc):
        """The shipped module plus everything the training step adds to it."""
        from ..openfold3_fold import OpenFold3
        dev = self.device
        # No precision levers: the step differentiates the plain verbs (a fused `_sdpa32` has no
        # backward), and training was graded without them.
        self._model = OpenFold3(sd, ckc, num_cycles=self.num_cycles, levers=())
        # The confidence heads upload their device weights lazily inside
        # `forward_device`, so a walk run before the first forward would not find them
        # and the optimizer's parameter set would be short by the whole confidence head.
        from ..openfold3_confidence import OF3ConfidenceHead
        self._model.confidence_head = OF3ConfidenceHead(
            self._model._confidence_sd, dev, ckc)
        self._model.confidence_head.materialize_device_weights()
        # Every TriangleMultiplication's in-projection as leaves the walk below finds.
        # Without this they are cut from host torch inside the taped forward, after
        # registration, and train as constants.
        from ..tenstorrent import train_in_projections
        train_in_projections(self._model)
        # The diffusion atom transformers upload their weights lazily inside the forward
        # too (D256); materialise them for the same reason.
        dm = self._model.sampler.dm
        for at in (dm.enc_at, dm.dec.at):
            at.materialize_device_weights()
        # The encoder's RefAtomFeatureEmbedder runs on the host in inference, so its eight
        # linears reach the module as a constant `cl0`/`plm0` and would never train (0.46 %
        # of the float64 step's squared gradient). The denoise arm runs the shipped device
        # module instead; the rollout keeps the host embedding.
        from ..openfold3 import RefAtomFeatureEmbedder
        from ..openfold3_weights import _sub
        dm.ref_embed = RefAtomFeatureEmbedder(
            _sub(sd, "diffusion_module.atom_attn_enc.ref_atom_feature_embedder"), ckc)
        # The input embedder's atom encoder runs on the host in inference too
        # (`run_input_atom_encoder`), so s_input reached the trunk as a constant and its 93
        # tensors never trained (D263). The taped step differentiates this device copy, built
        # at fp32 as the host leg computes all but its atom transformer.
        import ttnn
        from ..openfold3 import InputAtomEncoder
        from ..tenstorrent import device_dtype_override
        with device_dtype_override(ttnn.float32):
            self._model.input_atom_enc = InputAtomEncoder(
                _sub(sd, "input_embedder.atom_attn_enc"), ckc)

    def parameters(self) -> dict:
        """Every device weight the built model reaches, registered as a taped leaf.

        A WALK, not the call-site census: the census sees a weight only where the forward
        routes through ``tt_bio.ops.linear``, and every weight a module fuses in its own
        ``__init__`` -- the TriangleMultiplication in-projection, all of them -- is invisible
        to it. Registration is by the identity of the raw handle, so a walked weight becomes a
        leaf wherever it is passed.
        """
        from .. import autograd as ag
        from ..tenstorrent import walk_device_weights
        walked = {path: t for path, _owner, _key, t in walk_device_weights(self.model)}
        if not self._registered:
            for t in walked.values():
                ag.parameter(t)
            self._registered = True
        return walked

    def check_registered(self) -> None:
        """Raise if the model holds a device tensor that is not a registered leaf.

        Run after every taped forward. A weight uploaded lazily inside a forward appears after
        the registering walk and trains as a constant with nothing to say so: the trimul
        in-projections (D254) and the diffusion atom transformers (D256) both did. This is the
        catcher for the next one, whatever module it is in.

        Also raises if the forward sliced a registered weight without reaching the tape (D262):
        the leaf is registered but the slice is a constant, so the walk alone cannot see it.

        And from the checkpoint's side: raises if a key the step trains was never uploaded into
        a registered leaf (``lineage``). A module the forward applies on the host has no device
        tensor for the walk to find, which is how D261 and D263 trained nothing unseen.
        """
        from collections import Counter
        from .. import autograd as ag
        from ..taped_ttnn import take_raw_param_slices
        from ..tenstorrent import walk_device_weights
        walked = [(p, t) for p, _o, _k, t in walk_device_weights(self.model)]
        late = [p for p, t in walked if ag.parameter_for(t) is None]
        if late:
            raise RuntimeError(
                f"{len(late)} device tensors appeared after parameter registration and would "
                f"train as constants, e.g. {late[:4]}. Materialise them before the walk "
                f"(OpenFold3Forward.model).")
        raw = Counter(take_raw_param_slices())
        if raw:
            raise RuntimeError(
                f"{sum(raw.values())} slices of registered weights did not reach the tape and "
                f"train as constants, by site: {dict(raw)}")
        trained = {k for p, t in walked if ag.parameter_for(t) is not None
                   for k in self._lineage.get(p, ())}
        untrained = sorted(self._claimed - trained)
        if untrained:
            raise RuntimeError(
                f"{len(untrained)} of {len(self._claimed)} checkpoint tensors this step trains "
                f"were never uploaded into a registered leaf, so they train as constants: "
                f"{untrained}")

    def __call__(self, batch) -> dict:
        from .. import autograd as ag
        from ..openfold3_fold import build_dm_device_aux, create_noise_schedule
        from ..openfold3_host_prep import (derive_block_aux, derive_relpos,
                                           derived_template_slots,
                                           ref_atom_device_inputs, ref_atom_embed,
                                           run_input_atom_encoder)
        from ..openfold3_data import make_openfold3_msa_features
        from ..openfold3_sample_diffusion import fourier_noise_emb
        from ..openfold3_weights import _sub
        import ttnn

        m = self.model
        dev, ckc = self.device, m.ckc
        f = batch["features"]
        self.parameters()

        # ---- host prep. The SHIPPED functions, in the order `worker.py` calls them.
        aux = derive_block_aux(f)
        template_feat, template_slots = derived_template_slots(f)
        relpos = derive_relpos(f)
        msa_feat = make_openfold3_msa_features(f)
        token_feats = torch.cat([f["restype"], f["profile"],
                                 f["deletion_mean"].unsqueeze(-1)], dim=-1)
        s_input = torch.cat([run_input_atom_encoder(dev, ckc, m.sd, f, aux), token_feats], dim=-1)
        cl0, plm0 = ref_atom_embed(
            _sub(m.sd, "diffusion_module.atom_attn_enc.ref_atom_feature_embedder"), f)
        n_atom, n_token = aux["n_atom"], aux["n_token"]
        ft = lambda x, d=ttnn.bfloat16: ttnn.from_torch(  # noqa: E731
            x.float(), layout=ttnn.TILE_LAYOUT, device=dev, dtype=d)

        tok = f["token_mask"].float()
        # TWO pair masks, because the two consumers want different ranks and neither is
        # wrong: the Pairformer multiplies a [1, N, N] mask into a contraction, the diffusion
        # module a [1, N, N, 1] one into a channel-carrying pair. Passing one to the other
        # lands in ttnn.permute with input_rank != dims.size(), deep inside a
        # TriangleMultiplication chunk.
        pm = tok[:, None] * tok[None, :]
        pair_mask_pf = ft(pm.unsqueeze(0))
        pair_mask_dm = ft(pm.reshape(n_token, n_token, 1).unsqueeze(0))
        attn_mask_d = ft(((1.0 - tok) * -1e9).reshape(1, 1, 1, n_token))
        dm_aux = build_dm_device_aux(
            dev, ft, cl0=cl0, plm0=plm0, atom_mask=aux["atom_mask"],
            atom_to_token_index=aux["atom_to_token_index"],
            npe_q_indices=aux["npe_q_indices"], npe_k_indices=aux["npe_k_indices"],
            zij_mask=aux["zij_mask"], key_block_idxs=aux["key_block_idxs"],
            invalid_mask=aux["invalid_mask"], mask_trunked=aux["mask_trunked"],
            atom_to_token_mean=aux["atom_to_token_mean"],
            token_mask=tok, n_atom=n_atom, n_token=n_token,
            nb=aux["nb"], NP=aux["NP"], n_tok_pad=n_token)
        # The ref-atom features, for each atom encoder's embedder at its own dtype.
        ref_in = ref_atom_device_inputs(dev, f, aux["atom_mask"], aux["NP"])
        ie_dt = m.input_atom_enc._act_dtype
        ie_in = ref_atom_device_inputs(dev, f, aux["atom_mask"], aux["NP"], dtype=ie_dt)
        # Its own aggregation matrix: dm_aux's is bf16, where 1/7 rounds by 0.2 % and biases
        # every token's mean the same way instead of averaging out.
        ie_mean = ft(aux["atom_to_token_mean"].unsqueeze(0), ie_dt)

        # ---- the taped forward, in two blocks with the rollout raw between them.
        #
        # The rollout CANNOT be inside the tape, and unwrapping its arguments with `_v` is not
        # enough to keep it out: it re-enters `ops.linear` at every projection inside itself,
        # the hook sees a registered parameter on the tape whatever the activations are, and
        # hands back a `Tensor` again. One of those meets the raw `ttnn.layer_norm` beside it
        # in `OF3DiffusionConditioning` and pybind refuses it; the next meets the sampler`s own
        # per-step `ttnn.to_torch`. So the rollout runs under `ag.no_grad()`, where the hook
        # returns the shipped result RAW instead of rewrapping it.
        #
        # Two blocks is the honest shape rather than a workaround. Upstream detaches the
        # rollout (`model.py:381`), so the gradient genuinely does not cross it, and the tape
        # built by the first block survives the second being opened: `tape()` restores the
        # module-level `ttnn` name and drops the raw-handle map, and neither touches the node
        # graph or the registered leaves.
        with ag.tape():
            # s_input is computed twice. Its VALUE is the host leg's, the one inference computes:
            # 5.0e-4 from upstream float64 on the 64-token batch, where no device copy gets
            # under 3.3e-3 (on-device fp32 matmuls cost ~1e-3 each; ref_sinput.py,
            # bisect_fp32.py), and a bf16 copy's forward took the step's global rel from 0.135
            # to 0.186. Its GRADIENT goes through InputAtomEncoder, whose 93 weights are
            # registered leaves (D263). Every consumer of s_input sees the forward it saw before.
            s_input_d = ag.straight_through(ft(s_input.unsqueeze(0)), m.input_atom_enc(
                ie_in, dm_aux["amc_d"], dm_aux["kidx_tt"], dm_aux["valid_d"], dm_aux["mb_d"],
                dm_aux["pm_d"], dm_aux["amc_na_d"], ie_mean,
                ft(token_feats.unsqueeze(0)), n_atom, aux["NP"], aux["nb"]))
            relpos_d = ag.Tensor(ft(relpos.unsqueeze(0)))
            bonds_d = ag.Tensor(ft(f["token_bonds"].unsqueeze(0).unsqueeze(-1)))
            s_init, z_init = m.input_glue(s_input_d, relpos_d, bonds_d)
            s_trunk, z_trunk = m.trunk(
                s_init, z_init, {k: ag.Tensor(ft(v)) for k, v in template_feat.items()},
                ag.Tensor(ft(msa_feat.unsqueeze(0))), s_input_d,
                template_slots=template_slots, pair_mask=pair_mask_pf, attn_mask=attn_mask_d)

        # ---- the structure the confidence heads score. Raw, no tape open.
        #
        # `repr_coords_in` short-circuits the rollout with a structure the caller supplies,
        # and that is the ROLLOUT-OFF arm. Every other tensor in this forward is identical
        # between the two, so a parameter gradient that differs differs because of the
        # structure the rollout produced, which is the whole of the rollout's reach into a
        # gradient once upstream has detached it.
        # THE CROP OWN representative atoms, not the ground truth ones. `xl` below is the
        # rollout coordinate array and it holds the CROP atoms; `ground_truth` numbers the
        # atoms of the UNCROPPED structure, so on anything larger than the token budget its
        # indices run off the end -- index 2679 into a 2678-atom crop, measured on 2wig at
        # crop 384. The ground truth indices belong on the LABEL side, where
        # `OpenFold3Dataset.batch` uses them to read `ground_truth.atom_positions`.
        real = torch.nonzero(tok > 0, as_tuple=True)[0]
        # At the REAL tokens, not the whole crop axis: both use sites pair `rep` with `real`,
        # and on a target that does not fill the crop the two lengths differ -- 311 real tokens
        # against a 384 axis on 5ron, three steps into a twelve-step arm.
        rep = f["start_atom_index"].long()[real]
        if self.repr_coords_in is not None:
            repr_x = torch.as_tensor(np.asarray(self.repr_coords_in, np.float32)).reshape(-1, 3)
            self.rollout_ran = False
        else:
            # THE EXACTNESS INSTRUMENT IS OFF HERE WHATEVER THE RUN ASKED FOR, and that is a
            # scope decision rather than a cost one. `exact_training` replaces softmax and
            # layer norm to make a GRADIENT exact; upstream detaches the rollout
            # (`model.py:381`) so nothing computed in it reaches one. Leaving it installed
            # also broke: `_ln_forward64` downloads its input to host float64 and the shipped
            # decoder has already deallocated that buffer, so the reference arm died on
            # `tensor.is_allocated()` 398 s in, inside the discovery pass, before step 0. Both
            # It takes `without_exact` and not `exact_training(False)`: the second changes what
            # the SWITCH reports, and `install()` read that switch once when the run started.
            # Both arms of a comparison run the identical rollout, so scoping it out cannot bias
            # one against the other -- and it is what keeps the reference arm affordable.
            #
            # `no_grad` for the arithmetic and the SHIM for the plumbing, because the two
            # answer different halves. `no_grad` stops `_tape` building nodes the detached
            # rollout would never use. The shim is what lets the sampler`s own raw `ttnn.`
            # verbs accept the `Tensor` the hook hands back at every `ops.linear` inside it --
            # unwrapping the ARGUMENTS with `_v` cannot reach those, which is why the rollout
            # died on `ttnn.layer_norm` in `OF3DiffusionConditioning` and then on its own
            # per-step `ttnn.to_torch`.
            with ag.no_grad(), shim_scope(), ag.without_exact():
                schedule = create_noise_schedule(self.rollout, **m.ns_cfg)
                xl0, rots, trans, noise, ts, ctau = m._gen_rollout(schedule, n_atom, self.seed)
                xl_d = m.sampler(
                    ft(xl0.unsqueeze(0)), _v(s_trunk), _v(s_input_d), _v(z_trunk), _v(relpos_d),
                    ft(tok.reshape(1, n_token)), pair_mask_dm,
                    ft(tok.reshape(n_token, 1).unsqueeze(0)),
                    dm_aux["cl0_d"], dm_aux["plm0_d"], dm_aux["amc_d"], dm_aux["amc_na_d"],
                    dm_aux["idx_tt"], dm_aux["flat_tt"], dm_aux["zij_mask_d"], dm_aux["kidx_tt"],
                    dm_aux["valid_d"], dm_aux["mb_d"], dm_aux["pm_d"], dm_aux["mean_d"],
                    dm_aux["tok_pad_tt"], dm_aux["tok_col_pad_tt"],
                    n_atom, aux["NP"], aux["nb"], n_token, n_token,
                    schedule, rots, trans, noise, ts, ctau, m.step_scale)
                xl = torch.Tensor(ttnn.to_torch(_v(xl_d))).float().reshape(n_atom, 3)
                self.rollout_coords = xl
                self.rollout_ran = True
                # Atom scope -> token scope, on the CROP's axis. The representative index is the
                # real tokens' first atoms; padded rows stay at the origin and the pair mask
                # drops them.
                repr_x = torch.zeros(n_token, 3)
                repr_x[real] = xl[rep]
        self.repr_coords = repr_x

        # ---- the one-step denoise. THIS is what trains the diffusion module.
        #
        # Upstream's diffusion objective is not the rollout: it draws a noise level from the
        # log-normal `sample_noise_level`, noises the GROUND TRUTH at it, denoises once, and
        # takes the weighted MSE against the truth. The rollout is detached and feeds the
        # confidence heads; this arm is differentiated and feeds `mse`, `smooth_lddt` and
        # `bond`. Two separate uses of the same module, and conflating them is how a training
        # forward ends up with a diffusion module that never receives a gradient.
        #
        # `pred_xyz` has to come back on the TOKEN axis, because every other label the
        # objective reads is token-scope and `af3_loss` gives them one `true_xyz`. The
        # representative-atom gather is a one-hot matmul rather than an index: `ag.matmul` is
        # taped, indexing is not, and the one-hot is exact.
        pred = {}
        if self.denoise:
            s = m.sampler
            sigma, eps = denoise_draw(self.seed, n_atom)
            amask = aux["atom_mask"].float()
            gt_idx = _gt_atom_index(f, f["ground_truth"], real, n_atom)
            have = torch.from_numpy(gt_idx >= 0)
            xl_true = torch.zeros(n_atom, 3)
            xl_true[have] = f["ground_truth"]["atom_positions"].float()[
                torch.from_numpy(gt_idx[gt_idx >= 0])]
            xl_true = xl_true * amask[:, None]
            xl_noisy = xl_true + sigma * torch.from_numpy(eps).float()
            xl_noisy = xl_noisy * amask[:, None]
            rl_noisy = xl_noisy / math.sqrt(sigma * sigma + m.sigma_data ** 2)
            n_emb = fourier_noise_emb(sigma, m.sigma_data, s.fourier_w, s.fourier_b)

            one_hot = torch.zeros(n_token, n_atom)
            one_hot[real, rep] = 1.0

            # `exact_scope="trunk"` takes the instrument out for the diffusion half. Both
            # arms then run it device-native, so it cannot bias one against the other, and the
            # grade narrows to the section the tensor clause named.
            denoise_exact = (ag.without_exact() if self.exact_scope == "trunk"
                             else contextlib.nullcontext())
            with denoise_exact, ag.tape():
                # THE DTYPE BOUNDARY, crossed through the sampler's own helper rather than a
                # copy of it. `OF3_DIFFUSION_FP32_DEVICE` (default on) builds the diffusion
                # weights in fp32 against a bf16 trunk; driving `dc`/`dm` directly without
                # this hands fp32 weights bf16 activations. Measured, before the fix was in:
                # the squared gradient norm read 4.87e+11 against upstream's model
                # denominator of 10.279642678524981, with every loss VALUE sane -- a forward
                # that looks healthy and a backward that is not.
                #
                # The two conditioning masks stay bf16, as the rollout leaves them: the
                # conditioning's activations come out of `_lin` bf16, and ttnn.multiply of a
                # bf16 tensor by an fp32 last-dim-1 mask returns garbage that changes run to
                # run (PROBE_BCAST.json: up to 16061 wrong elements, every rank; exact when
                # both are bf16 or x is fp32). Cast, they made the A/A disagree (probe_aa.py).
                c = s.to_act_dtype
                si = s.dc.single(c(s_trunk), c(s_input_d),
                                 c(ag.Tensor(ft(n_emb.reshape(1, 1, 256)))),
                                 ft(tok.reshape(n_token, 1).unsqueeze(0)))
                zij = s.dc.pair(c(z_trunk), c(relpos_d), pair_mask_dm)
                # The conditioning hands back bf16 si/zij; the rollout lifts them to the
                # activation dtype inside `pad_dim`. Fed bf16, the fp32 module's one-step
                # denoise read 0.80-0.88 A RMS from the truth, varying run to run, against
                # 0.18 A lifted and 0.52 A for the noisy input (PROBE_FWD_T64_*.json). The
                # noisy coordinates are uploaded at that dtype too, as the rollout does.
                cl0_t, plm0_t = s.dm.ref_embed(*ref_in)
                xl_den = s.dm(
                    c(s_trunk), c(si), c(zij), c(cl0_t), c(plm0_t),
                    ag.Tensor(ft(s._pad_atoms_host(rl_noisy, n_atom, aux["NP"]), s._act_dtype)),
                    ag.Tensor(ft(xl_noisy.unsqueeze(0), s._act_dtype)),
                    c(dm_aux["amc_d"]), c(dm_aux["amc_na_d"]),
                    dm_aux["idx_tt"], dm_aux["flat_tt"],
                    c(dm_aux["zij_mask_d"]), dm_aux["kidx_tt"], dm_aux["valid_d"],
                    c(dm_aux["mb_d"]), c(dm_aux["pm_d"]), c(dm_aux["mean_d"]),
                    c(dm_aux["tok_pad_tt"]), c(dm_aux["tok_col_pad_tt"]),
                    n_atom, aux["NP"], aux["nb"], n_token, n_token, sigma, m.sigma_data,
                    cache={})
                pred_xyz = ag.matmul(ag.Tensor(ft(one_hot.unsqueeze(0))), xl_den)
                pred["pred_xyz"] = pred_xyz
                pred["pred_dist"] = ag.pairwise_distance(pred_xyz)
            self.denoise_sigma = sigma
            # The EDM loss weighting, written back onto the caller's batch. This is the
            # SECOND quantity the objective reads from the batch that the batch cannot know:
            # `losses.mse` takes it as `per_sample_scale` and `af3_loss` reads
            # `b.get("edm_scale")`, but sigma is DRAWN HERE, per forward, so a featuriser has
            # nothing to emit. Without it the diffusion term is unweighted and its gradient is
            # wrong by the EDM factor -- on one draw that took the squared gradient norm from
            # 9.79 to 3.7e+11 and nothing said so. Same shape of gap as pLDDT's label, and the
            # same proposal: the fix belongs in the objective, not in a per-model adapter.
            batch["edm_scale"] = float(losses.edm_scale(sigma, m.sigma_data))

        # ---- the confidence heads, on that structure. `forward_device` is their own
        # training entry point and it returns the distogram head with them.
        with ag.tape():
            oh_d = m.confidence_head.distance_onehot(repr_x)
            out = m.confidence_head.forward_device(
                s_input_d, s_trunk, z_trunk, ag.Tensor(oh_d),
                use_zij_trunk_embedding=True,
                pair_mask_d=pair_mask_pf, attn_mask_d=attn_mask_d)

        self.check_registered()
        return {**pred,
                "distogram_logits": out["distogram_logits"],
                "plddt_logits": out["plddt_logits"],
                "pde_logits": out["pde_logits"],
                "pae_logits": out["pae_logits"],
                "resolved_logits": out["experimentally_resolved_logits"]}


def _gt_atom_index(f, gt, real, n_atom):
    """For each atom of the CROP, which row of `ground_truth.atom_positions` it is. -1 = none.

    The denoise arm noises the GROUND TRUTH, and the ground truth is the whole deposited
    structure: 3580 atoms against the crop's 2678 on 2wig at crop 384. Multiplying one by the
    other's mask is a shape error when they differ and a SILENT mislabelling when they happen
    to match, because the crop's atoms are not the structure's first ones.

    The join is the same one the labels use, one level down: tokens match on `token_index`, and
    a token's atoms are a contiguous run at `start_atom_index` of length `num_atoms_per_token`
    on each side. A token whose two runs differ in length is refused rather than truncated.
    """
    import numpy as np
    f_start = f["start_atom_index"].long().numpy().reshape(-1)
    f_n = f["num_atoms_per_token"].long().numpy().reshape(-1)
    f_tok = f["token_index"].long().numpy().reshape(-1)
    g_start = gt["start_atom_index"].long().numpy().reshape(-1)
    g_n = gt["num_atoms_per_token"].long().numpy().reshape(-1)
    g_tok = gt["token_index"].long().numpy().reshape(-1)
    where = {int(t): i for i, t in enumerate(g_tok)}
    idx = np.full(int(n_atom), -1, np.int64)
    for i in np.asarray(real).reshape(-1):
        j = where.get(int(f_tok[i]))
        if j is None:
            raise ValueError(f"cropped token {int(f_tok[i])} is not in ground_truth")
        ni, nj = int(f_n[i]), int(g_n[j])
        if ni != nj:
            raise ValueError(f"token {int(f_tok[i])} holds {ni} atoms in the crop and {nj} in "
                             f"ground_truth; the two are not the same token")
        a, b = int(f_start[i]), int(g_start[j])
        idx[a:a + ni] = np.arange(b, b + nj)
    return idx


def denoise_draw(seed: int, n_atom: int):
    """The denoise arm's noise level and per-atom noise, a function of the seed alone.

    One function so that a reference run can draw exactly what the forward drew.
    """
    rng = np.random.default_rng(seed)
    sigma = float(losses.sample_noise_level(rng))
    return sigma, rng.standard_normal((n_atom, 3))


def _v(t):
    """The raw handle under a taped tensor. The rollout is not differentiated."""
    return t.value if hasattr(t, "value") else t


# ------------------------------------------------------------------------------ register

def adapter(path, tokens=None, *, checkpoint=None, rollout: int = 20, num_cycles: int = 1,
            seed: int = 0, exact_scope: str = "all"):
    """``(forward, dataset)`` for OpenFold3. ``path`` is the featurised corpus.

    ``checkpoint`` defaults to the weights ``tt-bio predict --model openfold3`` loads, so a
    run trains the model a user already folds with. Pass it to start from other weights.
    """
    ckpt = Path(checkpoint) if checkpoint else _shipped_weights()
    return (OpenFold3Forward(ckpt, rollout=rollout, num_cycles=num_cycles, seed=seed,
                             exact_scope=exact_scope),
            OpenFold3Dataset(path, tokens=tokens, seed=seed))


def _load_state_dict(path) -> dict:
    """An OpenFold3 checkpoint as ``{key: tensor}``, Lightning's ``model.`` prefix removed."""
    sd = torch.load(path, map_location="cpu", weights_only=False)
    sd = sd.get("state_dict", sd) if isinstance(sd, dict) else sd
    return {(k[6:] if k.startswith("model.") else k): v for k, v in sd.items()}


def trained_state_dict(masters: dict, base, *, device=None) -> dict:
    """``masters`` (the optimizer's, keyed by walk path) as an OpenFold3 state dict like ``base``.

    The masters are in device coordinates, keyed by where each weight sits in the built model;
    the model is built from an upstream-format state dict. So this builds the model from
    ``base`` with a differentiable lineage, reads back every device weight as a run from
    ``base`` starts from it, and folds each master's movement back into the keys it was built
    from (``lineage.fold_back``). Keys training never moved come back as the same tensors, so
    the result folds exactly as ``base`` does everywhere the run did not reach.

    Holds a second copy of the weights on the device until it returns.
    """
    from .tensors import to_host

    fwd = OpenFold3Forward(base, device=device)
    sd, lin, walked, uploads = fwd._record(differentiable=True)
    found = {p: t for p, _o, _k, t in walked}
    stray = sorted(set(masters) - set(found))
    if stray:
        raise ValueError(f"{len(stray)} trained tensors are not weights of this model, e.g. "
                         f"{stray[:3]}")
    # One device tensor reached by two walk paths (the DiT's `w_lg` is also its cache entry
    # `_wc[(key, True)]`) has a master per path, and the card holds the one the optimizer wrote
    # last. That master is the weight; the other paths are dropped so it counts once.
    order = {p: i for i, p in enumerate(masters)}
    by_object = {}
    for p, _o, _k, t in walked:
        if p in masters:
            by_object.setdefault(id(t), []).append(p)
    for paths in by_object.values():
        for p in sorted(paths, key=order.get)[:-1]:
            uploads.pop(p, None)
            masters = {q: m for q, m in masters.items() if q != p}
    moved = {}
    for p, m in masters.items():
        d = np.asarray(m, np.float32).reshape(-1) - to_host(found[p]).reshape(-1)
        if d.any():
            moved[p] = torch.from_numpy(d)
    del found, walked, fwd
    return lineage.fold_back(sd, lin, uploads, moved, _canonical_key)


def _shipped_weights() -> Path:
    """The inference checkpoint `tt-bio predict --model openfold3` reads, fetched if missing."""
    from .. import weights
    return weights.fetch(MODEL)


catalogue.register(MODEL, adapter)
