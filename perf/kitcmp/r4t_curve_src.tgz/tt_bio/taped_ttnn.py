"""ttnn as tt-bio's own modules see it while a tape is open.

`tt_bio/ops.py` is the narrow seam: two verbs, dispatched at the call site, with the grad
hook `tt_bio.autograd` installs. This module is the wide one, and it exists because the
Pairformer chain calls 380 ttnn verbs across 56 names (`perf/ptx_fastpath/census.py`).
Routing all of them through `ops` by hand would mean editing the most heavily tuned file in
the repo in 380 places, and then keeping every future perf lever in step with the tape by
hand. It also puts the gradient in the call site rather than in the op, and the call site is
what goes stale: a lever landed next week in the trimul would take the gradient with it,
silently.

So `tape()` rebinds the module-global name `ttnn` inside tt-bio's own modules to the proxy
below, which is ttnn with the differentiable verbs taped and every other attribute ttnn's
own. One rebinding per module, restored on exit even if the forward raises, live only while
a tape is open. It is not a monkeypatch of ttnn's namespace: nothing outside tt-bio sees a
different ttnn, and `tt_bio.autograd` is excluded so its backward closures call the real
verbs and cannot re-enter the tape.

The mechanism is `dispatch.OpSurface`'s, one level out. A taped verb computes its value BY
CALLING the shipped verb on unwrapped operands, so there is exactly one forward and the
grad-off column is bit-identical rather than nearly equal. The tuned paths are reached the
same way they always were, because the tuning reads shapes and memory configs off the
tensor and `autograd.Tensor` answers those.

A verb with no entry that is handed a taped tensor raises. That is deliberate: an op the
tape cannot follow is loud, not a silently dropped gradient.
"""

from __future__ import annotations

import contextlib
import functools
import os
import re
import sys
import types

import ttnn

from . import autograd as ag
from .envflags import env_flag
from . import mm_layout as _mm_layout
from . import pair_mm as _pair_mm
from .autograd import Tensor, precise_config
from .autograd import (_axis, _differentiating, _dims, _flat2d, _matmul, _on_tape, _raw,
                       _reduce_to, _sum_leading, _tape,
                       _taped_layer_norm, _taped_linear, _taped_rms_norm, _unwrap, _via2d, _wrap)

__all__ = ["tape", "recompute_scope", "shim_scope", "VERBS", "taped_ttnn", "KERNELS",
           "KERNEL_STATS", "enabled_kernels", "forget_shim_bindings"]

# ---------------------------------------------------------------------------------------
# The shipped forward, taped where it computes.
#
# `tt_bio.ops` routes two verbs, and the Pairformer chain calls 380 ttnn verbs across 56
# names (`perf/ptx_fastpath/census.py` counts them and re-counts them on demand). Routing
# every one by hand would mean editing the most heavily tuned file in the repo in 380
# places, and then keeping every future perf lever in step with the tape by hand. It also
# puts the gradient in the call site rather than in the op, and a call site is what goes
# stale: a lever landed next week in the trimul would take the gradient with it silently.
#
# So the seam moves one level out. `tape()` rebinds the name `ttnn` inside tt-bio's own
# modules to the object below, which is ttnn with the differentiable verbs taped and every
# other attribute ttnn's own. One rebinding per module, restored on exit, live only while a
# tape is open. It is not a monkeypatch of ttnn's namespace: nothing outside tt-bio sees a
# different ttnn, and `tt_bio.autograd` itself is excluded, so the backward closures below
# call the real verbs and cannot re-enter the tape.
#
# The mechanism is `dispatch.OpSurface`'s, one level up. A taped verb computes its value BY
# CALLING the shipped verb on unwrapped operands, so there is still exactly one forward and
# the grad-off column is bit-identical rather than nearly equal. The tuned path is reached
# the same way it always was, because the tuning reads shapes and memory configs off the
# tensor and a taped tensor answers those.
#
# A verb with no entry that is handed a taped tensor raises. That is deliberate: an op the
# tape cannot follow is loud, not a silently dropped gradient.
# ---------------------------------------------------------------------------------------

_VERBS: dict = {}
VERBS = _VERBS


def _verb(*names):
    """Register one taped verb under each ttnn name, dotted for a nested namespace."""
    def register(fn):
        for n in names:
            _VERBS[n] = fn
        return fn
    return register


# ---------------------------------------------------------------------------------------
# The `generic_op` kernels, taped where each one says how its own output differentiates.
#
# `_verb` above cannot reach these. A verb entry is keyed on a ttnn name and computes its
# value by calling that name on raw operands; a hand-written kernel is a `ttnn.generic_op`
# call carrying a program descriptor, and the tape can see neither what the descriptor does
# nor which of the operands it read. `ops.py::taping` says why unwrapping anyway is not an
# option: it would drop the gradient of everything upstream, silently. So the entry is
# per-kernel, the kernel declares its own VJP, and a kernel with no entry keeps declining.
#
# The shape is `_verb`'s deliberately -- `entry(shipped, args, kwargs)`, value from `shipped`
# -- so `_v_sdpa` below reads as the worked example for both kinds. `ops.fused_kernel` hands
# `shipped` in with the kernel's tape gate lifted, which is the one thing a verb entry does
# not need.
_KERNELS: dict = {}
KERNELS = _KERNELS

#: Reach, per kernel: `[served, declined]`. Declined is the kernel's own gate saying no on a
#: shape it does not cover, which is a fall-through to the composed path and not a failure.
#: An A/B whose arms agree is a lever that never fired, and this is where that shows.
KERNEL_STATS: dict = {}


#: Which kernels' entries are installed, read live at every tape entry. DEFAULT NONE, so a
#: process that sets nothing behaves exactly like the one before this registry existed: every
#: fused kernel declines under a tape and the composed path runs. Naming a kernel here is what
#: opens it. `all` takes every entry in the registry.
#:
#: Release-gated on purpose. Each entry changes which program computes a forward inside a
#: gradient round, so it moves both seconds and the last bits of the forward, and the grade is
#: a round A/B plus the campaign's Angstrom bar -- not this file's say-so. Live read rather
#: than resolved at import for the reason `_sdpa_wide_k` is: one process has to be able to A/B
#: both arms at the round boundary.
TAPED_KERNELS_DEFAULT = ""


def enabled_kernels() -> dict:
    """The entries this process wants installed for the tape it is about to open."""
    want = os.environ.get("TT_BIO_TAPED_KERNELS", TAPED_KERNELS_DEFAULT).strip()
    if not want:
        return {}
    if want == "all":
        return dict(_KERNELS)
    names = [n.strip() for n in want.split(",") if n.strip()]
    unknown = [n for n in names if n not in _KERNELS]
    if unknown:
        raise ValueError(
            f"TT_BIO_TAPED_KERNELS names {unknown}, which no kernel registers. Known: "
            f"{sorted(_KERNELS)}. A typo here reads as a lever that measured nothing.")
    return {n: _KERNELS[n] for n in names}


def _kernel(name):
    """Register the tape entry for the `generic_op` kernel that declares `ops.fused_kernel(name)`."""
    def register(fn):
        def counted(shipped, args, kwargs):
            out = fn(shipped, args, kwargs)
            c = KERNEL_STATS.setdefault(name, [0, 0])
            c[0 if out is not None else 1] += 1
            return out

        _KERNELS[name] = counted
        return fn
    return register


def _identity_grad(shipped, args, kwargs, cast=False):
    """A verb that moves or retypes bytes without changing what they mean.

    typecast, to_layout, to_memory_config, clone and reallocate are all this: the value is
    whatever the shipped verb produced and the gradient passes straight through. They are
    the ops a tuned forward is mostly made of, and none of them is a no-op on device.

    "Straight through" is about the VALUE, not the container. The cotangent arrives in the
    output's layout, and a parent that was tiled before a `to_layout(..., ROW_MAJOR)` needs
    it tiled again: hand it back row-major and the first matmul upstream dies with "Inputs
    to matmul must be tilized", several ops away from the op that caused it. The invariant
    every closure here keeps is that a parent receives its cotangent in ITS OWN layout and
    dtype -- the layout half was missing, and the OF3 diffusion module's atom broadcast is
    where it first ran, because that is a `to_layout -> reshape -> embedding` chain whose
    gradient comes back through the layout change.
    """
    x = _wrap(args[0])
    ra, rk = _raw(args, kwargs)
    out_v = shipped(*ra, **rk)
    src_dtype = x.value.dtype
    src_layout = x.value.layout

    def make():
        def bw(g):
            if g.layout != src_layout:
                g = ttnn.to_layout(g, src_layout)
            x.add_grad(ttnn.typecast(g, src_dtype) if cast and g.dtype != src_dtype else g)
        return bw

    # `bw` closes over the source dtype and layout, not over the source: nothing here reads
    # `x.value`, so the value is dead the moment the shipped forward deallocates it. This is
    # the verb that holds OpenFold3's bf16 attention scores and one of its two dead fp32
    # copies of them.
    return _tape(out_v, [x], make, reads=())


_VERBS["linear"] = _taped_linear
_VERBS["layer_norm"] = _taped_layer_norm
_VERBS["rms_norm"] = _taped_rms_norm


@_verb("matmul", "experimental.minimal_matmul")
def _v_matmul(shipped, args, kwargs):
    """Both shipped matmuls. `transpose_a`/`transpose_b` reassociate rather than transpose
    the result -- see `matmul` above for why writing the post-transpose is the classic way
    to get a wrong gradient that a shape check cannot catch."""
    kw = dict(kwargs)
    # `ttnn.matmul` takes its operands positionally; `experimental.minimal_matmul` names
    # them, and the shipped QKV and gate projections call it that way. One entry covers
    # both rather than two entries drifting.
    a = _wrap(args[0] if args else kw.get("input_tensor"))
    b = _wrap(args[1] if len(args) > 1 else kw.get("weight_tensor"))
    bias = _wrap(kw.get("bias_tensor"))
    ta = bool(kw.get("transpose_a", False))
    tb = bool(kw.get("transpose_b", False))
    if kw.get("activation") is not None:
        raise NotImplementedError(
            f"tt_bio.autograd has no backward for the fused activation "
            f"{kw['activation']!r} on a matmul. `ops.linear` composes its activation on the "
            f"tape; do the same here rather than dropping it.")
    cfg = kw.get("compute_kernel_config") or precise_config()
    ra, rk = _raw(args, kwargs)
    # The forward of a taped matmul is the shipped call verbatim, so the plan-less batched
    # ones arrive here as the model wrote them. `experimental.minimal_matmul` takes its
    # operands by keyword and has no `core_grid`, so only the positional `ttnn.matmul` form
    # is in range; `mm_layout.plan` is the identity with the lever off.
    if shipped is ttnn.matmul and len(ra) > 1:
        rk = _mm_layout.plan(ra[0], ra[1], rk)
    out_v = shipped(*ra, **rk)
    ashape, bshape = a.value.shape, b.value.shape

    def make():
        def bw(g):
            # `ttnn.matmul` BROADCASTS a leading axis of 1 against a batched operand, and the
            # gradient of a broadcast operand is the sum over the axis it was spread along.
            # Without that sum the gradient comes back with the OUTPUT's batch and `add_grad`
            # refuses it: measured in the OF3 MSA module's recompute at crop 128 as
            # "gradient shape (36, 128, 128) does not match value shape (1, 128, 128)". The
            # binary verbs have taken `_reduce_to` since they were written; the matmul had
            # the same broadcast and not the same reduction. It is a no-op on equal shapes,
            # so the ordinary path pays one shape comparison.
            if a.requires_grad:
                rows = _via2d if len(bshape) == 2 else (lambda t, fn: fn(t))
                da = (rows(g, lambda v: ag._pair_mm_or(
                                v, b.value, not tb, lambda: ag.bmm(v, b.value, False, not tb,
                                                                   compute_kernel_config=cfg),
                                cfg) if len(bshape) == 2 else
                           ag.bmm(v, b.value, False, not tb, compute_kernel_config=cfg))
                      if not ta else
                      ag.bmm(b.value, g, tb, True, compute_kernel_config=cfg))
                a.add_grad(_reduce_to(da, ashape))
            if b.requires_grad:
                # The weight reduces over every token, so it is `_flat2d`'s DRAM-normalised
                # long-K path and fp32 out, for the reason documented there.
                # A 2-D right operand is a WEIGHT, and only then does the contraction
                # run over every leading axis. A batched matmul whose right operand is
                # another activation contracts over the batch as well, and `_flat2d`
                # would fold that away: measured as a (64, 32) gradient arriving at a
                # (1, 4, 64, 32) value in AttentionPairBias.
                if (not ta and not tb and len(ashape) > 2 and len(bshape) == 2):
                    db = _matmul(_flat2d(a.value), _flat2d(g), transpose_a=True,
                                 compute_kernel_config=cfg, dtype=ttnn.float32)
                else:
                    db = (ag.bmm(a.value, g, not ta, compute_kernel_config=cfg) if not tb else
                          ag.bmm(g, a.value, True, ta, compute_kernel_config=cfg))
                b.add_grad(_reduce_to(db, bshape))
            if bias is not None and bias.requires_grad:
                bias.add_grad(_sum_leading(g, bias.value.shape))
        return bw

    return _tape(out_v, [p for p in (a, b, bias) if p is not None], make,
                 reads=ag._cross_reads(a, b))


# `d_logits = y * (g - sum_j g_j y_j)` has EXACTLY zero row sums when `sum_j y_j = 1`, and the
# attention backward downstream of it depends on that: `dq_i = sum_j d_logits_ij k_j` is
# `sum_j d_logits_ij (k_j - kbar)` precisely because the row sums vanish, so it never sees the
# mean of k. `ttnn.softmax` on a bf16 tensor does not give rows that sum to one -- measured
# 2.4e-02 rms on the OpenFold3 trunk's token attention at crop 64 -- and the residual row sum
# then multiplies kbar, which is large, and lands in dq as a term the gradient does not contain.
# Dividing `inner` by the row sum is the same expression whenever the row sums to one, and makes
# the row sums of d_logits vanish identically when it does not. Measured against an upstream
# 0.4.3 float64 reference, block 15 of the trunk: the module's own output cotangent goes from
# 33.29x the reference in norm to 0.64x. It touches NO forward, so no shipped inference result
# can move. ON by default since 2026-09-21 (ask 9629); `perf/of3t_d56renorm/` has the proof
# that it cannot reach a fold.
#
# An ALIAS, not a parse. This used to be its own `os.environ.get` and `autograd` has another,
# which meant one environment variable with two defaults -- flip one and the host float64
# backward keeps the other. The name stays because harnesses read it.
_SOFTMAX_BW_RENORM = ag.SOFTMAX_BW_RENORM


#: `ttnn.softmax`'s default SFPU path runs `math_approx_mode=True`, and that single field is the
#: whole of the forward's error: at the trunk's own shapes the rows come back summing to 0.9954
#: and the output reads 1.8e-02 to 2.0e-02 relative L2 from a float64 softmax, against 5.2e-04 to
#: 5.9e-04 with the field cleared, while HiFi4, `fp32_dest_acc_en` and `packer_l1_acc` are all
#: bit-exactly inert (`perf/of3t_d116_verify/APPROX.json`, four shape/seed cases, 31x).
#:
#: The backward `dx = y (g - sum_j g_j y_j)` carries `y` multiplicatively, so it inherits that
#: error whole: `of3t-p10grad` grades the shipped taped softmax `dx` at 2.201e-02 against float64
#: while the backward CLOSURE alone reads 9.750e-05, and giving the FORWARD a precise config takes
#: `dx` to 9.086e-04. The row-sum renorm below repairs the inner product, not the leading `y`.
#:
#: `autograd.softmax` has defaulted to `precise_config()` since it was written. This is the same
#: rule at the shipped verb, and it applies ONLY where a gradient is at stake: with taping off the
#: config is untouched, so every inference path -- including an evaluation inside a training run --
#: is bit-identical to shipped. That is what keeps this off the `TT_BIO_SOFTMAX_CKC` release gate,
#: which is a process-wide switch that does move shipped inference numbers on four models.
def _softmax_fw_config(kwargs):
    """The compute kernel config the taped softmax forward should run, or None to leave it."""
    if not ag.is_grad_enabled():
        return None
    return kwargs.get("compute_kernel_config") or precise_config()


@_verb("softmax", "softmax_in_place")
def _v_softmax(shipped, args, kwargs):
    """`softmax_in_place` is taped out of place. The backward reads y, which the in-place
    kernel has written over its own input, so the input is gone either way; what the tape
    cannot afford is the CALLER's copy being gone, and that is what in-place destroys."""
    x = _wrap(args[0])
    dim = kwargs.get("dim", args[1] if len(args) > 1 else -1)
    ra, rk = _raw(args, kwargs)
    cfg = _softmax_fw_config(rk)
    if cfg is not None:
        rk = dict(rk, compute_kernel_config=cfg)
    y0 = ttnn.softmax(*ra, **rk) if shipped is ttnn.softmax_in_place else shipped(*ra, **rk)
    box = [y0]

    def make():
        def bw(g):
            y = box[0]                      # through the box, so `free` may evict y to DRAM
            # The same expression as `autograd.softmax` and `triangle_attention`; the helper
            # carries the TT_BIO_SOFTMAX_BW_RENORM branch all three used to inline, and the
            # fused `moreh_softmax_backward` route all three now share.
            x.add_grad(ag.softmax_bw(y, g, dim=dim, config=cfg))
        return bw

    # The backward reads y and only y, so x is not pinned. Under `softmax_in_place` the
    # shipped forward wrote the result over x and will never deallocate it -- there is
    # nothing left to call `free` -- so the taped-out-of-place form has to release the
    # destination itself, exactly as the in-place binaries do. AFTER `_tape`, which is what
    # sets the pins.
    out = _tape(y0, [x], make, reads=("out",))
    if out.node is not None:
        out.box = box
    if shipped is ttnn.softmax_in_place:
        x.free()
    return out


def _unary(fn=None, reads_output=False, fused=None):
    """Register a unary eltwise verb whose backward is `fn(x_value, out_value) -> dy/dx`.

    An `output_tensor=` argument is dropped, which is the in-place case: the shipped verb
    writes its result over its input and the tape needs the input to still be there. That
    drop is also why a `fused` rule may read the input: under the tape the shipped verb
    allocates, so `x.value` is never the output's buffer.

    `fused(g, x_value, out_value) -> dx` replaces the whole `multiply(g, fn(...))` chain
    where the wheel already ships the backward as one kernel. Same expression, fewer verbs,
    and no intermediate derivative is materialised at all.
    """
    def impl(shipped, args, kwargs):
        x = _wrap(args[0])
        inplace = kwargs.get("output_tensor") is not None
        kw = {k: v for k, v in kwargs.items() if k != "output_tensor"}
        out_v = shipped(x.value, *[_unwrap(a) for a in args[1:]], **kw)
        box = [out_v]
        def make():
            def bw(g):
                # Through the Tensor for the input and through the box for the output:
                # `free` may have evicted either to DRAM.
                x.add_grad(fused(g, x.value, box[0]) if fused is not None
                           else ttnn.multiply(g, fn(x.value, box[0])))
            return bw

        out = _tape(out_v, [x], make)
        # The box is handed over whether or not the RULE reads the output, because the
        # CLOSURE reads it either way -- `fn` is called with `box[0]` and a rule that ignores
        # its second argument still evaluates it. Keeping the box current under eviction
        # costs one assignment and removes the only way it could go stale.
        if out.node is not None:
            out.box = box
        elif inplace:
            # `ttnn.silu(x, output_tensor=x)` is the unary form of the same signal, and
            # the same ordering rule applies: after `_tape`, so `free` can see that a
            # closure reads this and evict instead of releasing. Only safe when the rule
            # reads the INPUT; a rule that reads the output would be reading this tensor.
            x.free()
        return out
    return impl


# The three eltwise activations the wheel already backpropagates in one kernel. What they
# replaced, so the expression is on the page rather than only in the history:
#   silu     sigma * (1 + x * (1 - sigma)), then multiply by g -- six verbs
#   sigmoid  y * (1 - y), then multiply by g              -- three verbs
#   relu     (x > 0), then multiply by g                  -- two verbs
# `sigmoid_bw` takes the input and recomputes the sigmoid where the composed form read the
# retained output; `relu_bw` takes the input, which is what `gtz` read. Neither changes which
# tensors the node keeps alive, because `_tape` pins the input regardless.
_VERBS["silu"] = _unary(fused=lambda g, xv, y: ttnn.silu_bw(g, xv)[0])
_VERBS["sigmoid"] = _unary(fused=lambda g, xv, y: ttnn.sigmoid_bw(g, xv)[0])
_VERBS["relu"] = _unary(fused=lambda g, xv, y: ttnn.relu_bw(g, xv)[0])
_VERBS["exp"] = _unary(lambda xv, y: y, reads_output=True)
# of3t-trunkceiling, NOT SHIPPED -- stays on wk/of3t-trunkceiling. Without it the 5-op
# `_accurate_softmax` chain cannot be taped at all: its -60 floor is a `ttnn.clamp` and the tape
# raises on the first taped tensor handed to it, so the accurate-softmax lever is catalogued as
# reaching the trunk and RAISES on the training path. Measured, not argued: a 2-block trunk arm
# with TT_BIO_ACCURATE_SOFTMAX_AB=openfold3.trunk dies with "ttnn.clamp has no tape entry"
# after 102 leaves register.
#
# The rule needs no bounds. `clamp` is the identity exactly where it did not clip, so `x == y`
# IS the mask -- for either bound, for None, and at the boundary itself, which is what torch's
# `(x >= min) & (x <= max)` does. On the -60 floor the mask is 1 everywhere a weight exceeds
# exp(-60) = 8.8e-27, so on a live row this is the identity, and on a fully-masked row it
# correctly stops the gradient of a value the forward replaced.
_VERBS["clamp"] = _unary(lambda xv, y: ttnn.eq(xv, y))


# A fused eltwise activation, and its derivative from whichever of (input, output) is
# cheaper. `ttnn.multiply(a, b, input_tensor_b_activations=[SIGMOID])` applies the unary to
# the operand BEFORE the binary op, and a tape that forwards the keyword to the shipped verb
# but ignores it in the backward gets a correct forward and a silently wrong gradient. That
# is exactly what happened: the shipped `TriangleAttention` gate is
# `ttnn.multiply_(o, g, input_tensor_b_activations=[SIGMOID])` at `tenstorrent.py:7532`, and
# the composed module's dL/dz came out 4.88x too large -- flat across a 50x eps sweep, so
# not noise. Every op-scale check in this directory passed while that was true, because none
# of them composes a gate. `perf/ptx_fastpath/modulecheck.py` is what found it.
_FUSED_UNARY = {}


# A fused activation that carries a scalar. `UnaryWithParam(MUL_UNARY_SFPU, c)` is one
# op_type with a different function per call site, so it cannot be a constant entry above:
# the registry holds a builder that is handed the scalar and returns the same
# (forward, derivative) pair the plain entries are.
_FUSED_UNARY_PARAM: dict = {}

# Fused unaries whose DERIVATIVE is a constant, so neither the operand nor the activated
# operand is read in the backward. Only these let a binary verb leave its operand unpinned.
_FUSED_UNARY_CONST: set = set()


def _act_const(kwargs, key) -> bool:
    """True when the single fused unary on this operand has a constant derivative."""
    acts = list(kwargs.get(key) or ())
    if len(acts) != 1:
        return False
    return getattr(acts[0], "op_type", None) in _FUSED_UNARY_CONST


def _chain_fused(pair, d, xv, ev):
    """Carry the binary rule's output `d` through the fused activation's derivative.

    `pair[2]` is the wheel's own backward for that activation and does the whole thing in one
    kernel; without it the derivative is materialised and multiplied in, which is 2 verbs for
    relu, 3 for sigmoid and 6 for silu. `xv` is the PRE-activation operand and `ev` the
    activated one, so a wheel op that wants the input gets `xv` -- the same argument the
    plain-verb substitution takes, and graded on the same reading.
    """
    bw = pair[2] if len(pair) > 2 else None
    return bw(d, xv, ev) if bw is not None else ttnn.multiply(d, pair[1](xv, ev))


def _register_fused_unary():
    u = getattr(ttnn, "UnaryOpType", None)
    if u is None:                                                  # pragma: no cover
        return
    if hasattr(u, "MUL_UNARY_SFPU"):
        # `add_(x, y, input_tensor_a_activations=[MUL_UNARY_SFPU(c)])` is `x * c + y`. The
        # fp32-softmax tail rides the score scale on the add instead of paying a pass for
        # it (`tenstorrent.py:3757`), and openfold3's trunk, template and MSA stacks all
        # take that path by default -- `fp32_softmax=True` at every one of them -- so this
        # is the shipped path for a whole model, not an opt-in corner. The derivative is
        # the constant.
        _FUSED_UNARY_PARAM[u.MUL_UNARY_SFPU] = lambda c: (
            lambda x: ttnn.multiply(x, c), lambda x, y: c)
        _FUSED_UNARY_CONST.add(u.MUL_UNARY_SFPU)
    # The third element, where present, is the wheel's own backward for that activation:
    # `bw(d, x, y) -> d * dy/dx` as one kernel, replacing the `multiply(d, derivative)` chain
    # beside it. Same three ops the plain `_VERBS` entries take through `_unary(fused=...)`,
    # reached here instead when the activation rides another verb -- `multiply(o, g,
    # input_tensor_b_activations=[SIGMOID])` is how every OpenFold3 gate is written, so this
    # copy of the derivative is on the training tape whether or not `ttnn.sigmoid` is.
    # The composed form stays as the expression of record and as the control the wheel op
    # was graded against.
    if hasattr(u, "SIGMOID"):
        _FUSED_UNARY[u.SIGMOID] = (
            ttnn.sigmoid, lambda x, y: ttnn.multiply(y, ttnn.rsub(y, 1.0)),
            lambda d, x, y: ttnn.sigmoid_bw(d, x)[0])
    if hasattr(u, "RELU"):
        _FUSED_UNARY[u.RELU] = (ttnn.relu, lambda x, y: ttnn.gtz(x),
                                lambda d, x, y: ttnn.relu_bw(d, x)[0])
    if hasattr(u, "SILU"):
        _FUSED_UNARY[u.SILU] = (
            ttnn.silu,
            lambda x, y: (lambda sg: ttnn.multiply(
                sg, ttnn.add(ttnn.multiply(x, ttnn.rsub(sg, 1.0)), 1.0)))(ttnn.sigmoid(x)),
            lambda d, x, y: ttnn.silu_bw(d, x)[0])


_register_fused_unary()


_SCALAR_RE = re.compile(r"params=\[([^\]]*)\]")
_PARAM_CHECKED: set = set()


def _unary_scalar(op):
    """The scalar a parameterised fused unary carries, or None if it carries none.

    ttnn binds `op_type` on `UnaryWithParam` and nothing else -- there is no `params`
    attribute -- so the value is read out of the repr, which prints `params=[0.25]`. A
    format dependency is not something a gradient may rest on, so the number is not
    trusted: `_fused_param` measures it against the kernel the first time it sees it.

    The repr rounds -- 1/sqrt(32) prints as `params=[0.17677669]`, eight significant digits
    against the double's seventeen -- which is 3e-08 relative and three orders below bf16's
    own resolution at every site in this tree. It is recorded rather than corrected: there
    is nothing to correct it against, and a gradient carrying it is closer to the kernel's
    own fp32 constant than to the double the caller wrote.
    """
    m = _SCALAR_RE.search(repr(op))
    if m is None:
        return None
    parts = [p for p in m.group(1).split(",") if p.strip()]
    if len(parts) != 1:
        return None
    try:
        return float(parts[0])
    except ValueError:                                             # pragma: no cover
        return None


def _check_param(op, fwd, probe):
    """Confirm the scalar read out of the repr is the one the kernel applies.

    One comparison per distinct activation, on the operand already in hand: the kernel
    computes `f(x) + 0` through the fused path, and the model computes `f(x)` directly.
    The bar is loose on purpose, and it has to be: the probe is bf16, so one ulp at
    magnitude 1 is already 3.9e-03 and a tighter bar measures the dtype rather than the
    parse. This is not a precision check. It is here to catch the parse returning something
    that is not the scale at all, which is what an fp32 bit pattern
    (`rfd3_bias._scale_bits`) would look like if ttnn ever stored one: off by nine orders,
    not by a rounding. 5e-02 leaves a factor of twelve over the bf16 floor and still
    refuses a scalar wrong by more than 5 %.
    """
    key = repr(op)
    if key in _PARAM_CHECKED:
        return
    _PARAM_CHECKED.add(key)
    zero = ttnn.multiply(probe, 0.0)
    kern = ttnn.add(probe, zero, input_tensor_a_activations=[op])
    ours = fwd(probe)
    diff = ttnn.max(ttnn.abs(ttnn.subtract(kern, ours)))
    scale = ttnn.max(ttnn.abs(kern))
    d = float(ttnn.to_torch(diff).flatten()[0])
    sc = float(ttnn.to_torch(scale).flatten()[0])
    for t in (zero, kern, ours, diff, scale):
        ttnn.deallocate(t)
    if d > 5.0e-2 * (sc + 1.0e-30):
        raise NotImplementedError(
            f"tt_bio.autograd read the scalar of {op!r} out of its repr and the kernel "
            f"disagrees: max |kernel - model| {d:.3e} against |kernel| {sc:.3e}. The "
            f"gradient would be scaled by the wrong constant, so this refuses.")


def _fused_param(op, probe):
    """A parameterised fused unary as a (forward, derivative) pair, or None if it is not
    one. Unknown `op_type` returns None so `_activation` can raise with its own message."""
    build = _FUSED_UNARY_PARAM.get(getattr(op, "op_type", None))
    if build is None:
        return None
    c = _unary_scalar(op)
    if c is None:                                                  # pragma: no cover
        raise NotImplementedError(
            f"tt_bio.autograd cannot read the scalar of {op!r}, so it cannot differentiate "
            f"it. Guessing it would scale the gradient by the wrong constant.")
    pair = build(c)
    if probe is not None:
        _check_param(op, pair[0], probe)
    return pair


def _activation(kwargs, key, probe=None):
    """The single fused unary on one operand, or None. Anything unmodelled raises.

    Declining loudly is the whole point. The forward would be right either way, because it
    comes from the shipped verb; it is the backward that would quietly differentiate a
    different function.

    `probe` is the operand the activation is fused onto, when the caller has it. It is what
    a parameterised activation's scalar is checked against.
    """
    acts = kwargs.get(key) or ()
    acts = list(acts)
    if not acts:
        return None
    if len(acts) > 1:
        raise NotImplementedError(
            f"tt_bio.autograd tapes one fused activation per operand; {key} has {len(acts)}.")
    op = acts[0]
    pair = _fused_param(op, probe)
    if pair is not None:
        return pair
    # A bare `UnaryOpType` carries no scalar and has no `op_type` attribute; only the
    # plain registry can hold it, and only it is safe to look up as a dict key.
    if not hasattr(op, "op_type") and op in _FUSED_UNARY:
        return _FUSED_UNARY[op]
    raise NotImplementedError(
        f"tt_bio.autograd has no backward for the fused activation {op!r} on {key}. "
        f"Add it to tt_bio.taped_ttnn._FUSED_UNARY, or to _FUSED_UNARY_PARAM if it carries "
        f"a scalar -- forwarding it to the shipped verb and ignoring it here gives a "
        f"correct forward and a wrong gradient, which is how the TriangleAttention gate "
        f"read 4.88x high.")


def _binary(grad_a, grad_b, scalar, out_of_place=None, needs=(True, True), both=None,
            gate=False, cross=False):
    """Register a binary eltwise verb. The second operand may be a python scalar, which the
    shipped chain does often enough (`ttnn.multiply(s, 1 / sqrt(d))`) that treating it as a
    tensor would be wrong rather than merely slow.

    An in-place verb (`add_`, `multiply_`) is taped OUT of place. That is the memory cost
    the tape pays for a residual: the pre-update tensor stays live because the producer's
    backward reads it. It is one tensor per residual, not per layer.

    ``needs`` says which operand VALUES the rules read, and it is a property of the rules
    rather than of the call. `_MUL` reads both, because each side's gradient is the other
    side's value; `_ADD` and `subtract` read neither, and the default is the conservative
    answer for anything that has not said. A fused unary adds its own read, unless its
    derivative is a constant -- which `MUL_UNARY_SFPU`, the score scale OpenFold3's
    fp32-softmax tail rides on the add, is.

    ``both(g, a_value, b_value) -> (da, db)`` is the wheel's own two-sided backward, taken
    only where it is exactly `grad_a` and `grad_b`: no fused unary on either operand, both
    operands wanting a gradient, and no broadcast for `_reduce_to` to undo. Outside that it
    composes as before, because `mul_bw` carries neither a fused-activation correction nor a
    reducing output.
    gate marks the multiply verbs: `multiply(o, g, input_tensor_b_activations=[SIGMOID])`
    with both sides wanting a gradient and no broadcast runs as one kernel,
    `gate_bw.gate_bw`, where it would otherwise be seven ops.
    ``cross`` marks a product: each side's rule reads only the other side, so a side is read
    only when the other wants a gradient (`autograd._cross_reads`). A dropout multiply's mask
    has none, so its update is released.
    """
    def impl(shipped, args, kwargs):
        a = _wrap(args[0])
        raw_b = args[1]
        kw = {k: v for k, v in kwargs.items() if k != "output_tensor"}
        # THE in-place trap, and it is silent: `ttnn.multiply_(a, b)` writes the product
        # over a's buffer, and a is exactly what that product's backward reads for db.
        # Taping the call while still invoking the in-place kernel gives a forward that is
        # right and a gradient that is anti-correlated with the truth. Measured before this
        # line existed: d(fc2) cosine -0.028 on the shipped Transition.
        inplace = out_of_place is not None
        if inplace:
            shipped = out_of_place
        if not isinstance(raw_b, (Tensor, ttnn.Tensor)):
            _activation(kwargs, "input_tensor_a_activations")      # raises if unmodelled
            _activation(kwargs, "input_tensor_b_activations")
            if kwargs.get("input_tensor_a_activations") or kwargs.get(
                    "input_tensor_b_activations"):
                raise NotImplementedError(
                    "tt_bio.autograd does not tape a fused activation on a scalar operand")
            f = float(raw_b)
            out_v = shipped(a.value, raw_b, **kw)

            def make_s():
                def bw(g):
                    a.add_grad(scalar(g, f))
                return bw

            return _tape(out_v, [a], make_s, reads=() if not any(needs) else None)
        b = _wrap(raw_b)
        fa = _activation(kwargs, "input_tensor_a_activations", a.value)
        fb = _activation(kwargs, "input_tensor_b_activations", b.value)
        # An operand is read in the backward if a rule reads it, or if a non-constant fused
        # unary sits on it. Everything else is dead the moment the shipped forward is done,
        # and naming it here is what lets `_tape` leave it unpinned.
        gate_b = gate and fa is None and _is_sigmoid(kwargs.get("input_tensor_b_activations"))
        if cross:
            need_a, need_b = b.requires_grad, a.requires_grad
        else:
            need_a, need_b = needs
        reads_a = need_a or (fa is not None and a.requires_grad
                             and not _act_const(kwargs, "input_tensor_a_activations"))
        reads_b = need_b or (fb is not None and b.requires_grad
                             and not _act_const(kwargs, "input_tensor_b_activations"))
        ashape, bshape = a.value.shape, b.value.shape
        out_v = shipped(a.value, b.value, **kw)
        def make():
            def bw(g):
                # Read through the Tensors: either operand may have been evicted to DRAM
                # by a `deallocate` the tape declined between here and the backward.
                av, bv = a.value, b.value
                # The binary op sees the ACTIVATED operands, so the binary rule is
                # evaluated on those and the unary derivative is applied after. Recomputed
                # rather than retained: the fused forward never materialised them, and
                # holding two extra tensors is what the L1 budget cannot take. An operand no
                # rule reads is not recomputed either -- `add_(x, y, MUL_UNARY(c))` used to
                # pay a full-sized multiply in the backward to build an `ea` that `_ADD`
                # then ignored.
                if (both is not None and fa is None and fb is None
                        and a.requires_grad and b.requires_grad
                        and av.shape == bv.shape == g.shape):
                    da, db = both(g, av, bv)
                    a.add_grad(da)
                    b.add_grad(db)
                    return
                if (gate_b and a.requires_grad and b.requires_grad
                        and av.shape == bv.shape == g.shape):
                    from . import gate_bw as _gb
                    if _gb.eligible(g, av, bv):
                        do, dg = _gb.gate_bw(g, av, bv)
                        a.add_grad(do)
                        b.add_grad(dg)
                        return
                ea = (fa[0](av) if fa else av) if reads_a else None
                eb = (fb[0](bv) if fb else bv) if reads_b else None
                if a.requires_grad:
                    da = grad_a(g, ea, eb)
                    da = _chain_fused(fa, da, av, ea) if fa else da
                    a.add_grad(_reduce_to(da, ashape))
                if b.requires_grad:
                    db = grad_b(g, ea, eb)
                    db = _chain_fused(fb, db, bv, eb) if fb else db
                    b.add_grad(_reduce_to(db, bshape))
            return bw

        out = _tape(out_v, [a, b], make,
                    reads=tuple(i for i, r in enumerate((reads_a, reads_b)) if r))
        if inplace:
            # An in-place verb is a free of its destination plus a write, and the tuned
            # forward budgets the next kernel's L1 against that free. Taping it out of
            # place gives the result a new home and leaves the old one with no owner to
            # release it -- one stranded L1 tensor per residual, per chunk. Measured on
            # the shipped Transition at a [1,256,256,128] pair track: the row loop leaks
            # `x_1` on every chunk, because `multiply_` is what consumed it in inference
            # and nothing else deallocates it, and fc1 then cannot lay out its circular
            # buffers. So the verb's own signal is honoured: the destination's PLACE is
            # released, and `free` evicts rather than frees if a backward reads it.
            #
            # AFTER `_tape`, never before. `free` reads `pinned` to choose between
            # releasing and evicting, and `_tape` is what sets it, so releasing first
            # deallocates an operand the node is about to read. The throw lands far
            # away -- "TT_THROW @ ttnn/core/tensor/storage.cpp:60", in
            # AttentionPairBias's backward, from a free issued in the forward.
            a.free()
            # And the caller MUST take the return value. `ttnn.add_(a, b)` returns its
            # destination, so inference reads the same object whether or not it is rebound --
            # but under the tape the result has a NEW home and `a.free()` above has just
            # released the old one, so a call site that discards the return is left holding a
            # freed buffer and throws "Buffer is not allocated" on its next use. Five sites in
            # this tree discarded it and all five now rebind: `PairWeightedAveraging`'s head
            # accumulator, the attention output accumulator, `OuterProductMean`'s row
            # accumulator, and two MSA residuals in `openfold3_msa_embedder`. It is a
            # one-token change with no inference effect and there is no way to make the
            # discarding form work: the tape cannot write into a buffer whose size and
            # lifetime the backward still needs.
        return out
    return impl


_ADD = (lambda g, av, bv: g, lambda g, av, bv: g, lambda g, f: g)
_MUL = (lambda g, av, bv: ttnn.multiply(g, bv), lambda g, av, bv: ttnn.multiply(g, av),
        lambda g, f: ttnn.multiply(g, f))
_VERBS["add"] = _binary(*_ADD, needs=(False, False))
_VERBS["add_"] = _binary(*_ADD, out_of_place=ttnn.add, needs=(False, False))
_VERBS["subtract"] = _binary(
    lambda g, av, bv: g, lambda g, av, bv: ttnn.multiply(g, -1.0), lambda g, f: g,
    needs=(False, False))
_MUL_BOTH = lambda g, av, bv: ttnn.mul_bw(g, av, bv)


def _is_sigmoid(acts) -> bool:
    acts = list(acts or ())
    u = getattr(ttnn, "UnaryOpType", None)
    return (len(acts) == 1 and u is not None and hasattr(u, "SIGMOID")
            and getattr(acts[0], "op_type", acts[0]) == u.SIGMOID)


_VERBS["multiply"] = _binary(*_MUL, both=_MUL_BOTH, gate=True, cross=True)
_VERBS["multiply_"] = _binary(*_MUL, out_of_place=ttnn.multiply, both=_MUL_BOTH,
                               gate=True, cross=True)
_VERBS["divide"] = _binary(
    lambda g, av, bv: ttnn.divide(g, bv),
    lambda g, av, bv: ttnn.multiply(ttnn.divide(g, ttnn.multiply(bv, bv)),
                                    ttnn.multiply(av, -1.0)),
    lambda g, f: ttnn.multiply(g, 1.0 / f))


# --- shape ------------------------------------------------------------------------------
# Every one of these is its own inverse applied to the gradient. They carry no arithmetic,
# so nothing here can lose precision; what they can lose is an axis, which is why each
# reads the source shape at forward time rather than inferring it in the backward. For the
# same reason none reads a value, so none pins one (`reads=()`).

@_verb("reshape", "unsqueeze", "squeeze")
def _v_reshape(shipped, args, kwargs):
    """reshape, unsqueeze and squeeze differ only in how they name the target shape, and
    the backward of all three is the source shape, read here rather than inferred there."""
    x = _wrap(args[0])
    src = _dims(x.value.shape)
    ra, rk = _raw(args, kwargs)
    out_v = shipped(*ra, **rk)

    def make():
        def bw(g):
            x.add_grad(ttnn.reshape(g, src))
        return bw

    return _tape(out_v, [x], make, reads=())


@_verb("permute")
def _v_permute(shipped, args, kwargs):
    x = _wrap(args[0])
    dims = [int(d) for d in (kwargs.get("dims") if len(args) < 2 else args[1])]
    inv = [0] * len(dims)
    for i, d in enumerate(dims):
        inv[d] = i
    ra, rk = _raw(args, kwargs)
    out_v = _permute_fwd(shipped, ra, rk, dims)

    def make():
        def bw(g):
            x.add_grad(_permute_back(g, inv))
        return bw

    return _tape(out_v, [x], make, reads=())


# Whether a permute's backward goes through the reblock kernels where they serve its inverse.
# A module switch so an A/B can flip it in one process.
REBLOCK_PERMUTE_BW = True

# The same question asked of the FORWARD, which is where the two channel moves actually are.
#
# `reblock_permute.eligible` refuses every caller while a tape is open, because the kernel is a
# `generic_op` with no tape entry and a direct call would drop the gradient of everything above
# it. So a taped forward runs the stock `ttnn.permute` and a taped BACKWARD runs the kernel
# (`_permute_back`, above) -- the asymmetry `bcx-p10-trilay` measured as the triangle
# multiplication at 31.7 % of the DRAM roof forward against 55.3 % backward.
#
# There is no reason for it. These two moves are pure index reorderings and they are each
# other's inverse: `permute(0,3,1,2)` sends x[b,i,j,c] to y[b,c,i,j], so its VJP is
# `permute(0,2,3,1)`, which is the other kernel in that file. Recording the node HERE, where
# the shim already owns the permute, lets the forward take the kernel with a backward that is
# exactly the kernel the backward already takes. Both are `torch.equal` against `ttnn.permute`,
# so the arm is bit-exact by construction and is measured that way rather than argued.
#
# The switch is `reblock_permute.TAPED_MOVE`, next to the gates it opens and next to the
# `_channel_move_back` caller that has to make the same decision, so there is one of it.


def _permute_back(g, inv):
    """``ttnn.permute(g, inv)``, through the reblock kernel the forward's channel move uses
    when ``inv`` is one of its two moves and its own gate says yes.

    The tape records a model's channel move as the stock permute it falls back to under a tape,
    so its gradient paid the stock permute too: 12 calls on [1, 64, 256, 256] per AF2 Evoformer
    block at n=256. The kernel is a pure index reordering, so the gradient keeps its bits.

    Outside the gate, ``[0, 2, 3, 1]`` goes as ``transpose(1, 2)`` then ``transpose(2, 3)``: on
    p150a at 1350 MHz the stock permute takes 1.21 ms on [1, 128, 224, 224] against 0.37 ms for
    the pair (1.00 / 0.33 at 195 tokens, 0.64 / 0.18 at 64 channels), torch.equal in every case.
    That is BindCraft 2's trimul gradient, 208 calls an iteration. ``[0, 3, 1, 2]`` keeps the
    permute, the faster of the two there (0.27 / 0.36 ms).

    The 3-D form of the same move, ``[1, 2, 0]``, goes the same way: it is the VJP of the masked
    outer product's ``permute(T, (2, 0, 1))`` (`af2._sum_rows_joined`), and the stock permute ran
    it at 358 us on [224, 128, 64], 20 GB/s, 48 calls an iteration on a p300c (`bets/unnamed` u2).
    """
    if REBLOCK_PERMUTE_BW:
        from . import reblock_permute as R
        mc = g.memory_config()
        if inv == [0, 2, 3, 1] and R.eligible_back(g, mc):
            return R.reblock_permute_back(g, mc)
        if inv == [0, 3, 1, 2] and R.eligible(g, mc):
            return R.reblock_permute(g, mc)
    if list(inv) in ([0, 2, 3, 1], [1, 2, 0]):
        mid = ttnn.transpose(g, -3, -2)
        out = ttnn.transpose(mid, -2, -1)
        ttnn.deallocate(mid)
        return out
    return ttnn.permute(g, inv)


def _permute_fwd(shipped, ra, rk, dims):
    """The forward of a taped `ttnn.permute`, through the reblock kernel where it serves.

    `ra[0]` is the raw operand, so the kernel's own `ttnn.generic_op` is never handed a taped
    tensor and cannot try to tape itself. The node is `_v_permute`'s, and its backward is
    `_permute_back` unchanged: for these two `dims` that is the inverse kernel.
    """
    if len(ra) and not rk.get("pad_value"):
        from . import reblock_permute as R
        if not R.TAPED_MOVE:
            return shipped(*ra, **rk)
        x = ra[0]
        try:
            mc = rk.get("memory_config") or x.memory_config()
            if dims == [0, 3, 1, 2] and R.eligible(x, mc, taped_ok=True):
                return R.reblock_permute(x, mc)
            if dims == [0, 2, 3, 1] and R.eligible_back(x, mc, taped_ok=True):
                return R.reblock_permute_back(x, mc)
        except AttributeError:
            pass
    return shipped(*ra, **rk)


@_verb("transpose")
def _v_transpose(shipped, args, kwargs):
    """A transpose is its own inverse on the two axes it names, so the backward is the
    same call. It is NOT free on device -- it moves every byte -- but it is exact."""
    x = _wrap(args[0])
    d0 = kwargs.get("dim0", args[1] if len(args) > 1 else 0)
    d1 = kwargs.get("dim1", args[2] if len(args) > 2 else 1)
    ra, rk = _raw(args, kwargs)
    out_v = shipped(*ra, **rk)

    def make():
        def bw(g):
            x.add_grad(ttnn.transpose(g, d0, d1))
        return bw

    return _tape(out_v, [x], make, reads=())


@_verb("concat")
def _v_concat(shipped, args, kwargs):
    xs = [_wrap(t) for t in args[0]]
    dim = kwargs.get("dim", args[1] if len(args) > 1 else 0)
    ax = _axis(int(dim), len(xs[0].value.shape))
    sizes = [int(t.value.shape[ax]) for t in xs]
    kw = {k: v for k, v in kwargs.items() if k != "dim"}
    out_v = shipped([t.value for t in xs], dim=ax, **kw)

    def make():
        def bw(g):
            off = 0
            gs = [int(d) for d in g.shape]
            for t, n in zip(xs, sizes):
                if t.requires_grad:
                    starts, ends = [0] * len(gs), list(gs)
                    starts[ax], ends[ax] = off, off + n
                    t.add_grad(ttnn.slice(g, starts, ends))
                off += n
        return bw

    return _tape(out_v, xs, make, reads=())


@_verb("repeat")
def _v_repeat(shipped, args, kwargs):
    """A repeat along axes where the input has extent 1 is a broadcast, so its backward is the
    sum over each repeated axis. Tiling a wider axis is not taped: it raises rather than guess
    how the copies fold back."""
    x = _wrap(args[0])
    reps = [int(r) for r in (kwargs.get("repetition_vector") or args[1])]
    shape = [int(d) for d in x.value.shape]
    axes = [ax for ax, r in enumerate(reps) if r != 1]
    if any(shape[ax] != 1 for ax in axes):
        raise NotImplementedError(f"taped ttnn.repeat {reps} of {shape}: only extent-1 axes are taped")
    ra, rk = _raw(args, kwargs)
    out_v = shipped(*ra, **rk)

    def make():
        def bw(g):
            for ax in axes:
                g = ttnn.sum(g, dim=ax, keepdim=True)
            x.add_grad(g)
        return bw

    return _tape(out_v, [x], make)


def _sliced(x: "Tensor", out_v, starts, ends):
    """Tape one slice of ``x`` whose value is already computed.

    Shared by `slice`, `chunk` and `__getitem__`, which are the same op three ways: the
    backward hands its block to `add_grad_slice`, which joins the blocks of one tensor. `chunk`
    reads its cut points off the shipped call rather than recomputing them, so the tape
    cannot disagree with the kernel about where the blocks begin.
    """
    def make():
        def bw(g):
            x.add_grad_slice(g, starts, ends)
        return bw

    return _tape(out_v, [x], make)


@_verb("slice")
def _v_slice(shipped, args, kwargs):
    x = _wrap(args[0])
    starts = [int(v) for v in (kwargs.get("slice_start") or args[1])]
    ends = [int(v) for v in (kwargs.get("slice_end") or args[2])]
    ra, rk = _raw(args, kwargs)
    return _sliced(x, shipped(*ra, **rk), starts, ends)


@_verb("chunk")
def _v_chunk(shipped, args, kwargs):
    """n blocks along ``dim``. Each is a slice and each gets its own node, so a consumer
    that reads only some of the blocks -- which the row-chunked transition does, one
    block at a time -- contributes only those, and the fan-in sum does the rest."""
    x = _wrap(args[0])
    #  must not be evaluated when  arrives as a keyword, which is how
    # the trimul calls it (tenstorrent.py:6659).
    n = int(kwargs["chunks"] if "chunks" in kwargs else args[1])
    dim = int(kwargs.get("dim", args[2] if len(args) > 2 else 0))
    shape = [int(d) for d in x.value.shape]
    ax = _axis(dim, len(shape))
    outs, off, taped = shipped(x.value, n, dim=ax), 0, []
    for o in outs:
        m = int(o.shape[ax])
        starts, ends = [0] * len(shape), list(shape)
        starts[ax], ends[ax] = off, off + m
        taped.append(_sliced(x, o, starts, ends))
        off += m
    return taped


def _getitem(x: Tensor, index):
    """``x[...]`` on a taped tensor, in terms of `slice`. The shipped chain slices row
    blocks out of the pair tensor with exactly this syntax, and a taped tensor that did
    not answer to it would make the chunked paths -- which is all of the tuned ones --
    unreachable from a gradient."""
    shape = [int(d) for d in x.value.shape]
    idx = index if isinstance(index, tuple) else (index,)
    starts, ends = [0] * len(shape), list(shape)
    for ax, sl in enumerate(idx):
        if isinstance(sl, slice):
            s, e, step = sl.indices(shape[ax])
            if step != 1:
                raise NotImplementedError(f"strided slice on axis {ax} has no tape entry")
            starts[ax], ends[ax] = s, e
        elif isinstance(sl, int):
            s = sl + shape[ax] if sl < 0 else sl
            starts[ax], ends[ax] = s, s + 1
        else:
            raise NotImplementedError(f"index {sl!r} has no tape entry")
    return _sliced(x, ttnn.slice(x.value, starts, ends), starts, ends)


# `x[...]` on a RAW handle is a method of `ttnn.Tensor`, not a verb of the `ttnn` module, so
# `_swap` never reaches it. When the receiver is a registered parameter the slice is a fresh
# tensor with a new id, the parameter lookup misses, and the weight trains as a constant: the
# MSA module's per-head `m`/`g`/`o` projections did (D262). While the tape is installed such a
# slice goes through `_getitem`, like one on a taped tensor. One that still comes back raw (a
# slice inside a verb's own shipped call, where the lookup is off) is recorded by its first
# tt-bio frame, and `take_raw_param_slices` hands the list to the caller's guard.
_RAW_PARAM_SLICES: list = []
_SHIPPED_GETITEM = ttnn.Tensor.__getitem__


def _tt_bio_site() -> str:
    f = sys._getframe(2)
    while f is not None:
        path = f.f_code.co_filename
        if "/tt_bio/" in path and not path.endswith(("/taped_ttnn.py", "/autograd.py")):
            return f"tt_bio/{path.rsplit('/tt_bio/', 1)[1]}:{f.f_lineno}"
        f = f.f_back
    return "<outside tt_bio>"


def _param_getitem(self, index):
    p = ag._param_on_tape(self)
    if p is not None:
        return _getitem(p, index)
    if ag.parameter_for(self) is not None:
        _RAW_PARAM_SLICES.append(_tt_bio_site())
    return _SHIPPED_GETITEM(self, index)


def take_raw_param_slices() -> list:
    """The sites that sliced a registered parameter without reaching the tape since the last
    call, one entry per slice. Clears the record."""
    out = list(_RAW_PARAM_SLICES)
    _RAW_PARAM_SLICES.clear()
    return out


# --- attention ---------------------------------------------------------------------------

# One score block, in bytes, that the backward is allowed to hold while it recomputes.
# The object being bounded is concrete: at 800 aa with 8 heads the full [S, H, S, S] bf16
# score tensor is 8.19 GB on a 34.23 GB card, and the backward needs one while the whole
# forward tape is already resident. A leading-axis chunk of 1 is 10.24 MB.
SDPA_SCORE_BUDGET = 256 << 20


def _sdpa_chunking(B, H, n_q, n_k, itemsize, budget=None):
    """Pick (leading, query) chunk bounds so one recomputed score block fits `budget`.

    Gradients are invariant to both bounds -- `perf/hallgrad/gradcheck.py --cases
    triatt_chunked` checks that by differencing two chunkings rather than trusting one --
    so this is a memory decision and not a numeric one, and it is derived from the shape
    rather than tuned. The leading axis is spent first because chunking it costs nothing:
    each of the B attention problems is independent, so a leading chunk's softmax is
    already exact and complete and needs no running row statistics.
    """
    budget = SDPA_SCORE_BUDGET if budget is None else budget
    row = H * n_k * itemsize
    if row * n_q <= budget:
        per = max(1, min(B, budget // (row * n_q)))
        return (B if per >= B else per), None
    return 1, max(1, min(n_q, budget // row))


# Skip the shipped forward and let `autograd.triangle_attention` compute its own chunked one.
#
# The two forwards are different programs for the same maths. The kernel is an ONLINE softmax: it
# chunks keys and carries a running max, in bf16, and `triatt_sdpa.py` measures its row sums
# running a few parts in ten thousand short. `triangle_attention`'s own forward materialises one
# score block per chunk and reduces each row in a SINGLE pass under `precise_config()` -- HiFi4,
# math_approx off, fp32 destination accumulation -- which is the reduction order AF2's
# `fp32_softmax=True` exists to get. The backward is the same either way: it recomputes the scores
# from q, k, v and bias and never reads the forward output, which is why `value=` is optional at
# all.
#
# So this is the accuracy arm of a speed/accuracy pair on ONE route, not a second implementation.
# Off, the caller pays a flash forward and a chunked backward; on, both halves are chunked.
# Default off, live read, and counted -- a lever nobody can see reaching is a lever nobody can
# grade.
SDPA_OWN_FORWARD_DEFAULT = False
SDPA_OWN_FORWARD_STATS = {"own": 0, "kernel": 0}


def _sdpa_own_forward() -> bool:
    return os.environ.get("TT_BIO_SDPA_OWN_FORWARD",
                          "1" if SDPA_OWN_FORWARD_DEFAULT else "0") == "1"


@_verb("transformer.scaled_dot_product_attention")
def _v_sdpa(shipped, args, kwargs):
    """The shipped fused SDPA, with the chunked-recompute backward behind it.

    The forward is the production kernel -- every rung of `_tri_att_sdpa`'s ladder, its
    program config, its L1 routing -- called here and handed to `autograd.triangle_attention`
    as its value, unless `TT_BIO_SDPA_OWN_FORWARD` says to let that function compute its own
    chunked forward instead (see `_sdpa_own_forward`). There is no second attention implementation: that function's backward
    reads q, k, v and bias and recomputes the scores per chunk, and never reads the forward
    output, so the production forward and the verified backward compose into one node.

    This entry is the single shared implementation `ptx-diffusion` consumes as well
    (`state/ptx/LEDGER.md` K17). It is registered on the verb rather than in a model file,
    so `AttentionPairBias` in the pairformer and the denoiser's attention sites reach the
    same code without either of them naming it.

    `is_causal` is refused rather than approximated. No tt-bio caller sets it, and a causal
    mask the backward did not apply would be a wrong gradient that the forward agrees with.

    THE MASK IS ADDED BEFORE THE SCALE, and getting that backwards is a wrong gradient the
    forward agrees with, which is the failure mode this row exists to prevent. Measured on
    a p300c: the fused kernel computes ``softmax((q @ k^T + mask) * scale) @ v``, not
    ``softmax((q @ k^T) * scale + mask) @ v``. Against the first the error sits flat at
    3.3e-02 for every mask magnitude tested (0, 0.05, 0.5, 2.0), which is the fused
    softmax's own known deficit; against the second it grows with the mask -- 3.3e-02,
    5.1e-02, 3.7e-01, 8.3e-01. Production already knows this and compensates:
    `tenstorrent.py:7205` sets `self.scale = head_dim ** 0.5`, pre-multiplies
    `bias_weight` by it, and passes `scale ** -1` to the kernel, so the pair bias arrives
    pre-scaled and the composite is standard attention.

    `autograd.triangle_attention` uses the other convention -- it scales the scores and
    then adds the bias -- and it is not being changed, because it is a correct op with its
    own verified gradients and another campaign owns that file. Instead the mask is scaled
    ON THE TAPE here, with `autograd.scale`, so the composite the tape differentiates is
    the composite the kernel computes and the chain rule back to the caller's unscaled
    mask is the tape's own rather than a factor written out by hand.
    """
    q, k, v = (_wrap(a) for a in args[:3])
    kw = dict(kwargs)
    bias = _wrap(kw.get("attn_mask") if "attn_mask" in kw else
                 (args[3] if len(args) > 3 else None))
    if kw.get("is_causal"):
        raise NotImplementedError(
            "tt_bio.autograd has no backward for a causal SDPA. No tt-bio caller sets "
            "is_causal, and applying the mask in the forward but not the backward would be "
            "a wrong gradient the forward agrees with.")
    own = _sdpa_own_forward()
    SDPA_OWN_FORWARD_STATS["own" if own else "kernel"] += 1
    if own:
        out_v = None
    else:
        ra, rk = _raw(args, kwargs)
        out_v = shipped(*ra, **rk)
    qs = [int(d) for d in q.value.shape]
    B, H, n_q, head_dim = qs
    n_k = int(k.value.shape[2])
    scale = kw.get("scale")
    if scale is None:
        scale = head_dim ** -0.5
    if bias is not None:
        bias = ag.scale(bias, scale)
    itemsize = 4 if q.value.dtype == ttnn.float32 else 2
    cB, cQ = _sdpa_chunking(B, H, n_q, n_k, itemsize)
    return ag.triangle_attention(q, k, v, bias, scale=scale, chunk=cB, q_chunk=cQ,
                                 value=out_v)


@_kernel("tri_att_sdpa_hifi")
def _k_tri_att_sdpa_hifi(shipped, args, kwargs):
    """The persistent-mask fused triangle attention, with `_v_sdpa`'s backward behind it.

    `tenstorrent._tri_att_sdpa_hifi` is the whole fused-HiFi arm: `_sdpa_masked`'s ragged
    padding, the q x k x buffer-factor ladder, `triatt_sdpa.sdpa`'s hoisted mask fill and
    `_tri_att_sdpa`'s rungs under it. Taping the ARM rather than the kernel is what makes one
    entry cover all of them -- every rung computes the same function of the same operands, and
    which one serves is a performance decision the gradient does not depend on.

    The backward is `autograd.triangle_attention`'s and it is the same one `_v_sdpa` puts
    behind the stock verb, for the same reason: it recomputes one score block per chunk from
    q, k, v and bias and never reads the forward output, so a forward whose internals the tape
    cannot see composes with it unchanged.

    THE MASK IS ADDED BEFORE THE SCALE here too -- `sdpa_generic.plan` drives the same kernel
    family `_v_sdpa` documents that against -- so the bias is scaled ON THE TAPE with
    `autograd.scale` and the chain rule back to the caller's unscaled bias is the tape's own.

    A None from `shipped` is the arm declining: too short, no legal rung, an L1 refusal. It is
    returned unchanged so the caller falls through to the composed path it takes today, which
    the tape follows verb by verb.
    """
    q, k, v = (_wrap(a) for a in args[:3])
    a = list(args) + [None] * (5 - len(args))
    bias = _wrap(kwargs.get("bias", a[3]))
    scale = kwargs.get("scale", a[4])
    ra, rk = _raw(args, kwargs)
    out_v = shipped(*ra, **rk)
    if out_v is None:
        return None
    if bias is not None:
        bias = ag.scale(bias, scale)
    B, H, n_q, head_dim = (int(d) for d in q.value.shape)
    n_k = int(k.value.shape[2])
    itemsize = 4 if q.value.dtype == ttnn.float32 else 2
    cB, cQ = _sdpa_chunking(B, H, n_q, n_k, itemsize)
    return ag.triangle_attention(q, k, v, bias, scale=scale, chunk=cB, q_chunk=cQ,
                                 value=out_v)


def _reblock_vjp(dims):
    """A channel move's entry: the VJP of a permutation is the inverse permutation.

    Through `ttnn.permute` and not back through the kernel. The kernel's gate is a measured
    SHAPE WINDOW -- a buffer type and a band of N -- and a cotangent arrives in the output's
    layout, which is the other side of the move and outside that window by construction. The
    stock verb is correct at every shape and the gradient of a data movement is not where the
    seconds are.

    `reads=()` because the closure reads neither operand nor output: a permutation's gradient
    is a function of the cotangent alone. That is what lets the tape drop the moved tensor
    instead of pinning it, and these are the largest tensors the trunk moves.
    """
    def entry(shipped, args, kwargs):
        x = _wrap(args[0])
        ra, rk = _raw(args, kwargs)
        out_v = shipped(*ra, **rk)

        def make():
            def bw(g):
                x.add_grad(ttnn.permute(g, dims))
            return bw

        return ag._tape(out_v, [x], make, reads=())
    return entry


# `[1, N, N, C] -> [1, C, N, N]` and its inverse. Bit-exact both ways by the kernels' own
# `torch.equal` evidence, so this leg is the mechanism's proof as well as a lever: if a round
# with it on is not bit-identical to a round with it off, something other than the permutation
# moved.
_kernel("reblock_permute")(_reblock_vjp((0, 2, 3, 1)))
_kernel("reblock_permute_back")(_reblock_vjp((0, 3, 1, 2)))



@_kernel("reblock_permute_gated")
def _k_reblock_permute_gated(shipped, args, kwargs):
    """`reblock_permute_gated`'s entry: the gated channel move of a triangle multiplication.

    The forward is ``a = permute(p * sigmoid(g), (0, 3, 1, 2))`` with ``p`` and ``g`` two
    channel slices of the four-way in-projection ``xw``. Under the tape it replaces the four
    `ttnn.chunk` slices, the two gate multiplies and the two plain moves the composed path runs,
    so a round with it on computes the same forward values (the kernel is `torch.equal` to that
    chain) through fewer, larger programs.

    The VJP, with ``da' = permute(da, (0, 2, 3, 1))`` and ``s = sigmoid(g)``:
    ``dp = da' * s`` and ``dg = da' * p * s * (1 - s)``. Both go into ``xw`` as slice gradients,
    which `Tensor.add_grad_slice` joins with the other role's two in one concat, exactly where the
    composed path's four `chunk` gradients were joined. `reblock_permute.GATED_BW_FUSED` runs it as
    one kernel (`reblock_permute_gated_bw`, float32 between cotangent and pack); otherwise, or
    outside that kernel's window, it is the composed chain on stock verbs.

    `reads=(0,)`: the closure reads ``xw`` (p and g) and nothing else. The gate refuses the
    row-block mode under a tape, so ``out`` is always this call's own allocation.
    """
    from . import reblock_permute as R
    xw = _wrap(args[0])
    p_off, g_off, slice_c = (int(v) for v in args[1:4])
    ra, rk = _raw(args, kwargs)
    out_v = shipped(*ra, **rk)

    def make():
        def bw(g):
            x = xw.value
            N = int(x.shape[1])
            if R.GATED_BW_FUSED and R.eligible_gated_bw(g, x):
                if R.GATED_GRAD_PACKED and xw.requires_grad:
                    slab = xw.grad_slab()
                    R.reblock_permute_gated_bw(g, x, p_off, g_off, out=slab)
                    xw.slab_written(p_off, p_off + slice_c)
                    xw.slab_written(g_off, g_off + slice_c)
                    return
                dp, dg = R.reblock_permute_gated_bw(g, x, p_off, g_off)
            else:
                dap = ttnn.permute(g, (0, 2, 3, 1))
                pv = ttnn.slice(x, [0, 0, 0, p_off], [1, N, N, p_off + slice_c])
                s = ttnn.sigmoid(ttnn.slice(x, [0, 0, 0, g_off], [1, N, N, g_off + slice_c]))
                dp = ttnn.multiply(dap, s)
                dg = ttnn.multiply(ttnn.multiply(dap, pv), ttnn.multiply(s, ttnn.rsub(s, 1.0)))
            xw.add_grad_slice(dp, [0, 0, 0, p_off], [1, N, N, p_off + slice_c])
            xw.add_grad_slice(dg, [0, 0, 0, g_off], [1, N, N, g_off + slice_c])
        return bw

    return ag._tape(out_v, [xw], make, reads=(0,))

@_kernel("pair_transpose")
def _k_pair_transpose(shipped, args, kwargs):
    """`tt_bio.pair_transpose`'s entry: a permutation of S1 and S2, so its VJP is the same swap of
    the cotangent, through the same kernel where it covers the shape and `ttnn.permute` where not.
    Bit-exact both ways. `reads=()`: the gradient needs no operand."""
    from . import pair_transpose as PT
    x = _wrap(args[0])
    ra, rk = _raw(args, kwargs)
    out_v = shipped(*ra, **rk)
    perm = (1, 0, 2) if len(x.value.shape) == 3 else (0, 2, 1, 3)

    def make():
        def bw(g):
            if PT.shape_ok(g):
                x.add_grad(PT.pair_transpose.__wrapped__(g))
            else:
                x.add_grad(ttnn.permute(g, perm))
        return bw

    return ag._tape(out_v, [x], make, reads=())


def _weight_vjp(a, b, g, cfg):
    """The gradient `_v_matmul` gives `a @ b` for a 2-D weight `b` and no transposes: the same
    calls in the same order, so the two are bit-identical."""
    if a.requires_grad:
        a.add_grad(_reduce_to(
            _via2d(g, lambda v: ag.bmm(v, b.value, False, True, compute_kernel_config=cfg)),
            a.value.shape))
    if b.requires_grad:
        b.add_grad(_reduce_to(_matmul(_flat2d(a.value), _flat2d(g), transpose_a=True,
                                      compute_kernel_config=cfg, dtype=ttnn.float32),
                              b.value.shape))


class _QKVSink:
    """Where `triatt_bw` sends the packed q/k/v cotangent of one `triatt_qkv_heads` call.

    Module-level on purpose. Defined inside the entry, a fresh class per call, it was a
    reference cycle (a class always is: it sits in its own `__mro__`), so refcounting never
    freed it and the `x` its method closed over stayed on the card until the cyclic collector
    happened to run. At 480 tokens on Wormhole that held three extra pair tensors per Evoformer
    block, 177 MB a block and ~3 GB over the backward, which is what ran a 12 GiB chip out of
    memory (`perf/spd/bc2_blockmem.py`, `state/spd-bc2.md`). The collector never saw it in a
    probe either: ttnn tensors are not GC-tracked, so they do not appear in `gc.garbage`.
    """
    __slots__ = ("x", "w", "shape", "cfg")

    def __init__(self, x, w, shape, cfg):
        self.x, self.w, self.shape, self.cfg = x, w, shape, cfg

    def add_grad(self, G):
        _weight_vjp(self.x, self.w, ttnn.reshape(G, self.shape), self.cfg)


@_kernel("triatt_qkv_heads")
def _k_triatt_qkv_heads(shipped, args, kwargs):
    """`triatt_qkv.qkv_heads`: the qkv projection written head-major, so the taped recompute
    stops paying `nlp_create_qkv_heads` (a packed-width read and write per triangle attention).
    The head split is a permutation, so the VJP is the projection's matmul VJP on the packed
    cotangent. `triatt_bw` writes that cotangent in one pass when `QKV_PACKED` is on and hands
    it to the slots' shared sink; a slot that gets its own gradient goes through its third of
    the weight instead."""
    x, w = _wrap(args[0]), _wrap(args[1])
    cfg = _unwrap(args[2] if len(args) > 2 else kwargs.get("ckc")) or precise_config()
    ra, rk = _raw(args, kwargs)
    outs = shipped(*ra, **rk)
    if outs is None:
        return None
    B, H, L, dh = (int(d) for d in outs[0].shape)
    width, K = H * dh, int(w.value.shape[0])
    sink = _QKVSink(x, w, [B, L, 3 * width], cfg)

    def slot(s):
        def make():
            def bw(g):
                rows = ttnn.reshape(ag.merge_heads_value(g), [B, L, width])
                if x.requires_grad:
                    ws = ttnn.slice(w.value, [0, s * width], [K, (s + 1) * width])
                    x.add_grad(_reduce_to(_via2d(rows, lambda v: ag.bmm(
                        v, ws, False, True, compute_kernel_config=cfg)), x.value.shape))
                if w.requires_grad:
                    w.add_grad_slice(_matmul(_flat2d(x.value), _flat2d(rows), transpose_a=True,
                                             compute_kernel_config=cfg, dtype=ttnn.float32),
                                     [0, s * width], [K, (s + 1) * width])
            bw.qkv_slot = s
            bw.packed_sink = sink
            return bw
        return make

    return tuple(_tape(o, [x, w], slot(s), reads=(0, 1)) for s, o in enumerate(outs))


@_kernel("rne_add")
def _k_rne_add(shipped, args, kwargs):
    """`tt_bio.rne_add`'s entry: the VJP of a sum is the cotangent, to both operands.

    The kernel replaces four taped nodes -- two widening typecasts, an in-place add and a
    narrowing typecast -- with one, so the graph loses three nodes per residual and the chain
    of dtypes they carried. That is sound because every one of the four is its own identity on
    a cotangent: a typecast's gradient passes straight through (`_identity_grad`) and an add's
    goes to both parents unchanged (`_ADD`). What the kernel changes is the VALUE, and only in
    the direction of the reference -- it computes `round_rne_bf16(exact_sum)` bit-exactly where
    the four calls compute it too, so a round with this on is bit-identical to a round with it
    off and the A/B measures seconds alone.

    The two operands can disagree on RANK and still be the same tensor physically -- the MSA
    track hands `_residual` an `[1, S, N, C]` activation and an `[S, N, C]` update -- so each
    cotangent goes through `_reduce_to`, which is a reshape at equal volume and what every
    binary verb here has always done. Without it the backward raises `gradient shape
    (1, 2, 288, 256) does not match value shape (2, 288, 256)` from `add_grad`, far from the
    residual that caused it. The kernel's own gate refuses a real broadcast, so equal volume is
    the only case that reaches this.

    `reads=()`: the sum's gradient is a function of the cotangent alone, and the two shapes are
    captured here as plain tuples, so the tape drops both operands instead of pinning them.
    These are pair-representation tensors, the largest the trunk carries.
    """
    a, b = _wrap(args[0]), _wrap(args[1])
    ra, rk = _raw(args, kwargs)
    out_v = shipped(*ra, **rk)
    shapes = (_dims(args[0].shape), _dims(args[1].shape))

    def make():
        def bw(g):
            a.add_grad(_reduce_to(g, shapes[0]))
            b.add_grad(_reduce_to(g, shapes[1]))
        return bw

    return ag._tape(out_v, [a, b], make, reads=())


@_kernel("rne_add_masked")
def _k_rne_add_masked(shipped, args, kwargs):
    """`tt_bio.rne_add.rne_add_masked`'s entry: `a + b * m` with `m` a constant keep mask.

    The VJP is the two verbs it replaces: the sum's cotangent to `a`, and `g * m` to `b`, the
    same multiply the taped dropout ran. `m` takes no gradient, so it is the only value read:
    `reads=()` drops `a` and `b` like `rne_add`'s entry, and the mask (one [n, c] slab) is held
    raw by the closure.
    """
    a, b = _wrap(args[0]), _wrap(args[1])
    ra, rk = _raw(args, kwargs)
    out_v = shipped(*ra, **rk)
    mask = ra[2]
    shapes = (_dims(args[0].shape), _dims(args[1].shape))

    def make():
        def bw(g):
            a.add_grad(_reduce_to(g, shapes[0]))
            b.add_grad(_reduce_to(ttnn.multiply(g, mask), shapes[1]))
        return bw

    return ag._tape(out_v, [a, b], make, reads=())


@_kernel("pair_relu")
def _k_pair_relu(shipped, args, kwargs):
    """`pair_swiglu_ws.pair_relu`'s entry: AF2's whole Transition, LayerNorm through fc2 + b2, as one node.

    The composed path tapes four nodes and holds the normed x and the 4x-wide hidden for the backward; this one holds
    x alone. The backward is two programs: `pair_relu_bw` recomputes `xn @ w1 + b1` in L1 for the ReLU mask and writes
    the cotangent of xn, then `lnbw.layer_norm_bw` takes it back through the norm. The weights and the norm's affine
    take no gradient (BindCraft 2 differentiates the sequence, not the model), so the entry declines a call where any
    of them is a tracked parameter, and one with no `bw_weights`, `ln` or a shape the LayerNorm kernel does not serve.

    Not bit-identical to the composed backward: the cotangent enters as bf16 where the composed matmul VJPs read it as
    it comes, and the norm's backward is the bf16 kernel. So this is graded on BindCraft 2's own design metrics.
    """
    from . import lnbw
    from . import pair_swiglu_ws as W
    ra, rk = _raw(args, kwargs)
    ln, bww = rk.get("ln"), rk.get("bw_weights")
    tracked = list(args[1:5]) + [kwargs.get(k) for k in ("w1", "b1", "w2", "b2")] + list((kwargs.get("ln") or ())[:2])
    if ln is None or bww is None or any(isinstance(t, Tensor) and t.requires_grad for t in tracked):
        return None
    x = _wrap(args[0])
    if not lnbw.eligible(ra[0], ra[0], ln[0]):
        return None
    out_v = shipped(*ra, **rk)
    if out_v is None:
        return None
    b1 = ra[2] if len(ra) > 2 else rk["b1"]
    fid = rk.get("fidelity", ra[5] if len(ra) > 5 else ttnn.MathFidelity.HiFi4)
    gamma, eps = ln[0], ln[2]

    def make():
        def bw(g):
            xv = x.value
            dy = g if g.dtype == ttnn.bfloat16 else ttnn.typecast(g, ttnn.bfloat16)
            dxn = W.pair_relu_bw(xv, dy, bww[0], b1, bww[1], fidelity=fid, ln=ln)
            x.add_grad(lnbw.layer_norm_bw(xv, dxn, gamma, eps))
            ttnn.deallocate(dxn)
            if dy is not g:
                ttnn.deallocate(dy)
        return bw

    return _tape(out_v, [x], make, reads=(0,))


# --- attention head packing ------------------------------------------------------------
# Both layouts below are DERIVED FROM THE DEVICE with an index-valued tensor
# (`perf/ptx_fastpath/heads.py`), not read off a docstring. A head-split backward written
# from a guess about the packing is exactly how a wrong gradient ships: it is a pure
# rearrangement, so nothing about its magnitude looks wrong, and every downstream head
# would train on another head's signal.

@_verb("experimental.nlp_concat_heads")
def _v_concat_heads(shipped, args, kwargs):
    """``[B, H, L, dh] -> [B, 1, L, H*dh]``, measured equal to
    ``permute(0, 2, 1, 3).reshape(B, 1, L, H*dh)``. The backward is that inverted."""
    x = _wrap(args[0])
    H = int(x.value.shape[1])
    ra, rk = _raw(args, kwargs)
    out_v = shipped(*ra, **rk)

    def make():
        def bw(g):
            # Not reshape to [B, L, H, dh] + permute, which puts H on a tile row and pads 4
            # heads to 32: `split_heads_value` is 178 us against 2581 us at [256, 256, 128].
            x.add_grad(ag.split_heads_value(g, H))
        return bw

    return _tape(out_v, [x], make)


#: Hand each head's cotangent to `add_grad_slice` as its own slot of the packed axis, so the
#: three are joined by ONE concat when the gradient is read, instead of three packed-width
#: tensors that are two-thirds zeros summed through `add_grad`. The slots are disjoint, so the
#: sum of the zero-filled tensors and the concat of the slots are the same numbers: every
#: element is one head's value plus exact zeros. At the 288 pair track that is three
#: 60.75 MiB bfloat16 writes, two float32 widening adds and a narrowing cast per call replaced
#: by one 60.75 MiB write, the largest write-then-reread chain of the BindCraft 2 round
#: (`state/perf10/bcx-p10-devtop.md`). Default OFF, release-gated.
QKV_GRAD_JOIN = env_flag("TT_BIO_QKV_GRAD_JOIN", False)

#: Slot cotangents handed to `add_grad_slice`, cumulative; sample at a round boundary.
QKV_JOIN_STATS = {"served": 0}


@_verb("experimental.nlp_create_qkv_heads")
def _v_create_qkv_heads(shipped, args, kwargs):
    """``[B, 1, L, 3*H*dh] -> three [B, H, L, dh]``, measured equal to
    ``reshape(B, 1, L, 3, H, dh)[:, 0, :, s].permute(0, 2, 1, 3)`` for s in 0, 1, 2.

    Each output gets its own node, so a consumer that differentiates only q -- which the
    tape cannot know in advance -- contributes only q. Each scatters into the full packed
    width with zeros in the other two slots and `add_grad` sums them, which costs two
    packed-width temporaries more than a single shared closure would. It is the price of
    not having to know the fan-out at forward time, and the packed tensor is the smallest
    thing in the block.
    """
    x = _wrap(args[0])
    B, _, L, wide = (int(d) for d in x.value.shape)
    H = int(kwargs.get("num_heads", 1))
    dh = wide // (3 * H)
    outs = shipped(x.value, *[_unwrap(a) for a in args[1:]],
                   **{k: _unwrap(v) for k, v in kwargs.items()})

    def slot(s):
        def make():
            def bw(g):
                # [B, H, L, dh] -> [B, 1, L, H*dh], then into slot s of the packed axis.
                #
                # The slot rides the LAST axis. It used to ride dim 2, as an extent of 3, and
                # TILE layout pads a second-to-last dim up to 32: at 576 tokens the concat
                # asked for 2,717,908,992 B to carry 254,803,968 B of gradient, 90.6 %
                # padding, and that is what refused the backward. On the last axis the extent
                # is 3*H*dh, a whole number of tiles. The packed width decomposes as
                # [3, H, dh], so slot s is the contiguous range [s*H*dh, (s+1)*H*dh) either
                # way and the gradient is bit-identical.
                rows = ttnn.reshape(ag.merge_heads_value(g), [B, 1, L, H * dh])
                if QKV_GRAD_JOIN:
                    QKV_JOIN_STATS["served"] += 1
                    x.add_grad_slice(rows, [0, 0, 0, s * H * dh], [B, 1, L, (s + 1) * H * dh])
                    return
                # One zero tensor for both empty slots, then one concat. `ttnn.pad` would be
                # the single-allocation form and cannot be used: it refuses front padding
                # (`pad.cpp:278 front_padding_is_zero`), so slots 1 and 2 have no pad
                # expression. The packed width is 2,415,919,104 B at a 384-token pair track,
                # which is why this op is where the backward runs out of card.
                #
                # Through `ag.grad_zeros` since 2026-09-25, not a second zeros beside it. This
                # site built its own, and with `DEVICE_ZEROS` off that meant a HOST build and a
                # 37.75 MB upload per call -- 324 of them, the largest single verb in the device
                # backward. It is a cached device clone now: this closure goes 12.09 s -> 0.89 s
                # and the backward's wall 21.1 s -> 20.1 s at crop 384. The two figures differ
                # because the upload was also draining other verbs' queued device time; see
                # `DEVICE_ZEROS` in autograd.py and `state/of3t-zerosfill.md`.
                zero = ag.grad_zeros([B, 1, L, H * dh], rows.dtype, rows.device())
                parts = [rows if i == s else zero for i in range(3)]
                x.add_grad(ttnn.concat(parts, dim=-1))
            # Which slot this is, for a consumer that can write all three at once into `x`'s
            # layout (`triatt_bw.QKV_PACKED`): it then gives `x` one gradient and these none.
            bw.qkv_slot = s
            return bw
        return make

    return tuple(_tape(o, [x], slot(s)) for s, o in enumerate(outs))


@_verb("embedding")
def _v_embedding(shipped, args, kwargs):
    """A gather by row index. Its gradient is a scatter-add back into the table.

    `ttnn.embedding(indices, table)` is the broadcast every atom-level model makes: OF3's
    diffusion module fans a per-token single onto 601 atoms, its atom transformer fans the
    same tensor onto 19 key blocks, and the pair branch gathers a [96,96] map into blocked
    windows. The INDICES are host-precomputed and carry no gradient; the TABLE is the taped
    activation, and since many rows read the same table entry the backward accumulates
    rather than assigns. A closure that assigned would be exactly right on a permutation
    and silently wrong here, which is why the test drives it with duplicates.

    `ttnn.embedding_bw` is that scatter-add, with two constraints the shipped signature
    does not advertise: the cotangent must be rank 4 with both leading dims 1, and it must
    be bf16 or bfp8 (it refuses fp32 outright). Neither costs accuracy here, because the
    forward is already bf16 at this point -- every shipped call site downcasts the table
    before the gather, since `ttnn.embedding` is bf16-only too. Measured against float64
    index_add at the shapes OF3 runs: 1.03e-2 relative at [96,384] from 608 rows, 1.35e-2
    at [9216,128] from 77824. That is the kernel's own bf16 accumulation, not the input
    rounding -- splitting the cotangent into bf16 high and residual and running it twice
    moves 1.354e-2 to 1.344e-2, so there is nothing to buy there. It grows with rows per
    table entry: 6.2e-2 at 43 duplicates, over §3d's per-tensor bar. If a table ever gets
    that crowded the escape is a one-hot matmul, which accumulates in the fp32 dest
    register; at OF3's ~8 rows per entry it is not needed and would cost a [77824, 9216]
    intermediate.
    """
    idx = _unwrap(args[0])
    w = _wrap(args[1])
    ra, rk = _raw(args, kwargs)
    out_v = shipped(*ra, **rk)
    w_shape, w_dtype, w_layout = w.value.shape, w.value.dtype, w.value.layout
    V, C = int(w_shape[-2]), int(w_shape[-1])

    def make():
        def bw(g):
            flat = ttnn.reshape(ttnn.to_layout(g, ttnn.ROW_MAJOR_LAYOUT), (1, 1, -1, C))
            gb = ttnn.to_layout(flat, ttnn.TILE_LAYOUT)
            if gb.dtype != ttnn.bfloat16:
                gb = ttnn.typecast(gb, ttnn.bfloat16)
            gw = ttnn.embedding_bw(idx, w.value, gb)
            gw = ttnn.reshape(ttnn.to_layout(gw, ttnn.ROW_MAJOR_LAYOUT), tuple(w_shape))
            if w_layout != ttnn.ROW_MAJOR_LAYOUT:
                gw = ttnn.to_layout(gw, w_layout)
            if gw.dtype != w_dtype:
                gw = ttnn.typecast(gw, w_dtype)
            w.add_grad(gw)
        return bw

    return _tape(out_v, [w], make)

# --- placement and lifetime --------------------------------------------------------------

_VERBS["clone"] = _VERBS["reallocate"] = _VERBS["to_layout"] = \
    _VERBS["to_memory_config"] = lambda s, a, k: _identity_grad(s, a, k)
_VERBS["typecast"] = lambda s, a, k: _identity_grad(s, a, k, cast=True)


@_verb("deallocate")
def _v_deallocate(shipped, args, kwargs):
    """Inference frees an activation as soon as its consumer has read it. A backward reads
    it again, so the tape decides: `Tensor.free` releases what no closure can reach and
    refuses the rest. A raw handle never reaches here -- the wrapper below passes it
    straight to ttnn -- so nothing an inference run frees today stays live."""
    t = args[0]
    if not isinstance(t, Tensor):
        # A raw handle the tape has wrapped is still one the tape may be reading; one it
        # has never seen is nobody's activation and goes straight through.
        t = ag.wrapper_for(t) or t
    if isinstance(t, Tensor):
        t.free()
    else:
        shipped(*args, **kwargs)
    return _FREED


class _Freed:
    """`deallocate` returns None, and None is how a hook declines. This is neither."""
    __slots__ = ()
    def __repr__(self):                                                    # pragma: no cover
        return "<freed>"


_FREED = _Freed()


# --- the ttnn tt-bio sees while a tape is open --------------------------------------------

class _Ttnn:
    """ttnn, with the differentiable verbs taped. Every other attribute is ttnn's own.

    Lookups are cached into the instance dict on first use, so a hot call site pays one
    ordinary attribute load. A verb that never meets a taped tensor -- every config class,
    every device query -- costs one `_on_tape` scan of its arguments.
    """

    def __init__(self, real, prefix: str = ""):
        object.__setattr__(self, "_real", real)
        object.__setattr__(self, "_prefix", prefix)

    def __getattr__(self, name):
        real = object.__getattribute__(self, "_real")
        attr = getattr(real, name)
        qual = object.__getattribute__(self, "_prefix") + name
        # `types.ModuleType`, not `type(ttnn)`: the latter reads this module's own global,
        # so a second proxy that rebinds it makes this test a false negative and every
        # `ttnn.experimental.*` verb comes back raw, failing later as a pybind TypeError.
        if isinstance(attr, types.ModuleType):
            out = _Ttnn(attr, qual + ".")
        elif callable(attr) and not isinstance(attr, type):
            out = _taped_verb(qual, attr)
        else:
            return attr
        object.__setattr__(self, name, out)
        return out


# Verbs that must reach their tape entry even when no argument is a `Tensor`. There is
# exactly one, and the reason is the raw-handle map: a raw ttnn tensor can be an operand of
# a taped op -- the shipped attention does it at `tenstorrent.py:8209` and `:8290`, where
# the pair track is taped and the single track is not -- and the tape wraps and pins it.
# The caller then deallocates the RAW handle, whose argument list contains no `Tensor` at
# all, so an `_on_tape` short circuit hands it straight to ttnn and the pin never gets a
# say. The buffer goes and the throw arrives later, in the backward, in a different module.
_ALWAYS_DISPATCH = frozenset({"deallocate"})


def _taped_verb(qual, shipped):
    if qual == "linear":
        # The shipped pair modules call `ttnn.linear` directly; `ops.linear` asks `pair_mm` first.
        shipped = functools.partial(_pair_mm.or_linear, shipped)
    impl = _VERBS.get(qual)
    always = qual in _ALWAYS_DISPATCH

    def call(*args, **kwargs):
        if not always and not _on_tape(args, kwargs):
            return shipped(*args, **kwargs)
        if impl is None:
            # The refusal belongs exactly where it protects a gradient, and no further. A
            # tensor can be ON the tape and not be DIFFERENTIATING -- inside `no_grad`, or
            # frozen in a fine-tune -- and then there is no gradient upstream to drop and
            # unwrapping is the correct answer rather than a silent one. The shipped OF3
            # rollout crosses to host with `ttnn.to_torch` inside its own `no_grad`
            # (`openfold3_sample_diffusion.py:188`), which is a verb with no tape entry and
            # never will have one, and a blanket refusal stopped `train_loop` there.
            if not _differentiating(args, kwargs):
                ra, rk = _raw(args, kwargs)
                return shipped(*ra, **rk)
            raise NotImplementedError(
                f"ttnn.{qual} has no tape entry, and it was handed a tensor being "
                f"differentiated. Add one to tt_bio.autograd._VERBS -- unwrapping here would "
                f"drop the gradient of everything upstream of this call, silently.")
        with ag._no_param_scan():
            out = impl(shipped, args, kwargs)
        return None if out is _FREED else out

    return call


_SHIM = _Ttnn(ttnn)
_SHIMMED: list = []
_NEVER_SHIM = (__name__, "tt_bio.autograd")
_TT_MODULES: tuple = (-1, [])


def forget_shim_bindings(*names: str) -> None:
    """Drop `_SHIM`'s cached binding for these verb names, so the next call re-resolves it.

    `_Ttnn.__getattr__` caches a closure that captured BOTH the tape entry out of `_VERBS` and
    the shipped callable off `ttnn`, so a swap of either one afterwards is invisible at any
    call site that has already been through the shim once. `_SHIM` is a module singleton and
    outlives any one `tape()`, so this is not a first-tape problem -- it is the second tape in
    a process, where a lever installed between the two reads as perfectly inert.

    No names drops every binding, sub-proxies included: what a census that wraps all of ttnn needs.
    """
    for n in names or [k for k in vars(_SHIM) if k not in ("_real", "_prefix")]:
        _SHIM.__dict__.pop(n, None)


def taped_ttnn():
    """The proxy itself, for a caller outside `tt_bio` that wants to address it directly --
    a verification script, mostly. A shipped module never needs this; it writes `ttnn.`."""
    return _SHIM


def _swap(to_shim: bool) -> None:
    """Rebind the name `ttnn` in every tt-bio module that holds one.

    Every module, rather than a named list, because the chain reaches nine of them today
    and a tenth added next week would otherwise be the one place the tape stops. Two are
    excluded: this one, and `tt_bio.autograd`, whose backward closures must call the real
    verbs or they would tape their own gradients.

    `ttnn.Tensor.__getitem__` goes in and out with the modules, so an inference fold never
    executes `_param_getitem`.
    """
    global _SHIMMED, _TT_MODULES
    from . import ops
    if to_shim:
        _SHIMMED = []
        # The tt-bio modules, rescanned only when an import has grown `sys.modules`: a design
        # iteration opens this scope per callback and a full scan of thousands of jax and
        # torch modules was ~3 % of BindCraft 2's callback time on a Wormhole.
        if _TT_MODULES[0] != len(sys.modules):
            _TT_MODULES = (len(sys.modules), [
                mod for name, mod in list(sys.modules.items())
                if name.startswith("tt_bio") and mod is not None and name not in _NEVER_SHIM])
        for mod in _TT_MODULES[1]:
            if getattr(mod, "ttnn", None) is ttnn:
                mod.ttnn = _SHIM
                _SHIMMED.append(mod)
        ttnn.Tensor.__getitem__ = _param_getitem
        # The `generic_op` kernels go live with the shim and go away with it. Both call sites
        # guard on `_SHIMMED` so this never nests, and installing here rather than in
        # `tape()` covers `recompute_scope()` as well -- a checkpointed segment that rebuilt
        # itself without the entries would take a different forward in the backward than it
        # took in the forward, which is a wrong gradient nothing would report.
        ops.set_kernel_entries(enabled_kernels())
    else:
        for mod in _SHIMMED:
            mod.ttnn = ttnn
        _SHIMMED = []
        ttnn.Tensor.__getitem__ = _SHIPPED_GETITEM
        ops.set_kernel_entries(None)


@contextlib.contextmanager
def shim_scope():
    """Hook and shim together, restored exactly as found. Neither alone is a usable state.

    The grad hook makes `ops.linear` and `ops.layer_norm` hand back an `autograd.Tensor`; the
    shim is what makes every OTHER verb in the same module accept one. A shipped module mixes
    the two freely -- `OF3DiffusionConditioning._pair` is four `ops` calls and eleven raw
    `ttnn.` ones -- so with the hook on and the shim off, the first raw verb downstream of an
    `ops` call gets an `autograd.Tensor` and pybind refuses it. That is not hypothetical: it is
    where `tt_bio.train.recipes.train_loop` died on the OpenFold3 forward, in the discovery
    pass, before step 0.

    Nothing here opens a tape and nothing here changes what is differentiated. Under
    `no_grad` the shim's verbs run the shipped ones, so a forward inside this context computes
    what production computes.
    """
    if _SHIMMED:
        yield
        return
    from . import ops
    # The hook as well as the shim. `ops.linear` and `ops.layer_norm` tape through the hook,
    # not the shim, so a recompute without it would rebuild the segment with those sites
    # untaped and produce a partial gradient rather than an error. And `ops.taping()` -- which
    # is how nine fused kernels decide to decline, none of which has a backward -- is defined
    # as the hook being installed, so without it the recompute walks straight into
    # `generic_op has no tape entry`.
    prev = ops.grad_hook()
    if prev is None:
        ops.set_grad_hook(ag._hook)
    _swap(True)
    try:
        yield
    finally:
        _swap(False)
        if prev is None:
            ops.set_grad_hook(None)


def recompute_scope():
    """`shim_scope` under its other name: a recomputation from inside a BACKWARD.

    `tape()` is a forward-time context and has already closed by the time `backward` runs a
    checkpointed segment again, so the shipped module is looking at the real `ttnn` and hands
    it an `autograd.Tensor`. The scope must touch neither the wrapper map nor the hook the
    running backward owns, which is exactly what `shim_scope` does not touch.
    """
    return shim_scope()


@contextlib.contextmanager
def tape():
    """Make the shipped forward differentiable for the duration of the block.

        with tt_bio.autograd.tape():
            out = model(x)          # the production module, the production kernels
        out.backward()

    One line, and every knob the shipped path has is still reachable, because this changes
    no call site: the modules run the code they always ran and the tensors they are handed
    answer to everything a ttnn tensor answers to.

    Reentrant, and restores on the way out even if the forward raises. Modules imported
    INSIDE the block are not shimmed -- tt-bio imports its device modules at import time,
    so this only matters to a caller doing something unusual, and it fails loudly (a raw
    ttnn verb handed a taped tensor) rather than quietly.
    """
    if _SHIMMED:
        yield                       # already open; the outermost block owns the swap
        return
    prev = ag._install_hooks()
    _swap(True)
    try:
        # Softmax and layer norm exact for the forward under `autograd.exact_training(True)`,
        # a no-op otherwise. The backward opens the same scope for itself, since it runs after
        # this block closes.
        with ag._training_exact("tape"):
            yield
    finally:
        _swap(False)
        ag.forget_wrappers()
        ag._restore_hooks(prev)


# --- padding and reductions ---------------------------------------------------------------

@_verb("pad")
def _v_pad(shipped, args, kwargs):
    """The backward is the slice this op is the inverse of, and the pad VALUE is a constant
    so it carries no gradient of its own. Every tt-bio caller passes per-dimension
    (before, after) pairs, which is the form read here; a bare-int form would land on a
    different ttnn overload and is refused rather than guessed."""
    x = _wrap(args[0])
    padding = kwargs.get("padding", args[1] if len(args) > 1 else None)
    pairs = [(int(a), int(b)) for a, b in padding]
    shape = [int(d) for d in x.value.shape]
    ra, rk = _raw(args, kwargs)
    out_v = shipped(*ra, **rk)

    def make():
        def bw(g):
            starts = [b for b, _ in pairs]
            ends = [b + n for (b, _), n in zip(pairs, shape)]
            x.add_grad(ttnn.slice(g, starts, ends))
        return bw

    return _tape(out_v, [x], make)


@_verb("typecast")
def _v_typecast(shipped, args, kwargs):
    """Change dtype. The backward casts the gradient back to the INPUT's dtype.

    Needed because a dtype boundary inside the model is a real edge of the graph, not
    bookkeeping: OpenFold3 runs its diffusion half in fp32 against a bf16 trunk
    (`OF3_DIFFUSION_FP32_DEVICE`, default on), so a training forward that crosses that
    boundary crosses it through this verb. Without an entry here the tape raises, and the
    alternative -- casting outside the tape -- silently hands fp32 weights bf16 activations.

    `add_grad` already promotes and re-lays-out what it accumulates, so the cast here is the
    dtype the PARENT's value carries, nothing more.
    """
    x = _wrap(args[0])
    ra, rk = _raw(args, kwargs)
    out_v = shipped(*ra, **rk)
    src = x.value.dtype

    def make():
        def bw(g):
            x.add_grad(g if g.dtype == src else ttnn.typecast(g, src))
        return bw

    # `reads=()`: neither the input nor the output is read by the backward, only its dtype,
    # which is captured above.
    return _tape(out_v, [x], make, reads=())


@_verb("sum")
def _v_sum(shipped, args, kwargs):
    """Sum over one axis. The backward broadcasts the gradient back along it, which is one
    add against a zero tensor of the input's shape rather than a repeat."""
    x = _wrap(args[0])
    keepdim = bool(kwargs.get("keepdim", False))
    dim = kwargs.get("dim", args[1] if len(args) > 1 else None)
    shape = [int(d) for d in x.value.shape]
    if dim is None or isinstance(dim, (list, tuple)):
        raise NotImplementedError(
            "tt_bio.autograd tapes ttnn.sum over a single named axis only; an all-axis or "
            "multi-axis sum has a different broadcast and no tt-bio caller needs one.")
    ax = _axis(int(dim), len(shape))
    ra, rk = _raw(args, kwargs)
    out_v = shipped(*ra, **rk)

    def make():
        def bw(g):
            if not keepdim:
                kept = list(shape)
                kept[ax] = 1
                g = ttnn.reshape(g, kept)
            x.add_grad(ttnn.add(ag.grad_zeros(shape, g.dtype, g.device()), g))
        return bw

    return _tape(out_v, [x], make)


@_verb("max")
def _v_max(shipped, args, kwargs):
    """Max over one axis, gradient routed to the maximal elements by an equality mask.

    Ties SPLIT: k equal maxima each receive the full gradient rather than 1/k of it, which
    differs from torch's `max(dim)`, and the reason to accept it here is that the only
    tt-bio caller is the numerical-stability shift in `_accurate_softmax`
    (`tenstorrent.py:3444`). There the gradient through the max provably contributes zero
    whatever the tie rule: softmax is invariant to a uniform row shift, so the perturbation
    this path sends into the softmax lies along the all-ones direction, and the softmax
    Jacobian annihilates it. A caller wanting max as a real selection should ask for one.
    """
    x = _wrap(args[0])
    keepdim = bool(kwargs.get("keepdim", False))
    dim = kwargs.get("dim", args[1] if len(args) > 1 else None)
    shape = [int(d) for d in x.value.shape]
    if dim is None or isinstance(dim, (list, tuple)):
        raise NotImplementedError("tt_bio.autograd tapes ttnn.max over a single named axis only")
    ax = _axis(int(dim), len(shape))
    ra, rk = _raw(args, kwargs)
    out_v = shipped(*ra, **rk)
    xv = x.value

    box = [out_v]

    def make():
        def bw(g):
            m = box[0]                      # through the box: `free` may have evicted it
            if not keepdim:
                kept = list(shape)
                kept[ax] = 1
                m = ttnn.reshape(m, kept)
                g = ttnn.reshape(g, kept)
            x.add_grad(ttnn.multiply(g, ttnn.eq(x.value, m)))
        return bw

    out = _tape(out_v, [x], make)
    if out.node is not None:
        out.box = box
    return out
