"""Reverse-mode autograd over on-device ttnn tensors.

The design is tt-train's. In ``tt-metal/tt-train/sources/ttml/autograd/graph.cpp`` a
differentiated op pushes a closure onto a tape (``Graph::add_node(GradFunction&&,
span<NodeId>)``, :30) and ``Tensor::backward`` (tensor.cpp:65) topologically sorts from the
root, reverses, seeds the root gradient with ones and calls each closure in turn. Every
closure reads its output's gradient and accumulates into its inputs' via ``add_grad``
(tensor.cpp:35), which sums on fan-in. This module is that structure in Python over raw
ttnn tensors.

Why not torch.autograd, which is the obvious alternative: torch's engine can only route
torch tensors. A ttnn device handle returned from ``torch.autograd.Function.forward``
gets no ``grad_fn`` at all -- torch drops it from the graph silently -- and a handle
smuggled as an attribute on a real-tensor carrier is lost by the engine's fan-in sum and
absent on ``grad_output`` in backward (all three measured, see docs/hallgrad.md). Making
the carrier hold real data means a host round-trip per tape node, which the activation
budget does not allow. The engine would only be scheduling for us anyway; the reverse
topological sort and the fan-in sum below are the whole of what it would have supplied.
"""

from __future__ import annotations

import contextlib
import functools
import gc
import math
import os
import sys
import weakref
from typing import Optional, Sequence

import ttnn

from tt_bio.envflags import env_flag
from tt_bio import mm_layout as _mm_layout
from tt_bio import fanin_l1 as _fanin_l1
from tt_bio import mm_generic as _mm_generic
from tt_bio import rne_add as _rne_add

#: `ttnn.zeros(..., device=)` builds its zeros on the HOST and uploads them, and that upload is
#: what this flag exists to avoid. It was introduced for trace capture, which refuses a host
#: write (`perf/bcx_trace`); the price turned out to matter far more widely than that. Measured
#: on pc card 0, Blackhole p150a, 1350 MHz DURING, at the pair-track shape the backward actually
#: issues (`[384, 1, 384, 128]` bf16 TILE, 37.75 MB, `perf/of3t_zerosfill/zerobench.py`):
#: the host build and upload is **5.90 ms at 6.4 GB/s**, the cached device clone **0.21 ms at
#: 180.6 GB/s** -- 28x, against a 440 GB/s write roof. `ttnn.full` is the same host path at
#: 5.77 ms, so it is no escape.
#:
#: Worth 1.0 s of a 21.1 s device backward at crop 384, medians of three interleaved pairs, and
#: every host run was slower than every device run. NOT the 11.9 s a per-verb profile charges to
#: `zeros`: ttnn dispatch is asynchronous and the host upload is the only blocking op in its
#: neighbourhood, so it drains a queue the verbs before it filled and a stopwatch around it bills
#: their device time to it. With the upload gone those verbs grow by 89 % of what `zeros` lost
#: (`perf/of3t_zerosfill/compare.py`). The 5.90 ms above is the honest per-call price because
#: every rep of that micro-benchmark ends in `synchronize_device`.
#:
#: So ON is the default since 2026-09-25 (`of3t-zerosfill`). OFF is kept as the break control
#: that restores the defect, and as the arm `perf/bcx_trace/trace.py` uses to price a host write.
DEVICE_ZEROS = True
_ZERO_CACHE: dict = {}


def grad_zeros(shape, dtype, device):
    """A zero tensor of ``shape`` on ``device``, for a backward that pads a gradient out.

    The one place a taped backward gets a zero from. `_v_create_qkv_heads` used to build its
    own beside this one and that second copy was the 35.1 %.
    """
    shape = [int(d) for d in shape]
    if not DEVICE_ZEROS:
        return ttnn.zeros(shape, dtype=dtype, layout=ttnn.TILE_LAYOUT, device=device)
    key = (tuple(shape), str(dtype), id(device))
    z = _ZERO_CACHE.get(key)
    if z is None:
        z = _ZERO_CACHE[key] = ttnn.zeros(shape, dtype=dtype, layout=ttnn.TILE_LAYOUT,
                                          device=device)
    # A clone, so a caller that frees its input cannot free the cache entry. It costs a device
    # read beside the write (0.21 ms against a 0.086 ms write-only roof) and buys the aliasing
    # question not having to be asked at five call sites.
    return ttnn.clone(z)


__all__ = [
    "Tensor", "precise_config", "bmm_program_config", "bmm", "softmax_bw_inner",
    "softmax_bw", "no_grad",
    "parameter", "forget_parameters", "parameter_for", "untaped",
    "release_pins",
    "linear", "matmul", "layer_norm", "softmax", "host_f64_softmax",
    "host_f64_softmax_values", "mul", "add", "straight_through", "scale", "sigmoid",
    "relu", "silu", "reshape", "pairwise_distance", "split_heads", "merge_heads",
    "split_heads_value", "merge_heads_value",
    "triangle_attention", "permute", "pair_contract", "checkpoint",
    "install", "uninstall", "installed", "is_grad_enabled", "backward", "tape",
    "exact", "exact_training", "exact_training_ops", "EXACT_TRAINING_OPS", "exact_softmax", "exact_softmax_installed",
    "exact_layer_norm_installed", "EXACT_SOFTMAX_STATS", "EXACT_LAYER_NORM_STATS",
]


def precise_config():
    """HiFi4 with fp32 destination accumulation, per ``ComputeKernelConfig::precise()``.

    tt-train sets exactly this for backward math (core/compute_kernel_config.cpp:9-16:
    ``fp32_dest_acc_en = true``, ``math_approx_mode = false``, ``MathFidelity::HiFi4``,
    ``packer_l1_acc = true``). A backward accumulates over the reduction axis and again
    over fan-in, and bf16 accumulation is how a gradient turns into noise. Every op here
    defaults to it. `tenstorrent.PRECISE_HIFI3` makes it HiFi3.
    """
    from .tenstorrent import precise_fidelity
    return ttnn.WormholeComputeKernelConfig(
        math_fidelity=precise_fidelity(),
        math_approx_mode=False,
        fp32_dest_acc_en=True,
        packer_l1_acc=True,
    )


# `ttnn.softmax` does not return rows that sum to one. Measured over the OpenFold3 trunk's own
# shapes on `wk/of3t` (`perf/of3t_d116/rowsum.json`, float64-referenced): mean row sum 0.9934,
# rms deviation 1.20e-02, worst row 0.9506, and fp32 storage does not fix it (0.9954). So what
# the card computes is `c * softmax(x)` for a per-row `c`, and the vjp of THAT is
# `y * (g - sum(g*y)/sum(y))`. The plain rule `y * (g - sum(g*y))` is the vjp of a function the
# card did not evaluate.
#
# The cost is not in the rel_l2 of `dx`, which barely moves (2.0156e-02 against 2.0154e-02 at the
# trunk shape, so an op-level audit is blind to this). It is that the plain rule leaves `dx` with
# a nonzero ROW SUM, 4.62e-03 rms against the reference's 1.29e-16, and the attention backward
# below it consumes exactly that: `dq_i = sum_j dx_ij k_j` equals `sum_j dx_ij (k_j - kbar)` only
# when the row sums vanish. When they do not, `dq` picks up `(row residual) * kbar`, a term the
# true gradient does not contain, worth 1.00x to 13.09x on `||dq||` as the common component of k
# grows (`perf/of3t_d116/amplify.json`). End to end the leaf error mass falls 878.85 -> 2.636 over
# 523 matched tensors, and block 8's gradient norm ratio 87.643 -> 1.732 with cos -0.169 -> +0.694.
#
# ON by default since 2026-09-21, on Moritz's ask-9629 ruling. Every read is inside a backward
# closure, so no forward and no inference result can move whichever way the flag is set, and that
# is checked rather than asserted: `perf/land_standing/renorm_reach.py` proves by AST that every
# read of the flag is inside `softmax_bw_inner` or a `bw(g)` closure and that every caller of
# `softmax_bw_inner` is itself inside one. Set the variable to 0 for the old backward.
#
# ONE definition. The name below is the only parse of this variable in the package; two parses is
# how a flag acquires two defaults.
SOFTMAX_BW_RENORM = env_flag("TT_BIO_SOFTMAX_BW_RENORM", True)

# Reached only from a backward closure, and this counts the reaching so that claim is a reading
# rather than an argument. `applied` is the branch taken, `declined` the branch evaluated and not
# taken; both can only happen under the tape, which is the claim.
SOFTMAX_BW_RENORM_STATS = {"applied": 0, "declined": 0}

if os.environ.get("TT_BIO_RENORM_STATS_DIR"):
    # Per process, because a `predict` run does its device work in SPAWNED workers and the
    # counters the parent can see are not the ones that ran the model. One file per pid, and the
    # reader sums them; a claim that the flag was never reached has to be read where the model
    # actually ran or it is a claim about the launcher.
    import atexit as _atexit
    import json as _json

    @_atexit.register
    def _dump_renorm_stats():
        d = os.environ["TT_BIO_RENORM_STATS_DIR"]
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, "%d.json" % os.getpid()), "w") as f:
            _json.dump({"pid": os.getpid(), "flag": bool(SOFTMAX_BW_RENORM),
                        **SOFTMAX_BW_RENORM_STATS}, f)


def softmax_bw_inner(y, g, dim=-1, config=None):
    """`sum_j g_j y_j` for the softmax backward `dx = y * (g - inner)`, row-sum corrected.

    One helper for all THREE callers: `softmax` and `triangle_attention` below, and
    `taped_ttnn._v_softmax`. The defect is the rule, not the site, and the count matters -- the
    first repair of this expression enumerated two callers and routed two, and the one it missed
    was `softmax` itself, which `__all__` exports.
    """
    # `compute_kernel_config` only under TT_BIO_SOFTMAX_BW_FP32, which is on by default. With it
    # off (`TT_BIO_SOFTMAX_BW_FP32=0`) this call is the bf16 backward that shipped before the
    # flag existed, config dropped and all.
    inner = (ttnn.sum(ttnn.multiply(g, y), dim=dim, keepdim=True, compute_kernel_config=config)
             if SOFTMAX_BW_FP32 and config is not None
             else ttnn.sum(ttnn.multiply(g, y), dim=dim, keepdim=True))
    SOFTMAX_BW_RENORM_STATS["applied" if SOFTMAX_BW_RENORM else "declined"] += 1
    if not SOFTMAX_BW_RENORM:
        return inner
    return ttnn.divide(inner, ttnn.sum(y, dim=dim, keepdim=True,
                                       compute_kernel_config=config or precise_config()))


# Whether the softmax backward may go through `ttnn.moreh_softmax_backward`, the fused verb
# already bound in the `ttnn==0.68.0` wheel, instead of the composed expression. The fused
# route computes the SAME expression including the row-sum correction -- it does not trade the
# renorm for speed, which would be the wrong trade in both directions (the renorm costs 1.32 s
# and carries a repair worth up to 13.09x on ||dq||, `perf/of3t_d116/amplify.json`).
SOFTMAX_BW_FUSED = env_flag("TT_BIO_SOFTMAX_BW_FUSED", False)

# Whether the softmax backward runs in fp32. `dx = y (g - sum(g y) / sum(y))` is a cancellation:
# at a converged row `sum(g y) / sum(y)` approaches `g`, so the subtraction keeps only the low
# bits of two bf16 numbers, and the reduction feeding it is the one reduction in this file that
# carried no `compute_kernel_config`. Casting both operands to fp32 and the result back costs two
# typecasts and changes no algebra: the same expression runs, reached through the same function.
#
# Measured on the pre-registered OpenFold3 training clause (`perf/of3t_modelframe/clause.py`, bar
# 0.15210099830945006, pre-registered 0425448d4). On the 48-block crop-384 model frame the
# DEVICE-ONLY trunk reads clause 0.329774333 / x_bar 2.16813 with this off and 0.151699012 /
# x_bar 0.99736 with it on. That is the whole gap, and it is what lets `_EXACT_TRAINING` -- a PCIe
# round trip and a numpy float64 softmax and layer norm per call, 1541 s of one 48-block backward
# against 41 s without it -- be turned off and still clear the bar. `perf/of3t_p10exact`.
#
# On by default, with `_EXACT_TRAINING` off: the pair is the device path OpenFold3 training ships
# on. `TT_BIO_SOFTMAX_BW_FP32=0` is the off switch. The fp32 copies live for one backward call,
# not for the length of the backward; `perf/of3t_p10default` measures the peak at the recipe's
# crops.
SOFTMAX_BW_FP32 = env_flag("TT_BIO_SOFTMAX_BW_FP32", True)

# Reached only from a backward closure, like the renorm counter above, so which path ran is a
# reading and not an argument.
SOFTMAX_BW_FP32_STATS = {"fired": 0, "elements": 0}


def _last_axis(y, dim: int):
    """The positive last-axis index if `dim` names it, else None.

    Two jobs in one, because they have the same answer. `ttnn.moreh_softmax_backward`
    reduces the last axis only, so a caller on any other axis keeps the composed path --
    every concrete softmax site in the engine passes -1 and the six that pass `dim=dim` are
    forwarders, but the check is here rather than in a comment, because the helper is
    exported and a caller that does not qualify should get the right answer slowly rather
    than the wrong one quickly. And the index has to be POSITIVE: the op takes `dim` as a
    `uint32_t` (`moreh_softmax_backward.hpp`), so -1 does not mean the last axis to it.
    """
    rank = len(y.shape)
    return rank - 1 if dim in (-1, rank - 1) else None


def softmax_bw(y, g, dim=-1, config=None, refine=False):
    """The whole softmax backward `dx = y (g - sum_j g_j y_j)`, row-sum corrected.

    `refine` runs it twice, the second time on `g - inner` (the backward is exactly invariant
    to a per-row shift of `g`). The card reduces with TF32 operands, so on a one-hot row
    (AF2's IPA, logits ~5,000, top-2 gap ~800) `g_max - inner` keeps ~5e-4 |g| of rounding
    where float64 gets 0, and the large keys downstream amplify it: structure module d_act0
    rel 2.24. Centring first squares that error, 3e-5 -> 1e-8 of |g| per one-hot head
    (`perf/bc4_headdev/softmax_probe.py`). Costs one more product and two reductions.

    All three callers used to close `softmax_bw_inner` with the same two verbs of their own
    (`ttnn.multiply(y, ttnn.subtract(g, inner))`), which is the same duplication the inner
    helper was factored out to end, one expression short. Routing the whole backward through
    one helper is also what gives the fused verb a single seam instead of three.

    On the fused route the renorm is carried, not dropped:
    `moreh_softmax_backward(y/s, g) * s` is `y (g - sum(g y)/s)` exactly, because
    `moreh(y/s, g) = (y/s)(g - sum(g y)/s)`. Four verbs against the composed six, and with
    the renorm off, one.
    """
    if SOFTMAX_BW_FP32 and y.dtype != ttnn.float32:
        SOFTMAX_BW_FP32_STATS["fired"] += 1
        SOFTMAX_BW_FP32_STATS["elements"] += int(y.volume())
        y32, g32 = ttnn.typecast(y, ttnn.float32), ttnn.typecast(g, ttnn.float32)
        # Recursion, not a second copy of the expression: `y32` is fp32, so this branch is not
        # taken twice and the arithmetic below stays the only definition of the backward.
        dx32 = softmax_bw(y32, g32, dim=dim, config=config or precise_config(), refine=refine)
        ttnn.deallocate(y32)
        ttnn.deallocate(g32)
        dx = ttnn.typecast(dx32, g.dtype)
        ttnn.deallocate(dx32)
        return dx
    if refine:
        g = ttnn.subtract(g, softmax_bw_inner(y, g, dim=dim, config=config or precise_config()))
    ax = _last_axis(y, dim) if SOFTMAX_BW_FUSED else None
    if ax is not None:
        SOFTMAX_BW_RENORM_STATS["applied" if SOFTMAX_BW_RENORM else "declined"] += 1
        if not SOFTMAX_BW_RENORM:
            return ttnn.moreh_softmax_backward(y, g, ax)
        s = ttnn.sum(y, dim=-1, keepdim=True,
                     compute_kernel_config=config or precise_config())
        return ttnn.multiply(ttnn.moreh_softmax_backward(ttnn.divide(y, s), g, ax), s)
    return ttnn.multiply(y, ttnn.subtract(g, softmax_bw_inner(y, g, dim=dim, config=config)))


_GRAD_ENABLED = True

# Fan-in without the widening casts: `Tensor.add_grad` hands `ttnn.add` its two gradients as they
# come, with an fp32 output, instead of typecasting each to fp32 first. Off: the mixed add lands
# 8.2e-5 relative L2 from float64 at two contributions and 5.5e-4 at sixteen, against 1e-10 and
# 1e-9 widened (`perf/bcx_reduce/probe.json`). Graded as a stack in `perf/bcx_reduce`.
FANIN_MIXED = False

# The cast after a fan-in, folded into the fan-in's last add. A bf16 value read by k consumers
# sums its k gradients in float32 (`add_grad`) and `_backward` then cast the sum back to bf16
# for the closure: 1,719 Typecast calls a BindCraft 2 round right after a widen_add, 0.249 s of
# card. On, `add_grad` holds the last contribution back and the closure's read does that add with
# a bf16 output, rounded once at pack (`rne_add.round_add`). Any other read flushes it as before.
FANIN_CAST_FUSED = env_flag("TT_BIO_FANIN_CAST_FUSED", False)
FANIN_CAST_STATS = {"served": 0, "flushed": 0}
#: `Tensor.grad_slab` joins: whole (every slice written, no concat) or cut back out.
SLAB_STATS = {"whole": 0, "cut": 0}


def is_grad_enabled() -> bool:
    """Whether taping is on. ``no_grad`` is the only thing that turns it off, and a caller
    that needs to branch on it should not have to reach into the context manager to find out."""
    return _GRAD_ENABLED


class no_grad:
    """Run a forward without taping it. This is the stop-gradient on earlier recycles."""

    def __enter__(self):
        global _GRAD_ENABLED
        self._prev = _GRAD_ENABLED
        _GRAD_ENABLED = False
        return self

    def __exit__(self, *exc):
        global _GRAD_ENABLED
        _GRAD_ENABLED = self._prev
        return False


class _Node:
    __slots__ = ("fn", "parents", "group")

    def __init__(self, fn, parents, group=None):
        self.fn = fn
        self.parents = parents
        # A callable shared by the output nodes of one multi-output segment; `backward` calls
        # it once, after the last of them. None for every ordinary op.
        self.group = group


# Whether `_tape` may pin only the parents a closure actually READS. Off restores the
# behaviour every verb had before there was a way to say otherwise -- pin everything -- and
# is the control arm for the measurement, not a fallback: with it on, no gradient changes,
# no op changes and no accumulation order changes, because the only difference is which dead
# buffers the card gets back. Release-gated all the same: it moves memory, and memory is what
# this campaign is measuring.
DROP_DEAD_VALUES = True


class Tensor:
    """A ttnn tensor plus its place on the tape. The value stays on device throughout.

    It answers everything a ttnn tensor answers. The shipped modules do far more with a
    tensor than compute on it -- they read ``padded_shape`` to size a program config,
    ``memory_config()`` to decide whether an operand is already in L1, ``layout`` and
    ``device()`` to pick a kernel -- and a taped tensor that could not answer those would
    make the tuned path unreachable from a gradient. ``__getattr__`` forwards the rest.

    What it deliberately does NOT answer to is ``isinstance(x, ttnn.Tensor)``. That is the
    discriminator the tape needs: a raw handle is nobody's activation and may be freed, a
    taped one may not.
    """

    __slots__ = ("_value", "_grad", "_pend", "_slab", "_parts", "requires_grad", "node", "pinned",
                 "evictable",
                 "box", "shares", "__weakref__")

    def __init__(self, value, requires_grad: bool = False):
        self._value = value
        self._grad = None
        # The last float32-widened contribution, not yet added (`FANIN_CAST_FUSED`).
        self._pend = None
        # A full-shape gradient buffer kernels write slices of in place, and the last-axis ranges
        # they wrote (`grad_slab`).
        self._slab = None
        # Gradients of slices of this value, (starts, ends, g), until `grad` is read.
        self._parts = None
        self.requires_grad = requires_grad
        self.node = None
        # Set by `_tape` the moment a closure is built that can read this value. It is the
        # whole of the lifetime rule: `free` refuses a pinned tensor and nothing else.
        self.pinned = False
        # Whether `free` may touch this value at all. Cleared for the few ops whose
        # backward reads their own OUTPUT -- relu, sigmoid, softmax, max --
        # because those closures hold the handle directly and deliberately do not hold the
        # `Tensor` (a closure that did would make the cycle out -> node -> fn -> out that
        # CPython cannot collect). Storage sharing is `shares`, not this.
        self.evictable = True
        # A one-slot box holding this tensor's own value, set by the few ops whose backward
        # reads their OUTPUT -- softmax, sigmoid, relu, max. Those closures cannot hold the
        # `Tensor`, because `out -> node -> fn -> out` is a cycle refcounting cannot collect
        # and 96 of them is the difference between a backward that peaks at 8.92 GiB and one
        # refused 2.4 GB. Holding the raw handle instead made the output UNEVICTABLE, so an
        # L1-resident softmax score sat in L1 for the whole tape: at crop 256 the taped
        # backward was refused 57 671 680 B of L1 inside the softmax backward itself, with
        # exactly one L1 buffer live and that buffer being this one. A box is neither -- the
        # closure reads `box[0]`, nothing holds the `Tensor`, and `free` writes the evicted
        # handle back into the same box.
        self.box = None
        # The taped tensors over this one's buffer, itself included, or None if it owns its
        # buffer alone. One list shared by every member, of WEAK references; `_share` says why
        # and `_free_shared` reads it.
        self.shares = None

    @property
    def value(self):
        return self._value

    @value.setter
    def value(self, new):
        """Replace the handle, and carry the parameter registration with it.

        `_PARAMS` maps the identity of the RAW handle to the leaf that owns it, because
        that is the only question a taped call can ask: the model hands an op a raw tensor
        and the tape has to say whether it is trainable. A raw ttnn handle carries no
        stable identity of its own -- `from_torch` mints a new Python object every time --
        so the key is derived from a value that three callers legitimately replace:
        `AdamW.step` writes the updated weight (`train/optim.py`), `load_adapter` writes a
        checkpoint's (`train/checkpoint.py`), and `free` below moves an L1-resident tensor
        to DRAM.

        Leaving the key behind on any of those is not a degraded gradient, it is no
        gradient: the model holds a handle the tape has never seen, `parameter_for` returns
        None at every call site, and the next backward reaches zero parameters while the
        loss curve still falls. Measured on the OpenFold3 training composition as `grad_norm`
        exactly 0.0 from step 2 onward, with the weight trajectory bit-identical to a model
        that computes nothing. (The artifact lives on that branch, so it is deliberately not
        cited by path here: a citation this tree cannot resolve is one `tests/
        test_perf_citations.py` fails on, which is the gate working.)

        Re-keying HERE rather than at those three call sites is the point. A duty spelled
        out in a docstring and owed by the caller is the form this defect already took:
        `parameter()` documented it, no caller in this tree performed it, and per-step
        parity instruments could not see it because an injected gradient never asks the
        tape to resolve a parameter.
        """
        old = self._value
        self._value = new
        if _PARAMS.get(id(old)) is self:
            del _PARAMS[id(old)]
            _PARAMS[id(new)] = self

    @property
    def shape(self):
        return self.value.shape

    @property
    def dtype(self):
        return self.value.dtype

    def __getattr__(self, name):
        # Only reached on a miss, so slots and properties above keep their own meaning.
        # Reads the SLOT, not the `value` property: forwarding through the property would
        # recurse for the one instant in `__init__` before the slot is set.
        if name.startswith("__") or name == "_value":
            raise AttributeError(name)
        return getattr(object.__getattribute__(self, "_value"), name)

    def __getitem__(self, index):
        # Resolved lazily: the slicing lives with the taped verb surface, and importing it
        # here would make `import tt_bio` pull the whole surface in for an inference run.
        from .taped_ttnn import _getitem
        return _getitem(self, index)

    def free(self) -> None:
        """Release the device buffer, unless a backward can still read it.

        This is what ``ttnn.deallocate`` becomes while a tape is open. Inference frees an
        activation the moment its consumer has read it; a backward reads it again, much
        later, and the crash that follows a premature free surfaces in an unrelated op
        several layers away. A leaf parameter is never freed either -- it is not an
        intermediate, and its gradient lands on it.

        PINNED and REQUIRES_GRAD are two different questions, and the release turns on the
        first. Every intermediate in the middle of the graph requires a gradient -- that is
        what makes the chain continue -- while its VALUE may be read by no backward at all:
        `typecast`'s closure keeps the source dtype rather than the source, and `softmax`'s
        reads y. Those bytes go back to the card here and the `Tensor` stays exactly where
        it is, so the gradient still lands on it.

        A value that is already released has nothing to free and nothing to move. That is the
        input of a taped `ttnn.reallocate`, which the shipped trimul tail then deallocates, and
        it must return here: `ttnn.to_memory_config` of a released L1 handle does not refuse,
        it copies whatever now occupies that address -- the reallocated output -- into a new
        DRAM buffer that the tape then holds.
        """
        if not self.evictable or not self.value.is_allocated():
            return
        if self.shares is not None:
            self._free_shared(release=True)
            return
        if not self.pinned and (self.node is not None or not self.requires_grad):
            ttnn.deallocate(self.value)
        else:
            self.evict()

    def evict(self) -> None:
        """Give an L1-resident value its PLACE back without giving up its bytes.

        EVICT rather than refuse. The tuned forward puts an activation in L1 and then
        frees it the moment its consumer has read it, and the next kernel's circular
        buffers are sized against the room that leaves. A tape that simply declines
        the free keeps the room occupied and the next kernel cannot lay out: measured
        on the shipped Transition at a [1,256,256,128] pair track, "Statically
        allocated circular buffers in program 11 clash with L1 buffers ... L1 buffer
        allocated at 692224 and static circular buffer region ends at 893440".

        The backward needs the VALUE; the forward's tuning needs the PLACE. Moving to
        DRAM gives both, and it is the honest price of a gradient: one DRAM write per
        L1-resident activation that inference does not pay.

        A released value has no place to give back and no bytes to move, so it returns here
        for the same reason `free` does. `_evict_read_parents` reaches this method directly
        and never through `free`, so the guard has to be on both.
        """
        if not self.evictable or not self.value.is_allocated():
            return
        if self.shares is not None:
            self._free_shared()                                  # a view moves with its group
            return
        try:
            if self.value.memory_config().buffer_type != ttnn.BufferType.L1:
                return
        except Exception:                                        # noqa: BLE001
            return                                               # host tensor, or no buffer
        old = self.value
        self.value = ttnn.to_memory_config(old, ttnn.DRAM_MEMORY_CONFIG)
        ttnn.deallocate(old)
        if self.box is not None:
            self.box[0] = self.value

    def _free_shared(self, release: bool = False) -> None:
        """`free` (`release`) or `evict` for a buffer several taped tensors are views of, decided
        for all of them.

        A ttnn shape op can hand back a view (`_tape` explains), and a view pair used to be
        marked non-evictable outright, because releasing or evicting either one alone kills the
        other. That is safe and it strands L1: the shipped attention projects q/k/v into L1 and
        reshapes it for the head split, so every AF2 attention left its packed projection and
        the view of it resident for the rest of the tape. After one extra-MSA block the tape held
        three such pairs, and the second block's triangle multiplication could not lay out its
        circular buffers at any chunk width (`perf/bcx_afgrad/l1diag.py`).

        So the group moves together. With nothing pinned the buffer is released, which is what
        the shipped deallocate of any one view does in inference; that is also every group in a
        checkpointed segment's untaped forward, where no tensor has a node. Otherwise every
        member gets its own DRAM copy read through its own shape and the shared L1 buffer is
        released once, refused if a member is a leaf (its placement is the module's tuning, as in
        `_evict_read_parents`). Either way a member that holds its buffer for the other reason,
        `evictable` False for a closure that reads its output by raw handle, refuses both.

        A release asks what `free` asks of a lone tensor: does any backward read the bytes, and
        is any member a leaf. Requiring a gradient is not reading a value, and every intermediate
        in the middle of the graph requires one, so testing it here kept every dead view group
        of a KEPT tape on the card. BindCraft 2's masked outer product mean reshapes its matmul
        output, and from 7353c9aef that held one [N, N, 128] pair tensor per resident Evoformer
        block: 0.50 GB at 224 tokens and 40 blocks, which is what refused the backward at 47.
        """
        group = _members(self.shares)
        if any(not t.evictable for t in group):
            return
        if not any(t.pinned for t in group) and (
                not any(t.requires_grad for t in group)
                or (release and all(t.node is not None or not t.requires_grad for t in group))):
            ttnn.deallocate(self.value)
            return
        if any(t.node is None for t in group):
            return
        if self.value.memory_config().buffer_type != ttnn.BufferType.L1:
            return
        old = self.value
        for t in group:
            t.value = ttnn.to_memory_config(t.value, ttnn.DRAM_MEMORY_CONFIG)
            t.shares = None
            if t.box is not None:
                t.box[0] = t.value
        ttnn.deallocate(old)

    def add_grad(self, grad) -> None:
        """Accumulate one contribution. A tensor read by k consumers gets k calls.

        The second contribution promotes the accumulator to fp32, and that is not a
        precaution. Fan-in here is not two or three: a chunked forward calls this once per
        chunk, so a weight in the row-blocked transition takes one contribution per row
        block -- 64 of them on a 64-row pair block, 512 at 512 aa. bfloat16 carries 8
        mantissa bits, and a 64-term bf16 running sum measured 6.5e-02 relative L2 against
        the float64 reference where the same gradient unchunked measured 6.5e-03. The
        first contribution is stored as it arrives, so a tensor with one consumer -- most
        of the tape -- pays nothing in memory or in a cast.
        """
        if not self.requires_grad:
            return
        # Shapes compared as they come: `tuple()` of a ttnn.Shape walks its iterator at ~0.5 us
        # a dim, and this runs once per contribution. The tuples are still the arbiter, so a
        # shape type that does not compare to a ttnn.Shape cannot raise here where it did not.
        want, got = self.value.shape, grad.shape
        if want != got and tuple(want) != tuple(got):
            raise ValueError(f"gradient shape {tuple(got)} does not match value shape "
                             f"{tuple(want)}")
        # A parent receives its cotangent in ITS OWN layout. Closures compute in whatever
        # layout their output arrived in, and most of the tape is tiled end to end so this
        # never came up; a row-major activation -- `ttnn.embedding`'s table, the atom
        # broadcasts either side of it -- sends a row-major gradient up a chain of tiled
        # ops, and the throw lands in the first matmul or concat that sees it, several
        # closures away from the one that produced it. Enforcing the invariant here costs
        # a comparison per contribution and removes the whole class.
        # (OF3T's rule, verbatim from wk/of3t.) It is also a speed rule: a reshape the forward
        # made in ROW_MAJOR because it is not a tile view gets its gradient in ROW_MAJOR, so
        # the backward reshape is a view too. Taken in TILE, the outer-product mean's
        # [8192,8192] -> [256,1024,256] was a ReshapeView kernel at 5.5 % of the copy roof,
        # 11.95 ms per AF2 Evoformer block at n=256 (`perf/bcx_realcensus`).
        if grad.layout != self.value.layout:
            grad = ttnn.to_layout(grad, self.value.layout)
        if self._grad is None:
            self._grad = grad
            return
        if FANIN_MIXED:
            self._grad = ttnn.add(self._grad, grad, dtype=ttnn.float32)
            return
        # The promoted CONTRIBUTION is written and read straight back by this ttnn.add: 576
        # instances and 24.46 GB a round, the largest write-then-reread edge in
        # bcx-p10-l1fuse's chain census. `fanin_l1.typecast` puts it in L1 where the grid's own
        # budget takes it and leaves it in DRAM where it does not. Nothing here is taped, so
        # `Tensor.evict` never turns the placement back into a DRAM copy the way it does in a
        # forward.
        #
        # ONLY the contribution, and the accumulator and the sum stay in DRAM by name. The
        # contribution dies on the next line; `self._grad` lives until the whole backward is
        # done, and an L1 buffer that outlives the op that made it is not this row's chain --
        # it is a permanent 386 KB a bank that the next kernel's statically allocated circular
        # buffers collide with. Measured, not guessed: routing the accumulator here too threw
        # `Statically allocated circular buffers in program 209 clash with L1 buffers ... L1
        # buffer allocated at 1378304 and static circular buffer region ends at 1427968` on the
        # first backward. A budget that guards its own allocation does not guard the next
        # program's CB region, so residency is only safe for a value whose lifetime ends inside
        # the chain that reads it.
        #
        # `TT_BIO_WIDEN_ADD` removes the casts instead of placing them: one kernel widens both
        # operands in the unpacker and adds in a float32 DEST, the same function at 8-10
        # B/element against 18-24. Where it serves there is no promoted tensor left for
        # `fanin_l1` to place, so the two never act on one call.
        if self._pend is not None:
            self._flush_pend()
        if _rne_add.widen_eligible(self._grad, grad):
            if (FANIN_CAST_FUSED and grad.dtype == ttnn.bfloat16
                    and self.value.dtype == ttnn.bfloat16):
                self._pend = grad
                return
            self._grad = _rne_add.widen_add(self._grad, grad)
            return
        if self._grad.dtype != ttnn.float32:
            self._grad = ttnn.typecast(self._grad, ttnn.float32)
        self._grad = ttnn.add(
            self._grad,
            grad if grad.dtype == ttnn.float32 else _fanin_l1.typecast(grad, ttnn.float32),
            memory_config=ttnn.DRAM_MEMORY_CONFIG)

    def add_grad_slice(self, grad, starts, ends) -> None:
        """Accumulate the gradient of the slice ``[starts, ends)`` of this value.

        A chunked forward slices a tensor into blocks, and padding each block's gradient back
        out to the full shape before summing costs two host-built `ttnn.zeros` per block (a
        host build and upload at about 7 GB/s) plus a full-size fp32 add on device. In an AF2
        Evoformer block backward at n=256 that was 60 pads and 100.9 of the 182 ms of host
        time (`perf/bcx_realcensus`). The blocks are kept instead and joined when `grad` is
        first read, which the reverse topological order puts after the last of them.
        """
        if not self.requires_grad:
            return
        # `ttnn.concat` is tile-only, and a slice of a row-major tensor hands this a row-major
        # cotangent; `add_grad` puts the joined gradient back into this value's layout.
        if grad.layout != ttnn.TILE_LAYOUT:
            grad = ttnn.to_layout(grad, ttnn.TILE_LAYOUT)
        if self._parts is None:
            self._parts = []
        self._parts.append(([int(v) for v in starts], [int(v) for v in ends], grad))

    def _flush_pend(self):
        pend, self._pend = self._pend, None
        FANIN_CAST_STATS["flushed"] += 1
        self._grad = _rne_add.widen_add(self._grad, pend)

    def grad_slab(self):
        """An uninitialised gradient buffer in this value's shape (bf16 TILE DRAM) that kernels
        write last-axis slices of directly, with `slab_written` recording each. It becomes ONE
        contribution when the gradient is read: whole if the slices cover the axis, else the
        written slices are cut back out and joined like any `add_grad_slice`."""
        if self._slab is None:
            self._slab = (ttnn.empty(self.value.shape, ttnn.bfloat16, ttnn.TILE_LAYOUT,
                                     self.value.device(), ttnn.DRAM_MEMORY_CONFIG), [])
        return self._slab[0]

    def slab_written(self, start, end) -> None:
        self._slab[1].append((int(start), int(end)))

    def _join_slab(self):
        slab, spans = self._slab
        self._slab = None
        W = int(self.value.shape[-1])
        at = 0
        for s, e in sorted(spans):
            if s > at:
                break
            at = max(at, e)
        if at >= W:
            SLAB_STATS["whole"] += 1
            self.add_grad(slab)
            return
        SLAB_STATS["cut"] += 1
        shape = [int(d) for d in self.value.shape]
        for s, e in spans:
            starts, ends = [0] * len(shape), list(shape)
            starts[-1], ends[-1] = s, e
            self.add_grad_slice(ttnn.slice(slab, starts, ends), starts, ends)
        ttnn.deallocate(slab)

    def _join_parts(self):
        if self._slab is not None:
            self._join_slab()
        if self._parts:
            parts, self._parts = self._parts, None
            for g in _join_slices(parts, [int(d) for d in self.value.shape]):
                self.add_grad(g)

    @property
    def grad(self):
        self._join_parts()
        if self._pend is not None:
            self._flush_pend()
        return self._grad

    @grad.setter
    def grad(self, g):
        self._grad, self._parts, self._pend, self._slab = g, None, None, None

    def closure_grad(self):
        """The gradient a closure is handed: `grad` in this value's dtype.

        With a held-back contribution (`FANIN_CAST_FUSED`) the last add writes bf16 directly,
        so there is no float32 sum to cast.
        """
        self._join_parts()
        if self._pend is not None:
            pend, self._pend = self._pend, None
            FANIN_CAST_STATS["served"] += 1
            self._grad = _rne_add.round_add(self._grad, pend)
            return self._grad
        g = self.grad
        if g is not None and g.dtype != self.value.dtype:
            g = ttnn.typecast(g, self.value.dtype)
        return g

    def backward(self, seed=None) -> None:
        """Replay the tape from here. ``seed`` defaults to ones, i.e. d(sum(self))/d(self)."""
        backward([self], [seed])


def _pad_slice(g, starts, ends, shape):
    """A slice's gradient padded with zeros back out to the shape it was cut from.

    One `ttnn.pad` when the cut starts at 0 on every axis. A concat with a zeros tensor along a
    sub-tile last dim runs ~14 GB/s: 2.90 ms against the pad's 0.15 ms on the template's
    [224, 4, 224, 16] head, same bits (`perf/bc4_layout/padslice_ab.py`)."""
    if not any(starts):
        pads = [(0, n - e) for e, n in zip(ends, shape)]
        return ttnn.pad(g, pads, 0.0) if any(q for _, q in pads) else g
    for ax in range(len(shape)):
        before, after = starts[ax], shape[ax] - ends[ax]
        if before or after:
            g = ttnn.concat(([_zeros_like_along(g, ax, before)] if before else []) + [g]
                            + ([_zeros_like_along(g, ax, after)] if after else []), dim=ax)
    return g


def _zeros_like_along(g, ax, n):
    z = [int(d) for d in g.shape]
    z[ax] = n
    return grad_zeros(z, g.dtype, g.device())


def _join_slices(parts, shape):
    """Slice gradients as full-shape contributions to sum.

    Slices that cut one and the same axis without overlapping, which is every chunked loop,
    are one concat in axis order, with zeros only where no slice was read. Anything else is
    padded slice by slice. Both give the same numbers, since a padded zero adds nothing.
    """
    if len(parts) == 1:
        # One slice is one pad, not a concat with zeros: BindCraft 2's [224, 4, 224, 16] head
        # gradient took 2.9 ms as a concat on a p300c, 4 calls an iteration (`_pad_slice`).
        (s, e, g), = parts
        return [_pad_slice(g, s, e, shape)]
    cuts = {tuple(ax for ax in range(len(shape)) if (s[ax], e[ax]) != (0, shape[ax]))
            for s, e, _ in parts}
    if len(cuts) == 1 and len(next(iter(cuts))) == 1:
        (ax,) = next(iter(cuts))
        parts = sorted(parts, key=lambda p: p[0][ax])
        if all(a[1][ax] <= b[0][ax] for a, b in zip(parts, parts[1:])):
            if len({g.dtype for _, _, g in parts}) > 1:
                parts = [(s, e, g if g.dtype == ttnn.float32 else ttnn.typecast(g, ttnn.float32))
                         for s, e, g in parts]
            blocks, at = [], 0
            for s, e, g in parts:
                if s[ax] > at:
                    blocks.append(_zeros_like_along(g, ax, s[ax] - at))
                blocks.append(g)
                at = e[ax]
            if at < shape[ax]:
                blocks.append(_zeros_like_along(blocks[-1], ax, shape[ax] - at))
            return [blocks[0] if len(blocks) == 1 else ttnn.concat(blocks, dim=ax)]
    return [_pad_slice(g, s, e, shape) for s, e, g in parts]


def backward(roots, seeds=None) -> None:
    """Replay one tape from SEVERAL roots at once, seeding each.

    A loss assembled on the host from k device outputs comes back as k seeds, and calling
    ``Tensor.backward`` k times is wrong twice over rather than merely slow. It replays every
    shared ancestor k times -- for ABodyBuilder3 that is the whole trunk, eight times -- and
    because each replay runs a shared node's closure with only the gradient that had arrived
    by then, the fan-in sums land partial and then get summed again on the next pass. One
    reverse topological order over the union of the roots' ancestors fixes both: every node's
    closure fires exactly once, after every contribution to it has landed.

    ``seeds`` is one per root, ``None`` for ones. A root that is also an ancestor of another
    root is handled correctly, because its seed is accumulated with ``add_grad`` semantics
    before the traversal and its own closure does not fire until the topological order says
    every consumer has run.

    Requested by ``train-b2-abb3-port``, whose eight geometry-loss outputs share one trunk.
    The eight-term ``ProtenixLoss`` has the same shape the moment it reads a second head.
    """
    if isinstance(roots, Tensor):
        roots = [roots]
        seeds = [seeds] if not isinstance(seeds, (list, tuple)) else seeds
    roots = list(roots)
    if seeds is None:
        seeds = [None] * len(roots)
    seeds = list(seeds)
    if len(seeds) != len(roots):
        raise ValueError(f"{len(roots)} roots but {len(seeds)} seeds")
    with _training_exact("backward"):
        _backward(roots, seeds)


def _backward(roots, seeds) -> None:
    order = _reverse_topo(roots)
    keep = {id(r) for r in roots}
    for r, sd in zip(roots, seeds):
        g = ttnn.ones_like(r.value) if sd is None else sd
        r.grad = g if r.grad is None else ttnn.add(r.grad, g)
    # Nodes that share a `group` are the outputs of one multi-output segment (`checkpoint`).
    # Each one's closure only deposits its gradient; the group fires once, after the last of its
    # members on THIS walk. Every parent of every member comes later in the order, so nothing
    # the group writes to has run yet when it fires.
    pending: dict = {}
    for t in order:
        if t.node is not None and t.node.group is not None:
            pending[t.node.group] = pending.get(t.node.group, 0) + 1
    for t in order:
        if t.node is not None:
            g = t.closure_grad()
            if g is not None:
                # A gradient inherits the forward's SHARD PLAN, and a backward is not planned
                # against it. `ttnn.matmul` refuses a height-sharded operand B outright ("operand
                # B can only be interleaved or L1 width sharded", measured at crop 384 in the
                # matmul backward) and `ttnn.sum` refuses a plan with more shards than cores. One
                # place rather than one per verb: the dispatch point is where every closure gets
                # its gradient, so a verb added next week is covered without being asked.
                t.node.fn(_unshard(g))
            # else: on the tape and reachable from a root, but no gradient ever landed on it. A
            # multi-output segment makes this ordinary rather than exceptional: a checkpointed
            # `PairformerLayer` publishes both `s` and `z` as parents of the next block, and an
            # objective that seeds only the pair track leaves the single track's node with
            # nothing to propagate. Zero in, zero out -- running the closure on a None is the
            # crash, not the diagnosis. Its group still counts it as arrived.
            fire = t.node.group
            if fire is not None:
                pending[fire] -= 1
                if not pending[fire]:
                    fire()
            if id(t) not in keep:
                _retire(t)


def _retire(t) -> None:
    """Release an intermediate's value and gradient the moment its own closure has run.

    The ordering this relies on is the one `_reverse_topo` already guarantees and `add_grad`
    already depends on: every CONSUMER of a tensor runs before the tensor's own closure. So by
    the time `backward` reaches `t`, every closure that could read `t.value` has read it and
    `t.grad` has just been propagated to `t`'s parents. Nothing can want either again, and
    holding them to the end of the tape is what made the backward's high-water the whole tape
    instead of its live frontier. At crop 384 the taped backward peaked at 32.370 GB of a
    34.22 GB card and was refused a 1 207 959 552 B buffer with the largest contiguous block
    3.26 MB short (`perf/of3t_l1/out/r2_384.json`).

    Three things are deliberately NOT retired.

    A LEAF: `t.node is None` is exactly a parameter or a model input, and its gradient is what
    the caller came for. This only ever runs inside the `t.node is not None` branch.

    A ROOT: the caller may still read the output it seeded, so the roots are held by id.

    A TENSOR SHARING STORAGE: `evictable` is false for it and `free` declines, unchanged.

    `pinned` is cleared before the call because the pin means "a closure is live over this
    value" and that closure has just run; left set, `free` would evict to DRAM rather than
    release, which buys nothing at the point where the release is the whole objective. The
    deallocate is direct rather than through `free`'s release branch because that branch also
    tests `requires_grad`, which is true for every intermediate downstream of a weight -- and
    clearing THAT flag instead would make a stray later `add_grad` drop its contribution
    silently, where a dead buffer raises.
    """
    t.grad = None
    if not t.evictable or t.shares is not None:
        return
    t.pinned = False
    try:
        if t.value.is_allocated():
            ttnn.deallocate(t.value)
    except Exception:                                        # noqa: BLE001
        pass


def _reverse_topo(roots) -> list:
    """Reverse post-order DFS over tape edges (output -> inputs), from one root or many.

    Reverse post-order is a topological order of a DAG, so every consumer of a tensor runs
    before the tensor's own closure. That ordering is what makes the fan-in sum in
    ``add_grad`` complete rather than partial: a tensor's closure only fires once all of
    its gradient contributions have landed.
    """
    order: list = []
    seen: set = set()
    if isinstance(roots, Tensor):
        roots = [roots]
    # Reversed, so that with an explicit LIFO stack the first root is expanded first and the
    # single-root order is unchanged from what this function produced before it took a list.
    stack = [(r, False) for r in reversed(list(roots))]
    while stack:
        t, expanded = stack.pop()
        if expanded:
            order.append(t)
            continue
        if id(t) in seen:
            continue
        seen.add(id(t))
        stack.append((t, True))
        if t.node is not None:
            for p in t.node.parents:
                if id(p) not in seen:
                    stack.append((p, False))
    order.reverse()
    return order


def _storage(value):
    """The live device buffer `value` reads, as (buffer type, address), or None if it has none.

    This is what `_tape` compares to find a view, and each part of it is there because a bare
    `buffer_address()` answered wrong without it (measured on a p300c):

    - A view dies with its source: `ttnn.deallocate` of one frees the buffer under both. So a
      parent that is no longer allocated cannot be the storage of a live output, and the
      answer for it is None without asking. The address of a freed buffer is not a fact about
      anything: `ttnn.reallocate`, which the trimul tail runs on each chunk when it chunks,
      frees its input and hands the output back AT THAT SAME ADDRESS, so an address that
      survived the free would call every move a view. ttnn refuses the question instead,
      logging `TT_FATAL: Tensor is not allocated` at critical and throwing, about 1060 times
      in one 4+48 AF2 gradient step at n=256.
    - L1 and DRAM are separate address spaces over the same integers. L1 buffers sit near
      1.5 MB and DRAM counts up from 64 per bank, so an L1 activation and its DRAM copy can
      hold the same number and not a byte in common.
    """
    if value.storage_type() != ttnn.StorageType.DEVICE or not value.is_allocated():
        return None
    return value.memory_config().buffer_type, value.buffer_address()


def _tape(out_value, parents: Sequence[Tensor], make_fn, reads=None) -> Tensor:
    """Wrap ``out_value`` and tape ``make_fn(out)`` if any parent wants a gradient.

    Skipping the node when no parent requires one is tt-train's branch pruning
    (autograd/graph_utils.hpp:74) and it is what makes stop-gradient free: an untaped
    subgraph costs nothing to carry.
    """
    needs = _GRAD_ENABLED and any(p.requires_grad for p in parents)
    out = Tensor(out_value, requires_grad=needs)
    # A ttnn shape op can return a VIEW rather than a copy -- measured, `ttnn.reshape` of
    # (1,4,32,64) to (1,128,64) hands back the input's own buffer -- and the tape then
    # holds two `Tensor`s over one allocation. Freeing or evicting either kills both, and
    # the throw lands much later and somewhere else: in AttentionPairBias it surfaced as
    # "Buffer is not allocated" inside a sigmoid in the gate's backward, two ops
    # downstream of the reshape that caused it. Neither may be released alone, so both join
    # one `shares` group and `Tensor._free_shared` decides for the group.
    #
    # Checked on EVERY op, not only the differentiated ones: a view whose own gradient
    # nobody wants still shares storage with one that somebody does, and it is the view
    # that the shipped code deallocates.
    #
    # The question is whether the two share STORAGE, and `_storage` explains why an address
    # alone does not answer it: L1 and DRAM number their buffers over the same integers, and
    # a freed parent's address is not a fact about anything.
    here = _storage(out_value)
    if here is not None:
        for p in parents:
            if _storage(p.value) == here:
                _share(p, out)
    if needs:
        # `make_fn` takes no arguments and the closure it returns takes the output gradient,
        # so no backward closure ever captures `out`. That matters for more than style: a
        # closure that reads `out.grad` makes the cycle out -> node -> fn -> out, which
        # CPython's refcounting cannot collect, so every intermediate of every step stays
        # resident until the cyclic collector happens to run. Measured: the hallucination
        # loop died of OOM at step 2 at 256 aa and inside 410 steps at 128 aa, on a 34.23 GB
        # card, with a per-step tape that fits several times over.
        out.node = _Node(make_fn(), list(parents))
        # A closure is now live over the values it READS, and those are the ones nothing may
        # free. `reads` names them -- parent indices, plus "out" for the backwards that read
        # their own output (softmax, sigmoid, relu, max). `reads=None` pins everything, which
        # is what every verb did before there was a way to say otherwise, and it stays the
        # default so a verb that has not thought about it cannot get this wrong.
        #
        # The saving is not a corner case. OpenFold3's fp32-softmax tail is
        # `typecast -> add_ -> softmax_in_place -> typecast`, and of the five tensors a row
        # block leaves behind only two are ever read again; the other three -- two fp32 score
        # copies and the bf16 scores under them -- were held purely because `_tape` pinned
        # every parent it was handed.
        if reads is None or not DROP_DEAD_VALUES:
            out.pinned = True
            for p in parents:
                p.pinned = True
        else:
            sel = set(reads)
            out.pinned = "out" in sel
            for i, p in enumerate(parents):
                if i in sel:
                    p.pinned = True
        _evict_read_parents(parents)
    return out


def _cross_reads(a: Tensor, b: Tensor) -> tuple:
    """Parent indices a PRODUCT's backward reads, given which of its two operands want a gradient.

    For ``a * b`` and ``a @ b`` each operand's gradient reads only the OTHER operand's value, so a
    side is read exactly when the other side wants a gradient. In a design round every weight is
    frozen, so a linear's input and a dropout multiply's update are read by nothing: pinning them
    kept ~10 of a block's ~60 pair tensors on the card for a gradient nobody asked for. The shapes
    a backward needs are taken at record time, so an operand left unpinned can be released.
    """
    return tuple(i for i, other in ((0, b), (1, a)) if other is not None and other.requires_grad)


def _evict_read_parents(parents: Sequence[Tensor]) -> None:
    """Move every L1-resident intermediate this op has just read down to DRAM.

    `free` is the tape's answer to `ttnn.deallocate`, and it only ever runs where the shipped
    forward CALLS that verb. Most of a tuned forward does not: it lets an activation go out of
    scope and the handle's destructor releases the buffer. Under a tape the wrapper is held by
    the node graph, the raw handle never drops, and an L1-resident activation the forward
    merely stopped using occupies its place for the rest of the tape.

    Measured, and it is not the mechanism this was expected to be. At crop 384 the taped
    backward threw "statically allocated circular buffers in program 413 clash with L1 buffers
    ... L1 buffer allocated at 344064" inside a checkpoint recompute, with four taped tensors
    holding L1. The one AT the clash address is a [20, 4, 384, 384] fp32 triangle-attention
    score block, and its lifetime bits read `evictable=True, pinned=True` -- `free` would have
    moved it and was never offered it (`perf/of3t_l1/out/seam_384_holders.json`). Two of the
    other three are the non-evictable set, which is a separate defect and not this one.

    So the trigger is the READ rather than the release: once a consumer has run, the forward's
    reason for the tensor being in L1 is spent, and only the backward's reason to keep the
    VALUE is left. That is exactly what `free` already does for a pinned tensor, so this routes
    through `free` rather than repeating it, and every guard it has applies unchanged -- a
    tensor sharing storage with another taped one, or one whose backward closure holds the raw
    handle, is marked non-evictable and is left alone.

    It calls `evict` and never `free`, and that is load-bearing rather than tidy. `free` now
    RELEASES an unpinned intermediate, and "this op has read it" is not "the forward is done
    with it" -- a tensor two ops consume would lose its buffer to the first one. Only the
    shipped `ttnn.deallocate` says the forward is finished, and only that path releases.

    LEAVES ARE NOT TOUCHED. A parameter or a model input has no node, and its placement is the
    shipped module's tuning rather than an intermediate's lifetime; evicting one would move a
    weight to DRAM permanently on the first step of training.

    The price is the one the tape's own docstring already names: a later forward op that wanted
    the same operand in L1 now reads it from DRAM. That is the Protenix inversion, where the
    tape turned L1-placement levers from 1.19-1.29x faster into 0.83-0.85x slower, paid
    deliberately here because in OF3 the alternative is not a slower step but no step at all.
    """
    for p in parents:
        if p.node is None or not p.evictable:
            continue
        try:
            if p.value.memory_config().buffer_type != ttnn.BufferType.L1:
                continue
        except Exception:                                        # noqa: BLE001
            continue                                             # host tensor, or no buffer
        p.evict()


MIXED_TRANSPOSE_A = {"promoted": 0}


def _matmul(a, b, **kw):
    """`ttnn.matmul`, with the operands brought to one dtype when `transpose_a` is set.

    `ttnn.matmul(transpose_a=True)` is wrong when its two operands differ in dtype, and it is
    the only form that is. Measured on a p300c against float64, every transpose form and both
    dtype orders (`perf/of3t_denoise/PROBE_MM.json`): fp32 A with bf16 B leaves about half the
    output as garbage, values up to 3.4e+38; bf16 A with fp32 B is finite and uncorrelated
    with the answer (rel 1.41, the sqrt(2) of two unrelated vectors). Same-dtype operands,
    `transpose_a=False` in either order, and `ttnn.linear` are all right to 2e-3.

    A backward meets that case as a matter of course: dW = X^T G pairs a forward activation
    with a cotangent that arrived in its consumer's dtype, and across the OpenFold3 diffusion
    boundary those are fp32 and bf16. That was D257, the three non-finite
    `sampler.dc.w_lin_*` gradients. The narrower operand is promoted to fp32, which is exact,
    and nothing changes where the dtypes already agree.
    """
    kw = _mm_layout.plan(a, b, kw)
    if not kw.get("transpose_a") or a.dtype == b.dtype:
        return _split_k(a, b, kw) or ttnn.matmul(a, b, **kw)
    MIXED_TRANSPOSE_A["promoted"] += 1
    tmp = []
    if a.dtype != ttnn.float32:
        a = ttnn.typecast(a, ttnn.float32)
        tmp.append(a)
    if b.dtype != ttnn.float32:
        b = ttnn.typecast(b, ttnn.float32)
        tmp.append(b)
    out = _split_k(a, b, kw) or ttnn.matmul(a, b, **kw)
    for t in tmp:
        ttnn.deallocate(t)
    return out


# A 2-D ``a^T @ b`` whose output is at most this many tiles and whose contraction is at least
# `SPLIT_K_MIN_KT` tiles runs as K chunks on separate cores (`_split_k`).
SPLIT_K_OUT_TILES = 32
SPLIT_K_MIN_KT = 64
# At most this many chunks, a constant rather than the core count so that the grouping, and so
# the bits, are the same on every card.
SPLIT_K_CHUNKS = 64
SPLIT_K_STATS = {"served": 0}


def _split_k(a, b, kw):
    """``a^T @ b`` over a long K with a small output, as a batch of K chunks summed in fp32, or
    None to leave the call to ``ttnn.matmul``.

    ttnn plans a 2-D product over its OUTPUT tiles, so a reduction over every token into a
    [64, 224] result runs on 14 cores, each contracting the whole axis: BindCraft 2's masked
    outer product backward, ``[28672, 64]^T @ [28672, 224]``, took 604 us at 27 GB/s and
    ``[8192, 64]^T @ [8192, 224]`` 173 us, 0.037 device s/it together on a p300c
    (`bets/unnamed` u2). Splitting K by whole tiles is a view, each chunk is one batch element of
    `bmm_program_config`'s reuse plan, so the chunks land on separate cores, and the partials
    stay fp32 through a pairwise tree of adds. The same contraction, grouped by chunk instead of
    by K block.
    """
    if (not kw.get("transpose_a") or kw.get("transpose_b") or kw.get("program_config") is not None
            or set(kw) - {"transpose_a", "transpose_b", "program_config", "compute_kernel_config",
                          "dtype", "memory_config"}
            or len(a.shape) != 2 or len(b.shape) != 2 or a.layout != ttnn.TILE_LAYOUT
            or b.layout != ttnn.TILE_LAYOUT or a.is_sharded() or b.is_sharded()):
        return None
    K, M, N = int(a.shape[0]), int(a.shape[1]), int(b.shape[1])
    if K % ttnn.TILE_SIZE or M % ttnn.TILE_SIZE or N % ttnn.TILE_SIZE:
        return None
    Kt = K // ttnn.TILE_SIZE
    if (M // ttnn.TILE_SIZE) * (N // ttnn.TILE_SIZE) > SPLIT_K_OUT_TILES or Kt < SPLIT_K_MIN_KT:
        return None
    P = 1
    while P * 2 <= min(Kt // 2, SPLIT_K_CHUNKS) and Kt % (P * 2) == 0:
        P *= 2
    if P < 4:
        return None
    a3 = ttnn.reshape(a, [P, K // P, M])
    b3 = ttnn.reshape(b, [P, K // P, N])
    cfg = kw.get("compute_kernel_config")
    plan = bmm_program_config(a3, b3, True, dtype=ttnn.float32, compute_kernel_config=cfg)
    if plan is None:
        return None
    parts = ttnn.matmul(a3, b3, transpose_a=True, program_config=plan, dtype=ttnn.float32,
                        compute_kernel_config=cfg)
    # Halve with fp32 adds, not ttnn.sum: a reduction feeds the FPU, which reads fp32 as tf32, and
    # took rel L2 against float64 from the partials' 4.1e-4 to 1.0e-3 (stock 4.9e-4). P is a power of two.
    out = parts
    while P > 1:
        P //= 2
        lo = ttnn.slice(out, [0, 0, 0], [P, M, N])
        hi = ttnn.slice(out, [P, 0, 0], [2 * P, M, N])
        ttnn.deallocate(out)
        out = ttnn.add(lo, hi, dtype=ttnn.float32)
        ttnn.deallocate(lo)
        ttnn.deallocate(hi)
    out = ttnn.reshape(out, [M, N])
    dtype = kw.get("dtype") or a.dtype
    if dtype != ttnn.float32:
        out = ttnn.typecast(out, dtype)
    mc = kw.get("memory_config")
    if mc is not None and mc != out.memory_config():
        out = ttnn.to_memory_config(out, mc)
    SPLIT_K_STATS["served"] += 1
    return out


def _share(a: Tensor, b: Tensor) -> None:
    """Put `a` and `b` in one storage group, merging any groups they already belong to.

    The group holds its members WEAKLY. Every member points at the list, so a list of strong
    references is a cycle -- a view and its source owning each other -- and a cycle is the one
    thing refcounting cannot free. One of them per storage group was enough to keep a whole tape
    alive until the cyclic collector ran, and that collector counts Python objects, not the
    device bytes they hold: BindCraft 2's design loop at n=307 kept 4.746 GB per step and was
    refused a buffer in step 4 (`perf/bcx_dram/memtrace_seed200t1.json`), and a `gc.collect()`
    after step 2 released 9.492 GB (`perf/bcx_dram/holder_probe.json`).

    Weak is also exactly the right strength. A member can only matter to a group decision while
    something can still read its value, and whatever can -- a child node's `parents`, its own
    node's closure -- already holds it strongly. A member nothing holds is gone, and so is every
    reader of it.
    """
    group = a.shares if a.shares is not None else [weakref.ref(a)]
    have = _members(group)
    for t in _members(b.shares) if b.shares is not None else [b]:
        if not any(t is m for m in have):
            group.append(weakref.ref(t))
            have.append(t)
    for t in have:
        t.shares = group


def _members(group) -> list:
    """The live tensors of a storage group."""
    return [t for t in (r() for r in group) if t is not None]


def _flat2d(t):
    """Collapse every leading dim, leaving (prod(leading), last), DRAM-interleaved.

    The reshape is shape bookkeeping. The move is not, and it is the difference between a
    gradient and a direction.

    Every caller here is setting up a reduction over EVERY token at once -- K is 4096 on a
    64x64 pair block and 262144 at 512 aa -- and a long-K matmul only keeps fp32
    accumulation across its K blocks when it can use L1 accumulation for the partials. An
    L1-INTERLEAVED operand has already spent that L1, so ttnn plans the same matmul without
    it and the reduction falls back to bf16. Measured on a p300c, the shipped Transition's
    dW3, identical operands, identical kernel config, the only difference being where the
    left operand lived: 6.65e-02 relative L2 from L1, 5.41e-04 from DRAM. 123x, and the
    Wormhole and Blackhole kernel configs read the same to four digits, so this is
    placement and not fidelity.

    The forward never sees it: its matmuls reduce over a channel, 128 or 256, which fits in
    one K block. It is the backward that contracts over the token axis, and the tuned
    forward is exactly the code that leaves its activations in L1.
    """
    s = [int(d) for d in t.shape]
    if t.memory_config().buffer_type == ttnn.BufferType.L1:
        t = ttnn.to_memory_config(t, ttnn.DRAM_MEMORY_CONFIG)
    return ttnn.reshape(t, [int(math.prod(s[:-1])), s[-1]])


def _pair_mm_or(v, w, transpose_b, fallback, cfg):
    """A 2-D-weight dX on `pair_mm` when its lever serves the shape, else `fallback()`."""
    from tt_bio import pair_mm
    out = pair_mm.matmul(v, w, compute_kernel_config=cfg, transpose_b=transpose_b)
    return fallback() if out is None else out


def _via2d(x, fn, kw=None):
    """``fn(x)`` on ``x`` with its leading dims collapsed, when collapsing them is a view.

    ``fn`` is a matmul against a 2-D weight. At a rank-3 left operand ttnn picks a program
    that runs several times slower than the same product on the (prod(leading), K) view:
    [256,256,128] @ [128,128] takes 792 us, the view 118 us, HiFi4 on a p300c at 1350 MHz
    (``perf/bcx_mm2d/probe_n256.json``). Collapsing moves no data when the second-last dim fills
    whole tiles, because the tiles already sit in that order; any other reshape here is a
    relayout (the heads split [N,N,128] -> [N,N,4,32] costs 2 ms), so such a shape, a
    sharded operand, or a caller-chosen program config is left as it came. The exception is
    one row per leading index, AF2's MSA track at depth 1: the relayout is small and the
    rank-3 plan is not. dX = dY @ W^T at [256,1,768] took 2280 us as issued and 104 us folded,
    and the forward linear 130 against 125 us (`perf/bcx_bwdplan/mm_probe.json`,
    `lin_fwd_probe.json`).

    Same operands, same reduction, not always the same bits: where they differ, the 2-D
    result is the one closer to float64.
    """
    s = [int(d) for d in x.shape]
    mc = (kw or {}).get("memory_config")
    if (len(s) <= 2 or (s[-2] % ttnn.TILE_SIZE and s[-2] != 1) or x.layout != ttnn.TILE_LAYOUT
            or x.is_sharded() or (kw or {}).get("program_config") is not None
            or (mc is not None and mc.is_sharded())):
        return fn(x)
    y = fn(ttnn.reshape(x, [int(math.prod(s[:-1])), s[-1]]))
    return ttnn.reshape(y, s[:-1] + [int(y.shape[-1])])


# `triangle_attention` issues its six batched products with `bmm_program_config`. A module
# attribute rather than an argument because it exists for one reason, the same-process A/B that
# prices it (`perf/bcx_triatt/block_ab.py`); nothing else sets it.
TRIATT_BMM_CONFIG = True

# The largest output matrix `bmm_program_config` gives one core-block: 64 tiles is 256 KB of fp32
# partials. `triangle_attention` narrows its query chunk so a score block fits under it.
BMM_OUT_TILES = 64

# {(Mt, Nt, Kt, transpose_a): (asked, given)} for every product whose first-choice K block did
# not fit a core and was narrowed; `given` is None where no block fit and ttnn planned it. Empty
# on every axis the narrowing does not touch, which is how a sweep proves that it did not.
BMM_NARROWED: dict = {}

_L1_BANK: dict = {}


def _l1_bank(device) -> int:
    """Bytes of L1 per core a program's circular buffers may grow into, read off the device.

    The allocator's bank size, which is exactly the room above the CB base: on a p300c the
    refusals quote a 1572864 B ceiling and the CBs start 111104 B up it, and the bank reads
    1461760 (`perf/bcw_bmm/out/cb_probe2_bh.json`). Wormhole's bank is 1395424. One read per
    device, because the view drains the pipeline.
    """
    k = id(device)
    if k not in _L1_BANK:
        _L1_BANK[k] = int(ttnn.get_memory_view(device, ttnn.BufferType.L1).total_bytes_per_bank)
    return _L1_BANK[k]


def bmm_cb_bytes(Mt, Nt, in0_block_w, transpose_a, a_tile, b_tile, out_tile, fp32_partials):
    """Circular-buffer bytes one core of the batched reuse matmul asks for.

    Fitted on Blackhole to the byte, fifteen refusals over both transposes, M, N, the block
    width, both operand dtypes, the output dtype and the compute config
    (`perf/bcw_bmm/out/cb_probe2_bh.json`). in0 and in1 are double-buffered, and in0 twice
    over with `transpose_a`, which transposes each block in L1. `fp32_partials` is the float32
    intermediate a packer- or dest-accumulating config adds beside a narrower output.
    """
    return ((4 if transpose_a else 2) * Mt * in0_block_w * a_tile + 2 * in0_block_w * Nt * b_tile
            + Mt * Nt * (out_tile + (4096 if fp32_partials else 0)))


def bmm_program_config(a, b, transpose_a: bool = False, transpose_b: bool = False, *,
                       dtype=None, compute_kernel_config=None, in0_block_w: int | None = None):
    """An explicit program config for a batched ``op(a) @ op(b)``, or None to keep ttnn's plan.

    With a real batch axis on both operands and no program config, ttnn's matmul plans a
    kernel that runs the triangle-attention products at 0.66-1.9 TFLOP/s on Blackhole: PV
    ``[128,4,128,256] x [128,4,256,32]`` took 1627 us, 6.5 % of its byte roof. The batched
    reuse kernel with one whole output matrix per core-block does the same product in 104 us
    at the same HiFi4 config and sits closer to float64 (`perf/bcx_triatt/mm_probe2_n256.json`).
    A rank-3 view changes nothing and the default fidelity only 3 %, so the plan was the gap.

    The backward needs it more than the forward. A product with a transposed operand gets a
    1-to-8-core plan from ttnn, so the VJPs of batched products ran there: at n=256, AF2's
    column attention over a one-sequence MSA (2048 single-tile products, 6.5 ms on one core,
    63 us here) and the triangle-attention blocks (1132 us against 122 us), 2.29 s of an AF2
    gradient step (`perf/bcx_realcensus`, `perf/bcx_bwdplan/mm_probe.json`). So `bmm`, which
    every batched VJP product goes through, asks here first.

    ONLY the region that was proven. The reuse kernel requires ``per_core_N == N``, and with
    ``per_core_M < M`` -- one batch's output split over two M blocks -- it returned a few
    non-finite elements and non-reproducible finite ones inside a real block, from finite
    inputs, while never failing in isolation (`perf/bcx_triatt/HAZARD.md`). So the whole
    output matrix goes to one block, at most `BMM_OUT_TILES`; the contraction runs in K blocks
    of up to 8 tiles. Both operands batched with equal batch dims. A dim that is not a whole
    number of tiles counts its padded tiles, which is what every plan computes on; at depth 1
    the column-attention products are bit-identical to ttnn's own plan. Anything else returns
    None and ttnn plans it as before.

    The K block is the widest divisor of Kt up to 8 whose circular buffers fit the core
    (`bmm_cb_bytes` against `_l1_bank`). Without that check BindCraft 2 crashed at the 768 axis:
    the dA product of its attention VJP, ``[2,8,768,768]^T @ [2,8,768,32]``, took 8 of Kt = 24
    and asked for 1753088 B. 800 and 864 escaped only because Kt = 25 and 27 divide by 5 and 3.
    The block width only splits the contraction, so a narrower one is the same product in more
    steps; a plan that fits today is never changed. If no width fits, None. A caller-named
    `in0_block_w` replaces the priced pick: it is how `bmm`'s refusal retry walks narrower where
    the pricing, fitted on Blackhole, still let a refusal through.
    """
    sa = [int(d) for d in a.shape]
    sb = [int(d) for d in b.shape]
    if len(sa) < 3 or len(sa) != len(sb) or sa[:-2] != sb[:-2]:
        return None
    M, K = (sa[-1], sa[-2]) if transpose_a else (sa[-2], sa[-1])
    N = sb[-2] if transpose_b else sb[-1]
    Mt, Nt, Kt = (-(-d // ttnn.TILE_SIZE) for d in (M, N, K))
    if Mt * Nt > BMM_OUT_TILES:
        return None

    def largest_divisor(n, cap):
        return max(d for d in range(1, min(n, cap) + 1) if n % d == 0)

    # `_matmul` runs a mixed-dtype transpose_a product in fp32, and the output takes a's dtype
    # unless the caller names one.
    da, db = (ttnn.float32,) * 2 if transpose_a and a.dtype != b.dtype else (a.dtype, b.dtype)
    do = da if dtype is None else dtype
    try:
        tiles = [_mm_generic.tile_bytes(d) for d in (da, db, do)]
    except ValueError:
        return None
    cfg = compute_kernel_config
    partials = do != ttnn.float32 and bool(getattr(cfg, "packer_l1_acc", False)
                                           or getattr(cfg, "fp32_dest_acc_en", False))
    if in0_block_w is not None:
        w = in0_block_w
    else:
        budget = _l1_bank(a.device())
        asked = largest_divisor(Kt, 8)
        w = next((d for d in range(asked, 0, -1) if Kt % d == 0
                  and bmm_cb_bytes(Mt, Nt, d, transpose_a, *tiles, partials) <= budget), None)
        if w != asked:
            BMM_NARROWED[(Mt, Nt, Kt, bool(transpose_a))] = (asked, w)
        if w is None:
            return None
    # The dest register holds 4 fp32 tiles, which bounds the subblock.
    sw = largest_divisor(Nt, 4)
    sh = largest_divisor(Mt, max(1, 4 // sw))
    return ttnn.MatmulMultiCoreReuseProgramConfig(
        compute_with_storage_grid_size=a.device().compute_with_storage_grid_size(),
        in0_block_w=w, out_subblock_h=sh, out_subblock_w=sw,
        per_core_M=Mt, per_core_N=Nt)


def bmm_k_blocks(a, b, transpose_a: bool = False, transpose_b: bool = False):
    """The `in0_block_w` values to try, widest first: the divisors of Kt that are at most 8.

    `in0_block_w` is how many tiles of the contraction a core holds at once, so the in0 circular
    buffer is `per_core_M * in0_block_w` tiles and the widest choice is the one that blows L1
    first. Narrowing it blocks the SAME contraction into more passes over K rather than changing
    what is contracted.
    """
    K = (a.shape[-2] if transpose_a else a.shape[-1])
    Kt = -(-int(K) // ttnn.TILE_SIZE)
    return [d for d in range(min(Kt, 8), 0, -1) if Kt % d == 0]

def bmm(a, b, transpose_a: bool = False, transpose_b: bool = False, **kw):
    """``ttnn.matmul`` under `bmm_program_config`'s plan where it has one, ttnn's otherwise.

    A call ttnn's own planner cannot fit in L1 is retried in ROW BLOCKS (`_bmm_blocked`). The
    retry is on the REFUSAL and not on the shape: every call that fits today takes the plan it
    took yesterday, to the bit.
    """
    plan = bmm_program_config(a, b, transpose_a, transpose_b, **_bmm_plan_kw(kw))
    try:
        return _matmul(a, b, transpose_a=transpose_a, transpose_b=transpose_b,
                       program_config=plan, **kw)
    except Exception as exc:                                             # noqa: BLE001
        from .tenstorrent import report_l1_refusal
        if not report_l1_refusal("autograd.bmm", exc):
            raise
        if plan is not None:
            narrower = _bmm_narrower_k(a, b, transpose_a, transpose_b, kw)
            if narrower is not None:
                return narrower
        blocked = _bmm_blocked(a, b, transpose_a, transpose_b, kw)
        if blocked is None:
            raise
        return blocked


def _bmm_plan_kw(kw):
    """The output dtype and compute config of a `bmm` call, which `bmm_program_config` prices."""
    return {"dtype": kw.get("dtype"), "compute_kernel_config": kw.get("compute_kernel_config")}


def _bmm_narrower_k(a, b, transpose_a: bool, transpose_b: bool, kw):
    """The same product under a narrower `in0_block_w`, or None if no width fits.

    What refuses at 768 tokens is not a wide output but a deep contraction under a tall one:
    `a[2, 8, 768, 768]` against `b[2, 8, 768, 32]` transposed gives `per_core_M = 24` output
    tiles against `per_core_N = 1`, and `in0_block_w = 8` makes the in0 circular buffer
    24 x 8 tiles. That is 1.86 MB against the 1.5 MB a Tensix has, and the round dies at compile
    inside the Evoformer backward with 7 GB of DRAM free (measured on one Wormhole Galaxy chip,
    2026-10-01, `perf/bcw_slowmode/`). Row blocking cannot help: the output is 32 wide, so it is
    already inside one block, which is what `_bmm_blocked` says when it declines.

    Narrowing `in0_block_w` passes over K more times with less held at once. It is the same
    contraction in the same order over the same operands, blocked differently, so the result
    moves only by fp32 accumulation grouping -- and only for a call that otherwise does not run
    at all. Tried widest first, so a card that can afford more holds more.
    """
    widths = bmm_k_blocks(a, b, transpose_a, transpose_b)
    for w in widths[1:]:
        try:
            out = _matmul(a, b, transpose_a=transpose_a, transpose_b=transpose_b,
                          program_config=bmm_program_config(a, b, transpose_a, transpose_b,
                                                            in0_block_w=w, **_bmm_plan_kw(kw)),
                          **kw)
        except Exception as exc:                                         # noqa: BLE001
            from .tenstorrent import report_l1_refusal
            if not report_l1_refusal(f"autograd.bmm in0_block_w={w}", exc):
                raise
            continue
        return out
    return None


def _bmm_blocked(a, b, transpose_a: bool, transpose_b: bool, kw):
    """A batched product whose output is too large for one core-block, done a row block at a
    time, or None when this is not that case.

    `bmm_program_config` gives the whole output matrix of a batch element to one core-block.
    At 768 tokens a `[128, 768, 768]` triangle-multiplication VJP is laid out on ONE COLUMN of
    nine cores, whichever planner lays it, and the circular buffers grow to 1.86 MB against the
    1.5 MB a Tensix has: the gradient round dies at compile, inside the backward, with the card
    7 GB free. Measured on one chip of a Wormhole Galaxy on 2026-10-01 (`perf/bcw_slowmode/`,
    hHSA + 150 at 768 in the offload memory mode), and it is a program-config limit rather than
    a memory one. The first cut of this retry fired only where `bmm_program_config` had
    DECLINED, on the reading that ttnn's own planner was the one at fault; the refusal came
    back unchanged, because at this size the plan exists and is itself too wide. So the retry
    now fires on the refusal alone, whoever planned the call.

    A row block of `A` times `B` IS the matching row block of `AB`: the rows of a product do
    not interact. So the output is cut into blocks of at most `BMM_OUT_TILES` tiles, each one a
    complete product under the plan the kernel was proven on -- `per_core_M` is the block's own
    whole M, never a split of it, which is the hazard `bmm_program_config` documents -- and
    `in0_block_w` is the same for every block, so the contraction runs in the same order and
    the result is bit-identical to what one call under that plan would give.
    """
    sa, sb = [int(d) for d in a.shape], [int(d) for d in b.shape]

    def decline(why):
        """Say why the row-block retry does not apply, because the caller then RE-RAISES.

        Without this the refusal that follows is indistinguishable from the retry never having
        been reached, which is exactly the hour this cost once already.
        """
        import os
        line = (f"[tt-bio] autograd.bmm: row blocking does not apply ({why}): a{sa} b{sb} "
                f"transpose_a={transpose_a} transpose_b={transpose_b}\n")
        try:
            os.write(2, line.encode("utf-8", "replace"))
        except OSError:
            pass
        return None

    if len(sa) < 3 or len(sa) != len(sb) or sa[:-2] != sb[:-2]:
        return decline("not a batched product with matching batch dims")
    ax = len(sa) - (1 if transpose_a else 2)                 # a's axis that carries the output's M
    M = sa[ax]
    if M % ttnn.TILE_SIZE:
        return decline(f"M={M} is not a whole number of tiles")
    N = sb[-2] if transpose_b else sb[-1]
    Nt = -(-N // ttnn.TILE_SIZE)
    rows = max(1, BMM_OUT_TILES // max(1, Nt)) * ttnn.TILE_SIZE
    if Nt > BMM_OUT_TILES or M <= rows:
        return decline(f"M={M} is already within one block of {rows} rows (N={N})")
    parts = []
    for start in range(0, M, rows):
        end = min(start + rows, M)
        starts = [0] * len(sa)
        ends = list(sa)
        starts[ax], ends[ax] = start, end
        block = ttnn.slice(a, starts, ends)
        parts.append(_matmul(block, b, transpose_a=transpose_a, transpose_b=transpose_b,
                             program_config=bmm_program_config(block, b, transpose_a,
                                                               transpose_b, **_bmm_plan_kw(kw)),
                             **kw))
        ttnn.deallocate(block)
    out = ttnn.concat(parts, dim=len(sa) - 2)
    for p in parts:
        ttnn.deallocate(p)
    return out


def _dims(shape) -> list:
    """`[int(d) for d in shape]`, by index: a ttnn.Shape's iterator costs ~0.5 us a dim and
    `shape[i]` ~40 ns, which matters on paths that run once per taped call."""
    return [int(shape[i]) for i in range(len(shape))]


def _reduce_to(g, shape):
    """A broadcast operand's gradient: the output's, summed over the axes it was spread along.

    `_sum_leading` is the bias case -- reduce everything down to a trailing shape -- and it is
    wrong here, because the operands of a broadcasting binary op differ in a LEADING axis that
    is 1 on one side, not in rank alone. `ttnn` broadcasts an operand of shape (497, 128)
    against (1, 497, 128) happily and the backward then hands back a gradient of the output's
    shape, which `add_grad` refuses, correctly: a gradient that does not have its value's shape
    has been summed over the wrong thing or not at all. Same volume is a reshape; a genuinely
    stretched axis is a sum, at fp32 fidelity for `_sum_leading`'s reason.
    """
    if g.shape == shape:
        # The common case, without the two list copies below (~4 us for a 4D ttnn.Shape).
        # Only a True is trusted; anything else is decided by the ints as before.
        return g
    gs = _dims(g.shape)
    ws = [int(d) for d in shape]
    if gs == ws:
        return g
    gv, wv = 1, 1
    for d in gs:
        gv *= d
    for d in ws:
        wv *= d
    if gv == wv:
        return ttnn.reshape(g, ws)
    pad = [1] * (len(gs) - len(ws)) + ws
    out = _unshard(g)
    for ax in range(len(gs)):
        if pad[ax] == 1 and gs[ax] != 1:
            if TREE_REDUCE and out.dtype == ttnn.float32 and ax < len(gs) - 2:
                prev, out = out, _tree_sum(out, ax)
                if prev is not g:
                    ttnn.deallocate(prev)
            else:
                out = ttnn.sum(out, dim=ax, keepdim=True, compute_kernel_config=precise_config())
    return ttnn.reshape(out, ws)


def _unshard(t):
    """A gradient on its way into a reduction, interleaved.

    A backward inherits its operands' placement from the forward: `grad_b(g, ea, eb)` is an
    elementwise verb, so if the forward left the activation L1-SHARDED the gradient is sharded
    too, on the forward's shard plan. A reduction is not planned against that. At crop 384 the
    taped backward died in exactly this call with `num_shards <= num_cores` -- "number of shards
    along height 512 must not exceed number of cores 64" -- which is a spec the device refuses
    outright rather than a plan it retries narrower.

    The move is placement only, so the reduction is bit-identical, and it is taken here rather
    than at every producer because this is the one consumer that cares. Interleaved DRAM and not
    interleaved L1: the operands that reach this path are whole pair-track gradients, and the
    reason they were in L1 was the forward's, which is spent.
    """
    try:
        if not t.memory_config().is_sharded():
            return t
    except Exception:                                        # noqa: BLE001
        return t
    return ttnn.to_memory_config(t, ttnn.DRAM_MEMORY_CONFIG)
# Whether `_reduce_to` sums an fp32 gradient over a leading axis with `_tree_sum` instead of
# `ttnn.sum`. A module switch so an A/B can flip it in one process.
TREE_REDUCE = True


def _tree_sum(t, ax):
    """``t`` summed over axis ``ax`` (kept as size 1), as a pairwise tree of fp32 adds.

    `ttnn.sum` on an fp32 tensor is 8.3e-4 relative L2 from float64 at `precise_config()` on the
    0.68 wheel, at 13 rows and at 256 alike, so the loss is in how it reads its input and not in
    how it accumulates. An fp32 `ttnn.add` keeps its operands, and a halving tree of them lands
    7.7e-8 from float64, under torch fp32's own 1.1e-7. For an axis outside the last two,
    `ttnn.sum` also permutes the whole tensor to bring the axis into the tile, at 85 GB/s on the
    triangle-attention bias gradient [256, 4, 256, 256]; the tree only slices it
    (`perf/bcx_reduce`).
    """
    shape = [int(d) for d in t.shape]

    def rows(x, lo, hi):
        s, e = [0] * len(shape), [int(d) for d in x.shape]
        s[ax], e[ax] = lo, hi
        return ttnn.slice(x, s, e)

    cur, left, r = t, [], shape[ax]
    while r > 1:
        h = r // 2
        if r % 2:
            left.append(rows(cur, 2 * h, r))
        a, b = rows(cur, 0, h), rows(cur, h, 2 * h)
        nxt = ttnn.add_(a, b)
        ttnn.deallocate(b)
        if cur is not t:
            ttnn.deallocate(cur)
        cur, r = nxt, h
    for x in left:
        cur = ttnn.add_(cur, x)
        ttnn.deallocate(x)
    return cur


def _sum_leading(t, out_shape):
    """Sum ``t`` down to ``out_shape``, which must be its trailing dims. Used for bias/gamma.

    fp32 destination accumulation, not for style: this reduces every leading coordinate at
    once -- 4096 of them on a 64x64 pair block, 262144 at 512 aa -- and bf16 carries 8
    mantissa bits, so the default fidelity returns a direction rather than a gradient.
    Measured at the 64x64 block before the kernel config was passed: cosine 0.379 against
    the float64 reference, 0.999995 after. That config still leaves `ttnn.sum` 7.7e-4 from
    float64 on an fp32 input (`_tree_sum`), so fp32 goes through the add tree.
    """
    flat = _flat2d(t)
    n, c = (int(d) for d in flat.shape)
    T = ttnn.TILE_SIZE
    if TREE_REDUCE and flat.dtype == ttnn.float32 and n % T == 0:
        # Whole tiles of rows are a view as [n/32, 32, c], so `_tree_sum` takes them down to one
        # tile's 32 rows. Those sit inside the tile, where only `ttnn.sum` reaches them, so they
        # are laid out one row per tile first: 32 x c elements, a few kB.
        rows = _tree_sum(ttnn.reshape(flat, [n // T, T, c]), 0) if n > T else flat
        rm = ttnn.to_layout(rows, ttnn.ROW_MAJOR_LAYOUT)
        tiles = ttnn.to_layout(ttnn.reshape(rm, [T, 1, c]), ttnn.TILE_LAYOUT)
        summed = _tree_sum(tiles, 0)
        for x in (rows, rm, tiles):
            if x is not flat:
                ttnn.deallocate(x)
    else:
        summed = ttnn.sum(flat, dim=0, keepdim=True, compute_kernel_config=precise_config())
    return ttnn.reshape(summed, [int(d) for d in out_shape])


def matmul(a: Tensor, b: Tensor, *, transpose_a: bool = False, transpose_b: bool = False,
           config=None) -> Tensor:
    """``op(a) @ op(b)`` where op is transpose-or-not on the last two dims.

    The four backward cases are tt-train's, worked out in ttnn_fixed/matmuls.cpp:54-79. The
    part worth restating is why a transposed operand does not simply get a transposed
    gradient: if the forward used A^T, then dA_effective is the gradient of the transposed
    operand and dA is its transpose, so the product has to be re-associated rather than
    post-transposed. Writing `ttnn.transpose` on the result instead is the classic way to
    get a silently wrong gradient on a non-square operand, and a shape check will not catch
    it when both dims are equal, which for a pair tensor they always are.
    """
    cfg = config or precise_config()
    # Against a 2-D weight the leading dims are a batch of rows, and `_via2d` runs them as one.
    rows = _via2d if not transpose_a and len(b.value.shape) == 2 else (lambda t, fn: fn(t))
    out_v = rows(a.value, lambda v: _matmul(v, b.value, transpose_a=transpose_a,
                                            transpose_b=transpose_b,
                                            compute_kernel_config=cfg))
    ashape, bshape = a.value.shape, b.value.shape

    def make():
        def bw(g):
            # ttnn broadcasts a rank-3+ operand whose leading axis is 1 against a taller one, so
            # the forward accepts (S, N, K) @ (1, K, M) and the backward hands that operand back a
            # gradient of the OUTPUT's shape. Summing it over the stretched axis is the same
            # correction `_binary` already applies, and `_reduce_to` returns `g` untouched when the
            # shapes already agree -- which is every call that was passing before, including the
            # `_via2d` path against a 2-D weight, where the flattening does the reduction inside
            # the matmul. Without it a sample axis on a taped matmul raises in `add_grad` rather
            # than training, which is how it was found (of3t-p10batch, card 2, 2026-09-26).
            if a.requires_grad:
                if not transpose_a:
                    # dA = g @ op(b)^T
                    a.add_grad(_reduce_to(rows(g, lambda v: bmm(v, b.value, False, not transpose_b,
                                                                compute_kernel_config=cfg)),
                                          ashape))
                else:
                    # A entered as A^T, so dA = (dA_eff)^T = op(b) @ g^T
                    a.add_grad(_reduce_to(bmm(b.value, g, transpose_b, True,
                                              compute_kernel_config=cfg), ashape))
            if b.requires_grad:
                if not transpose_b:
                    # dB = op(a)^T @ g
                    b.add_grad(_reduce_to(bmm(a.value, g, not transpose_a,
                                              compute_kernel_config=cfg), bshape))
                else:
                    # B entered as B^T, so dB = (dB_eff)^T = g^T @ op(a)
                    b.add_grad(_reduce_to(bmm(g, a.value, True, transpose_a,
                                              compute_kernel_config=cfg), bshape))
        return bw

    return _tape(out_v, [a, b], make, reads=_cross_reads(a, b))


def linear(x: Tensor, w: Tensor, b: Optional[Tensor] = None, *, dtype=None, core_grid=None,
           config=None, backward_config=None, **kw) -> Tensor:
    """``x @ w (+ b)``, with ``w`` in ttnn's (in, out) layout -- tt-bio's own convention.

    Backward is two matmuls rather than ``ttnn.moreh_linear_backward``. tt-train ships both
    side by side in ops/linear_op.cpp (``ttnn_linear_backward`` :21,
    ``moreh_linear_backward`` :52) and wires only the two-matmul one into ``linear_op``
    (:115), which is the answer to why they kept both: moreh is the reference, the explicit
    pair is what runs. Two reasons it is also right for us. The moreh family is
    interleaved-only at our pin, so routing a gradient through it forfeits the L1-residency
    levers tt-bio ships; and ``moreh_linear_backward`` is itself just these two matmuls plus
    a reduction, so there is no kernel to gain. Our linears are thin-K, where a matmul the
    production path already tunes beats a generic one.

    ``dtype`` and ``core_grid`` exist here because the shipped call site passes them and
    this op used to drop them: the training forward is meant to be the served forward, and
    an output dtype or a core grid silently changed is a deviation nobody measured.
    ``backward_config`` separates the two halves, because they want opposite things. The
    forward wants whatever the production site measured; the backward accumulates over the
    reduction axis and again over fan-in, so it wants ``precise_config()``. Default is the
    forward's, which is what every caller predating the split already got.

    No ``activation``. ``ttnn.linear`` fuses one into the packer and the result is not
    generally invertible -- silu's is not -- so a fused activation here would be a silently
    wrong gradient. The attach point composes a taped activation on the output instead.
    """
    cfg = config or precise_config()
    bwcfg = backward_config or cfg
    out_v = _via2d(x.value, lambda v: ttnn.linear(v, w.value,
                                                  bias=(b.value if b is not None else None),
                                                  dtype=dtype, core_grid=core_grid,
                                                  compute_kernel_config=cfg, **kw), kw)
    parents = [p for p in (x, w, b) if p is not None]

    def make():
        def bw(g):
            if x.requires_grad:
                x.add_grad(_via2d(g, lambda v: _matmul(v, w.value, transpose_b=True,
                                                      compute_kernel_config=bwcfg)))
            if w.requires_grad:
                # dW = X^T @ dY, summed over every leading dim, so flatten both first:
                # a batched matmul would give one dW per batch instead of their sum.
                w.add_grad(_matmul(_flat2d(x.value), _flat2d(g),
                                   transpose_a=True, compute_kernel_config=bwcfg))
            if b is not None and b.requires_grad:
                b.add_grad(_sum_leading(g, b.value.shape))
        return bw

    return _tape(out_v, parents, make)


# Whether `_row_mean` divides the row sum by K or calls `ttnn.mean`. A module switch so a step
# A/B can flip it between reps of ONE warm process, the way `SOFTMAX_BW_RENORM` already is: the
# 384-token step's own rep-to-rep spread is 2.551 s
# (`perf/of3t_stepfloor/out/step_fp32bw_48_384.json`), and four extra scalar divides per
# layer-norm backward do not live at that resolution across two separate runs. Default on.
# `ttnn.mean` is the measured-wrong path; the switch exists to PRICE the fix, not to offer it.
ROW_MEAN_DIVIDE = True
ROW_MEAN_STATS = {"divide": 0, "mean": 0}


def _row_mean(v, cfg, K: int):
    """Mean over the last axis, as ``sum`` then an explicit multiply by ``1/K``.

    Not a style choice. ``ttnn.mean`` carries its own ``1/K`` and returns it short at a K that
    is not a power of two: at K=384 the four means of the closure below all inherit the same
    signed constant and ``dx`` reads 2.089e-03 relative L2 against a finite-difference-validated
    float64 reference, a +2.08e-03 systematic at 11327 sigma over 32 draws, where the identical
    closure at K=128 reads 1.481e-04 and is unbiased. 1/128 is a power of two and exact in any
    float; 1/384 is not. Summing and scaling by the host's own fp32 constant takes K=384 to
    1.399e-04 and leaves K=128 bit-identical, which is the control the explanation predicts
    (``perf/of3t_p10grad/PEROP.md``, SUMSCALE arms).

    ``c_s = 384`` and ``c_z = 128``, so this is the single track's bias and not the pair
    track's, and it is a function of the channel width rather than of the crop.
    """
    if not ROW_MEAN_DIVIDE:
        ROW_MEAN_STATS["mean"] += 1
        return ttnn.mean(v, dim=-1, keepdim=True, compute_kernel_config=cfg)
    ROW_MEAN_STATS["divide"] += 1
    return ttnn.divide(ttnn.sum(v, dim=-1, keepdim=True, compute_kernel_config=cfg), float(K))


def _layer_norm_bw(x, gamma, beta, eps, bwcfg, center=True):
    """The layer-norm backward, shared by ``layer_norm``, ``_taped_layer_norm`` and, with
    ``center=False``, ``_taped_rms_norm``.

    RMSNorm is this op with the mean pinned at zero, ``norm = x * rsqrt(mean(x^2) + eps)``, and
    its ``dx`` is the same expression without ``- mean(dnorm)``, the derivative of the centring.
    One closure for both, so a fix to one is a fix to both.

    One definition, because the two sites carried verbatim copies of it and a fix to either
    one was a fix to neither.

    mean and rstd are recomputed here rather than retained from the forward: two reductions,
    and it is what buys the production ``ttnn.layer_norm`` forward, which returns neither. The
    two-pass ``E[(x - mean)^2]`` rather than tt-train's ``E[x^2] - E[x]^2``
    (``ops/layernorm_op.cpp:144``), which cancels catastrophically once the mean dominates the
    spread. ``x.value`` is read inside ``bw`` and not captured: ``Tensor.free`` may have evicted
    it to DRAM since the forward, and a captured handle would be freed storage.
    """
    def bw(g):
        xv = x.value
        # dx alone, which is all a sequence gradient asks for, in one kernel when it serves
        # (`tt_bio.lnbw`). A weight gradient needs the composed path's `norm`.
        if center and x.requires_grad and not any(p is not None and p.requires_grad
                                                  for p in (gamma, beta)):
            from . import lnbw
            gv = None if gamma is None else gamma.value
            if lnbw.eligible(xv, g, gv):
                x.add_grad(lnbw.layer_norm_bw(xv, g, gv, eps))
                return
        K = int(xv.shape[-1])
        # ONE dtype through the closure. A fan-in accumulator is fp32 and the activation it
        # meets is bf16, and `ttnn.multiply(bf16, fp32)` is not a function of its inputs: it
        # repeats bit-exact with the operands swapped and differs run to run as written, on
        # row, vector and full operands (`perf/of3t_p10trainfix/bcast_det.py`). Here that was
        # `norm * mean(dnorm * norm)`, rounded to bf16 inside a three-term cancellation, and
        # two runs handed the same g, x and gamma got dx 7-40 % apart in norm from it.
        dt = ttnn.float32 if ttnn.float32 in (xv.dtype, g.dtype) else xv.dtype
        xv, g = (v if v.dtype == dt else ttnn.typecast(v, dt) for v in (xv, g))
        gv = None if gamma is None else gamma.value
        if gv is not None and gv.dtype != dt:
            gv = ttnn.typecast(gv, dt)
        centered = ttnn.subtract(xv, _row_mean(xv, bwcfg, K)) if center else xv
        var = _row_mean(ttnn.multiply(centered, centered), bwcfg, K)
        rstd = ttnn.rsqrt(ttnn.add(var, eps))
        norm = ttnn.multiply(centered, rstd)
        if gamma is not None and gamma.requires_grad:
            gamma.add_grad(_sum_leading(ttnn.multiply(g, norm), gamma.value.shape))
        if beta is not None and beta.requires_grad:
            beta.add_grad(_sum_leading(g, beta.value.shape))
        if x.requires_grad:
            dnorm = ttnn.multiply(g, gv) if gv is not None else g
            # dx = (dnorm - mean(dnorm) - norm * mean(dnorm * norm)) * rstd
            dn_norm_mean = _row_mean(ttnn.multiply(dnorm, norm), bwcfg, K)
            lead = ttnn.subtract(dnorm, _row_mean(dnorm, bwcfg, K)) if center else dnorm
            dx = ttnn.subtract(lead, ttnn.multiply(norm, dn_norm_mean))
            x.add_grad(ttnn.multiply(dx, rstd))
    return bw


def layer_norm(x: Tensor, gamma: Optional[Tensor] = None, beta: Optional[Tensor] = None,
               *, eps: float = 1e-6, config=None, backward_config=None,
               memory_config=None) -> Tensor:
    """Layer norm over the last dim. The forward is ``ttnn.layer_norm``, production's own.

    This op used to be a composite five-op forward, justified by ``ttnn.layer_norm`` returning
    neither mean nor rstd while ``moreh_layer_norm_backward`` needs both and then refuses
    bfloat8_b. That argument rules out MOREH; it does not rule out keeping the production
    forward. The backward already retains ``x`` -- ``dx`` is a function of it -- so mean and
    rstd can be recomputed there for two reductions on a pass that carries one per op anyway.
    The composite forward was an unforced concession and it cost the one thing worth having:
    with the kernel back, a taped layer norm's forward is BIT-IDENTICAL to the served one, not
    merely close. Found by ``train-b2-abb3-port``'s ``abodybuilder3_ops.layer_norm``, which
    reached the same shape from the other end.

    Note what is NOT recoverable and why it does not matter: ``ttnn.layer_norm``'s internal
    mean and rstd are whatever its kernel computed, and the two the backward recomputes here
    are a two-pass ``E[(x - mean)^2]``, so they can differ in the last bits. That is a
    backward-side approximation of the backward's own coefficients, which is the half of the
    op where precision is cheap and where ``precise_config`` already applies. It is not a
    forward difference, and the forward is the half that has to match what we serve.

    ``eps`` defaults to 1e-6 while every tt-bio layer norm on the inference path uses 1e-5, a
    factor of ten. The default stays because the diagnostics under ``perf/hallgrad`` are
    calibrated against it; the attach point passes the site's own epsilon, so nothing
    dispatched through ``tt_bio.ops`` can inherit this default.
    """
    cfg = config or precise_config()
    bwcfg = backward_config or precise_config()
    xv = x.value
    kw = {} if memory_config is None else {"memory_config": memory_config}
    out_v = ttnn.layer_norm(xv, weight=(gamma.value if gamma is not None else None),
                            bias=(beta.value if beta is not None else None),
                            epsilon=eps, compute_kernel_config=cfg, **kw)
    parents = [p for p in (x, gamma, beta) if p is not None]

    def make():
        return _layer_norm_bw(x, gamma, beta, eps, bwcfg)

    return _tape(out_v, parents, make)


def softmax(x: Tensor, dim: int = -1, *, config=None, refine=False) -> Tensor:
    """Softmax over ``dim``. Backward is ``y * (dy - sum(dy * y))``, which needs only y;
    ``refine`` as in `softmax_bw`."""
    cfg = config or precise_config()
    y0 = ttnn.softmax(x.value, dim=dim, compute_kernel_config=cfg)
    box = [y0]

    def make():
        def bw(g):
            y = box[0]                      # through the box: `free` may have moved it
            x.add_grad(softmax_bw(y, g, dim=dim, config=cfg, refine=refine))
        return bw

    out = _tape(y0, [x], make)
    if out.node is not None:
        out.box = box
    return out


def host_f64_softmax_values(v, dim: int = -1):
    """``softmax(v, dim)`` on the host in float64: the float64 result, and it back on the card.

    Both, because the two are not interchangeable. The card holds the rounded copy; the
    backward must read the float64 one, or the Jacobian goes back through a device-precision
    softmax and undoes what the round trip bought.

    Raw ttnn in, raw ttnn out, no tape node. This is the entry point the cost and row-sum
    harnesses use (`perf/of3t_softmax/softmax_cost.py`, `perf/of3t_f64softmax/rowsum_probe.py`),
    which measure the arithmetic and want nothing to do with a tape. A model never arrives here
    directly: it goes through `tenstorrent.site_softmax`, which will not reach this module at
    all without a tape open.
    """
    import torch

    y64 = torch.softmax(ttnn.to_torch(v).double(), dim=dim)
    y = ttnn.from_torch(y64.float(), layout=v.layout, device=v.device(), dtype=v.dtype,
                        memory_config=v.memory_config())
    return y64, y


def host_f64_softmax(x, dim: int = -1):
    """``softmax(x, dim)`` computed on the host in float64, differentiable under the tape.

    The backward is the softmax Jacobian in float64 as well, ``dx = y * (g - (g * y).sum(dim))``,
    applied to the float64 forward output rather than to the rounded copy that went back to the
    card.

    Training only, and it lives here rather than beside the call sites it serves for that
    reason. `tt_bio/tenstorrent.py` is on every model's inference path and must not import the
    tape (`tests/test_training_opt_in.py::test_no_inference_module_imports_training`); the call
    site reaches this function through the hook `install` fills, so an inference fold has no
    route to it. The check below is the same rule stated once more at the entry point itself,
    for a caller that found the function some other way: it costs a host round trip per softmax
    and returns different numbers, so reaching it without a tape is a mistake in either
    direction and says so instead of quietly folding slower.

    `x` may be a raw ttnn tensor or a taped `Tensor`; the only difference is whether a tape node
    is created. A tape is open either way, so a frozen block and a `no_grad` recycle inside a
    training forward still take the same softmax the differentiated cycles take.
    """
    if not installed():
        raise RuntimeError(
            "tt_bio.autograd.host_f64_softmax needs an open tape. It is a training-path lever: "
            "a host round trip per softmax, 166.8x the op, bought for gradient fidelity that "
            "inference has no use for. Open one with `with tt_bio.autograd.tape():`, or call "
            "`ttnn.softmax` / `tt_bio.autograd.host_f64_softmax_values` for the raw arithmetic.")

    from .tenstorrent import HOST_F64_SOFTMAX_STATS as stats

    xt = x if isinstance(x, Tensor) else None
    v = xt.value if xt is not None else x
    y64, y = host_f64_softmax_values(v, dim)
    stats["served"] += 1
    stats["elements"] += int(y64.numel())
    # An exact FORWARD and an exact JACOBIAN are two claims, and `served` is only the first.
    # A raw ttnn tensor gets the float64 softmax and no tape node, so the gradient path through
    # that softmax is whatever the surrounding region already was; a taped one gets the float64
    # Jacobian as well. An arm that serves more calls than another and moves the gradient less
    # is telling you the split moved, and no other counter here can see it.
    stats["served_raw" if xt is None else "served_taped"] += 1
    if xt is None:
        return y

    def make():
        def bw(g):
            g64 = ttnn.to_torch(g).double()
            inner = (g64 * y64).sum(dim=dim, keepdim=True)
            SOFTMAX_BW_RENORM_STATS[
                "applied" if SOFTMAX_BW_RENORM else "declined"] += 1
            if SOFTMAX_BW_RENORM:
                # of3t-apbgrad's repair, honoured here so ONE flag covers both softmax
                # backends. `d_logits = y (g - sum g y)` has vanishing row sums only when the
                # row sums to one, and `ttnn.softmax` returns 0.9769; dividing by the row sum
                # restores the identity. On THIS path the row already sums to one to float64
                # round-off, so the division is arithmetically a no-op -- which is the point.
                # It is the consistency check between two independently derived repairs, and
                # it is why the flag reaches here instead of stopping at the tape verb.
                inner = inner / y64.sum(dim=dim, keepdim=True)
            d = y64 * (g64 - inner)
            xt.add_grad(ttnn.from_torch(d.float(), layout=g.layout, device=g.device(),
                                        dtype=g.dtype, memory_config=g.memory_config()))
        return bw

    return _tape(y, [xt], make)


# --- the exact training ops: softmax and layer norm in float64 on the host ----------------
#
# OFF by default, ON inside `exact_training(True)`. It was the default until the fp32 softmax
# backward (`SOFTMAX_BW_FP32`) brought the device-only trunk inside the same bar at 0.99736x
# (`perf/of3t_p10exact`); it is now the float64 reference for a precision question, not the
# route to accuracy. of3t-stackexact measured the model-frame trunk gradient against
# upstream OpenFold3 0.4.3: with the device ops it reads 1.4511706984958472x the
# 0.15210099830945006 bar, with the exact softmax 1.3037867474869442x, with both exact
# 0.9822570327981535x, and the float64 contrast space improves at the same time, so this is
# fidelity rather than matching upstream's rounding.
#
# TWO reaches per op, because they are two claims and neither implies the other:
#
#   the VERB    `_VERBS[...]` (and `_TAPED["layer_norm"]` for `ops.layer_norm`'s hook), so every
#               op the shipped modules take under a tape is exact in the forward AND in its
#               backward.
#   the RAW op  `ttnn.softmax` / `ttnn.layer_norm` themselves, so `triangle_attention._scores`
#               (which calls the real `ttnn.softmax` from this `_NEVER_SHIM` module), frozen and
#               `no_grad` sites, and a checkpointed block's untaped first pass are exact too,
#               and every recompute sees the activations the taped forward produced.
#
# What is left on the card is `softmax_bw_inner`'s reduction inside `triangle_attention`'s
# backward, computed on an EXACT p.
#
# When on, the GATE is the tape being installed. `install()` opens the scope until its
# `uninstall()`, which is the whole fit in `train/recipes.py` and the discovery forward in
# `walked_weights`; `tape()` and `backward()` open it for their own extent too, for a caller
# that drives a tape without `install()`. Each takes out only what it put in. While open the
# raw half is a process-wide rebinding, which is why it never outlives the block. No inference
# fold enters any of them:
# `tests/test_training_opt_in.py::test_no_inference_module_imports_training` keeps the
# inference modules from importing this one at all. There is no
# environment variable; `exact_training(True)` is the on switch.

EXACT_SOFTMAX_STATS = {"verb": 0, "raw": 0, "raw_elements": 0}
EXACT_LAYER_NORM_STATS = {"verb": 0, "raw": 0, "elements": 0, "bw": 0}


def _exact_softmax_raw(v, dim: int = -1, **kwargs):
    """`ttnn.softmax`'s signature, computed on the host in float64. No tape node.

    `compute_kernel_config` and the rest are accepted and dropped: they configure a device
    kernel that no longer runs. `ttnn.softmax`'s contract is a ttnn tensor, so the rounded copy
    is what comes back and the exactness this buys is in the FORWARD. That is enough for
    `triangle_attention`, which recomputes its probabilities rather than saving them, so its
    Jacobian is taken at this p rather than at a device-precision one.
    """
    EXACT_SOFTMAX_STATS["raw"] += 1
    y64, y = host_f64_softmax_values(v, dim)
    EXACT_SOFTMAX_STATS["raw_elements"] += int(y64.numel())
    return y


def _v_exact_softmax(shipped, args, kwargs):
    """The taped `softmax` verb, served by `host_f64_softmax`: exact forward, exact Jacobian.

    `softmax_in_place` lands here as well and is taped out of place, as the shipped verb is.
    The host path never writes the caller's buffer, so the in-place kernel's one advantage is
    gone and its one hazard with it.
    """
    if not _GRAD_ENABLED:
        # See `_v_exact_layer_norm` for why `no_grad` takes the raw form. Same arithmetic,
        # no wrapper, no tape node.
        ra, rk = _raw(args, kwargs)
        return _exact_softmax_raw(*ra, **rk)
    x = _wrap(args[0])
    dim = kwargs.get("dim", args[1] if len(args) > 1 else -1)
    EXACT_SOFTMAX_STATS["verb"] += 1
    return host_f64_softmax(x, dim)


# The layer norm, built the same way: of3t-stackexact's `exactln.py`, moved here unchanged so
# there is one definition. On bf16 inputs its dx, dgamma and dbeta sit at the bf16 storage
# floor against torch float64 autograd (worst 1.74e-3) where `_taped_layer_norm` reads 3.5e-3
# to 4.7e-3 (`perf/of3t_stackexact/LNCHECK.json`).
_LN_KWARGS = {"weight", "bias", "epsilon", "compute_kernel_config", "memory_config",
              "program_config", "l1_headroom"}


def _ln_affine64(t, d):
    v = ttnn.to_torch(t).double().reshape(-1)
    assert v.numel() == d, f"layer_norm affine of {v.numel()} elements for a last dim of {d}"
    return v


def _ln_args(args, kwargs):
    args = list(args) + [None] * (3 - len(args))
    x, gamma, beta = args[0], args[1], args[2]
    kw = dict(kwargs)
    unknown = set(kw) - _LN_KWARGS
    if unknown:
        raise NotImplementedError(f"exact layer_norm does not know {sorted(unknown)}")
    gamma = kw.pop("weight", None) if kw.get("weight") is not None else gamma
    beta = kw.pop("bias", None) if kw.get("bias") is not None else beta
    return x, gamma, beta, kw.get("epsilon", 1e-5), kw.get("memory_config")


def _ln_forward64(v, gamma, beta, eps, memory_config=None):
    """Raw ttnn in, the float64 result rounded back onto the card out, in the dtype, layout and
    memory config the shipped op would have returned."""
    import torch
    x64 = ttnn.to_torch(v).double()
    d = x64.shape[-1]
    xc = x64 - x64.mean(-1, keepdim=True)
    y64 = xc * torch.rsqrt((xc * xc).mean(-1, keepdim=True) + eps)
    if gamma is not None:
        y64 = y64 * _ln_affine64(gamma, d)
    if beta is not None:
        y64 = y64 + _ln_affine64(beta, d)
    EXACT_LAYER_NORM_STATS["elements"] += int(x64.numel())
    return ttnn.from_torch(y64.float(), layout=v.layout, device=v.device(), dtype=v.dtype,
                           memory_config=memory_config or v.memory_config())


def _exact_layer_norm_raw(*args, **kwargs):
    """`ttnn.layer_norm` in float64 on the host, no tape node. Reaches a frozen or `no_grad`
    site, and a checkpointed block's untaped first pass, so its recompute sees the activations
    the taped forward produced."""
    x, gamma, beta, eps, mc = _ln_args(args, kwargs)
    EXACT_LAYER_NORM_STATS["raw"] += 1
    return _ln_forward64(x, gamma, beta, eps, mc)


def _v_exact_layer_norm(shipped, args, kwargs):
    """The taped `layer_norm`: float64 forward, and dx, dgamma, dbeta in float64 from x re-read
    off the card. mean and rstd are re-derived in the backward, not held on the host."""
    if not _GRAD_ENABLED:
        # Inside `no_grad` there is no tape to pin a wrapper into and no backward to serve it,
        # so the verb form buys nothing and costs the wrapper map: `_wrap` hands back whatever
        # wrapper the handle's id already has, and in a `no_grad` census the shipped decoder
        # frees its activations two lines after each call (`openfold3_diffusion_decoder.py:99`
        # norms `ql_out_pad` and deallocates it immediately). The forward then read a dead
        # handle and the reference arm died on `tensor.is_allocated()` in the discovery pass,
        # before step 0. The raw form is the SAME float64 arithmetic, which matters: the
        # discovery pass has to run the arithmetic the step will run, because the fused
        # softmax tail learns its L1 row caps from whatever it sees first (`install`).
        ra, rk = _raw(args, kwargs)
        return _exact_layer_norm_raw(*ra, **rk)
    x, gamma, beta, eps, mc = _ln_args(args, kwargs)
    x, gamma, beta = _wrap(x), _wrap(gamma), _wrap(beta)
    EXACT_LAYER_NORM_STATS["verb"] += 1
    y = _ln_forward64(x.value, None if gamma is None else gamma.value,
                      None if beta is None else beta.value, eps, mc)
    parents = [t for t in (x, gamma, beta) if t is not None]

    def make():
        def bw(g):
            import torch
            EXACT_LAYER_NORM_STATS["bw"] += 1
            g64 = ttnn.to_torch(g).double()
            x64 = ttnn.to_torch(x.value).double()
            d = x64.shape[-1]
            xc = x64 - x64.mean(-1, keepdim=True)
            rstd = torch.rsqrt((xc * xc).mean(-1, keepdim=True) + eps)
            n = xc * rstd
            lead = tuple(range(g64.dim() - 1))

            def put(t64, like):
                return ttnn.from_torch(t64.float(), layout=like.layout, device=g.device(),
                                       dtype=like.dtype, memory_config=like.memory_config())

            if gamma is not None and gamma.requires_grad:
                gamma.add_grad(put((g64 * n).sum(lead).reshape(ttnn.to_torch(gamma.value).shape),
                                   gamma.value))
            if beta is not None and beta.requires_grad:
                beta.add_grad(put(g64.sum(lead).reshape(ttnn.to_torch(beta.value).shape),
                                  beta.value))
            if x.requires_grad:
                dn = g64 if gamma is None else g64 * _ln_affine64(gamma.value, d)
                dx = rstd * (dn - dn.mean(-1, keepdim=True) - n * (dn * n).mean(-1, keepdim=True))
                x.add_grad(put(dx, g))
        return bw

    return _tape(y, parents, make)


# What each exact op replaces: the taped verbs in `taped_ttnn._VERBS`, the hook's entry in
# `_TAPED`, and the raw `ttnn` callables, each with its exact stand-in.
_EXACT_OPS = {
    "softmax": {"verbs": {"softmax": _v_exact_softmax, "softmax_in_place": _v_exact_softmax},
                "taped": {},
                "raw": {"softmax": _exact_softmax_raw, "softmax_in_place": _exact_softmax_raw}},
    "layer_norm": {"verbs": {"layer_norm": _v_exact_layer_norm},
                   "taped": {"layer_norm": _v_exact_layer_norm},
                   "raw": {"layer_norm": _exact_layer_norm_raw}},
}
# The set a training tape runs exact under `exact_training(True)`, of3t-stackexact's SL arm:
# 0.9822570327981535x the bar where the device ops read 1.4511706984958472x.
EXACT_TRAINING_OPS = ("softmax", "layer_norm")
# op -> (owner, the objects it replaced). Each scope takes out only the ops it put in.
_EXACT_SAVED: dict = {}
_EXACT_TRAINING = [False]   # innermost `exact_training()` block wins


def _install_exact(ops, owner: str) -> tuple:
    """Install each op in `ops` not already installed. Keeps the objects it replaced, so the
    teardown restores those and not a guess at what they were. Returns the ops THIS call
    installed; only those are its to take back out."""
    from . import taped_ttnn as tt
    mine = tuple(op for op in ops if op not in _EXACT_SAVED)
    for op in mine:
        spec = _EXACT_OPS[op]
        saved = {"verbs": {n: tt._VERBS[n] for n in spec["verbs"] if n in tt._VERBS},
                 "taped": {n: _TAPED[n] for n in spec["taped"]},
                 "raw": {n: getattr(ttnn, n) for n in spec["raw"] if hasattr(ttnn, n)}}
        for n in saved["verbs"]:
            tt._VERBS[n] = spec["verbs"][n]
        for n in saved["taped"]:
            _TAPED[n] = spec["taped"][n]
        for n in saved["raw"]:
            setattr(ttnn, n, spec["raw"][n])
        # Both swaps are invisible to a shim that has already resolved these names once. See
        # `taped_ttnn.forget_shim_bindings`: this is why a package install is not the same
        # thing as the same patch applied at process start.
        tt.forget_shim_bindings(*spec["verbs"])
        _EXACT_SAVED[op] = (owner, saved)
    return mine


def _uninstall_exact(ops, owner: Optional[str] = None) -> None:
    """With `owner`, takes an op out only if that owner is the one that put it in."""
    from . import taped_ttnn as tt
    for op in ops:
        if op not in _EXACT_SAVED or (owner is not None and _EXACT_SAVED[op][0] != owner):
            continue
        _, saved = _EXACT_SAVED.pop(op)
        tt._VERBS.update(saved["verbs"])
        _TAPED.update(saved["taped"])
        for n, fn in saved["raw"].items():
            setattr(ttnn, n, fn)
        tt.forget_shim_bindings(*_EXACT_OPS[op]["verbs"])


@contextlib.contextmanager
def without_exact():
    """Take the exact ops OUT for the block, and put back exactly what was there.

    `exact_training(False)` changes what `exact_training_ops()` returns; it does not uninstall
    what an enclosing `install()` already put in, and `install()` reads that function once at
    the start of a run. So a section that has to run on the device`s own arithmetic whatever
    the run asked for needs the ops gone, not the answer changed.

    The detached rollout is that section. Upstream detaches it, so nothing computed there
    reaches a gradient and the instrument has nothing to make exact; leaving it installed also
    fails outright, because `_ln_forward64` downloads its input to host float64 and the shipped
    diffusion decoder has already deallocated that buffer.
    """
    taken = {op: owner for op, (owner, _saved) in _EXACT_SAVED.items()}
    _uninstall_exact(list(taken))
    try:
        yield
    finally:
        for op, owner in taken.items():
            _install_exact((op,), owner)


def exact_softmax_installed() -> bool:
    return "softmax" in _EXACT_SAVED


def exact_layer_norm_installed() -> bool:
    return "layer_norm" in _EXACT_SAVED


@contextlib.contextmanager
def exact(ops=EXACT_TRAINING_OPS, owner: str = "exact"):
    """The named ops exact for the block. Nests: an op an outer block already installed is
    left to it, the way `tape()` leaves the shim to the outermost block."""
    mine = _install_exact(ops, owner)
    try:
        yield
    finally:
        _uninstall_exact(mine)


def exact_softmax():
    """Every softmax exact for the block, and nothing else. What of3t-modelever's arms used."""
    return exact(("softmax",), owner="exact_softmax")


@contextlib.contextmanager
def exact_training(on: bool = True):
    """The float64 instrument's switch. Inside `exact_training(True)`, `install()`, `tape()`
    and `backward()` run softmax and layer norm on the host in float64; otherwise they stay on
    the device ops, as inference runs them.

    OFF is the default. With `SOFTMAX_BW_FP32` on, the device-only trunk clears the OpenFold3
    accuracy clause at 0.99736x the bar against the instrument's 0.98737x (`perf/of3t_p10exact`),
    and the instrument costs a host round trip per softmax and per layer norm, about 40x on the
    trunk backward. It stays as a diagnostic: the float64 reference for a precision question.
    """
    _EXACT_TRAINING.append(bool(on))
    try:
        yield
    finally:
        _EXACT_TRAINING.pop()


def exact_training_ops() -> tuple:
    """The ops a tape opened now would run exact: `EXACT_TRAINING_OPS` inside
    `exact_training(True)`, else none. What a run records in its provenance."""
    return EXACT_TRAINING_OPS if _EXACT_TRAINING[-1] else ()


def _training_exact(owner: str):
    """The scope `tape()` and `backward()` open for their own extent, for a caller that never
    called `install()`. Nothing outside the training entry points enters it."""
    ops = exact_training_ops()
    return exact(ops, owner) if ops else contextlib.nullcontext()


def mul(a: Tensor, b: Tensor) -> Tensor:
    """Elementwise product. Same shapes only; broadcasting would need a reducing backward."""
    out_v = ttnn.multiply(a.value, b.value)

    def make():
        def bw(g):
            if a.requires_grad and b.requires_grad:
                # `ttnn.mul_bw` returns g*b and g*a from one call -- the same expression the
                # two multiplies below compute, one verb instead of two. Every gate in the
                # trunk is one of these nodes, so a verb here is a verb off every block.
                da, db = ttnn.mul_bw(g, a.value, b.value)
                a.add_grad(da)
                b.add_grad(db)
            elif a.requires_grad:
                a.add_grad(ttnn.multiply(g, b.value))
            elif b.requires_grad:
                b.add_grad(ttnn.multiply(g, a.value))
        return bw

    return _tape(out_v, [a, b], make)


def scale(x: Tensor, factor: float) -> Tensor:
    """Multiply by a python scalar. The backward is the same scalar.

    `mul` cannot do this: it takes two taped tensors of equal shape, and a scalar has
    neither a shape nor a gradient. LoRA needs it for the `alpha/rank` factor, which
    tt-train applies as `lora_update * scaling` (modules/lora.py:106).
    """
    f = float(factor)
    out_v = ttnn.multiply(x.value, f)

    def make():
        def bw(g):
            x.add_grad(ttnn.multiply(g, f))
        return bw

    return _tape(out_v, [x], make)


def add(a: Tensor, b: Tensor) -> Tensor:
    """Elementwise sum. Both gradients are the incoming one, which is why fan-in must sum."""
    out_v = ttnn.add(a.value, b.value)

    def make():
        def bw(g):
            if a.requires_grad:
                a.add_grad(g)
            if b.requires_grad:
                b.add_grad(g)
        return bw

    return _tape(out_v, [a, b], make)


def straight_through(value, x: Tensor) -> Tensor:
    """``value`` forward, ``x``'s derivative backward: the incoming gradient goes to ``x`` as is.

    For a quantity computed twice, once as precisely as it can be and once through registered
    weights on the card. Consumers read the precise value; the weights get the gradient of the
    device computation, evaluated where that computation landed. ``value`` is a raw ttnn tensor
    of ``x``'s shape and dtype.

    ``x`` is WRAPPED rather than assumed: the device leg is only a `Tensor` when something on
    it is registered, and in an inference pass over the same forward it comes back as a raw
    handle. `_tape` then reads `.value` off a parent that has none -- `AttributeError` on a
    raw ttnn tensor, in the evaluation of a run that had just finished training. Wrapping is a
    no-op when it is already a `Tensor`, and it is what makes `add_grad` below well defined
    either way.
    """
    x = _wrap(x)

    def make():
        def bw(g):
            x.add_grad(g)
        return bw

    return _tape(value, [x], make, reads=())


# The ReLU backward as one gated multiply. An attribute rather than an argument because it exists
# for the same-process A/B that prices it (`perf/bcw_callcut/enq_block.py`); nothing else sets it.
RELU_BW_GATED = True


def relu(x: Tensor) -> Tensor:
    """ReLU. The denoiser applies one between the atom encoder and the token aggregation
    (``protenix.py:1110``), and it is the only activation in that path the tape lacked.

    The backward gates on the OUTPUT rather than the input: relu(x) > 0 exactly where
    x > 0, and the output is already materialised, so the input need not be retained.
    """
    out_v = ttnn.relu(x.value)
    box = [out_v]

    def make():
        def bw(g):
            # g * (out > 0). Gating on the OUTPUT is exact rather than an approximation:
            # relu(x) > 0 exactly where x > 0, and the output is what this node retains.
            # `ttnn.relu_bw` launches a `gtz` and a `multiply` and round-trips the mask
            # through DRAM; the GTZ as the multiply's operand activation is one program,
            # bit-identical, 1.015 -> 0.598 ms at the pair transition's [1,288,288,512]
            # (`perf/bcw_callcut/out/relu_op.json`).
            if RELU_BW_GATED:
                x.add_grad(ttnn.multiply(g, box[0],
                                         input_tensor_b_activations=[ttnn.UnaryOpType.GTZ]))
            else:
                x.add_grad(ttnn.relu_bw(g, box[0])[0])
        return bw

    out = _tape(out_v, [x], make)
    if out.node is not None:
        out.box = box              # the closure reads the box, so `free` may still evict
    return out


def sigmoid(x: Tensor) -> Tensor:
    """Sigmoid. Backward ``g * y * (1 - y)``, through the wheel's own kernel.

    It used to be three verbs off the retained output, ``rsub`` then two ``multiply``s.
    ``ttnn.sigmoid_bw`` is the same expression in one, and it takes the INPUT, which is a
    parent and pinned regardless -- so the output stops being read and ``reads=(0,)`` lets
    ``free`` release it. Two verbs and one live tensor off every gate on the tape.
    """
    def make():
        def bw(g):
            x.add_grad(ttnn.sigmoid_bw(g, x.value)[0])
        return bw

    return _tape(ttnn.sigmoid(x.value), [x], make, reads=(0,))


def silu(x: Tensor) -> Tensor:
    """SiLU, ``x * sigmoid(x)``. Eight shipped linears fuse this activation into the packer.

    The backward needs the INPUT, not the output: ``y = x*s`` is not invertible, so unlike
    relu and sigmoid there is no way back from what was materialised. ``dy/dx = s*(1 + x*(1
    - s))``, and the sigmoid is retained rather than recomputed because it is the expensive
    half.
    """
    out_v = ttnn.multiply(x.value, ttnn.sigmoid(x.value))

    def make():
        def bw(g):
            # `ttnn.silu_bw` is the whole derivative in one verb, against the six this used
            # to compose. It keeps the choice that matters: the sigmoid is RECOMPUTED inside
            # the kernel rather than retained, and the input is read through the Tensor in
            # case `free` evicted it to DRAM.
            #
            # Retaining the sigmoid was the older choice, on the grounds that it is the
            # expensive half. It is, and it is still the wrong trade here, because what the
            # retention actually costs is L1: the shipped `Transition` asks for its swiglu
            # operands in L1 and sizes the next kernel's circular buffers against what that
            # leaves, and the tape composes this activation where production fuses it into
            # the packer. Measured at a [1,256,256,128] pair track with hidden 512, the
            # retained sigmoid plus the composed output is two L1 tensors production does
            # not hold, and fc2 then throws "Statically allocated circular buffers in
            # program 11 clash with L1 buffers ... allocated at 692224 and static circular
            # buffer region ends at 893440" on the FIRST row chunk. The fused backward is
            # stricter than that fix, not looser: it holds no intermediate at all.
            x.add_grad(ttnn.silu_bw(g, x.value)[0])
        return bw

    return _tape(out_v, [x], make)


def reshape(x: Tensor, shape: Sequence[int]) -> Tensor:
    """Reshape. The backward of a shape op is the inverse shape op: no kernel work."""
    src = [int(d) for d in x.value.shape]
    out_v = ttnn.reshape(x.value, [int(d) for d in shape])

    def make():
        def bw(g):
            x.add_grad(ttnn.reshape(g, src))
        return bw

    return _tape(out_v, [x], make)


def pairwise_distance(x: Tensor) -> Tensor:
    """Euclidean distance between every pair of rows of ``x`` ``[..., N, 3]``. Taped.

    Every AF3-family objective seeds two terms off a distance rather than off a
    coordinate -- ``smooth_lddt`` and ``bond`` both name ``pred_dist`` in
    ``tt_bio.train.objectives._SEED`` -- so the distance is a node on the tape and not a
    statistic the loss recomputes. One implementation here rather than one per adapter.

    The value is computed on the host, which is a decision rather than a gap. The reduction
    runs over a THREE-element axis, so a tiled device form pays a 32x32 tile to carry 3
    floats and moves 10x the bytes it multiplies; at OpenFold3's 384 tokens the whole
    round trip is 4.6 KB out and 590 KB back. The BACKWARD is where the arithmetic is, and
    it is `tt_bio.train.losses.dist_grad_to_coords` -- imported lazily inside the closure
    because that module is pure numpy and the engine must not depend on the training
    package at import time. Sharing it is the point: the factor-of-two that the transpose
    term carries is exactly the silent defect its docstring warns about, and a second copy
    here would be a second place to get it wrong.
    """
    import torch

    xv = ttnn.to_torch(x.value).to(torch.float32)
    lead, n = tuple(xv.shape[:-2]), int(xv.shape[-2])
    pts = xv.reshape(-1, n, 3)
    d = torch.cdist(pts, pts).reshape(*lead, n, n)
    out_v = ttnn.from_torch(d, dtype=ttnn.float32, layout=ttnn.TILE_LAYOUT,
                            device=x.value.device())

    def make():
        def bw(g):
            from .train.losses import dist_grad_to_coords
            gh = ttnn.to_torch(g).to(torch.float64).reshape(*lead, n, n).numpy()
            coords = ttnn.to_torch(x.value).to(torch.float64).reshape(*lead, n, 3).numpy()
            dx = dist_grad_to_coords(gh, coords)
            x.add_grad(ttnn.from_torch(torch.from_numpy(dx).to(torch.float32),
                                       dtype=x.value.dtype, layout=x.value.layout,
                                       device=x.value.device()))
        return bw

    # `reads=(0,)`: the backward reads the COORDINATES, never its own output.
    return _tape(out_v, [x], make, reads=(0,))
def split_heads_value(x, heads):
    """``[B, S, H*d]`` or ``[B, 1, S, H*d] -> [B, H, S, d]`` on a raw ttnn tensor, untaped.
    `split_heads` tapes it and `taped_ttnn`'s ``nlp_concat_heads`` backward calls it directly.

    Transposing first puts the head split on a dim of extent d rather than H, so no H axis ever
    becomes a tile row, and it is three ops whatever the head count. Against H tile-aligned
    slices and a concat it is 178 us to 277 us at [256, 256, 4x32], 882 to 1382 us at
    [576, 576, 4x32] and 694 to 1658 us at 16 heads, bit-exact at every shape including d=16,
    where the slice form had to fall back to a permute (`perf/bcx_heads/heads_ab_run1.json`, qb1
    p150a, 1350 MHz).
    """
    B, S, C = int(x.shape[0]), int(x.shape[-2]), int(x.shape[-1])
    t = ttnn.reshape(ttnn.transpose(x, -2, -1), [B, heads, C // heads, S])
    return ttnn.transpose(t, -2, -1)


def merge_heads_value(x):
    """``[B, H, S, d] -> [B, S, H*d]`` on a raw ttnn tensor, untaped. See `merge_heads`.

    ``nlp_concat_heads`` keeps the pad lanes of a head width that is not whole tiles, and at
    d=16 it is not the permutation (`perf/bcx_heads/heads_ab_run1.json`), so such a width takes
    ``permute`` + ``reshape``. The DRAM pin costs nothing measurable at nine shapes.
    """
    B, H, S, d = (int(e) for e in x.shape)
    if d % 32:
        return ttnn.reshape(ttnn.permute(x, (0, 2, 1, 3)), [B, S, H * d])
    return ttnn.reshape(ttnn.experimental.nlp_concat_heads(x, memory_config=ttnn.DRAM_MEMORY_CONFIG),
                        [B, S, H * d])


def split_heads(x: Tensor, heads: int) -> Tensor:
    """``[B, S, H*d] -> [B, H, S, d]``, the attention head split. The backward is `merge_heads`.

    ``permute(reshape(x, [B, S, H, d]), (0, 2, 1, 3))`` is the same rearrangement and in tile
    layout it moves 8x the bytes, because the H axis becomes a tile row and 4 heads pad to 32:
    2581 us against 178 us for `split_heads_value` at [256, 256, 128] with 4 heads. A pure
    rearrangement, so bit-exact either way.
    """
    out_v = split_heads_value(x.value, heads)

    def make():
        def bw(g):
            x.add_grad(merge_heads_value(g))
        return bw

    return _tape(out_v, [x], make)


def merge_heads(x: Tensor) -> Tensor:
    """``[B, H, S, d] -> [B, S, H*d]``, the inverse of `split_heads`, on ``nlp_concat_heads``.

    90 us against 2208 us for ``permute`` + ``reshape`` at the same shape, bit-exact.
    """
    heads = int(x.value.shape[1])
    out_v = merge_heads_value(x.value)

    def make():
        def bw(g):
            x.add_grad(split_heads_value(g, heads))
        return bw

    return _tape(out_v, [x], make)


def _packed_qkv_source(q, k, v):
    """The packed tensor q, k and v were split from, when `triatt_bw` can write their gradient
    into its layout in one pass; else None.

    Only when they are slots 0, 1 and 2 of ONE `nlp_create_qkv_heads` call, all three
    differentiated, with one-tile heads on a whole-tile token axis, so the packed pages and the
    slot closures' `merge_heads` + join name the same elements. A slot that is read elsewhere too
    still gets that consumer's gradient through its own closure; this only replaces the part
    that came from here.
    """
    nodes = [t.node for t in (q, k, v)]
    if any(n is None or getattr(n.fn, "qkv_slot", None) != s for s, n in enumerate(nodes)):
        return None
    # The fused head-major projection (`taped_ttnn` entry `triatt_qkv_heads`) never builds the
    # packed tensor; its slots share a sink that takes the packed gradient straight into the
    # projection's VJP.
    sink = getattr(nodes[0].fn, "packed_sink", None)
    if sink is not None:
        return sink if all(getattr(n.fn, "packed_sink", None) is sink for n in nodes) else None
    x = nodes[0].parents[0]
    if any(n.parents[0] is not x for n in nodes) or not x.requires_grad:
        return None
    B, H, N, d = (int(i) for i in q.value.shape)
    if d != 32 or N % 32 or tuple(int(i) for i in x.value.shape) != (B, 1, N, 3 * H * d):
        return None
    if x.value.layout != ttnn.TILE_LAYOUT or x.value.dtype != q.value.dtype:
        return None
    return x


def triangle_attention(q: Tensor, k: Tensor, v: Tensor, bias: Optional[Tensor] = None,
                       *, scale: Optional[float] = None, chunk: Optional[int] = None,
                       q_chunk: Optional[int] = None, config=None, value=None) -> Tensor:
    """Triangle attention with a chunked-recompute backward that never holds the scores.

    ``q``/``k``/``v`` are ``[B, H, N, d]`` head-major and ``bias`` is ``[1, H, N, N]``,
    broadcast over B. This is the shape tt-bio's ``TriangleAttention`` produces: for a pair
    tensor ``[S, S, c]`` the leading axis B is S, so triangle attention is S independent
    attention problems rather than one big one.

    That leading axis is why this needs no log-sum-exp bookkeeping. A flash kernel chunks
    KEYS, so each block sees a partial softmax denominator and has to carry running row
    statistics to rescale. Here the only reason to chunk is to keep the score tensor out of
    DRAM, and chunking the leading axis and the QUERY axis while keeping every key does
    that, so each chunk's softmax is already exact and complete. The retained set is q, k,
    v and bias; scores and probabilities are recomputed in the backward and freed per chunk.

    The object being avoided is concrete: at 800 aa with 8 heads the full
    ``[S, H, S, S]`` bf16 score tensor is 8.19 GB. One leading-axis chunk of 1 is 10.24 MB.

    ``chunk`` bounds the leading axis, ``q_chunk`` the query axis; both default to the whole
    extent, which materialises the scores and is only appropriate at small N. Gradients are
    invariant to both, which ``perf/hallgrad/gradcheck.py --cases triatt_chunked`` checks by
    differencing two chunkings rather than trusting one.

    ``value`` hands in a forward that has already been computed, and it is what lets the
    shipped fused SDPA share this backward instead of getting a second copy of it. The
    backward below reads q, k, v and bias and recomputes the scores; it never reads the
    forward output, so supplying the output changes nothing about the gradient and saves
    computing the attention twice. ``tt_bio.taped_ttnn`` passes the fused kernel's result
    here, which is how the production forward and this backward end up in one node.
    """
    cfg = config or precise_config()

    def mm(a, b, ta=False, tb=False):
        if TRIATT_BMM_CONFIG:
            return bmm(a, b, ta, tb, compute_kernel_config=cfg)
        return _matmul(a, b, transpose_a=ta, transpose_b=tb, compute_kernel_config=cfg)

    qs = [int(d) for d in q.value.shape]
    ks = [int(d) for d in k.value.shape]
    if len(qs) != 4 or len(ks) != 4:
        raise ValueError(f"expected [B, H, N, d] q and k, got {qs} and {ks}")
    B, H, n_q, head_dim = qs
    n_k = ks[2]
    if scale is None:
        scale = head_dim ** -0.5
    # A bias with a leading extent of 1 broadcasts over the B independent attention
    # problems, which is what the pair tracks pass. The atom transformer's local windows
    # pass a DIFFERENT bias per trunk, so its gradient is the score gradient itself
    # rather than a sum over that axis, and summing it there would quietly average the
    # windows together.
    bias_bcast = bias is None or int(bias.value.shape[0]) == 1
    cB = B if chunk is None else min(int(chunk), B)
    cQ = n_q if q_chunk is None else min(int(q_chunk), n_q)
    if TRIATT_BMM_CONFIG and n_k % 32 == 0:
        # A score block wider than one core-block leaves the fast plan; more query chunks do
        # not change the gradient, which the chunk invariance below already relies on.
        cQ = min(cQ, max(32, BMM_OUT_TILES // (n_k // 32) * 32))

    def _scores(qb, b0, b1, i0, i1):
        """Recompute one score block and its softmax. The only place the scores exist."""
        s = mm(qb, k.value[b0:b1], tb=True)
        s = ttnn.multiply(s, scale)
        if bias is not None:
            # bias is [1, H, n_q, n_k] and broadcasts over the leading axis, so the row
            # slice follows the query chunk and the leading slice is dropped.
            s = ttnn.add(s, bias.value[:, :, i0:i1, :])
        return ttnn.softmax(s, dim=-1, compute_kernel_config=cfg)

    out_blocks = []
    for b0 in range(0, B, cB) if value is None else ():
        b1 = min(b0 + cB, B)
        row_blocks = []
        for i0 in range(0, n_q, cQ):
            i1 = min(i0 + cQ, n_q)
            p = _scores(q.value[b0:b1, :, i0:i1, :], b0, b1, i0, i1)
            row_blocks.append(mm(p, v.value[b0:b1]))
            ttnn.deallocate(p)
        out_blocks.append(row_blocks[0] if len(row_blocks) == 1
                          else ttnn.concat(row_blocks, dim=2))
    if value is not None:
        out_v = value
    else:
        out_v = out_blocks[0] if len(out_blocks) == 1 else ttnn.concat(out_blocks, dim=0)
    parents = [p for p in (q, k, v, bias) if p is not None]

    def make():
        def bw(g):
            # Counted unconditionally, before any gate. "served 0, declined 0" is ambiguous on its
            # own -- it reads the same whether this backward never ran or ran and was refused --
            # and which of those is true decides whether the lever needs a narrower gate or
            # another row's routing change.
            from . import triatt_bw as _tbw0
            _tbw0.STATS["bw_calls"] = _tbw0.STATS.get("bw_calls", 0) + 1
            # The fused backward, when it is on and the shape fits. It computes the same gradient
            # over the same blocks with the score tensor never leaving L1: 238.88 MB a call at the
            # shipped 288-token shape against 9172.90 for the loop below. Default off, and it
            # refuses rather than approximates -- everything it declines falls through to the
            # chunked recompute, which is correct at every shape.
            from . import triatt_bw as _tbw
            if _tbw.FUSED and bias is not None and bias_bcast:
                _ok, _why = _tbw.eligible(q.value, k.value, v.value, bias.value)
                if _ok:
                    _dev = q.value.device()
                    _p = _tbw.serving_plan(*(int(x) for x in q.value.padded_shape),
                                           grid=(_dev.compute_with_storage_grid_size().x,
                                                 _dev.compute_with_storage_grid_size().y))
                    if _p is not None:
                        # The packed gradient is the whole-query kernel's only: a chunked plan's
                        # dK/dV are float32 running sums, so those take the three-tensor path.
                        _src = (_packed_qkv_source(q, k, v)
                                if _tbw.QKV_PACKED and _p["Qt"] == _p["Nt"] else None)
                        _dq, _dk, _dv, _db = _tbw.run(
                            _dev, q.value, k.value, v.value, bias.value, g, scale,
                            (ttnn.MathFidelity.HiFi4,), packed=_src is not None)
                        if _src is not None:
                            _src.add_grad(_dq)
                            if bias.requires_grad:
                                bias.add_grad(_db)
                            else:
                                ttnn.deallocate(_db)
                            return
                        for _t, _d in ((q, _dq), (k, _dk), (v, _dv), (bias, _db)):
                            if _t.requires_grad:
                                _t.add_grad(_d)
                            else:
                                ttnn.deallocate(_d)
                        return
                    _tbw.STATS["declined"] += 1
                else:
                    _tbw.STATS["declined"] += 1

            dq_blocks, dk_blocks, dv_blocks = [], [], []
            dbias_blocks = []
            for b0 in range(0, B, cB):
                b1 = min(b0 + cB, B)
                dk_acc = dv_acc = None
                dq_rows, dbias_acc = [], []
                for i0 in range(0, n_q, cQ):
                    i1 = min(i0 + cQ, n_q)
                    # Recompute, rather than retain. This is the whole memory argument:
                    # one forward matmul plus one softmax per block, traded against the
                    # 8.19 GB the retained scores would cost at 800 aa.
                    p = _scores(q.value[b0:b1, :, i0:i1, :], b0, b1, i0, i1)
                    go = g[b0:b1, :, i0:i1, :]
                    # dV = P^T @ dO, summed over the query chunks that share these keys.
                    dv_part = mm(p, go, ta=True)
                    dv_acc = dv_part if dv_acc is None else ttnn.add(dv_acc, dv_part)
                    # dS = P * (dP - rowsum(dP * P)), the softmax backward on the block.
                    dp = mm(go, v.value[b0:b1], tb=True)
                    ds = softmax_bw(p, dp, dim=-1, config=cfg)
                    ttnn.deallocate(p)
                    if bias is not None:
                        # CLONE on the per-trunk path. The broadcast path appends the
                        # result of a sum, a fresh tensor, but ds itself is deallocated
                        # a few lines down, so keeping a reference to it hands the bias
                        # gradient freed storage -- which surfaces much later, in an
                        # unrelated permute backward.
                        dbias_acc.append(ttnn.sum(ds, dim=0, keepdim=True)
                                         if bias_bcast else ttnn.clone(ds))
                    dq_rows.append(ttnn.multiply(mm(ds, k.value[b0:b1]), scale))
                    dk_part = ttnn.multiply(mm(ds, q.value[b0:b1, :, i0:i1, :], ta=True), scale)
                    dk_acc = dk_part if dk_acc is None else ttnn.add(dk_acc, dk_part)
                    ttnn.deallocate(ds)
                dq_blocks.append(dq_rows[0] if len(dq_rows) == 1
                                 else ttnn.concat(dq_rows, dim=2))
                dk_blocks.append(dk_acc)
                dv_blocks.append(dv_acc)
                if bias is not None:
                    rows = dbias_acc[0] if len(dbias_acc) == 1 else ttnn.concat(dbias_acc, dim=2)
                    if bias_bcast:
                        # Each leading chunk's partial goes straight to the tape, whose
                        # accumulator is float32. Summing the partials here in bf16 rounded the
                        # running total once per chunk: at 544 tokens and the default budget
                        # that is five roundings, and dbias drifted 0.6-1.2 % between chunkings
                        # that must agree (perf/b2p_ceiling/bw_transient.json).
                        if bias.requires_grad:
                            bias.add_grad(rows)
                    else:
                        dbias_blocks.append(rows)
            def cat0(blocks):
                return blocks[0] if len(blocks) == 1 else ttnn.concat(blocks, dim=0)
            if q.requires_grad:
                q.add_grad(cat0(dq_blocks))
            if k.requires_grad:
                k.add_grad(cat0(dk_blocks))
            if v.requires_grad:
                v.add_grad(cat0(dv_blocks))
            if bias is not None and bias.requires_grad and not bias_bcast:
                bias.add_grad(cat0(dbias_blocks))
        return bw

    return _tape(out_v, parents, make)


def _axis(dim: int, rank: int) -> int:
    return dim + rank if dim < 0 else dim


def narrow(x: Tensor, dim: int, start: int, length: int) -> Tensor:
    """``x[..., start:start+length, ...]`` along ``dim``, with a zero-padding backward.

    Added for the atom transformer's local attention window, which upstream builds with
    ``unfold(dim, size=n_keys, step=n_queries)`` (primitives.py:371). Because n_keys is
    exactly 4 x n_queries, that unfold is four shifted slices concatenated rather than a
    general gather, so a slice and a concat are the only two ops the tape was missing.

    KEEP THE SLICED AXIS TILE-ALIGNED. Every use here slices the leading trunk axis or a
    32-multiple of the key axis; a sub-tile slice of the LAST axis is the documented
    Blackhole wedge and is not what this is for.
    """
    shape = [int(d) for d in x.value.shape]
    ax = _axis(dim, len(shape))
    starts = [0] * len(shape)
    ends = list(shape)
    starts[ax], ends[ax] = start, start + length
    out_v = ttnn.slice(x.value, starts, ends)
    before, after = start, shape[ax] - (start + length)

    # `ttnn.pad` would be this backward in one verb instead of three, and it cannot be:
    # "ttnn.pad: on device tile padding does not support front padding"
    # (`pad.cpp:278`, `front_padding_is_zero`), measured at fp32 and bf16 on a p150a. Every
    # window but the first has `start > 0`, so front padding is the case. 0.68.0 binds no
    # `slice_bw` either, so the zero blocks and the concat stay.
    def make():
        def bw(g):
            parts = []
            if before:
                z = list(shape)
                z[ax] = before
                parts.append(grad_zeros(z, g.dtype, g.device()))
            parts.append(g)
            if after:
                z = list(shape)
                z[ax] = after
                parts.append(grad_zeros(z, g.dtype, g.device()))
            x.add_grad(parts[0] if len(parts) == 1 else ttnn.concat(parts, dim=ax))
        return bw

    return _tape(out_v, [x], make)


def concat(xs: Sequence[Tensor], dim: int = -2) -> Tensor:
    """Concatenate along ``dim``. The backward is the slice this op is the inverse of.

    A tensor may appear more than once in ``xs`` -- the window build concatenates four
    overlapping slices of the same padded key tensor -- so each occurrence adds its own
    contribution rather than overwriting, which ``add_grad`` already does.
    """
    xs = list(xs)
    shape = [int(d) for d in xs[0].value.shape]
    ax = _axis(dim, len(shape))
    sizes = [int(x.value.shape[ax]) for x in xs]
    out_v = ttnn.concat([x.value for x in xs], dim=ax)

    # `ttnn.concat_bw` would cover the two-input case in one verb instead of two slices, and
    # it throws on anything that is not rank 4: "ShapeBase[] index out of range. 2 not in
    # [-4, 2)" from `shape_base.cpp:16` on a [128,128] pair at dim 0, at fp32 and at bf16.
    # This op is called at rank 2 and rank 3 as well, and it takes four inputs at the atom
    # window, which `concat_bw` cannot express at any rank.
    def make():
        def bw(g):
            off = 0
            gs = [int(d) for d in g.shape]
            for x, n in zip(xs, sizes):
                if x.requires_grad:
                    starts = [0] * len(gs)
                    ends = list(gs)
                    starts[ax], ends[ax] = off, off + n
                    x.add_grad(ttnn.slice(g, starts, ends))
                off += n
        return bw

    return _tape(out_v, xs, make)


def windows(x: Tensor, n_queries: int, n_keys: int, n_trunks: int,
            pad_left: int) -> Tensor:
    """The local-attention key window: ``[n_trunks, n_keys, c]`` out of ``[n_pad, c]``.

    ``x`` must ALREADY be padded to ``n_trunks * n_queries + pad_left + pad_right`` rows,
    and ``n_keys`` must be a multiple of ``n_queries`` -- upstream runs 128 and 32
    (primitives.py:366-372), so window i is exactly the four consecutive query-blocks
    starting at block i of the padded tensor. That is why this needs no gather.
    """
    if n_keys % n_queries:
        raise ValueError(f"n_keys {n_keys} is not a multiple of n_queries {n_queries}")
    per = n_keys // n_queries
    c = int(x.value.shape[-1])
    n_blocks = int(x.value.shape[-2]) // n_queries
    if n_blocks < n_trunks + per - 1:
        raise ValueError(f"padded length {n_blocks * n_queries} is too short for "
                         f"{n_trunks} trunks of {n_keys} keys")
    blocks = reshape(x, [n_blocks, n_queries, c])
    return concat([narrow(blocks, 0, i, n_trunks) for i in range(per)], dim=1)


def permute(x: Tensor, dims: Sequence[int]) -> Tensor:
    """Permute axes. The backward is the inverse permutation, so no kernel work but a real
    data movement, which is why the trimul contraction below pays for two of them."""
    dims = [int(d) for d in dims]
    inv = [0] * len(dims)
    for i, d in enumerate(dims):
        inv[d] = i
    out_v = ttnn.permute(x.value, dims)

    def make():
        def bw(g):
            x.add_grad(ttnn.permute(g, inv))
        return bw

    return _tape(out_v, [x], make)


def pair_contract(a: Tensor, b: Tensor, *, incoming: bool = False, config=None) -> Tensor:
    """TriangleMultiplication's contraction, composed from `permute` and `matmul`.

    Outgoing is ``out[i,j,c] = sum_k a[i,k,c] * b[j,k,c]``, incoming is
    ``out[i,j,c] = sum_k a[k,i,c] * b[k,j,c]``. Both are one per-channel matmul once the
    channel axis is moved to the front, so this needs no new differentiated op at all: the
    tape's own `permute` and `matmul` with transpose flags cover it, and its gradient is
    therefore already verified by their gradchecks rather than needing its own.

    Inputs are ``[N, N, C]``, which is tt-bio's pair layout.
    """
    ap = permute(a, (2, 0, 1))
    bp = permute(b, (2, 0, 1))
    if incoming:
        # sum over the FIRST index: A_c^T @ B_c
        prod = matmul(ap, bp, transpose_a=True, config=config)
    else:
        # sum over the SECOND index: A_c @ B_c^T
        prod = matmul(ap, bp, transpose_b=True, config=config)
    return permute(prod, (1, 2, 0))


# Every input a checkpointed segment pinned. The pin has to outlive the forward, because the
# recompute happens in the backward, so nothing in `checkpoint` itself can drop it -- and a pinned
# tensor is never released, so a run that does several forwards without a backward between them
# accumulates one whole segment input per block per forward. Measured: a finite-difference sweep
# at 384 aa (six extra forwards) left the next training step's backward OOM at 31.9 GB. The run
# owns the release, and `release_pins` is how it says so.
# Flat, and it stays flat even when several trajectories share the card. A pin is taken inside
# a device SEAM (the checkpointed forward, or the recompute inside a backward) and released at
# the end of that same seam, and `tt_bio.duotraj`'s gate lets only one seam run at a time -- so
# no pin of one trajectory is ever live while another is taking or releasing its own. Keying
# this by trajectory would be dead machinery, and it could not be done honestly anyway: the
# seam does not run on the trajectory's thread.
_CKPT_PINS: list = []


def release_dead(outputs: Sequence[Tensor], inputs: Sequence[Tensor]) -> None:
    """Release every intermediate of a taped segment that no backward reads.

    The tape keeps a Tensor for every value it recorded, and a value goes back to the card only
    where the shipped forward calls `ttnn.deallocate` on it. Most of a tuned forward lets an
    activation go out of scope instead, and under a tape the node graph keeps the handle alive,
    so an unpinned value nobody will read stays on the card until the backward has run. For a
    segment whose tape is KEPT (BindCraft 2's resident Evoformer blocks) that is the difference
    between a block's tape fitting and not. This walks from `outputs` back to `inputs` and frees
    what lies between, through `free`, which keeps anything pinned and decides shared-storage
    groups together. Only values with a node are touched: constants and parameters have none.
    """
    stop = {id(t) for t in (*outputs, *inputs) if isinstance(t, Tensor)}
    seen = set(stop)
    stack = [p for t in outputs if isinstance(t, Tensor) and t.node is not None
             for p in t.node.parents]
    while stack:
        t = stack.pop()
        if id(t) in seen or not isinstance(t, Tensor):
            continue
        seen.add(id(t))
        if t.node is None:
            continue
        t.free()
        stack.extend(t.node.parents)


def release_pins() -> None:
    """Drop every pin a checkpointed segment took. Call after a backward, or after a forward
    whose tape is being discarded."""
    for t in _CKPT_PINS:
        t.pinned = False
    _CKPT_PINS.clear()


# Sentinel: "whichever registered parameters this segment turns out to read", resolved by the
# touch census around the untaped forward. A caller that names its own parameters still can.
_ALL_PARAMS = object()


def substep(fn, *inputs: Tensor):
    """``fn(*inputs)``, checkpointed on its own when a tape is being recorded.

    This is how a checkpointed block checkpoints its sub-modules. Its untaped first forward
    runs ``fn`` straight through: nothing is taped there, so nothing could be saved. Its
    recompute runs with gradients on, and there each sub-module becomes a `checkpoint` of its
    own, so the block's backward holds the sub-module boundaries plus ONE sub-module's tape
    instead of every sub-module's tape at once. The values are the same ops on the same inputs
    either way, so the gradient does not move; what it costs is one more forward of every
    sub-module.
    """
    if not _GRAD_ENABLED or not any(isinstance(t, Tensor) and t.requires_grad for t in inputs):
        return fn(*inputs)
    return checkpoint(fn, *inputs, _nested=True)


def _to_host(t: Tensor):
    """Move a pinned segment input off the card, or None if it must stay.

    A view stays: its buffer is shared with another taped tensor and moving one moves neither.
    Returns what the recompute needs to put it back."""
    v = t.value
    if t.shares is not None or v.storage_type() != ttnn.StorageType.DEVICE \
            or not v.is_allocated():
        return None
    home = (v.device(), v.memory_config())
    t.value = ttnn.from_device(v)
    ttnn.deallocate(v)
    # Off the card is off the card: `free` and `evict` have nothing to release or move, and
    # they would ask a HOST tensor for its allocation and its memory config on the way to
    # finding that out. `evictable` is the flag both of them test first.
    t.evictable = False
    return home


# A checkpointed segment's backward -- its taped recompute and the walk of that inner tape --
# replayed from a metal trace, keyed by the caller's `trace` key and every operand's shape.
#
# On a host-bound card (a Wormhole Galaxy chip runs a BindCraft 2 round at ~60 % idle, the host
# spending ~14 us dispatching each of ~64k calls plus the tape's own Python) the recompute is
# pure host overhead: the same programs on the same shapes every round. Rounds 1 and 2 at a key
# run eagerly; round 2 also allocates the SHARED buffers every segment of that shape copies its
# operands into and its input gradients out of; round 3 captures; every later round copies in,
# replays, and clones the gradients out. Shared buffers are allocated in round 2 and not at the
# capture because a capture keeps its intermediates at addresses the allocator then calls free:
# anything that is live at a replay and was not live at the capture can sit there and be
# overwritten. Allocating them a whole round before the first capture makes every later round's
# allocation sequence -- the forward's pins included -- the one the captures saw.
#
# Raw ttnn operands (a segment's dropout masks, new each round) are copied in like the taped
# ones, so `fn` must take them as inputs rather than close over them. Bit-exact by construction:
# the replay runs the programs the eager recompute runs, on the same values.
# Default OFF until graded on a card: TT_BIO_TRACE_RECOMPUTE=1. Needs a trace region at open.
TRACE_RECOMPUTE = env_flag("TT_BIO_TRACE_RECOMPUTE", False)
_RTRACE: dict = {}    # (key, signature) -> rounds seen (int), then (trace id, shared)
_RSHARED: dict = {}   # signature -> dict(ins=[...], seeds=[...], outs=[...])
RTRACE_STATS = {"eager": 0, "capture": 0, "replay": 0, "refused": 0, "regrow": 0}
# The checkpoint's untaped FORWARD replayed the same way (`_traced_forward`), so a block's three
# passes per round (two forwards, one recompute + VJP) all come from traces. Follows
# TRACE_RECOMPUTE unless set on its own.
TRACE_FORWARD = env_flag("TT_BIO_TRACE_FORWARD", TRACE_RECOMPUTE)


@contextlib.contextmanager
def block_traces(on: bool = True):
    """Replay every traced block unit (checkpoint forward, recompute + VJP) for the duration, or
    run them all eagerly with `on=False`. What `bindcraft2.predictor(trace=...)` sets; the two
    environment flags only pick the default. Captures made inside stay cached after the exit."""
    global TRACE_RECOMPUTE, TRACE_FORWARD
    saved = TRACE_RECOMPUTE, TRACE_FORWARD
    TRACE_RECOMPUTE = TRACE_FORWARD = bool(on)
    try:
        yield
    finally:
        TRACE_RECOMPUTE, TRACE_FORWARD = saved


_RPEAK: dict = {}     # signature -> DRAM rise per bank of its first eager run; sizes the hole
_RSHAPE: dict = {}    # forward signature -> whether fn returns a tuple
_SCRATCH: list = [None]   # the device's `TraceScratch`, made at the first capture
_EAGER = object()
_RPEND: dict = {}     # signature -> {key: make(shared)}, keys waiting for their batch capture
# Diagnostic: the first N replays also run the block eagerly on the same inputs and record the
# relative L2 error of each input gradient against it (RTRACE_CHECKS). Replays are expected to be
# exact; anything else means a replay read or wrote memory the eager side now owns.
TRACE_RECOMPUTE_CHECK = int(os.environ.get("TT_BIO_TRACE_RECOMPUTE_CHECK", "0"))
RTRACE_CHECKS: list = []


_RMODE: dict = {}     # diagnostic: the ambient mode at a key's registration and at its capture


def _mode():
    from . import ops
    return dict(taping=ops.taping(), recording=ops.recording(), grad=_GRAD_ENABLED,
                nogradinf=ops.NOGRAD_IS_INFERENCE, relu_entry=ops._KERNEL_ENTRIES.get("pair_relu") is not None,
                raw=ops._RAW_DEPTH)


def _rt_raw(t, home):
    return home(t) if isinstance(t, Tensor) else (t if isinstance(t, ttnn.Tensor) else None)


def _grad_value(dup):
    g = dup.grad if isinstance(dup, Tensor) else None
    return g.value if isinstance(g, Tensor) else g


def _rt_sig(vals, extra=()):
    """What a block trace is keyed on: its operands' shapes, plus the ambient state that picks the
    block's op sequence. An open tape turns off the fused kernels that have no tape entry
    (`ops.taping`), so one block ran 300 ttnn calls under a tape and 288 without; a trace captured
    in one mode and replayed in the other was off by rel 1e-4 on every block (bc4-bet-dispatch c10)."""
    from . import ops
    return (tuple(None if v is None else (tuple(v.shape), str(v.dtype), str(v.layout)) for v in vals),
            tuple(extra), ops.taping(), tuple(sorted(_EXACT_SAVED)))


def _in_dram(vals) -> bool:
    """Every device operand interleaved in DRAM. L1 is not fenced (`TraceScratch`), so a unit
    whose operands or outputs live in L1 stays eager."""
    return all(v.memory_config().buffer_type == ttnn.BufferType.DRAM for v in vals if v is not None)


from .tenstorrent import dram_rise as _rise  # the hole TraceScratch opens is sized by it


def _op_desc(v):
    if isinstance(v, ttnn.Tensor):
        return f"T{tuple(v.shape)}:{v.dtype}:{v.layout}:{v.memory_config().buffer_type}"
    if isinstance(v, (list, tuple)):
        return "[" + ",".join(_op_desc(x) for x in v) + "]"
    return repr(v)[:120]


def _ops(run):
    """``run()`` and the list of ttnn calls it made, each as name plus operand description.
    Diagnostic for `TRACE_RECOMPUTE_CHECK`: a replay that disagrees with eager on the same
    inputs ran different calls, and the first differing one names the state that moved."""
    from ttnn import decorators as D
    real = {c: c.__call__ for c in (D.FastOperation, D.Operation)}
    log = []

    def rec(f):
        def call(op, *a, **k):
            log.append(f"{getattr(op, 'python_fully_qualified_name', op)}("
                       + ", ".join([_op_desc(x) for x in a] + [f"{n}={_op_desc(x)}" for n, x in k.items()]) + ")")
            return f(op, *a, **k)
        return call

    for c, f in real.items():
        c.__call__ = rec(f)
    try:
        out = run()
    finally:
        for c, f in real.items():
            c.__call__ = f
    return out, log


def _ops_diff(key, ref, now) -> None:
    import difflib
    print(f"[trace-check] {key!r}: capture made {len(ref)} calls, eager {len(now)}", flush=True)
    for tag, a0, a1, b0, b1 in difflib.SequenceMatcher(None, ref, now, autojunk=False).get_opcodes():
        if tag != "equal":
            print(f"[trace-check]   {tag} capture[{a0}:{a1}] eager[{b0}:{b1}]", flush=True)
            for x in ref[a0:a1][:6]:
                print(f"[trace-check]     - {x}", flush=True)
            for x in now[b0:b1][:6]:
                print(f"[trace-check]     + {x}", flush=True)


_ROPS: dict = {}      # (key, signature) -> the calls its capture made, when checking


def _rt_first(device, sig, run):
    """A unit's first eager run at a key; its DRAM rise is measured for the signature's first."""
    if sig in _RPEAK:
        return run()
    out, _RPEAK[sig] = _rise(device, run)
    return out


def _rt_clone(vals):
    return [None if v is None else ttnn.clone(v) for v in vals]


def _rt_inner(kinds, bufs):
    return [Tensor(ttnn.clone(b), requires_grad=rg) if tensor else (ttnn.clone(b) if b is not None else raw)
            for (tensor, rg, raw), b in zip(kinds, bufs)]


def _rt_kinds(inputs):
    return [(isinstance(t, Tensor), getattr(t, "requires_grad", False),
             None if isinstance(t, (Tensor, ttnn.Tensor)) else t) for t in inputs]


def _rt_copy_in(vals, bufs):
    for v, b in zip(vals, bufs):
        if b is not None:
            ttnn.copy(v, b)


def _rt_batch(device, sig, sh):
    """Capture every key of ``sig`` waiting in `_RPEND`, all inside one fence."""
    from .tenstorrent import TraceScratch
    pend = _RPEND.pop(sig, {})
    if not pend:
        return
    if _SCRATCH[0] is None:
        _SCRATCH[0] = TraceScratch(device)
    sc = _SCRATCH[0]
    margin = lambda b: b + b // 4 + sc.CHUNK
    need = margin(_RPEAK[sig])
    if sc.hole is not None and need > sc.hole[1] - sc.hole[0]:
        # A unit measured after the hole was opened needs a bigger one: drop every trace and
        # the hole, and let every key capture again into one sized for all of them.
        release_recompute_traces(device)
        RTRACE_STATS["regrow"] += 1
        return
    runs = [functools.partial(make, sh) for make in pend.values()]
    if TRACE_RECOMPUTE_CHECK:
        def logged(key, run):
            def go():
                _RMODE.setdefault(("cap", key, sig), _mode())
                _, _ROPS[(key, sig)] = _ops(run)
            return go
        runs = [logged(key, run) for key, run in zip(pend, runs)]
    # One warm pass through the shared buffers compiles anything only they reach.
    runs[0]()
    ttnn.synchronize_device(device)
    before = set(_WRAPPED)

    def settle():
        # Wrappers the captures made hold buffers allocated in the hole. Dropped before the
        # hole is filled, so no later tape close frees them into it (bcx-tracewire).
        for k in set(_WRAPPED) - before:
            del _WRAPPED[k]
        gc.collect()

    try:
        tids = sc.capture(need, margin(max(_RPEAK.values())), runs, settle)
    except RuntimeError as e:   # a trace region too small for the batch: the keys stay eager
        print(f"[trace] {len(runs)} captures refused: {str(e).splitlines()[0][:200]}", flush=True)
        tids = None
    for i, key in enumerate(pend):
        _RTRACE[(key, sig)] = "eager" if tids is None else (tids[i],)
    RTRACE_STATS["refused" if tids is None else "capture"] += len(pend)


def _traced_recompute(key, fn, inputs, home, seeded) -> bool:
    """`_recompute(seeded)` from a trace, or False to let the caller run it eagerly.

    Round 1 at a key runs eagerly and registers the key. Round 2 runs eagerly, makes the
    signature's shared buffers if they are new, and captures every registered key of that
    signature in one fence (`_rt_batch`). Later rounds copy in, replay and clone the input
    gradients out."""
    from .taped_ttnn import recompute_scope
    vals = [_rt_raw(t, home) for t in inputs]
    ks = [k for k, _ in seeded]
    sig = ("bwd",) + _rt_sig(vals, ((k, tuple(g.shape), str(g.dtype)) for k, g in seeded))
    st = _RTRACE.get((key, sig), 0)
    if st == "eager":
        return False
    device = next(v for v in vals if v is not None).device()

    if isinstance(st, tuple):
        sh = _RSHARED[sig]
        _rt_copy_in(vals, sh["ins"])
        _rt_copy_in([g for _, g in seeded], sh["seeds"])
        ttnn.execute_trace(device, st[0], cq_id=0, blocking=False)
        RTRACE_STATS["replay"] += 1
        if RTRACE_STATS["replay"] <= TRACE_RECOMPUTE_CHECK:
            _check_replay(key, fn, inputs, vals, seeded, sh["outs"])
        for src, ob in zip(inputs, sh["outs"]):
            if ob is not None and isinstance(src, Tensor):
                src.add_grad(ttnn.clone(ob))
        return True

    def eager():
        inner = [Tensor(v, requires_grad=t.requires_grad) if isinstance(t, Tensor) else t
                 for t, v in zip(inputs, vals)]
        with recompute_scope():
            y = fn(*inner)
        backward([y[k] if k is not None else y for k in ks], [g for _, g in seeded])
        return inner

    inner = _rt_first(device, sig, eager) if st == 0 else eager()
    grads = [_grad_value(d) for d in inner]
    for src, dup in zip(inputs, inner):
        if isinstance(src, Tensor) and isinstance(dup, Tensor) and dup.grad is not None:
            src.add_grad(dup.grad)
    RTRACE_STATS["eager"] += 1
    if st == 0:
        if not _in_dram([*vals, *grads]):
            _RTRACE[(key, sig)] = "eager"
            return True
        kinds = _rt_kinds(inputs)

        def make(sh):
            inner = _rt_inner(kinds, sh["ins"])
            with recompute_scope():
                y = fn(*inner)
            backward([y[k] if k is not None else y for k in ks], [ttnn.clone(b) for b in sh["seeds"]])
            for dup, ob in zip(inner, sh["outs"]):
                if ob is not None:
                    ttnn.copy(_grad_value(dup), ob)
            del y, inner
        _RPEND.setdefault(sig, {})[key] = make
        if TRACE_RECOMPUTE_CHECK:
            _RMODE[("key", key, sig)] = _mode()
        _RTRACE[(key, sig)] = 1
        return True
    if sig not in _RSHARED:
        _RSHARED[sig] = dict(ins=_rt_clone(vals), seeds=_rt_clone([g for _, g in seeded]),
                             outs=_rt_clone(grads))
    sh = _RSHARED[sig]
    _rt_copy_in(vals, sh["ins"])
    _rt_copy_in([g for _, g in seeded], sh["seeds"])
    del inner, grads
    _rt_batch(device, sig, sh)
    return True


def _traced_forward(key, fn, inputs):
    """A checkpoint's untaped forward ``fn(*inputs)`` from a trace, or the sentinel `_EAGER` to
    let the caller run it. The same rounds as `_traced_recompute`; the caller is under
    `no_grad`."""
    vals = [_rt_raw(t, lambda t: t.value) for t in inputs]
    sig = ("fwd",) + _rt_sig(vals)
    st = _RTRACE.get((key, sig), 0)
    if st == "eager":
        return _EAGER
    device = next(v for v in vals if v is not None).device()

    def flat(y):
        ys = y if isinstance(y, (tuple, list)) else (y,)
        return [o.value if isinstance(o, Tensor) else o for o in ys]

    if isinstance(st, tuple):
        sh = _RSHARED[sig]
        check = RTRACE_STATS["replay"] < TRACE_RECOMPUTE_CHECK
        pre = _rt_clone(flat(fn(*inputs))) if check else None
        _rt_copy_in(vals, sh["ins"])
        ttnn.execute_trace(device, st[0], cq_id=0, blocking=False)
        RTRACE_STATS["replay"] += 1
        outs = [None if ob is None else ttnn.clone(ob) for ob in sh["outs"]]
        if check:
            # Four readings on the same inputs separate the two ways a replay can be wrong:
            # replay != replay again means it read scratch another trace last wrote;
            # eager before != eager after means it wrote memory the eager side owns.
            _rt_copy_in(vals, sh["ins"])
            ttnn.execute_trace(device, st[0], cq_id=0, blocking=False)
            again = _rt_clone(sh["outs"])
            post, now = _ops(lambda: flat(fn(*inputs)))
            rel = lambda xs, ys: max([_rel(x, y) for x, y in zip(xs, ys) if x is not None and y is not None] or [0.0])
            r = dict(eager=rel(outs, post), again=rel(outs, again), drift=rel(pre, post), pre=rel(outs, pre))
            RTRACE_CHECKS.append(dict(key=repr(key), unit="fwd", replay=RTRACE_STATS["replay"], rel=[r["eager"]], **r))
            if max(r.values()) > 0:
                print(f"[trace-check] fwd replay {RTRACE_STATS['replay']} {key!r}: "
                      + " ".join(f"{k} {v:.3e}" for k, v in r.items()), flush=True)
                print(f"[trace-check]   mode at key {_RMODE.get(('key', key, sig))}, capture "
                      f"{_RMODE.get(('cap', key, sig))}, now {_mode()}", flush=True)
                if (key, sig) in _ROPS:
                    _ops_diff(key, _ROPS.pop((key, sig)), now)
        return tuple(outs) if _RSHAPE[sig] else outs[0]

    y = _rt_first(device, sig, lambda: fn(*inputs)) if st == 0 else fn(*inputs)
    RTRACE_STATS["eager"] += 1
    if st == 0:
        if not _in_dram([*vals, *flat(y)]):
            _RTRACE[(key, sig)] = "eager"
            return y
        _RSHAPE[sig] = isinstance(y, (tuple, list))
        kinds = _rt_kinds(inputs)

        def make(sh):
            inner = _rt_inner(kinds, sh["ins"])
            for o, ob in zip(flat(fn(*inner)), sh["outs"]):
                if ob is not None:
                    ttnn.copy(o, ob)
            del inner
        _RPEND.setdefault(sig, {})[key] = make
        if TRACE_RECOMPUTE_CHECK:
            _RMODE[("key", key, sig)] = _mode()
        _RTRACE[(key, sig)] = 1
        return y
    if sig not in _RSHARED:
        _RSHARED[sig] = dict(ins=_rt_clone(vals), outs=_rt_clone(flat(y)))
    sh = _RSHARED[sig]
    _rt_copy_in(vals, sh["ins"])
    _rt_batch(device, sig, sh)
    return y


def _rel(a, b) -> float:
    a, b = ttnn.to_torch(a).double(), ttnn.to_torch(b).double()
    den = float(b.norm())
    return float((a - b).norm()) / den if den else float((a - b).norm())


def _check_replay(key, fn, inputs, vals, seeded, outs) -> None:
    """Run the block eagerly on the replay's own inputs and record each gradient's error."""
    from .taped_ttnn import recompute_scope
    inner = [Tensor(ttnn.clone(v), requires_grad=t.requires_grad) if isinstance(t, Tensor)
             else (ttnn.clone(v) if v is not None else t) for t, v in zip(inputs, vals)]
    with recompute_scope():
        y = fn(*inner)
    roots = [y[k] if k is not None else y for k, _ in seeded]
    backward(roots, [ttnn.clone(g) for _, g in seeded])
    rels = []
    for dup, ob in zip(inner, outs):
        ref = _grad_value(dup) if isinstance(dup, Tensor) else None
        if ob is None or ref is None:
            continue
        a = ttnn.to_torch(ob).double()
        b = ttnn.to_torch(ref).double()
        den = float(b.norm())
        rels.append(float((a - b).norm()) / den if den else float((a - b).norm()))
    RTRACE_CHECKS.append(dict(key=repr(key), replay=RTRACE_STATS["replay"], rel=rels))
    if rels and max(rels) > 0:
        print(f"[trace-check] bwd replay {RTRACE_STATS['replay']} {key!r}: grad rel L2 {max(rels):.3e}", flush=True)
    del y, inner, roots


def release_recompute_traces(device) -> None:
    """Drop every recompute trace and its shared buffers; each key starts again at round 1.

    Called when something persistent is allocated mid-run (a trunk loading its weights): it would
    sit wherever the allocator then found room, which may be a capture's intermediates."""
    for st in _RTRACE.values():
        if isinstance(st, tuple):
            ttnn.release_trace(device, st[0])
    for sh in _RSHARED.values():
        for b in (*sh["ins"], *sh.get("seeds", ()), *sh["outs"]):
            if b is not None:
                ttnn.deallocate(b)
    _RTRACE.clear()
    _RSHARED.clear()
    _RSHAPE.clear()
    _RPEND.clear()
    if _SCRATCH[0] is not None:
        _SCRATCH[0].release()
        _SCRATCH[0] = None


def checkpoint(fn, *inputs: Tensor, params: Sequence[Tensor] = (), offload: bool = False,
               _nested: bool = False, trace=None) -> Tensor:
    """Run ``fn`` untaped, and re-run it taped inside its own backward.

    Trades one extra forward for dropping every intermediate ``fn`` produced. The
    feasibility study called per-block checkpointing mandatory for a 48-block trunk; the
    measurement is sharper than that. ONE pairformer block at 512 aa with c_z=256 exhausts
    all 34.23 GB without it (perf/hallgrad/e2e_distogram.py at --n 512 dies in
    bank_manager.cpp:439 with 34.0 GB allocated and 0.03 GB free), because a tape retains
    both every op's saved intermediate AND a gradient per op. So checkpointing is not an
    optimisation that buys depth, it is what makes a single block fit.

    ``inputs`` are re-taped as duplicates, so their gradients arrive on the duplicates and
    are forwarded. Parameters ``fn`` closes over need no duplication: they are LEAVES, so
    the recomputed tape calls ``add_grad`` on the original objects and the gradient lands
    where it belongs without any plumbing.

    ``params`` therefore exists for one reason, and it is not plumbing -- it is the
    PRUNING decision. ``_tape`` only builds a node when some parent requires a gradient,
    so a checkpointed segment whose input is frozen (the first adapted block, reading a z
    the production path produced) would get NO node, its backward would never run, and
    every weight gradient inside it would be silently absent. Naming the parameters as
    parents is what keeps that from happening. Fine-tuning is exactly the case where the
    input can be frozen while the weights are not, so the old signature was correct for
    hallucination and wrong here.

    ``offload`` moves the pinned inputs to host memory once the forward has read them and
    brings them back for the recompute. It is for a chain of segments, each fed the previous
    one's output, where nothing but the next segment reads an input: it frees one segment
    input of device memory per segment for one download and one upload of it.

    ``_nested`` is `substep`'s: a segment taken inside another one's recompute. Its pins are
    not the run's to release, because the enclosing recompute drops its whole inner tape
    the moment its backward is done, and parking them on `_CKPT_PINS` would keep every
    sub-module input of every block alive to the end of the backward.
    """
    # PIN the inputs across the untaped forward. A shipped block deallocates the tensor it was
    # handed the moment it has read it -- that is what the tuned forward is -- and under
    # `no_grad` nothing on the tape objects, so the segment frees its own input and the
    # recompute later reads a dead buffer: "Buffer is not allocated", raised inside the
    # BACKWARD from a free issued in the forward. Pinning is exactly `free`'s existing
    # mechanism: a pinned tensor is evicted to DRAM rather than released, so the block's
    # tuning still gets its L1 place back and the recompute still gets its value. The pin
    # outlives the forward because the recompute happens in the backward.
    held = [t for t in inputs if isinstance(t, Tensor)]
    for t in held:
        t.pinned = True
        if not _nested:
            _CKPT_PINS.append(t)
    _TOUCHED.clear()
    with no_grad():
        produced = _EAGER
        if trace is not None and TRACE_FORWARD and not offload and params is not _ALL_PARAMS:
            produced = _traced_forward(trace, fn, inputs)
        if produced is _EAGER:
            produced = fn(*inputs)
    # Only the parameters this segment READ. Naming all of them would give every block a node,
    # including the ones that touch no trainable weight, and those recompute to an empty tape.
    touched = [t for k, t in _PARAMS.items() if k in _TOUCHED] if params is _ALL_PARAMS \
        else list(params)
    _TOUCHED.clear()
    parents = list(held) + touched

    def _recompute(seeded):
        """Re-run the segment on fresh nodes over the same input VALUES and replay its tape
        ONCE, seeding every output in `seeded`, a list of (output index or None, gradient)."""
        from .taped_ttnn import recompute_scope
        if trace is not None and TRACE_RECOMPUTE and _traced_recompute(
                trace, fn, inputs, _home, seeded):
            return
        inner = [Tensor(_home(t), requires_grad=t.requires_grad) if isinstance(t, Tensor) else t
                 for t in inputs]
        with recompute_scope():
            y = fn(*inner)
        roots = [y[k] if k is not None else y for k, _ in seeded]
        if any(r.node is None for r in roots):
            raise RuntimeError("checkpoint(fn): the recomputed segment built no tape; fn must "
                               "use taped ops and at least one input must require a gradient")
        backward(roots, [g for _, g in seeded])
        for src, dup in zip(inputs, inner):
            if isinstance(src, Tensor) and isinstance(dup, Tensor) and dup.grad is not None:
                src.add_grad(dup.grad)
        # The inner tape is a plain DAG (`_share` holds storage groups weakly), so dropping the
        # names below frees it here, at the refcount. It once took a `gc.collect()` per
        # recompute, 0.16 s each in a process holding AF2, and then a walk that cleared the
        # groups it could reach from the roots -- which missed every group off that path.
        del y, inner, roots

    # Where each offloaded input lives on the card, by identity. Filled after the outputs are
    # taped, so `_tape`'s view test still sees the inputs on the card.
    homes: dict = {}

    def _home(t):
        home = homes.get(id(t))
        return t.value if home is None else ttnn.to_device(t.value, home[0], home[1])

    def _offload(out):
        if offload:
            for t in held:
                home = _to_host(t)
                if home is not None:
                    homes[id(t)] = home
        return out

    if not isinstance(produced, (tuple, list)):
        return _offload(_tape(produced.value if isinstance(produced, Tensor) else produced,
                              parents, lambda: (lambda g: _recompute([(None, g)]))))

    # A segment with SEVERAL outputs, which is what a real block is: a `PairformerLayer`
    # returns the pair (s, z) and the single-output form cannot express it.
    #
    # One node per output, all in one `group`: each output's closure deposits its gradient, and
    # `backward` fires the group once, after the last of its members on the walk, so the segment
    # is recomputed and replayed ONCE with every seed. It used to be once per output, which is
    # exact (the derivative through a shared ancestor is the sum over the output paths) and cost
    # the whole recompute again: on AF2's two-output Evoformer block that was a second taped
    # forward, a second inner backward and a second collect per block.
    seeds = [None] * len(produced)

    def fire():
        seeded = [(k, g) for k, g in enumerate(seeds) if g is not None]
        seeds[:] = [None] * len(seeds)
        if seeded:
            _recompute(seeded)

    outs = []
    for k, prod in enumerate(produced):
        if prod is None:
            outs.append(None)
            continue
        out = _tape(prod.value if isinstance(prod, Tensor) else prod, parents,
                    (lambda k=k: (lambda g: seeds.__setitem__(k, g))))
        if out.node is not None:
            out.node.group = fire
        outs.append(out)
    return _offload(tuple(outs))


# ---------------------------------------------------------------------------------------
# The attach point.
#
# `tt_bio/ops.py` is the one linear and layer-norm call every device module makes, and it
# offers each call to a hook before running it. This is that hook, and installing it is the
# whole of what makes the SHIPPED forward differentiable -- there is no taped copy of a
# production module to drift from what we serve.
#
# `ops` holds a slot and `install` fills it. Nothing under `tt_bio/` imports this module, so
# importing `tt_bio` cannot reach the tape and an inference path that never calls `install`
# pays one `is None` test per linear.
#
# Three things the hook does that a substitution could not, each of them a measured gap:
#
#   * It declines outright when no operand is on the tape, so the call is the shipped one,
#     byte for byte, including the tuned narrow-projection and L1-resident-norm routings.
#   * It runs the SHIPPED op, not the composite one, for an operand that is on the tape but
#     not being differentiated -- under `no_grad`, or for a frozen block in a fine-tune.
#     `_GRAD_ENABLED` alone cannot do this: it prunes the tape node after the caller has
#     already computed the forward.
#   * It forwards `dtype`, `core_grid` and the site's own compute kernel config and epsilon,
#     all four of which the tape's ops used to drop.
#
# With `layer_norm` now running `ttnn.layer_norm` in the forward and recomputing mean and
# rstd in the backward, the taped forward is the production forward op for op. The one
# remaining difference is a fused activation, which is composed rather than fused because
# `ttnn.linear` fuses into the packer and silu's output cannot be inverted. That is measured,
# not assumed, and it only exists where a gradient is actually wanted.
# ---------------------------------------------------------------------------------------

_ACTIVATIONS = {"relu": relu, "sigmoid": sigmoid, "silu": silu}


def _activation(a):
    """The composed backward for a fused `activation`: a name, or a `ttnn.UnaryWithParam` such as the
    `dit_sigf32` epilogue (`tenstorrent._SIGMOID_F32`, an approx-mode SIGMOID on an fp32 dest). Its params only
    choose how the packer evaluates the function, so the derivative is the plain one; what composing instead of
    fusing costs in the forward is measured by gradcheck like any other activation's."""
    if isinstance(a, str):
        return _ACTIVATIONS.get(a)
    op = getattr(a, "op_type", None)
    return _ACTIVATIONS.get(op.name.lower()) if op is not None else None


# Wrappers built over raw ttnn handles the CALLER still owns, keyed by the handle's id.
# Cleared when the tape closes; the wrapper holds the handle, so the id cannot be reused
# while the entry is live.
_WRAPPED: dict = {}


# Weights a caller has declared TRAINABLE, keyed by the raw handle's id. Distinct from
# `_WRAPPED`, which is bookkeeping the tape does for itself and drops when the tape closes:
# this one is the user's parameter set and outlives a tape, because the optimizer holds it.
#
# It exists because the two seams did not meet. `tt_bio.train.lora.weights_for` censuses
# `ops.linear` sites, and the shipped pairformer routes none of its calls through `ops.linear`
# (LEDGER K3) -- it calls `ttnn.linear`, which `taped_ttnn` covers. But that surface
# short-circuits to the shipped op when no ARGUMENT is already a `Tensor`, and a weight the
# caller wants to train arrives as a raw handle among raw handles, so the short circuit fired
# first and the parameter was never seen. A model could therefore be fully differentiable and
# still have no trainable weight. Registering here is what makes a raw weight a leaf at all 331
# taped calls rather than at the four routed ones.
_PARAMS: dict = {}


def parameter(raw, requires_grad: bool = True):
    """Declare a device weight trainable. Idempotent per handle; returns the leaf.

    The leaf, not a copy: `_wrap` hands the same object to every call site that reads this
    weight, so a 48-block trunk sharing one tensor accumulates into one gradient.

    Nothing is owed after an optimizer step. `AdamW.step` replaces `t.value` with a fresh
    device tensor, and `Tensor.value`'s setter carries this registration onto the new handle,
    so the leaf keeps resolving. It was not always so: the duty used to be documented here
    and owed by the caller, no caller in this tree performed it, and the result was a run
    whose second step had no gradients at all. Passing the LEAF back is still accepted and
    still re-keys; passing a bare `t.value` would mint a SECOND leaf over the same weight.
    """
    if isinstance(raw, Tensor):
        _PARAMS[id(raw.value)] = raw
        return raw
    t = _PARAMS.get(id(raw))
    if t is not None and t.value is raw:
        return t
    t = Tensor(raw, requires_grad=requires_grad)
    _PARAMS[id(raw)] = t
    return t


def forget_parameters() -> None:
    """Drop the trainable set. A run owns it; nothing here survives the run."""
    _PARAMS.clear()


# True only at the OUTERMOST taped call. A taped verb computes its value by calling the
# SHIPPED verb, and the shipped verb is sometimes itself a tt-bio function whose body calls
# `ttnn` -- `ops.linear`'s fallback is literally `ttnn.linear`, and inside `tt_bio.ops` that
# name is the shim. With a registered parameter among the operands, that re-entrant call would
# tape a SECOND time and hand the outer verb a `Tensor` where it expects a raw handle, so the
# outer `_tape` wraps a wrapper and the next op gets an `autograd.Tensor` as a pybind argument.
# Observed exactly once, as `ttnn.matmul(): incompatible function arguments ... invoked with
# (ttnn.Tensor, tt_bio.autograd.Tensor)` from the denoiser's atom decoder. Activations do not
# have this problem because the inner call sees them already unwrapped; a parameter is
# recognised by IDENTITY of a raw handle, which unwrapping cannot hide. So the lookup is
# switched off for the duration of a verb, and `_wrap` is deliberately NOT gated: the outer
# verb still resolves the parameter to its leaf, which is the whole point.
_PARAM_SCAN = True


class _no_param_scan:
    """Suppress parameter lookup for the duration of one taped verb's shipped call."""

    def __enter__(self):
        global _PARAM_SCAN
        self._prev = _PARAM_SCAN
        _PARAM_SCAN = False

    def __exit__(self, *exc):
        global _PARAM_SCAN
        _PARAM_SCAN = self._prev
        return False


# Which parameters a stretch of forward actually read. `checkpoint` needs it: a 48-block trunk
# where only the last block's weights are trainable would otherwise name every registered
# parameter as a parent of every block, so every block gets a node, and 47 of those nodes
# recompute a segment that touches no parameter and builds no tape.
_TOUCHED: set = set()


def parameter_for(raw):
    """The leaf `parameter()` registered over this raw handle, or `None`.

    The public form of the one question every coverage check asks: is the tensor the MODEL
    holds a thing the tape can hand a gradient to? A check that reaches into `_PARAMS`
    directly is a check that stops agreeing with the tape the first time the tape changes.

    A pure query: unlike `_param` it does not record the handle as touched, so asking cannot
    change what `checkpoint` decides to recompute.
    """
    t = _PARAMS.get(id(raw))
    return t if t is not None and t.value is raw else None


def _param(v):
    t = _PARAMS.get(id(v))
    if t is not None and t.value is v:
        _TOUCHED.add(id(v))
        return t
    return None


def _param_on_tape(v):
    return _param(v) if _PARAM_SCAN else None


def _wrap(t):
    """A raw ttnn tensor joins the tape as an untracked leaf; a `Tensor` passes through.

    The wrapper is REMEMBERED, and that is not bookkeeping for its own sake. A raw handle
    can reach a taped op as one operand among taped ones -- the shipped attention does it
    twice, `batched_matmul(probs, v)` at `tenstorrent.py:8209` and the gate multiply at
    `:8290`, where the pair track is taped and the single track is not. The tape wraps and
    pins the raw operand, but the pin is invisible to the caller, which still holds the raw
    handle and deallocates it three lines later. The buffer goes, and the throw arrives
    much later inside the backward: "Buffer is not allocated" in a sigmoid, in a module
    whose forward completed cleanly. `deallocate` consults this map so a raw handle the
    tape has wrapped is routed through `Tensor.free` and respects the pin.
    """
    if t is None or isinstance(t, Tensor):
        return t
    p = _param(t)
    if p is not None:
        return p
    w = _WRAPPED.get(id(t))
    if w is not None and w.value is t:
        # Idempotent per handle. Wrapping the same raw tensor twice would give the tape a
        # pinned parent and the caller's deallocate a DIFFERENT, unpinned wrapper over the
        # same buffer, and the unpinned one takes the release branch.
        return w
    w = Tensor(t)
    _WRAPPED[id(t)] = w
    return w


def wrapper_for(raw):
    """The `Tensor` the tape built over this raw handle, if it built one."""
    w = _WRAPPED.get(id(raw))
    return w if w is not None and w.value is raw else None


def forget_wrappers() -> None:
    """Drop the raw-handle map. Called when a tape closes; nothing survives it."""
    _WRAPPED.clear()


def _unwrap(t):
    return t.value if isinstance(t, Tensor) else t


def _walk(args, kwargs):
    for vs in (args, kwargs.values()):
        for v in vs:
            if isinstance(v, (list, tuple)):
                yield from v
            else:
                yield v


def _on_tape(args, kwargs):
    # A registered parameter counts, even though it arrives as a raw handle: it is the first
    # taped thing in a forward whose inputs are all data, and without it the short circuit
    # below reaches the shipped op and the whole downstream chain is never taped.
    #
    # `_walk` spelled out, because every ttnn call under a tape comes through here (~64k per
    # BC2 step) and the generator plus two list copies were most of its cost. Same operands in
    # the same order, same short circuit, so `_param` touches exactly what it touched before;
    # with nothing registered it can only answer None, and it is not asked.
    scan = _PARAM_SCAN and bool(_PARAMS)
    for vs in (args, kwargs.values()):
        for v in vs:
            if isinstance(v, (list, tuple)):
                for u in v:
                    if isinstance(u, Tensor) or (scan and _param(u) is not None):
                        return True
            elif isinstance(v, Tensor) or (scan and _param(v) is not None):
                return True
    return False


def _differentiating(args, kwargs):
    if not _GRAD_ENABLED:
        return False
    scan = _PARAM_SCAN and bool(_PARAMS)
    for vs in (args, kwargs.values()):
        for v in vs:
            for u in (v if isinstance(v, (list, tuple)) else (v,)):
                if isinstance(u, Tensor):
                    if u.requires_grad:
                        return True
                elif scan:
                    p = _param(u)
                    if p is not None and p.requires_grad:
                        return True
    return False


def _deep_unwrap(v):
    if isinstance(v, (list, tuple)):
        return type(v)(_unwrap(u) for u in v)
    return _unwrap(v)


def _raw(args, kwargs):
    return ([_deep_unwrap(v) for v in args],
            {k: _deep_unwrap(v) for k, v in kwargs.items()})


def untaped(shipped, args, kwargs, wrap: bool = True):
    """`shipped` on RAW operands. What a listening hook must do instead of declining.

    A hook that returns `None` falls through to the production op, which is a ttnn pybind and
    refuses an `autograd.Tensor`: `ttnn.layer_norm(): incompatible function arguments ... called
    with (tt_bio.autograd.Tensor, ...)`. That TypeError is what stopped `lora.weights_for` from
    completing a census over a triangle multiplication, and a census that cannot complete over
    the modules that matter most reports zero adaptable sites and reads as a clean result.

    Returns `None` when no operand is a `Tensor`, so a hook may use this AS its decline: there
    is nothing to unwrap and production's own call is the right one.

    `wrap=False` hands back production's own raw result. A listener wants that: wrapping would
    put a taped operand into the next raw `ttnn` call the listener never sees, which is the same
    TypeError one op later, and a census has to compute exactly what an inference pass computes.
    """
    if not any(isinstance(v, Tensor) for v in _walk(args, kwargs)):
        return None
    ra, rk = _raw(args, kwargs)
    with _no_param_scan():
        out = shipped(*ra, **rk)
    return Tensor(out) if wrap else out


def _taped_linear(shipped, args, kwargs):
    """`ops.linear` with a gradient. The VALUE comes from `shipped`, never recomputed here."""
    args = list(args) + [None] * (3 - len(args))
    x, w, bias = (_wrap(args[0]), _wrap(args[1]), _wrap(args[2]))
    if bias is None and "bias" in kwargs:
        bias = _wrap(kwargs["bias"])
    kw = {k: v for k, v in kwargs.items() if k != "bias"}
    activation = kw.pop("activation", None)
    act = None
    if activation is not None:
        act = _activation(activation)
        if act is None:
            raise NotImplementedError(
                f"tt_bio.autograd has no backward for the fused activation {activation!r}. "
                f"Add one to _ACTIVATIONS -- dropping it would train against a forward we do "
                f"not serve.")
    cfg = kw.pop("compute_kernel_config", None)
    # The activation is composed rather than fused, because `ttnn.linear` fuses it into the
    # packer and silu's output cannot be inverted back to its input. That is a real deviation
    # of the training forward from the served one, and it is measured, not assumed away.
    out_v = shipped(x.value, w.value, bias=(bias.value if bias is not None else None),
                    activation=None, compute_kernel_config=cfg, **kw)
    cfg = cfg or precise_config()
    bwcfg = precise_config()
    parents = [t for t in (x, w, bias) if t is not None]
    xshape, wshape = x.value.shape, w.value.shape

    def make():
        def bw(g):
            if x.requires_grad:
                # dX reduces over the OUTPUT channel -- 128 to 512 terms -- and is
                # activation-shaped, so it stays in the forward dtype.
                # `_reduce_to` because a matmul normalises rank: an x of (1, N, N, c)
                # comes back as (N, N, c) and `add_grad` refuses a gradient that is not
                # its value's shape, correctly.
                x.add_grad(_reduce_to(_via2d(g, lambda v: _pair_mm_or(
                                          v, w.value, True, lambda: _matmul(
                                              v, w.value, transpose_b=True,
                                              compute_kernel_config=bwcfg), bwcfg)),
                                      xshape))
            if w.requires_grad:
                # dW reduces over every token at once: 4096 terms on a 64x64 pair block,
                # 262144 at 512 aa. `fp32_dest_acc_en` does not cover that, because
                # `packer_l1_acc` accumulates the per-K-block partials at the OUTPUT
                # dtype, so a bf16 result means a bf16 running sum however precise the
                # destination register is. Measured on the shipped Transition: 6.5e-02
                # relative L2 at K=4096 against 6.5e-03 at K=64, the sqrt(K) signature of
                # a bf16 reduction. Asking for fp32 out fixes it and costs nothing that
                # matters -- a weight gradient is weight-shaped, and the optimiser wants
                # it in fp32 anyway.
                w.add_grad(_reduce_to(
                    _matmul(_flat2d(x.value), _flat2d(g), transpose_a=True,
                            compute_kernel_config=bwcfg, dtype=ttnn.float32),
                    wshape))
            if bias is not None and bias.requires_grad:
                bias.add_grad(_sum_leading(g, bias.value.shape))
        return bw

    out = _tape(out_v, parents, make, reads=_cross_reads(x, w))
    if act is None:
        return out
    activated = act(out)
    # The pre-activation is now read only by the activation's own backward, which reads it
    # through its `Tensor`. Production never materialises it at all -- `ttnn.linear` fuses
    # the activation into the packer -- so leaving it in the L1 the site asked for is the
    # tape holding a tensor the tuning did not budget. Hand its PLACE back; `free` evicts
    # to DRAM rather than releasing it, because the backward still needs the value.
    out.free()
    return activated


def _taped_layer_norm(shipped, args, kwargs, center=True):
    """`ops.layer_norm` with a gradient. The VALUE comes from `shipped`.

    `l1_headroom` is dropped on purpose. It asks for an L1-resident RESULT, and a backward
    holding a tape's worth of activations cannot be priced against a budget sized for one
    tensor. It is a placement lever and not a numeric one -- the values `ttnn.layer_norm`
    computes do not depend on where it writes them -- so the forward stays bit-identical to
    production either way.
    """
    args = list(args) + [None] * (3 - len(args))
    x, gamma, beta = (_wrap(args[0]), _wrap(args[1]), _wrap(args[2]))
    kw = dict(kwargs)
    for nm, slot in (("weight", 1), ("bias", 2)):
        if kw.get(nm) is not None:
            v = _wrap(kw.pop(nm))
            gamma, beta = (v, beta) if slot == 1 else (gamma, v)
        else:
            kw.pop(nm, None)
    kw.pop("l1_headroom", None)
    eps = kw.pop("epsilon", 1e-5)
    cfg = kw.pop("compute_kernel_config", None)
    if kw.get("residual_input_tensor") is not None:
        raise NotImplementedError(
            "tt_bio.autograd has no backward for a norm with a fused residual_input_tensor; "
            "the tape would drop the residual's gradient. Add it, do not strip it.")
    xv = x.value
    out_v = shipped(xv, weight=(gamma.value if gamma is not None else None),
                    bias=(beta.value if beta is not None else None),
                    epsilon=eps, compute_kernel_config=cfg, **kw)
    bwcfg = precise_config()
    parents = [t for t in (x, gamma, beta) if t is not None]

    def make():
        return _layer_norm_bw(x, gamma, beta, eps, bwcfg, center=center)

    return _tape(out_v, parents, make)


def _taped_rms_norm(shipped, args, kwargs):
    """``ttnn.rms_norm`` with a gradient: the layer norm's entry with the centring off.

    The forward is the shipped kernel with the site's own arguments, so it is production's
    value byte for byte. RFD4 issues it at every AdaLN, QK norm and recycle norm; ESMFold2
    and RFD3 issue the same verb.
    """
    return _taped_layer_norm(shipped, args, kwargs, center=False)


_TAPED = {"linear": _taped_linear, "layer_norm": _taped_layer_norm}


def _hook(name, shipped, args, kwargs):
    """`tt_bio.ops`'s grad hook. Returns None to decline, which falls through to production."""
    if not _on_tape(args, kwargs):
        return None
    if not _differentiating(args, kwargs):
        # On the tape but frozen, or inside `no_grad`: the SHIPPED op, then rewrapped.
        ra, rk = _raw(args, kwargs)
        with _no_param_scan():
            return Tensor(shipped(*ra, **rk))
    impl = _TAPED.get(name)
    if impl is None:
        raise NotImplementedError(
            f"tt_bio.ops.{name} has no taped implementation. Add one to "
            f"tt_bio.autograd._TAPED; declining here would silently drop the gradient.")
    with _no_param_scan():
        return impl(shipped, args, kwargs)


# What `ops.recording()` asks under `NOGRAD_IS_INFERENCE`: a forward inside `no_grad` records
# nothing. `raw` is how `ops.fused_kernel` hands such a forward's kernel its operands.
_hook.recording = is_grad_enabled
_hook.raw = lambda args, kwargs: _raw(args, kwargs)
# What `ops.declines_under_tape` asks of a kernel's operands: the shim's own test, registered
# parameters included, so a kernel declines exactly where the stock op would be taped.
_hook.on_tape = lambda args, kwargs: _on_tape(args, kwargs)


def _checkpoint_segment(fn, *inputs):
    """`ops.checkpoint_segment`'s implementation: checkpoint a block, or just run it.

    Run it plainly whenever a tape could not use the trade -- grad off, nothing on the tape and
    no registered parameter. Under a tape it is not an optimisation that buys depth, it is what
    makes the thing fit: at 384 aa the composed backward exhausted all 34.23 GB of the card
    without it, and `ptx-crop` measured the same trunk WITH per-block checkpointing at 7.762 GB.
    """
    if not _GRAD_ENABLED:
        return fn(*inputs)
    live = [t for t in inputs if isinstance(t, Tensor) and t.requires_grad]
    if not live and not _PARAMS:
        return fn(*inputs)
    return checkpoint(fn, *inputs, params=_ALL_PARAMS)


def _install_hooks():
    """The four hooks, and nothing else. What `tape()` re-arms on every entry. Returns the four
    it replaced, in `_restore_hooks` order."""
    from . import ops
    # A recycling model asks `ops.recycle_region` whether a non-final cycle is differentiated.
    # Installed together with the verb hook because the two are the same opt-in.
    return (ops.set_recycle_hook(no_grad),
            ops.set_checkpoint_hook(_checkpoint_segment),
            # The host float64 softmax a construction site may select. Injected rather than
            # imported, so `tt_bio/tenstorrent.py` can offer the lever without reaching the tape.
            ops.set_host_softmax_hook(host_f64_softmax),
            ops.set_grad_hook(_hook))


def _restore_hooks(prev):
    """Put back what `_install_hooks` replaced. A checkpoint hook left behind sends a later
    inference forward through `checkpoint`, which hands raw ttnn verbs an `autograd.Tensor`."""
    from . import ops
    recycle, ckpt, host_softmax, grad = prev
    ops.set_recycle_hook(recycle)
    ops.set_checkpoint_hook(ckpt)
    ops.set_host_softmax_hook(host_softmax)
    ops.set_grad_hook(grad)


# What each open `install()` armed, innermost last, so `uninstall()` takes out exactly what its
# own `install()` put in. Pairing by nesting rather than by an owner name: an owner name is the
# same literal for every caller, and an unrelated pair closing first then tore down a lever it
# never armed (measured: PKG_HF3 came back the device-softmax control to sixteen digits).
_INSTALL_EXACT: list = []


def install(*, exact_softmax: bool = False):
    """Route `tt_bio.ops` through the tape, and run softmax and layer norm exact until the
    matching `uninstall()` (`exact_training`). Returns the hook it replaced.

    This is the narrow seam -- two verbs. `tape()` is the whole shipped forward.

    The exact ops are scoped to the install and not only to a tape because the training stack
    runs forwards outside any tape that the step then depends on: `walked_weights`' discovery
    forward is `install()` plus `no_grad`, and the fused-softmax tail learns its L1 row caps
    from whatever it runs first. With discovery on the device ops the trunk step's gradient
    came back 1958 of 2736 tensors off of3t-stackexact's arm (`perf/of3t_stackship/`).

    `exact_softmax` also arms the exact softmax inside `exact_training(False)`.
    """
    ops_ = exact_training_ops()
    if exact_softmax and "softmax" not in ops_:
        ops_ = ops_ + ("softmax",)
    _INSTALL_EXACT.append(_install_exact(ops_, "install"))
    return _install_hooks()[-1]


def uninstall(*, exact_softmax: bool = False) -> None:
    """Put the inference path back. Idempotent: an `uninstall()` with no open `install()` only
    clears the hooks. `exact_softmax` is accepted for symmetry with `install()`; the pairing is
    by nesting, so an inner install/uninstall pair never disarms what an outer one armed.
    """
    from . import ops
    ops.set_recycle_hook(None)
    ops.set_checkpoint_hook(None)
    ops.set_host_softmax_hook(None)
    if _INSTALL_EXACT:
        _uninstall_exact(_INSTALL_EXACT.pop())
    ops.set_grad_hook(None)


def installed() -> bool:
    from . import ops
    return ops.grad_hook() is _hook


# The taped ttnn surface lives in `taped_ttnn.py`, not here: `state/ptx/DESIGN.md` §6 puts
# this file under `ptx-unify` and the surface under `ptx-fastpath`, and they are genuinely
# different things -- this module is the tape, that one is how the shipped modules reach it.
# Re-exported because `tt_bio.autograd.tape()` is the one entry point a caller should need.
def tape():
    """Make the shipped forward differentiable for the duration of the block.

        with tt_bio.autograd.tape():
            out = model(x)          # the production module, the production kernels
        out.backward()

    See `tt_bio.taped_ttnn.tape` for what it does and what it deliberately does not.
    """
    from .taped_ttnn import tape as _tape_cm
    return _tape_cm()

