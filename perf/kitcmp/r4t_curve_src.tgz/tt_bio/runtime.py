"""Tiny runtime primitives used by the scheduler and CLI.

PredictionJob is one input file the user asked us to predict; WorkerSlot is
one accelerator we can run it on. Discovery and detection helpers live here
so they can be reused from both the CLI and the worker subprocess.
"""

from __future__ import annotations

import contextlib
import glob
import os
import subprocess
import re
import socket
import time
from dataclasses import dataclass
from pathlib import Path

from tt_bio.envflags import env_flag


INPUT_SUFFIXES = (".fa", ".fas", ".fasta", ".yml", ".yaml")

HOST_THREAD_VARS = ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS",
                    "NUMEXPR_NUM_THREADS")

# The per-worker thread share at or below which parking idle pool threads beats spinning them.
# Not derived: measured on whglx (64 hardware threads, 32 Wormhole chips) as paired active/passive
# arms of Boltz-2 512 aa run back to back in one session, each at the share this module's own
# arithmetic hands that width. Passive over active, folds per hour:
#
#     share 4 (width 16)  0.993     share 3 (width 20)  0.990
#     share 2 (width 24)  1.004     share 2 (width 32)  1.014, and 1.016 on a repeat
#
# A repeat of the width-32 pair puts the same-config floor at 0.35 %, so the sign really does flip
# between three threads and two: with three a parked thread's wake latency costs more than the
# core it frees, with two there is no spare core to absorb the spinning in the first place.
IDLE_PARK_THREAD_SHARE = 2

# What a worker gets instead of spinning when the box is oversubscribed. Idle OpenMP pool threads
# busy-wait by default, which is free while cores are spare and pure contention once they are not:
# a fold blocks on ~200 per-step device syncs and spins through every one of them.
IDLE_THREADS_PARK = {"OMP_WAIT_POLICY": "PASSIVE", "GOMP_SPINCOUNT": "0", "KMP_BLOCKTIME": "0"}


# tt-metal ships the OpenMPI it wants (ttnn.libs/libmpi-*.so.40) and single-host prediction
# needs no MPI setup of yours. A host OpenMPI on the environment does not replace that build, it
# poisons it: OMPI_MCA_pml=ucx names a component the bundled build does not contain, so
# MPI_Init_thread aborts on a NULL communicator before any Python runs. That is moritztng/tt-bio#12
# -- a 4.1.6 under ~/opt/mpi-stack, exported from a shell rc, cost the reporter hours because the
# abort went to a worker's /dev/null.
#
# So warn, and never scrub. The variables may belong to a job the user means to run in this shell,
# and a tool that silently unsets someone's MPI configuration is worse than one that names it.
MPI_UNSET_HINT = "unset OMPI_MCA_pml OMPI_MCA_plm OPAL_PREFIX LD_LIBRARY_PATH"

# The one MPI setting tt-bio does make. The bundled build starts its tcp BTL at device open, and that
# listener binds 0.0.0.0 on a port from 1024 up for the life of the process, whatever
# btl_tcp_if_include says. One process per card on one host never sends a byte over it: a lone rank
# talks to itself through "self" and to a sibling rank through "sm". So the tcp BTL is left out. It is
# a default, not a scrub: an OMPI_MCA_btl already in the environment wins.
LOCAL_MPI_ENV = {"OMPI_MCA_btl": "^tcp"}


def keep_mpi_local(env: dict | None = None) -> None:
    """Default the bundled MPI to on-host transports, so a fold opens no LAN listener."""
    env = os.environ if env is None else env
    for key, value in LOCAL_MPI_ENV.items():
        env.setdefault(key, value)


def _bundled_mpi_root() -> Path | None:
    """The ttnn package directory, whose libmpi is the one we want. None if ttnn is absent.

    Found from the import spec rather than by importing: this runs on the CLI's host process,
    where importing ttnn costs seconds and opens nothing we asked for.
    """
    try:
        import importlib.util

        spec = importlib.util.find_spec("ttnn")
    except Exception:                                                  # noqa: BLE001
        return None
    origin = getattr(spec, "origin", None) if spec else None
    return Path(origin).parent if origin else None


def conflicting_mpi_env(env: dict | None = None) -> list[str]:
    """Host OpenMPI settings in `env` that can abort tt-metal's bundled MPI, or []."""
    env = os.environ if env is None else env
    found = []
    mca = sorted(k for k in env if k.startswith("OMPI_MCA_") and env[k] != LOCAL_MPI_ENV.get(k))
    if mca:
        found.append(", ".join(f"{k}={env[k]}" for k in mca))
    if env.get("OPAL_PREFIX"):
        found.append(f"OPAL_PREFIX={env['OPAL_PREFIX']}")
    bundled = _bundled_mpi_root()
    for entry in env.get("LD_LIBRARY_PATH", "").split(os.pathsep):
        if not entry:
            continue
        d = Path(entry)
        if bundled is not None and (d == bundled or bundled in d.parents):
            continue
        try:
            libs = sorted(p.name for p in d.glob("libmpi.so*"))
        except OSError:
            continue
        if libs:
            found.append(f"{libs[0]} on LD_LIBRARY_PATH at {d}")
    return found


def mpi_env_warning(found: list[str]) -> str:
    """The warning `found` deserves. Names what was seen and what to run; changes nothing."""
    return ("a host OpenMPI is configured here: " + "; ".join(found)
            + ".\ntt-metal ships its own and single-host prediction needs none of yours; a "
            "foreign one can abort MPI_Init before Python starts. If a fold dies at startup, "
            "clear them for this shell:\n    " + MPI_UNSET_HINT
            + "\nNothing has been changed for you.")


def seed_everything(seed: int) -> None:
    """Seed every RNG a pipeline draws from: python, numpy and torch (all devices).

    RDKit's conformer embedding reads the python and numpy RNGs, not torch's, so a
    torch-only seed leaves reference conformers different run to run.
    """
    import random

    import numpy as np
    import torch

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def host_thread_cap(n_workers: int, host_threads: int | None = None) -> int:
    """Per-worker host thread budget for a process driving ``n_workers`` cards.

    Each worker's torch/OMP/BLAS pools otherwise default to ALL cores, so N
    co-resident workers spawn N*cores threads that thrash the CPU and collapse the
    host-side work (weight load, featurization, output) -- the multi-card slowdown.
    ``host_threads`` is this PROCESS's share of the host CPU, defaulting to every
    core. All-cores is right for one process driving the whole box, but wrong when an
    external launcher runs one single-card job per chip: each process then sees
    n_workers == 1 and claims all cores. Such a launcher passes
    ``cores // concurrent_jobs``.
    """
    budget = host_threads if host_threads and host_threads > 0 else (os.cpu_count() or 1)
    return max(1, budget // max(1, n_workers))


def host_thread_cap_env(n_workers: int, host_threads: int | None = None) -> dict[str, str]:
    """Thread-cap environment for a spawned per-card child.

    Explicit beats inherited: a passed ``host_threads`` overrides a pre-set env var
    (the launcher knows how many siblings it started), while the default only fills in
    what the operator left unset.

    When the split leaves a worker ``IDLE_PARK_THREAD_SHARE`` threads or fewer the
    children are also told to park idle pool threads rather than spin on them. At 512 aa
    with 32 concurrent folds on whglx, each on the 2-thread share this arithmetic hands
    it, that is 1789.4 -> 1813.9 folds/hour, bit-exact, both arms writing one CIF digest.
    It is worth 1.4 %, not more: the same pair at a fixed cap of 8, which oversubscribes
    that box fourfold, reads 1311.2 -> 1839.5, and nearly all of that 1.40x is the cap
    the line above already applies. Above the share, parking costs wake latency the spare
    cores were absorbing, so it stays off and a single ``predict`` keeps today's latency.
    An operator who set any of the three wait-policy variables themselves owns all three:
    they are one setting spelled three ways and half of a policy is not a policy.
    """
    cap = host_thread_cap(n_workers, host_threads)
    env = {var: str(cap) for var in HOST_THREAD_VARS
           if host_threads or var not in os.environ}
    if cap <= IDLE_PARK_THREAD_SHARE and not any(k in os.environ for k in IDLE_THREADS_PARK):
        env.update(IDLE_THREADS_PARK)
    return env


#: Whether serial_host() serializes. A switch for paired A/Bs in one process
#: (perf/of3_4xpd/xmodel_ab.py --ab-attr tt_bio.runtime:SERIAL_HOST), not a user setting.
SERIAL_HOST = True


@contextlib.contextmanager
def serial_host():
    """Run a block of tiny host tensor math on one torch thread.

    A diffusion sampler does a few atom-sized ops on the host every step (the random
    augmentation, Boltz-2's rigid alignment). At 4117 atoms each is microseconds of work, and
    fanning it out to every core costs more than the work: measured per step on a loaded qb1
    (loadavg 11-16, 16 threads) 10-12 ms against 1.1 ms on one thread, and on qb2 at loadavg 6
    0.9 ms against 0.4 ms. Two hundred steps a fold make that 2 s of a 15 s Boltz-2 fold on a
    busy host. The thread count changes the summation order of the reductions, so the CIF
    digest can move (it already depends on the host's core count); the accuracy does not.
    """
    import torch

    n = torch.get_num_threads()
    if not SERIAL_HOST or n == 1:
        yield
        return
    torch.set_num_threads(1)
    try:
        yield
    finally:
        torch.set_num_threads(n)


def bind_host_threads() -> None:
    """Bind torch's thread pools to the OMP_NUM_THREADS cap set by the launcher.

    A fresh torch import honours the cap for the intra-op pool -- but not for the
    inter-op pool, which always sizes itself to cores/2 regardless. Bind both
    explicitly so a capped worker really holds only its share of the CPU. Nothing to
    do when the launcher set no cap.
    """
    cap = os.environ.get("OMP_NUM_THREADS")
    if not cap:
        return
    import torch

    torch.set_num_threads(int(cap))
    try:
        torch.set_num_interop_threads(int(cap))
    except RuntimeError:
        pass  # already started (only settable before the first parallel op)


@dataclass(frozen=True)
class PredictionJob:
    """One input target to predict."""

    id: str
    path: Path


@dataclass(frozen=True)
class WorkerSlot:
    """One execution slot that can run prediction jobs."""

    worker_id: str
    host: str
    accelerator: str
    device_id: int | str
    visible_devices: str | None = None
    logical_device_id: int = 0
    mesh_graph_descriptor: str | None = None

    @property
    def label(self) -> str:
        if self.accelerator == "tenstorrent":
            return f"{self.host}:tt{self.device_id}"
        return f"{self.host}:{self.accelerator}"


def discover_jobs(data: Path, structure_dir: Path, output_format: str, override: bool) -> list[PredictionJob]:
    """Discover runnable input files, applying resume semantics."""
    files = sorted(
        p for p in (data.glob("*") if data.is_dir() else [data])
        if p.suffix.lower() in INPUT_SUFFIXES
    )
    # A job is identified by its file stem (used for output filenames AND result/failure keys),
    # so two inputs sharing a stem — e.g. target.fasta and target.yaml — would silently overwrite
    # each other's output and merge into one result. Refuse the ambiguous case with a clear message
    # rather than lose a prediction. Checked on the full input set (before the resume filter).
    by_stem: dict[str, list[Path]] = {}
    for p in files:
        by_stem.setdefault(p.stem, []).append(p)
    dups = {stem: ps for stem, ps in by_stem.items() if len(ps) > 1}
    if dups:
        detail = "; ".join(f"'{stem}' <- {', '.join(pp.name for pp in ps)}"
                           for stem, ps in sorted(dups.items()))
        raise ValueError(
            "Input files share a name stem and would overwrite each other's output. "
            f"Rename so each input has a unique stem ({detail})."
        )
    if not override:
        files = [p for p in files if not (structure_dir / f"{p.stem}.{output_format}").exists()]
    return [PredictionJob(id=p.stem, path=p) for p in files]


#: Blackhole board types by the PCI ``subsystem_device`` the kernel driver publishes under
#: ``/sys/class/tenstorrent/tenstorrent!N/device/``, which names the board without opening it or
#: needing tt-smi. The P300 ids mirror tt-metal's own board-type map. 0x0040 is measured: every
#: p150a node on pc and qb1 reads it while tt-smi calls the same card p150a. A p300 is a board
#: PAIR whose lone chip opens only with a 1x1 mesh descriptor; a p150a is one chip.
P300_SUBSYSTEMS = frozenset({"0x0044", "0x0045", "0x0046"})
P150_SUBSYSTEMS = frozenset({"0x0040"})
#: Wormhole Galaxy chips publish 0x0035, the UPI tt-smi maps to ``tt-galaxy-wh``; every chip the
#: kernel lists is PCIe-local, which tt-smi suffixes " L", so the board key is ``tt-galaxy-wh-l``.
WH_GALAXY_SUBSYSTEMS = frozenset({"0x0035"})


#: What a chip whose ARC firmware is dead answers from its ``tt_*`` sysfs telemetry, AICLK
#: included. It does not raise: the chip still opens, runs and returns results, and the clock
#: reads 4294967295 MHz. qb1's node 0 did exactly that on 2026-09-26 and a 312 s anchor was banked
#: with every clock sample at this value, shaped like a measurement and worth nothing.
ARC_DEAD = 0xFFFFFFFF


def aiclk_reading(mhz: int) -> int | None:
    """An AICLK value as read, or None when it is the dead-ARC sentinel and not a clock.

    The one place a sampler decides that, so a dead chip reads as "no clock" in every
    instrument instead of as a 4.3 GHz median in the ones that forgot to check.
    """
    return None if mhz == ARC_DEAD else mhz


def tt_dev_node_bdfs() -> dict[int, str]:
    """``/dev/tenstorrent/N`` -> that card's PCI BDF, from the tenstorrent sysfs class.

    The node number is the kernel driver's PROBE order. It is not the UMD device index
    and on a multi-root-complex box it is not even PCI order.
    """
    out: dict[int, str] = {}
    for entry in glob.glob("/sys/class/tenstorrent/tenstorrent!*/device"):
        node = int(os.path.basename(os.path.dirname(entry)).rsplit("!", 1)[-1])
        out[node] = os.path.basename(os.path.realpath(entry)).lower()
    return out


def _bdf_sort_key(bdf: str) -> tuple[int, ...]:
    """Numeric sort key for a PCI BDF, so ``0000:c1:00.0`` orders after ``0000:81:00.0``."""
    return tuple(int(part, 16) for part in re.split(r"[:.]", bdf) if part)


def tt_bdf_to_index() -> dict[str, int]:
    """PCI BDF -> UMD device index for every Tenstorrent card.

    UMD numbers chips by PCI enumeration order. That is NOT the ``/dev/tenstorrent/N``
    node number, which the kernel driver assigns in probe order, and the two differ on
    any box whose root complexes are probed out of PCI order.

    Measured on the Galaxy ``UF-EV-A13-GWH02`` (32 chips on four root complexes,
    2026-09-02): its nodes 0-7 are buses c1-c8, nodes 8-15 are 81-88, nodes 16-23 are
    01-08 and nodes 24-31 are 41-48. Cross-checking all 32 device-lease files (keyed on
    the UMD index the process pinned with ``TT_VISIBLE_DEVICES``) against ``lsof`` on
    every node gave UMD index k -> node f(k) with f a permutation that has NO fixed
    point: UMD 0 is node 16, UMD 7 is node 23, UMD 16 is node 8, UMD 24 is node 0. The
    permutation is exactly BDF-ascending rank, from two independent process families
    (the JapanFold pool and a sibling worker). Reading the node number as the UMD index,
    as this function used to, therefore named a different chip for all 32 cards.
    """
    return {bdf: i for i, bdf in enumerate(sorted(tt_dev_node_bdfs().values(),
                                                  key=_bdf_sort_key))}


def umd_index_to_dev_node() -> dict[int, int]:
    """UMD device index -> ``/dev/tenstorrent/N`` node number.

    The bridge every occupancy check needs: a lease and a ``TT_VISIBLE_DEVICES`` pin
    name a UMD index, while ``lsof`` and the fd-level collision live on the node. Check
    one and act on the other and you test the freeness of a chip you never open.
    """
    by_bdf = tt_bdf_to_index()
    return {by_bdf[bdf]: node for node, bdf in tt_dev_node_bdfs().items() if bdf in by_bdf}


def dev_node_to_umd_index() -> dict[int, int]:
    """``/dev/tenstorrent/N`` node number -> UMD device index."""
    return {node: idx for idx, node in umd_index_to_dev_node().items()}


def visible_device_indices(visible: str) -> list[int]:
    """Parse a ``TT_VISIBLE_DEVICES`` value into UMD device indices.

    ttnn's device open accepts either form per token: a UMD index (``0``) or a PCI
    BDF (``0000:01:00.0``). BDFs resolve through the tenstorrent sysfs class, whose
    per-card ``device`` symlink names the card's PCI address; a token that matches
    no card raises a ValueError naming the index form, so a typo fails here with a
    clear message instead of at device open (issue #11).
    """
    indices: list[int] = []
    bdfs: list[str] = []
    for tok in visible.split(","):
        tok = tok.strip()
        if not tok:
            continue
        try:
            indices.append(int(tok))
        except ValueError:
            bdfs.append(tok.lower())
    if bdfs:
        by_bdf = tt_bdf_to_index()
        for bdf in bdfs:
            match = next((idx for full, idx in by_bdf.items()
                          if full == bdf or full.endswith(":" + bdf)), None)
            if match is None:
                known = ", ".join(f"{idx} ({full})" for full, idx in sorted(by_bdf.items()))
                raise ValueError(
                    f"TT_VISIBLE_DEVICES entry '{bdf}' matches no Tenstorrent card "
                    f"(present: {known or 'none detected'}). Use the UMD index form, "
                    "e.g. TT_VISIBLE_DEVICES=0."
                )
            indices.append(match)
    # The index form was the one token that was never checked: a BDF that matches no card has
    # raised above since issue #11, but an integer went straight through to ttnn, which answers
    # at device open with a UMD TT_THROW and a C++ backtrace ("Invalid device ID in
    # TT_VISIBLE_DEVICES: 99"). The chip number is in there, but a backtrace is not a refusal,
    # and on a 32-chip Galaxy a mistyped pin is the easiest mistake to make. Worse, the predict
    # path did not even get that far: detect_tenstorrent_devices() intersects the present cards
    # with this list, so an absent index silently left ZERO devices and the run looked like a
    # host with no cards. Checked against the same sysfs map the BDF form resolves through, so
    # both forms refuse on one piece of evidence; on a host with no cards that map is empty and
    # an index is not checked at all, so a card-free run carrying TT_VISIBLE_DEVICES=0 -- every
    # CPU fold in CI -- is untouched.
    chips = len(by_bdf) if bdfs else len(tt_bdf_to_index())
    absent = [index for index in indices if not 0 <= index < chips] if chips else []
    if absent:
        raise ValueError(
            f"TT_VISIBLE_DEVICES names chip(s) {absent}, which this host does not have: it has "
            f"{chips} Tenstorrent chip(s), numbered 0 to {chips - 1}. Pin to one of those, or "
            "unset TT_VISIBLE_DEVICES to use every chip on the host."
        )
    return indices


def local_addresses() -> set[str]:
    """This host's IPv4 addresses, from ``hostname -I``; empty if that cannot be read."""
    try:
        out = subprocess.run(["hostname", "-I"], capture_output=True, text=True, timeout=5).stdout
    except (OSError, subprocess.SubprocessError):
        return set()
    return set(out.split())


def quarantine_path() -> str:
    return os.path.expanduser(os.environ.get("TT_BIO_QUARANTINE", "~/japanfold/QUARANTINE"))


def quarantined_chips(path: str | None = None, addresses: set[str] | None = None) -> dict[int, str]:
    """UMD index -> reason, for each chip on this host the operators' quarantine list names.

    The list is the one the JapanFold box agent already honours
    (``<ip> <UMD id> <PCI bdf> <reason>`` per line, ``~/japanfold/QUARANTINE``): chips that flip
    DRAM bits or fold off the majority. The agent keeps them out of its own pool, but nothing kept
    them out of anything else -- measured on `.107` on 2026-09-30, UMD 22 ("flipped bit 13 on
    5/256 DRAM reads") had a lease note naming a holder whose pid was dead and no flock on it, so
    a campaign pinned there with ``TT_VISIBLE_DEVICES=22`` would have opened it without a word
    and designed on a chip that corrupts reads. A wrong design is worse than a refused one.

    Matched on this host's address AND the chip's BDF, and the BDF is resolved to the UMD index
    through sysfs rather than trusting the listed id: a BDF like ``0000:c1:00.0`` exists on every
    Galaxy, so a line for another box must never quarantine this one's chip. No list, no
    readable address, or no Tenstorrent sysfs entries: nothing is quarantined.
    """
    path = path or quarantine_path()
    try:
        with open(path) as f:
            lines = f.read().splitlines()
    except OSError:
        return {}
    addresses = local_addresses() if addresses is None else addresses
    if not addresses:
        return {}
    by_bdf = tt_bdf_to_index()
    out: dict[int, str] = {}
    for line in lines:
        fields = line.split(None, 3)
        if len(fields) < 3 or line.lstrip().startswith("#") or fields[0] not in addresses:
            continue
        index = by_bdf.get(fields[2].lower())
        if index is not None:
            out[index] = fields[3].strip() if len(fields) > 3 else "no reason given"
    return out


def refuse_quarantined_chips(indices, path: str | None = None) -> None:
    """Refuse a chip the operators quarantined, unless TT_BIO_ALLOW_QUARANTINED=1 says it is meant."""
    if env_flag("TT_BIO_ALLOW_QUARANTINED", False):
        return
    bad = quarantined_chips(path)
    hit = [index for index in indices if index in bad]
    if not hit:
        return
    named = "; ".join(f"chip {index}: {bad[index]}" for index in hit)
    raise RuntimeError(
        f"Tenstorrent chip(s) {hit} on this host are quarantined by its operators ({named}), per "
        f"{path or quarantine_path()}. Results on a quarantined chip can be silently wrong, so "
        f"this run is refused rather than started. Pin to another chip; to test the chip itself "
        f"on purpose, set TT_BIO_ALLOW_QUARANTINED=1."
    )


def missing_device_nodes(indices) -> list[tuple[int, int]]:
    """UMD indices whose chip is listed in sysfs but has no ``/dev/tenstorrent`` node.

    A chip can enumerate and still be unusable, and this is the shape a wedged or
    half-attached card takes: the tenstorrent sysfs class still lists it, so every
    index check passes, while the character device the driver should have created is
    gone. Reproduced on `.108` on 2026-09-30 by mounting a tmpfs over
    ``/dev/tenstorrent`` inside a private mount namespace -- the same view a box has
    after a driver reload that half-probed, or when the nodes are there but this chip's
    is not -- and what a user got was a UMD throw 2.0 s in::

        RuntimeError: TT_THROW @ .../umd/device/pcie/pci_device.cpp:313: tt::exception
        info: Invalid device ID in TT_VISIBLE_DEVICES: 0.  Valid device identifiers are
        either integers or part of the BDF string. Valid integer IDs are between 0 and
        18446744073709551615.

    which blames the one thing that was right. ``TT_VISIBLE_DEVICES=0`` is a valid pin
    on a host with chips; the chip is what is missing, the range it offers is
    ``0..UINT64_MAX``, and there is no sentence telling anyone what to look at.

    Existence only, deliberately: a node held by another tenant is not a fault and must
    not be refused here, so this never opens anything. Empty list on a host with no
    Tenstorrent sysfs entries at all, which is every CPU run.
    """
    nodes = umd_index_to_dev_node()
    if not nodes:
        return []
    return [(index, nodes[index]) for index in indices
            if index in nodes and not os.path.exists(f"/dev/tenstorrent/{nodes[index]}")]


def chip_summary() -> str:
    """One line on the Tenstorrent chips this host can actually use, for ``tt-bio preflight``.

    Reads sysfs, the quarantine list and ``/dev`` only. Nothing is opened, so it is honest
    while every chip is busy, and it says the two things a weights check cannot: whether a
    chip is there at all, and whether one of them is listed but unusable.
    """
    indices = sorted(tt_bdf_to_index().values())
    if not indices:
        return "no Tenstorrent chip visible (CPU only; is tt-kmd loaded?)"
    problems = [f"chip {i} quarantined ({reason})"
                for i, reason in sorted(quarantined_chips().items()) if i in indices]
    problems += [f"chip {i} has no /dev/tenstorrent/{node}"
                 for i, node in missing_device_nodes(indices)]
    head = f"{len(indices)} Tenstorrent chip(s): {', '.join(str(i) for i in indices)}"
    if not problems:
        return head
    return f"{head}; {len(problems)} unusable: " + "; ".join(problems)


def refuse_missing_device_nodes(indices) -> None:
    """Refuse, in a sentence, before UMD throws a backtrace about the wrong thing."""
    missing = missing_device_nodes(indices)
    if not missing:
        return
    named = ", ".join(f"chip {index} (/dev/tenstorrent/{node})" for index, node in missing)
    raise RuntimeError(
        f"Tenstorrent {named} is listed by the driver's sysfs class but its device node does not "
        f"exist, so it cannot be opened: the chip is missing, not your TT_VISIBLE_DEVICES. Check "
        f"`ls /dev/tenstorrent`, `tt-smi -ls` and `dmesg | grep -i tenstorrent` on this host, and "
        f"reload the driver or reset that chip before pinning to it."
    )


#: How long a chip's ARC heartbeat may stand still before the chip is called dead. The kernel
#: driver publishes the counter as ``tt_heartbeat``; it advanced 10-11 per second on every chip
#: measured on 2026-11-15 (all 32 Wormhole chips of the Galaxy .107, the four p300 chips of
#: qb2, pc's p150a), so 2 s is ~20 ticks of margin and a live chip passes in ~0.1 s.
HEARTBEAT_WINDOW_S = 2.0
_SYSFS_CLASS = "/sys/class/tenstorrent"


class ChipNeedsResetError(RuntimeError):
    """A chip's ARC firmware is not running, so opening it would hang instead of failing."""


def dead_heartbeats(indices, window_s: float | None = None,
                    sysfs: str | None = None) -> dict[int, str]:
    """UMD index -> why its ARC is dead, for each of ``indices`` whose heartbeat does not advance.

    Reads sysfs only: no device node is opened, so it is safe on a chip someone else holds and
    on one that is wedged. A chip whose driver publishes no ``tt_heartbeat`` (an older tt-kmd) or
    that sysfs does not list is skipped: unknown is not dead.
    """
    window_s = HEARTBEAT_WINDOW_S if window_s is None else window_s
    sysfs = sysfs or _SYSFS_CLASS
    nodes = umd_index_to_dev_node()

    def read(index):
        with open(f"{sysfs}/tenstorrent!{nodes[index]}/tt_heartbeat") as f:
            return int(f.read().strip())

    first, dead = {}, {}
    for index in indices:
        if index not in nodes:
            continue
        try:
            first[index] = read(index)
        except FileNotFoundError:
            continue
        except (OSError, ValueError) as e:
            dead[index] = f"its ARC telemetry cannot be read ({getattr(e, 'strerror', None) or e})"
            continue
        if first[index] == ARC_DEAD:
            dead[index] = "its ARC telemetry reads 0xffffffff (firmware dead or chip off the PCIe bus)"
            del first[index]
    end = time.monotonic() + window_s
    while first and time.monotonic() < end:
        time.sleep(0.05)
        for index in list(first):
            try:
                if read(index) != first[index]:
                    del first[index]
            except (OSError, ValueError):
                pass
    for index, value in first.items():
        dead[index] = f"its ARC heartbeat stayed at {value} for {window_s:g} s"
    return dead


def refuse_dead_chips(indices) -> None:
    """Fail in seconds, before any lease or lock, on a chip whose ARC firmware is not running.

    ``ttnn.open_device`` on such a chip does not fail, it parks in UMD's bring-up holding the
    host-wide device-init lock, and every other chip's open on the host queues behind it
    (qb1 2026-09-17: one chip's open parked and all four cards waited). This catches the
    dead-ARC and off-bus chip before it gets that far. A chip whose ARC runs but whose cores are wedged
    passes here; the deadline in ``device_lease.device_init_lock`` bounds that case.
    """
    dead = dead_heartbeats(indices)
    if not dead:
        return
    nodes = umd_index_to_dev_node()
    named = "; ".join(f"chip {i} (/dev/tenstorrent/{nodes[i]}): {why}" for i, why in sorted(dead.items()))
    raise ChipNeedsResetError(
        f"Tenstorrent chip(s) {sorted(dead)} need a reset before they can be opened: {named}. "
        f"Reset with `tt-smi -r {' '.join(str(i) for i in sorted(dead))}` (on a p300, reset both "
        f"chips of the board), or pin to another chip.")


def detect_tenstorrent_devices(device_ids: str | None, num_devices: int, max_workers: int) -> list[int]:
    """Return TT device IDs selected for this run without importing ttnn.

    An explicit ``device_ids`` is validated against the cards actually present under
    ``/dev/tenstorrent``: a request for a device that isn't there (a typo like ``--device_ids 7``
    on a two-card box) raises a clear error naming the available ids, instead of passing straight
    through and failing much later with an opaque low-level device-open error.
    """
    # Device ids are UMD indices, dense 0..n-1 over the cards present (tt_bdf_to_index), not
    # /dev node numbers: a Galaxy that lost nodes 20, 24 and 25 after a PCIe error kept UMD
    # 0-28, and a job pinned to UMD 20 was told the host had no cards.
    all_devices = list(range(len(glob.glob("/dev/tenstorrent/[0-9]*"))))
    # Honor ambient TT_VISIBLE_DEVICES (the same env ttnn/tt-smi read at
    # device-open time): a job pinned to card N via the environment must fan out
    # only onto card N. Without this filter, a predict launched with
    # TT_VISIBLE_DEVICES=1 enumerated every physical card and spawned one worker
    # per card, so the card-0 worker wedged card 0 for every concurrent job on
    # the box. Explicit --device_ids still wins (validated below against the
    # ambient-visible set).
    visible = os.environ.get("TT_VISIBLE_DEVICES")
    if visible is not None:
        allowed = set(visible_device_indices(visible))
        all_devices = [d for d in all_devices if d in allowed]
    if device_ids:
        requested = [int(d.strip()) for d in device_ids.split(",") if d.strip()]
        missing = [d for d in requested if d not in all_devices]
        if missing:
            avail = ", ".join(map(str, all_devices)) if all_devices else "none detected"
            raise ValueError(
                f"Requested Tenstorrent device id(s) {missing} not available "
                f"(present: {avail}). Fix --device_ids, or leave it unset to use all cards."
            )
        devices = requested
    elif num_devices > 0:
        devices = all_devices[:num_devices]
    else:
        devices = all_devices
    return devices[:max_workers]


def build_local_workers(accelerator: str, jobs: list, devices: list[int]) -> list[WorkerSlot]:
    """Build worker slots for the local host (one per device, capped to jobs)."""
    host = socket.gethostname()
    if accelerator == "tenstorrent":
        return [
            WorkerSlot(
                worker_id=f"{host}:tt:{device}",
                host=host,
                accelerator=accelerator,
                device_id=device,
                visible_devices=str(device),
            )
            for device in devices[:len(jobs)]
        ]
    return [WorkerSlot(worker_id=f"{host}:{accelerator}:0", host=host,
                       accelerator=accelerator, device_id=0)]


# --- address space, and why a dying fold can freeze the host -------------------------------
#
# Only the task that drops the LAST reference to an address space gets to tear it down, and it
# may be a task that cannot sleep there. The kernel then defers the whole teardown to one work
# item on the bounded per-CPU system_wq (mmput_async_fn). A fold exits with ~4.7 GB anonymous
# across ~2900 mappings, which makes that one work item long enough for the workqueue watchdog
# to start printing
#
#     workqueue: mmput_async_fn hogged CPU for >10000us N times
#
# and a second long system_wq item landing while the queue is saturated is the documented host
# livelock (MINFRA-1586, PCB-4609). We cannot choose who drops the reference or which workqueue
# the kernel picks, so the lever is to make the teardown cheap: free in our own preemptible
# context before exit and hand the pages back, so whatever runs mmput_async_fn afterwards finds
# almost nothing left.

M_ARENA_MAX = -8            # glibc malloc.h
M_TRIM_THRESHOLD = -1
M_MMAP_MAX = -4


def _libc():
    """glibc, or None where there is no glibc (musl, a non-Linux host)."""
    import ctypes

    try:
        return ctypes.CDLL("libc.so.6")
    except OSError:
        return None


def cap_malloc_arenas(arenas: int) -> bool:
    """Cap the number of per-thread malloc arenas glibc may create. True if it took.

    glibc hands any thread that contends on the main arena a fresh 64 MB heap of its own, so a
    52-thread fold ends up with several hundred anonymous rw-p mappings that all have to be
    unmapped again at exit. ``mallopt`` is the way in, not ``MALLOC_ARENA_MAX``: the environment
    variable is read once when libc starts, long before Python could set it for itself, while
    ``mallopt`` caps arenas that do not exist yet. So call this before torch spawns its thread
    pools; arenas already created stay.

    ``arenas <= 0`` leaves glibc's default (8 * cores) alone.
    """
    libc = _libc()
    if arenas <= 0 or libc is None:
        return False
    return libc.mallopt(M_ARENA_MAX, int(arenas)) == 1


def reuse_freed_heap(trim_bytes: int = 1 << 30) -> bool:
    """Serve large host tensors from memory the process already faulted in. True if it took.

    glibc puts every allocation over its mmap threshold (at most 32 MiB) in a fresh mapping and
    unmaps it on free, so each [1, N, N, 128] fp32 pair tensor (145 MB at 532 tokens) is paged in
    from zero on every op. Host glue around a device trunk made that way ran 2.5x slower than
    the same ops served from freed heap (Nesso-1 forward, +1.1 s per record at 512 aa). With
    mmap off and the trim threshold raised, a freed tensor stays in the heap for the next one.
    The cost is that up to ``trim_bytes`` of freed memory is kept rather than returned to the OS.
    """
    libc = _libc()
    if libc is None:
        return False
    return libc.mallopt(M_MMAP_MAX, 0) == 1 and libc.mallopt(M_TRIM_THRESHOLD, int(trim_bytes)) == 1


def address_space() -> tuple[int, int]:
    """This process's (resident kB, number of mapped regions).

    The two numbers the teardown is paid by: pages to free, and VMAs to walk.
    """
    rss = 0
    with open("/proc/self/status") as f:
        for line in f:
            if line.startswith("VmRSS:"):
                rss = int(line.split()[1])
                break
    with open("/proc/self/maps") as f:
        vmas = sum(1 for _ in f)
    return rss, vmas


def drop_cycles() -> None:
    """Run the cycle collector while the device is still open.

    Anything holding a device buffer expects to be finalised against a live device, so the
    collection has to happen before the close, not after it -- an atexit ``gc.collect()`` placed
    after ``ttnn.close_device()`` would run those finalisers against a closed chip.
    """
    import gc

    gc.collect()


def release_address_space() -> tuple[int, int]:
    """Give this process's freed heap back to the kernel. Returns the footprint left behind.

    glibc keeps every block the fold freed in its arenas, so RSS does not move at all until
    ``malloc_trim`` hands the pages back -- which is the step usually missed, and on a 512 aa fold
    it is 517 MB of ``[heap]``. Pair it with ``drop_cycles`` before the device close; this half is
    pure bookkeeping and safe to run last.
    """
    libc = _libc()
    if libc is not None:
        libc.malloc_trim(0)
    return address_space()


def quiet_teardown_wanted(env=None) -> bool:
    """Whether `end_after_teardown` drops the C-level stderr of the interpreter's last steps.

    `--debug` sets ``TT_BIO_DEBUG_STDERR`` rather than being read from argv, because a
    multiprocessing spawn inherits the environment and not the argv: a worker spawned by
    ``tt-bio predict --debug`` has to keep its stderr too.
    """
    env = os.environ if env is None else env
    return not env.get("TT_BIO_DEBUG_STDERR")


def end_after_teardown() -> None:
    """The last atexit hook: once tt-bio has closed its card, end the process without the
    C++ static destructors of tt-metal and XLA.

    After the device is closed and its lease released there is nothing left for those
    destructors to do, and running them is where a finished BindCraft 2 campaign died
    (issue #20): exit 139 after printing its final status, exit 139 four seconds after an
    allocator refusal, or a hang with every thread in ``futex_do_wait``. They run inside
    ``exit()``, after Python has finalised, alongside XLA and tt-metal worker threads that are
    still alive. So this registers libc's own ``_exit`` with ``on_exit``. glibc calls it with
    the real exit status, ahead of every handler registered before it, which is all of them:
    a library registers its destructors when it loads. Whatever status Python chose, from
    ``sys.exit(n)`` or an uncaught exception, is the one the caller sees.

    It also points C's ``stderr`` at /dev/null for the rest of finalisation. What writes there
    after this point is nanobind's report of the ttnn objects still alive at shutdown, dozens
    of lines on every run that are noise to a user. Python's own ``sys.stderr`` writes fd 2
    directly and is untouched, so a traceback, an "Exception ignored" and a faulthandler dump
    still print. tt-bio used to drop the report with a filter process forked at import, which
    is unsafe next to JAX's threads and lost the parent's last words when it crashed.
    ``TT_BIO_DEBUG_STDERR=1`` (or ``--debug``) keeps the report.
    """
    import ctypes

    try:
        libc = ctypes.CDLL(None)
        libc.fflush(None)
        if quiet_teardown_wanted():
            libc.fopen.restype = ctypes.c_void_p
            libc.fopen.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
            sink = libc.fopen(b"/dev/null", b"w")
            if sink:
                # The global, not its FILE: freopen would close fd 2 under Python's sys.stderr.
                ctypes.c_void_p.in_dll(libc, "stderr").value = sink
        libc.on_exit.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        libc.on_exit(ctypes.cast(libc._exit, ctypes.c_void_p), None)
    except (OSError, AttributeError, ValueError):
        pass   # no glibc: exit the ordinary way
