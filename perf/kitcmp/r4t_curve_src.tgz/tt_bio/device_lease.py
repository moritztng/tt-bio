"""Host-local, physical-card-keyed device lease enforced at the device-open choke point.

Every tt-bio device acquisition routes through ``get_device()`` -> ``ttnn.open_device``
(``tenstorrent.py``). Wrapping that single choke point with an exclusive, auto-releasing
file lock makes it IMPOSSIBLE for two processes on the same host to open the same physical
TT card at once, no matter how the job was launched -- fleet worker, detached campaign,
cross-host fanout, or a manual one-off. This replaces the previous convention-only "remember
to write a lease" rule (a human-followed PLAYBOOKS note) with enforcement in code.

Mechanism -- one exclusive ``flock()`` held on a per-card lock file for the entire lifetime
the device is open:

* Serialization: a second opener of the same card blocks up to a bounded timeout, then fails
  with an explicit ``DeviceInUseError`` naming the holder -- never a silent fd-level collision.
* Stale reclaim / crash safety: ``flock`` is released by the kernel on ANY process death --
  clean exit, SIGTERM, or SIGKILL -- so a crashed, killed, or orphaned holder (e.g. a leaked
  mp.spawn worker) never leaves a phantom claim. There is no pid-liveness scan to get wrong:
  a dead holder's lock is simply gone, so the next acquire succeeds immediately.
* No self-deadlock: the fleet dispatcher writes its lease JSON without holding an ``flock``,
  so a worker opening its own already-dispatch-leased card acquires instantly and just
  overwrites the metadata with its live pid.

Shared view with the fleet dispatcher: the lock/metadata files use the same directory and the
same ``<host>-card<N>.json`` naming the dispatcher already uses, so the dispatcher and the
device-open observe ONE consistent set of leases. Collision-freedom does NOT depend on that
sharing, though -- because both colliding jobs pass through this same choke point, they
serialize here even if the dispatcher never sees the lease.

Scope of one lease -- the VISIBLE set, not the chip that gets opened. ttnn brings up every
chip ``TT_VISIBLE_DEVICES`` makes visible, not only the one ``open_device`` names. Measured on
qb2 2026-08-21: under ``TT_VISIBLE_DEVICES=0,1`` ttnn returned a 1x1 mesh
(``get_num_devices() == 1``, ``get_device_ids() == [0]``, ``shape == MeshShape([1, 1])``) while
the process held two fds on ``/dev/tenstorrent/0`` AND two on ``/dev/tenstorrent/1`` for the
device's whole lifetime; under ``TT_VISIBLE_DEVICES=1`` it held node 1 alone. So a single lease
keyed on the opened chip leased card 0 and silently HELD card 1 -- which the fleet, seeing one
held lease, then handed to a second worker. ``CardSetLease`` leases every card in the visible
set, so what a process holds and what it has leased are the same thing, and a visibility wider
than the card grant is refused rather than hidden. The mesh object cannot report this: it says
one device while two chips are open, which is why the lease has to key on visibility.
"""

import contextlib
import errno
import fcntl
import glob
import json
import os
import signal
import socket
import sys
import threading
import time

# Bounded wait so a genuinely-contended card fails loudly instead of hanging a job forever.
DEFAULT_TIMEOUT_S = float(os.environ.get("TT_BIO_LEASE_TIMEOUT", "120"))
_POLL_S = 0.25


class DeviceInUseError(RuntimeError):
    """Raised when the physical card cannot be leased within the timeout."""


#: Exit code an entry point uses when it dies of :class:`DeviceInUseError`, so a caller can
#: tell "a co-tenant had the card" from "the thing under test is broken" by return code alone.
#: 75 is sysexits' EX_TEMPFAIL: retriable, nothing wrong with the input. Same reserved-code
#: convention as ``install_parent_death_guard(exit_code=70)`` below.
#:
#: Why this exists: a release-gate leg that cannot open the card waits out
#: ``TT_BIO_LEASE_TIMEOUT`` and exits 1, which every gate arm renders as an accuracy verdict --
#: "missed the ground-truth floor", "drifted run to run". Eleven legs across two v0.7.0 gate
#: passes read as model defects when not one of them executed a device instruction.
CONTENDED_EXIT_CODE = 75


# --- Host-wide device bring-up lock -------------------------------------------------------
#
# This module holds both of tt-bio's device guards, and they answer a permission error
# differently on purpose. The card lease answers "may this process have card N": refusing is
# safe, the job simply does not get the card, so it raises. The bring-up lock answers "may
# this process bring a chip up right now": refusing would break every box where bring-up
# works today, so it degrades instead, to a per-user lock file, and says so. What it must
# never do is degrade silently, which is what it did until 2026-09-13.

DEVICE_INIT_LOCK_PATH = "/tmp/tt-bio-device-open.lock"

_init_lock_path = None      # resolved once per process; "" means nothing was writable


def _init_lock_candidates():
    """Lock files to try for the bring-up lock, best first.

    The shared path is first: it is the only candidate that serializes across unix accounts.
    Every fallback is keyed on the uid, so it serializes this account's processes and nobody
    else's. The first fallback is a sibling of the shared path, which is the case that
    actually happens in the field: one account created ``/tmp/tt-bio-device-open.lock`` with
    a default umask, a second account cannot write it, but ``/tmp`` itself is world-writable.
    """
    name = os.path.basename(DEVICE_INIT_LOCK_PATH)
    per_user = f"{name}.uid{os.getuid()}"
    cands = [DEVICE_INIT_LOCK_PATH,
             os.path.join(os.path.dirname(DEVICE_INIT_LOCK_PATH) or ".", per_user)]
    cands += [os.path.join(d, per_user)
              for d in (os.environ.get("XDG_RUNTIME_DIR"), os.environ.get("TMPDIR")) if d]
    cands.append(os.path.join(os.path.expanduser("~"), "." + per_user))
    return list(dict.fromkeys(cands))


def _open_init_lock_file():
    """Open the bring-up lock file, falling back to a path this account can actually write.

    Returns an open file, or ``None`` when no candidate is writable. ``None`` means bring-up
    will run unserialized, and that is announced on stderr rather than assumed harmless.
    Resolution and both warnings happen once per process.
    """
    global _init_lock_path
    if _init_lock_path == "":
        return None
    if _init_lock_path:
        try:
            return open(_init_lock_path, "a+")
        except Exception:
            _init_lock_path = None      # it vanished or changed owner; resolve again
    refused = []
    for path in _init_lock_candidates():
        try:
            f = open(path, "a+")     # never "w": truncating would erase the holder's record
        except Exception as e:
            why = getattr(e, "strerror", None) or repr(e)
            refused.append(f"{path} ({why})")
            continue
        _init_lock_path = path
        if refused:
            print(f"[tt-bio] device bring-up lock: cannot use {refused[0]}; serializing on "
                  f"{path} instead. That covers tt-bio processes running under uid "
                  f"{os.getuid()} on this host and nothing else, so a tt-bio process running "
                  f"as a different unix account brings chips up unserialized against this "
                  f"one.", file=sys.stderr, flush=True)
        return f
    _init_lock_path = ""
    print(f"[tt-bio] WARNING: device bring-up is NOT serialized: no writable lock file "
          f"({'; '.join(refused)}). Concurrent opens can deadlock in UMD's "
          f"LockManager::acquire_mutex, or bring a chip up remote-only so it throws on the "
          f"first program dispatch. Make one of those paths writable.",
          file=sys.stderr, flush=True)
    return None


@contextlib.contextmanager
def device_init_lock(purpose="bring-up"):
    """Serialize TT device bring-up/teardown across every process on the host.

    Opening (or closing) a chip runs through the user-mode driver's cross-process
    device-init path: tt::umd::LocalChip::start_device -> LockManager::acquire_mutex,
    coordinating via robust mutexes in /dev/shm (TT_UMD_LOCK.*). That path is NOT
    concurrency-safe on a Galaxy, in two ways:
      * it deadlocks when several processes hit it at once (observed live: many
        design-shard cold-opens all blocked in acquire_mutex during start_device);
      * it races the per-chip fabric/MMIO bring-up, so a chip can come up
        "remote-only" -- no local dispatch core, SubDeviceManagerTracker never
        initialized -- and then throws on the FIRST program dispatch
        ("...contains only remote devices (no local device)", mesh_device.cpp).
    The platform opens 32 single-chip workers at startup, so WITHOUT serialization
    that race is hit on many boots (a few workers come up bad and silently fail
    every job routed to them). Serializing the opens is the fix.

    A single host-wide advisory lock makes every open/close strictly one-at-a-time,
    so the UMD init path is never raced. Blocking on purpose: a best-effort timeout
    that let opens proceed concurrently after waiting is exactly what reintroduced
    the deadlock. The kernel drops the lock if a holder dies, and no holder
    keeps it past ``INIT_LOCK_DEADLINE_S``: a section still running then is a chip that
    will never answer, and the process ends (see ``exit_if_stuck``), which releases the
    lock and the chip's fds. So one dead chip costs the other chips' opens at most the
    deadline, never forever. Opens are one-time per worker (the
    chip is reused for every job, predict AND design -- design runs in-process on the
    already-open chip, never cold-opening), so serialization only lengthens startup
    slightly and never adds any runtime latency.

    What this does NOT cover. The lock file is one file, so two accounts serialize against
    each other only if both can write it. When they cannot (whglx: ``/tmp/tt-bio-device-
    open.lock`` owned by ``tt-admin`` mode 664, the ``agent`` account not in that group) each
    account falls back to its own ``.uidN`` file and the two accounts bring chips up
    concurrently, unserialized, exactly as the lease directory is already blind across
    accounts there. A shared, group- or world-writable lock file is the only fix for that,
    and creating one is an admin decision about /tmp permissions, not something tt-bio should
    do behind the operator's back. The fallback is announced on stderr when it is taken, so
    the uncovered case is visible rather than silent."""
    f = _open_init_lock_file()
    if f is None:
        yield                    # unserialized, and already warned about above
        return
    serve = None
    try:
        serve = open(_init_lock_path + ".serve", "a")
    except Exception:
        pass                     # no priority on this box; the lock itself still serializes
    held = False
    try:
        borrow = os.environ.get(DEVICE_CLASS_ENV) == "borrow"
        waited = None
        if not _lock_now(f, serve if borrow else None):
            waited = time.time()
            print(f"[tt-bio] {purpose} waits for the device bring-up lock {_init_lock_path}: "
                  f"{_lock_holder(f)}", file=sys.stderr, flush=True)
            if borrow:
                _take_behind_serve(f, serve)
            else:
                if serve is not None:
                    fcntl.flock(serve, fcntl.LOCK_SH)   # says "a serving open is waiting"
                fcntl.flock(f, fcntl.LOCK_EX)  # wait our turn; do NOT proceed concurrently
        if waited is not None:
            print(f"[tt-bio] {purpose} took the device bring-up lock after "
                  f"{time.time() - waited:.0f} s", file=sys.stderr, flush=True)
        held = True
        _record_holder(f, purpose)
        with exit_if_stuck(INIT_LOCK_DEADLINE_S):
            yield
    finally:
        for x in (f, serve):
            try:
                if x is not None:
                    if x is f and held:
                        x.truncate(0)    # the record names a holder; there is none now
                    fcntl.flock(x, fcntl.LOCK_UN)
                    x.close()
            except Exception:
                pass


#: Longest any process may hold the bring-up lock. A healthy single-chip open takes 1-15 s on a
#: Galaxy (bench.jsonl ``device_open``, .114 2026-10-11) and a close a few seconds. A section
#: still running after this is a chip left dirty by a process killed mid-op: it spins in C at
#: 100 % CPU, ignores SIGINT and SIGTERM, and never returns (.114 2026-10-11: 21 opens waited
#: 24 min behind one such process, 13 of 31 chips busy).
INIT_LOCK_DEADLINE_S = 600.0


@contextlib.contextmanager
def exit_if_stuck(seconds):
    """End this process if the block is still running after ``seconds``.

    Bounds a call into the device stack that can block forever in native code, which a Python
    timer or ``signal.alarm`` cannot: ``ttnn.open_device`` holds the GIL while it spins, and
    ``synchronize_device`` blocks with it released and is never interrupted. faulthandler's
    watchdog is a C thread: it dumps every thread's stack to stderr and ``_exit(1)``s, the code
    any other failed open exits with, and the kernel then drops this process's flocks and
    device fds. The dump names the stuck call; reset that chip before reusing it.

    faulthandler has one watchdog per process, so these blocks must not nest.
    """
    import faulthandler

    faulthandler.dump_traceback_later(seconds, exit=True, file=2)   # fd 2: sys.stderr may be redirected
    try:
        yield
    finally:
        faulthandler.cancel_dump_traceback_later()


def _record_holder(f, purpose):
    """Write who holds the bring-up lock into the lock file, for the next waiter to print."""
    try:
        f.truncate(0)
        f.write(json.dumps({"pid": os.getpid(), "since": time.time(), "purpose": purpose,
                            "holder": _holder_label(),
                            "visible": os.environ.get("TT_VISIBLE_DEVICES"),
                            "cmd": " ".join(sys.argv)[:200]}))
        f.flush()
    except Exception:
        pass                     # the record is for people; the lock does not depend on it


def _lock_holder(f):
    """One line naming the process that holds the bring-up lock and since when."""
    try:
        f.seek(0)
        rec = json.loads(f.read() or "null")
    except Exception:
        rec = None
    if not isinstance(rec, dict) or not _pid_alive(rec.get("pid")):
        return "held by a process that left no record (an older tt-bio, or one exiting now)"
    since = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(rec["since"]))
    return (f"held by pid {rec['pid']} ({rec.get('holder')}, {rec.get('purpose')}, "
            f"TT_VISIBLE_DEVICES={rec.get('visible')}, `{rec.get('cmd')}`) since {since}, "
            f"{time.time() - rec['since']:.0f} s ago; a holder still in it at "
            f"{INIT_LOCK_DEADLINE_S:.0f} s is ended")


def _pid_alive(pid):
    try:
        os.kill(int(pid), 0)
        return True
    except PermissionError:
        return True              # alive, under another account
    except Exception:
        return False


#: ``borrow`` marks a process running on a chip a serving host lent it (the JapanFold agent's
#: borrow lane sets it): its bring-ups go after every serving one. Anything else, or unset, serves.
DEVICE_CLASS_ENV = "TT_BIO_DEVICE_CLASS"
#: How often a borrowing open looks again while a serving one waits or the lock is held.
BORROW_POLL_S = 0.5


def _lock_now(f, serve=None):
    """Take the bring-up lock if it is free right now; with ``serve``, only if no serving open waits."""
    try:
        if serve is not None:
            fcntl.flock(serve, fcntl.LOCK_EX | fcntl.LOCK_NB)
            fcntl.flock(serve, fcntl.LOCK_UN)
        fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return True
    except BlockingIOError:
        return False


def _take_behind_serve(f, serve):
    """Take the bring-up lock only when no serving open waits for it.

    .107 2026-10-24 00:07-01:01Z: release legs requeued on lent chips queued their bring-ups
    in the same lock as the agent's canaries, each canary gave up after 300 s behind them,
    and five chips sat out until the box reset itself. A serving open holds ``<lock>.serve``
    shared from before it waits until it is done; a borrowing one never sits in the kernel's
    queue, it polls, so the next release always goes to a waiting serving open."""
    while True:
        if serve is not None:
            try:
                fcntl.flock(serve, fcntl.LOCK_EX | fcntl.LOCK_NB)
                fcntl.flock(serve, fcntl.LOCK_UN)
            except BlockingIOError:
                time.sleep(BORROW_POLL_S)
                continue
        try:
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return
        except BlockingIOError:
            time.sleep(BORROW_POLL_S)


def lease_dir():
    """Directory holding the per-card lease files.

    Defaults to the fleet's lease directory when a ``~/.coworker`` tree exists (so the
    dispatcher's ``pick_card`` and this device-open share one view), else a neutral
    host-local directory for a standalone tt-bio install. ``TT_BIO_LEASE_DIR`` overrides.
    """
    d = os.environ.get("TT_BIO_LEASE_DIR")
    if d:
        return d
    coworker = os.path.expanduser("~/.coworker")
    if os.path.isdir(coworker):
        return os.path.join(coworker, "state", "leases")
    return "/tmp/tt-bio-device-leases"


def lease_host():
    """Host label used in the lease filename. ``TT_BIO_LEASE_HOST`` overrides the hostname
    so it can be aligned with whatever name the dispatcher uses for this host."""
    return os.environ.get("TT_BIO_LEASE_HOST") or socket.gethostname()


def physical_card():
    """The physical card ``get_device()`` will open, named exactly as the fleet names it.

    A worker (or manual run) exports ``TT_VISIBLE_DEVICES`` to the physical chip(s) it may
    use; ``get_device`` then opens logical id ``TT_BIO_LOGICAL_DEVICE_ID`` (default 0), which
    is the ``logical``-th visible chip. Keying the lease on that same value makes the lease
    filename identical to the fleet dispatcher's ``<host>-card<N>.json`` for card N.
    """
    logical = int(os.environ.get("TT_BIO_LOGICAL_DEVICE_ID", "0"))
    visible = os.environ.get("TT_VISIBLE_DEVICES", "")
    if visible.strip():
        # Tokens may be PCI BDFs, which ttnn also accepts; resolve to UMD indices so
        # the lease file keeps the fleet's <host>-card<N>.json naming (issue #11).
        from tt_bio.runtime import visible_device_indices
        cards = visible_device_indices(visible)
        if logical >= len(cards):
            # Silently falling back to cards[0] leased a card the open was never going to
            # get, so the lease named one card and the device work happened on another.
            raise ValueError(
                f"TT_BIO_LOGICAL_DEVICE_ID={logical} is out of range for "
                f"TT_VISIBLE_DEVICES={visible!r} ({len(cards)} card(s) visible: {cards}). "
                "Set it to an index within the visible set, or leave it unset for 0."
            )
        return str(cards[logical])
    return str(logical)


def physical_cards():
    """Every physical card a device open will HOLD, not just the one it computes on.

    ttnn brings up the whole visible set (see the module docstring for the fd measurement),
    so this -- not ``physical_card()`` -- is the set a lease has to cover. With
    ``TT_VISIBLE_DEVICES`` set it is that value's cards; set and EMPTY it is none of them;
    unset, it is every card present, which is exactly the whole-box open this exists to stop
    being invisible.

    Sorted ascending so every process acquires an overlapping set in the same order and two
    of them cannot deadlock holding each other's next card.
    """
    visible = os.environ.get("TT_VISIBLE_DEVICES")
    if visible is not None and not visible.strip():
        # Set and empty is a DECLARATION, not an absence: `TT_VISIBLE_DEVICES= <cmd>` is the
        # deliberate CPU-only run tests/conftest.py documents, and ttnn shows such a process
        # no chips at all. Treating it like unset leased every card on the box for a run that
        # could never use one -- on a single-card host that is a 120 s block behind whoever
        # legitimately held the card, per get_device() call. The open now fails on ttnn's own
        # no-chips abort, which is the honest error and the one conftest already reads.
        return []
    if visible:
        from tt_bio.runtime import visible_device_indices
        cards = visible_device_indices(visible)
    else:
        cards = range(len(glob.glob("/dev/tenstorrent/[0-9]*")))  # UMD indices, not node numbers
    # No cards present (device-free host, CI): keep the single-card behaviour rather than
    # leasing nothing, so a lease is still taken and the open fails on its own terms.
    return [str(c) for c in sorted(set(cards))] or [physical_card()]


def _holder_label():
    """Identity written into the lease. The fleet exports ``TT_BIO_LEASE_HOLDER=worker:<name>``
    at dispatch; a detached/manual job with no such env falls back to its own pid."""
    return os.environ.get("TT_BIO_LEASE_HOLDER") or f"pid:{os.getpid()}"


# An ancestor with one of these names means a human or the fleet is attached above the open: an
# ssh command, a terminal multiplexer, cron. Such an open is not detached, and the daemon at the
# top of its chain lives forever, so recording it would mark the card busy for good.
_ATTACHED_COMMS = ("sshd", "tmux", "screen", "cron", "crond", "atd")


def _detached_ancestor(pid=None):
    """Pid of the DETACHED chain this open belongs to, or ``None`` when it is not detached.

    The lease's own ``pid`` is one device open. A detached chain (a ``nohup``/``setsid``
    release gate, a trajectory ladder) opens and closes the card once per leg, so between
    legs that pid is dead and the lease says released while the chain is about to open the
    card again. The fleet dispatcher reads this field to keep the card busy for as long as the
    chain lives.

    Walks parents up to the one whose parent is init or a ``systemd`` subreaper. That process
    is the answer only if nothing on the way is attached: a controlling terminal, an sshd,
    a multiplexer, cron, or the fleet's ``worker.sh`` (whose own liveness already covers its
    card). An unreadable ``/proc`` answers ``None``, which leaves the lease as it always was.
    """
    me = os.getpid() if pid is None else pid
    pid, top = me, None
    try:
        while pid > 1:
            with open(f"/proc/{pid}/stat") as f:
                stat = f.read()
            comm = stat[stat.index("(") + 1:stat.rindex(")")]
            fields = stat[stat.rindex(")") + 2:].split()
            ppid, tty = int(fields[1]), int(fields[4])
            if comm == "systemd" or comm == "init":
                break
            with open(f"/proc/{pid}/cmdline", "rb") as f:
                argv = f.read().split(b"\0")
            if (tty or comm.startswith(_ATTACHED_COMMS)
                    or any(os.path.basename(a) == b"worker.sh" for a in argv)):
                return None
            top, pid = pid, ppid
    except (OSError, ValueError, IndexError):
        return None
    return top if top not in (None, me) else None


def granted_cards():
    """Physical cards this process is ALLOWED to open, or ``None`` for unbounded.

    ``TT_VISIBLE_DEVICES`` is advice the caller gives itself: a job that never exports it
    (a detached chain, a hand-launched campaign, a gate leg that shells out without the
    ambient pin) selects cards by discovery and can take the whole box while holding a
    one-card grant. That is how qb1 went down on 2026-08-21 -- a gate leg opened all four
    cards under a single-card lease.

    ``TT_BIO_LEASE_CARDS`` is the grant instead of the advice: the dispatcher writes the
    cards it actually handed out, and an open outside that set is refused here, at the one
    choke point every device open passes through. A ``fleet.sh`` that can only refuse to
    *dispatch* cannot stop a process it did not launch; this can.

    Absent or empty means unbounded, which is every path in existence until a control plane
    starts writing it -- so the production service, the Galaxy's multi-card mesh opens and
    every manual run behave exactly as before.
    """
    raw = os.environ.get("TT_BIO_LEASE_CARDS", "")
    if not raw.strip():
        return None
    cards = {tok.strip() for tok in raw.split(",") if tok.strip()}
    return cards or None


class DeviceLease:
    """An exclusive lease on one physical TT card, held for as long as the device is open."""

    def __init__(self, card=None, timeout=DEFAULT_TIMEOUT_S):
        self.card = str(card if card is not None else physical_card())
        self.host = lease_host()
        self.timeout = timeout
        self.dir = lease_dir()
        self.path = os.path.join(self.dir, f"{self.host}-card{self.card}.json")
        self._fd = None
        self._lock = threading.Lock()

    def _read_holder(self):
        try:
            with open(self.path) as f:
                return json.load(f)
        except Exception:
            return None

    def _write_metadata(self):
        meta = {
            "host": self.host,
            "card": self.card,
            "holder": _holder_label(),
            "pid": os.getpid(),
            "detached_pid": _detached_ancestor(),
            "acquired": time.time(),
            "released": None,
        }
        # We hold the exclusive flock, so this rewrite is safe against other leasers.
        # Single truncate + single write keeps a lock-free reader (pick_card) from
        # observing a torn record for these small payloads.
        os.ftruncate(self._fd, 0)
        os.lseek(self._fd, 0, os.SEEK_SET)
        os.write(self._fd, (json.dumps(meta) + "\n").encode())
        os.fsync(self._fd)

    def acquire(self):
        """Atomically claim the card. Blocks up to ``timeout`` if a LIVE process holds it,
        then raises :class:`DeviceInUseError`. Returns ``self``."""
        granted = granted_cards()
        if granted is not None and self.card not in granted:
            raise DeviceInUseError(
                f"physical card {self.card} on {self.host} is outside this job's card grant "
                f"TT_BIO_LEASE_CARDS={','.join(sorted(granted))}. Refusing to open it. "
                f"(Held grant, not advice: unset TT_BIO_LEASE_CARDS for an unbounded run.)"
            )
        os.makedirs(self.dir, exist_ok=True)
        fd = os.open(self.path, os.O_RDWR | os.O_CREAT, 0o664)
        deadline = time.time() + self.timeout
        while True:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError as e:
                if e.errno not in (errno.EWOULDBLOCK, errno.EAGAIN, errno.EACCES):
                    os.close(fd)
                    raise
                if time.time() >= deadline:
                    holder = self._read_holder()
                    os.close(fd)
                    who, same = "?", ""
                    if holder:
                        who = f"{holder.get('holder')} (pid {holder.get('pid')})"
                        # Two processes sharing one TT_BIO_LEASE_HOLDER make the message read
                        # as the job blocking itself, which sends the reader hunting a stale lease
                        # that is not there. Say which it is.
                        if (holder.get("holder") == _holder_label()
                                and holder.get("pid") != os.getpid()):
                            same = (" -- the same holder identity in a DIFFERENT process, so "
                                    "this is a real co-tenant, not a stale lease")
                    raise DeviceInUseError(
                        f"physical card {self.card} on {self.host} is in use by {who}{same}; "
                        f"waited {self.timeout:.0f}s. Refusing to open it concurrently "
                        f"(would collide at the fd level)."
                    )
                time.sleep(_POLL_S)
        self._fd = fd
        try:
            self._write_metadata()
        except Exception:
            pass  # metadata is observability only; the flock is the real lease
        return self

    def release(self):
        """Release the lease: mark the metadata free (best effort) and drop the flock.

        Idempotent and safe to call from atexit. The kernel also drops the flock on process
        death, so a missed release (e.g. SIGKILL) never leaves the card falsely held."""
        with self._lock:
            if self._fd is None:
                return
            fd, self._fd = self._fd, None
            try:
                meta = self._read_holder() or {}
                meta["released"] = time.time()
                os.ftruncate(fd, 0)
                os.lseek(fd, 0, os.SEEK_SET)
                os.write(fd, (json.dumps(meta) + "\n").encode())
            except Exception:
                pass
            try:
                fcntl.flock(fd, fcntl.LOCK_UN)
            except Exception:
                pass
            try:
                os.close(fd)
            except Exception:
                pass

    def __enter__(self):
        return self.acquire()

    def __exit__(self, *exc):
        self.release()


class CardSetLease:
    """Leases EVERY physical card the device open will hold, all-or-nothing.

    One ``DeviceLease`` per card in :func:`physical_cards`, so the fleet's lease-file view
    matches the fds the process actually holds. ``DeviceLease`` stays the unit: this only
    composes it, which keeps the flock semantics (kernel-released on any death, including
    SIGKILL) for every card in the set for free.
    """

    def __init__(self, cards=None, timeout=DEFAULT_TIMEOUT_S):
        # physical_cards() is already sorted; a caller-supplied set is sorted here so the
        # deadlock-free acquisition order does not depend on the caller getting it right.
        raw = list(cards) if cards is not None else physical_cards()
        self.cards = sorted((str(c) for c in raw), key=lambda c: (not c.isdigit(), int(c) if c.isdigit() else c))
        self.timeout = timeout
        self.host = lease_host()
        self._held = []
        self._lock = threading.Lock()

    def acquire(self):
        """Claim every card in the set, or none of them. Returns ``self``."""
        # Check the grant against the WHOLE set first: a refusal names every offending card
        # at once, and a request that was never going to be granted never half-acquires.
        granted = granted_cards()
        if granted is not None:
            outside = [c for c in self.cards if c not in granted]
            if outside:
                raise DeviceInUseError(
                    f"this device open would hold physical card(s) {','.join(outside)} on "
                    f"{self.host}, outside this job's card grant "
                    f"TT_BIO_LEASE_CARDS={','.join(sorted(granted))}. Refusing to open it. "
                    f"ttnn brings up every card TT_VISIBLE_DEVICES makes visible, not only the "
                    f"one it computes on, so pin TT_VISIBLE_DEVICES to your granted card(s) "
                    f"(currently {os.environ.get('TT_VISIBLE_DEVICES') or 'unset, i.e. the whole box'})."
                )
        # ONE timeout budget for the set, not len(cards) x timeout: a contended set must fail
        # in the time a caller was told to expect, not four times it.
        deadline = time.time() + self.timeout
        for card in self.cards:
            try:
                self._held.append(DeviceLease(card=card,
                                              timeout=max(0.0, deadline - time.time())).acquire())
            except BaseException:
                self.release()   # never leave half a set leased
                raise
        return self

    def release(self):
        """Free every card held. Idempotent, safe from atexit."""
        with self._lock:
            while self._held:
                self._held.pop().release()

    @property
    def card(self):
        """The card the device is opened on, for callers that log a single id."""
        return self.cards[0] if self.cards else None

    def __enter__(self):
        return self.acquire()

    def __exit__(self, *exc):
        self.release()


def pin_one_card(cards=None):
    """Pin an unpinned single-device open to ONE card and lease it. Returns the lease, or None.

    ``get_device()`` computes on one chip, but with ``TT_VISIBLE_DEVICES`` unset ttnn brings up
    every card on the host and builds a fabric over them first. Where the cards are not wired
    as the mesh ttnn auto-derives, that bring-up is a TT_FATAL and nothing opens: on a 4x p150a
    box whose cards are cabled only in pairs (Tamarind f12cs06, 2026-11-24), every in-process
    open -- embed, saprot, rfd3 design -- died with "Graph specified in MGD could not fit in the
    discovered physical topology", while the predict fanout, which pins one card per worker,
    ran fine. It also held all four cards for a one-card job.

    So the unpinned open is made exactly the open a fanout worker does: ``TT_VISIBLE_DEVICES``
    = one card, logical device 0. The card is an explicit ``TT_BIO_LOGICAL_DEVICE_ID`` if one
    is set (it named a UMD index, which is what ``TT_VISIBLE_DEVICES`` takes), else the first
    card in the grant that is free right now, else the first one, waited on the usual bounded
    time. Set visibility -- including set-and-empty -- is the caller's decision and is left
    alone, as is a host with one card.
    """
    if "TT_VISIBLE_DEVICES" in os.environ:
        return None
    cards = [str(c) for c in (cards if cards is not None else physical_cards())]
    if len(cards) <= 1:
        return None
    logical = os.environ.get("TT_BIO_LOGICAL_DEVICE_ID", "").strip()
    if logical:
        idx = int(logical)
        if not 0 <= idx < len(cards):
            raise ValueError(f"TT_BIO_LOGICAL_DEVICE_ID={idx} is out of range for this host's "
                             f"{len(cards)} card(s): {cards}.")
        lease = DeviceLease(card=cards[idx]).acquire()
    else:
        granted = granted_cards()
        candidates = [c for c in cards if granted is None or c in granted] or cards
        lease = None
        for card in candidates:
            try:
                lease = DeviceLease(card=card, timeout=0).acquire()
                break
            except DeviceInUseError:
                continue
        if lease is None:
            lease = DeviceLease(card=candidates[0]).acquire()
    os.environ["TT_VISIBLE_DEVICES"] = lease.card
    os.environ["TT_BIO_LOGICAL_DEVICE_ID"] = "0"
    return lease


# ---------------------------------------------------------------------------
# Process-lifetime guard: who may still be holding a card
# ---------------------------------------------------------------------------
_ARMED = False


#: How long an orphan gets to unwind after its parent is gone before it is SIGKILLed. A worker's
#: SIGTERM handler closes its chip in seconds, and its heartbeat backstop exits at ~60 s when the
#: interpreter still runs; this is the case where neither can.
ORPHAN_KILL_AFTER_S = 90.0

# Runs in its own interpreter, so a process wedged inside a C call cannot stop it. It is the
# guarded process's child: while ``getppid()`` names that process, a kill cannot hit a recycled
# pid. The parent's death shows as a changed ppid in /proc, which needs no pidfd (a uv-built
# Python has no os.pidfd_open). It ignores the group signals its guarded process gets, so a
# `timeout` that SIGTERMs the whole group does not take the reaper down first, and it holds
# none of the guarded process's fds, so a reader waiting for that process's EOF never waits on it.
_REAPER_SRC = """
import os, signal, sys, time
for s in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
    signal.signal(s, signal.SIG_IGN)
guarded, parent, after = int(sys.argv[1]), int(sys.argv[2]), float(sys.argv[3])

def parent_of(pid):
    try:
        with open(f"/proc/{pid}/stat") as f:
            return int(f.read().rsplit(")", 1)[1].split()[1])
    except (OSError, IndexError, ValueError):
        return None

while os.getppid() == guarded and parent_of(guarded) == parent:
    time.sleep(0.25)
deadline = time.monotonic() + after
while os.getppid() == guarded and time.monotonic() < deadline:
    time.sleep(0.25)
if os.getppid() == guarded:
    try:
        with open(f"/proc/{guarded}/fd/2", "w") as err:
            err.write(f"tt-bio: pid {guarded} outlived its parent {parent} by {after:.0f}s "
                      "without taking SIGTERM; killing it (SIGKILL)\\n")
    except OSError:
        pass
    os.kill(guarded, signal.SIGKILL)
"""
_REAPER = None


def _start_orphan_reaper(parent_pid: int, kill_after_s: float) -> None:
    """SIGKILL this process ``kill_after_s`` after ``parent_pid`` stops being its parent.

    The reaper exits within a quarter second of this process, so it never outlives what it guards.
    """
    global _REAPER
    import subprocess

    _REAPER = subprocess.Popen(
        [sys.executable, "-I", "-S", "-c", _REAPER_SRC,
         str(os.getpid()), str(parent_pid), str(kill_after_s)],
        stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def install_parent_death_guard(parent_pid: int, *, exit_code: int = 70,
                               kill_after_s: float = ORPHAN_KILL_AFTER_S) -> None:
    """Die with the process that owns this one, from inside any call.

    PR_SET_PDEATHSIG is delivered by the kernel the moment the parent dies, so it
    covers the case a between-jobs ``getppid()`` check cannot: a process orphaned in
    the middle of device work, still holding its chip and its card lease. One was
    found holding /dev/tenstorrent/0 and card 3's flock for 6 h at 100% CPU; another,
    a gate scorer, held card 1 for 1 h 43 m and killed the next gate's first leg with
    DeviceInUseError.

    The death signal is SIGTERM so that a worker's handler can close its chip cleanly.
    A Python handler only runs when the interpreter does, though, and a process wedged
    in a ttnn call never gets back to it: a predict worker stuck in the bring-up
    dispatch probe held card 3 for 1 h 48 min after `timeout` killed its CLI
    (2026-11-13). So a reaper process escalates to SIGKILL ``kill_after_s`` later,
    which nothing in this process can block or delay. Stale-lease reclaim stays the
    backstop behind both.

    The kernel sends the signal when the parent THREAD that created us exits, not when
    the parent process does, so a caller spawning from a thread pool must not let that
    thread return while the child is still alive. The reaper watches the process.
    """
    if not parent_pid:
        return
    try:
        import ctypes

        ctypes.CDLL(None).prctl(1, int(signal.SIGTERM))  # 1 = PR_SET_PDEATHSIG
    except Exception:
        pass
    # The parent can die between our spawn and the prctl above. man 2 prctl: no signal
    # is sent if it is already gone, so re-check by hand.
    if os.getppid() != parent_pid:
        os._exit(exit_code)
    try:
        _start_orphan_reaper(parent_pid, kill_after_s)
    except OSError:
        pass


def orphan_guard_env() -> dict:
    """Environment that lets a child this process spawns arm its guard against us.

    Merge it into the env of any child that can open a device. The child arms in
    ``arm_orphan_guard``, which every device open and every CLI entry point calls.
    """
    return {"TT_BIO_PARENT_PID": str(os.getpid())}


def arm_orphan_guard() -> None:
    """A process about to take a card must not outlive whoever wanted the result.

    ``TT_BIO_PARENT_PID`` names the process that spawned us: the predict CLI for its
    workers, a gate driver for its scorers and folds. Arm only when the value really is
    our parent. A stale value inherited from a dead grandparent means we are a detached
    fleet job, and those must keep running, so the test is exact rather than "the
    variable is set".

    SIGTERM keeps its default disposition here on purpose. A Python handler only runs
    when the interpreter does, and a process wedged inside a ttnn call would then hold
    its card forever, which is the failure this guard exists to end. Workers can afford
    a handler because ``run_worker_loop``'s heartbeat backstops it.
    """
    global _ARMED
    if _ARMED:
        return
    parent = int(os.environ.get("TT_BIO_PARENT_PID") or 0)
    if not parent or parent != os.getppid():
        return
    _ARMED = True
    install_parent_death_guard(parent)
