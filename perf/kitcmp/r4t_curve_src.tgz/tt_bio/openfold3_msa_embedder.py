"""OF3 MSAModuleEmbedder device port (P7).

OF3 ``MSAModuleEmbedder`` (AF3 Algorithm 8 lines 1-4): subsample the MSA, then

    m = linear_m(msa_feat) + linear_s_input(s_input).unsqueeze(-3)

Two bias-free linears (``linear_m`` 34->c_m=64 over ``cat([msa, has_deletion,
deletion_value])``; ``linear_s_input`` c_s_input=449->c_m=64) and a broadcast add over
the MSA-sequence dim. The MSA subsampling (stochastic, AF3 SI 2.2) is host-side and
captured in the golden (``scripts/of3_msa_embedder_golden.py`` records the post-subsample
``msa_feat`` via a ``linear_m`` input hook), so this module is PCC-gated against the exact
reference subsample -- isolating the device linear precision from the subsample logic, the
same discipline as the other OF3 golden legs.

This extends the trunk validation past the InputEmbedder: ``s_input -> m`` here, complementing
the already-gated MSA stack (``m, z -> z`` in tests/test_openfold3_msa.py).
"""
from __future__ import annotations

import torch
import ttnn

from . import ops
from .tenstorrent import (
    Module, OuterProductMean, PairWeightedAveraging, Transition, PairformerLayer,
    accurate_softmax_site, msa_depth_chunks, msa_update_chunks, pwa_single_shot_bytes,
    triatt_sdpa_hifi_site, _z_residual,
)
from .openfold3_weights import remap_msa_module


class MSAModuleEmbedder(Module):
    def __init__(self, state_dict, compute_kernel_config):
        super().__init__(state_dict, compute_kernel_config)
        self.w_m = self.torch_to_tt("linear_m.weight")
        self.w_s = self.torch_to_tt("linear_s_input.weight")

    def __call__(self, msa_feat, s_input):
        """msa_feat: [1, N_seq, N_token, 34] device; s_input: [1, N_token, 449] device.
        Returns m: [1, N_seq, N_token, c_m=64]."""
        lin = self._lin
        m = lin(msa_feat, self.w_m)
        s = lin(s_input, self.w_s)            # [1, N_token, 64]
        s = ttnn.unsqueeze(s, -3)             # [1, 1, N_token, 64] -- broadcast over N_seq
        m = ttnn.add(m, s)
        ttnn.deallocate(s)
        return m


# OF3 msa_module dims (config.model_config): c_hidden_msa_att=8, no_heads_msa=8;
# c_hidden_pair_att=32, no_heads_pair=4. The pair_stack runs pair-only (transform_s=False).
_MSA_AVG_DIMS = (8, 8)
_MSA_TRI_DIMS = (32, 4)


class MSAModuleBlock:
    """One OF3 ``MSAModuleBlock`` (AF3 Algorithm 10), ``opm_first=True`` ordering
    (OuterProductMean runs BEFORE the msa update -- the reverse of
    ``tt_bio.tenstorrent.MSALayer``'s Boltz-2 ``opm_first=False`` order, so the block
    is composed from the raw primitives directly, not via ``MSALayer``).

    m, z -> m, z per block:

        z = z + outer_product_mean(m)
        if not skip_msa_update:                  # all blocks except the last
            m = m + pair_weighted_averaging(m, z)
            m = m + msa_transition(m)
        z = pair_stack(z)                        # tri_mul + tri_att + pair_transition

    The last block (``skip_msa_update=True``) has no PWA/transition; ``has_msa_update``
    is inferred from which keys ``remap_msa_block`` returned. Composes the same
    primitives, in the same order, as ``tests/test_openfold3_msa.py::_run_block`` -- the
    single source of truth for the OF3 block ordering.
    """

    def __init__(self, block_remap, compute_kernel_config, transpose_bias: bool = True,
                 z_fp32_residual: bool = False):
        ckc = compute_kernel_config
        self.z_fp32_residual = z_fp32_residual
        self.opm = OuterProductMean(block_remap["outer_product_mean"], ckc,
                                  scale_bias=True)
        self.has_msa_update = "pair_weighted_averaging" in block_remap
        if self.has_msa_update:
            self.pwa = PairWeightedAveraging(
                *_MSA_AVG_DIMS, block_remap["pair_weighted_averaging"], ckc)
            self.msa_transition = Transition(block_remap["msa_transition"], ckc)
        # scale_pair_bias=False: openfold3 adds the tri_att pair bias UNSCALED (q is
        # pre-scaled by 1/sqrt(d)); the shared primitive's default sqrt(d) fold is the
        # Boltz convention and was root-caused as the OF3 MSA z-track degradation.
        self.pair_stack = PairformerLayer(
            *_MSA_TRI_DIMS, None, None, False, block_remap["pair_stack"], ckc,
            scale_pair_bias=False, fp32_softmax=True, transpose_bias=transpose_bias,
            accurate_softmax=accurate_softmax_site("openfold3.msa"),
            # Default ON with the template and confidence sites (spd-of3 g14, see openfold3_template).
            tri_att_sdpa_hifi=triatt_sdpa_hifi_site("openfold3.msa", True),
            z_fp32_residual=z_fp32_residual)

    def __call__(self, m, z, pair_mask=None, attn_mask=None):
        # OuterProductMean is deliberately left unmasked: it reduces over MSA DEPTH, so a padded
        # token can only reach a padded pair through it. PairWeightedAveraging is not -- its
        # softmax runs over the token axis, so a padded key would take real weight without the
        # additive -1e9 (protenix.py Trunk.update_msa passes the same tensor for the same reason).
        # Every residual in this block accumulates IN PLACE. Out of place, an add holds three
        # copies of its operand at the peak -- the input, the update and the new sum. For `m`,
        # [depth, tokens, c_m], that third copy is 1 859 780 608 B at 1024 tokens against a
        # 14189-row alignment and 1 976 016 896 B at the 1088 tokens a ligand pushes OpenBind-0
        # to; both are buffers a fold is refused on a 12 GiB Wormhole part.
        #
        # The `m` residual lands in the UPDATE's buffer, never in the caller's `m`. Two
        # callers need that. The trunk keeps the embedder's `m` and hands the SAME tensor back
        # on every recycle (openfold3_trunk.py), so writing into it would corrupt the next
        # cycle; and a checkpointed segment recomputes itself from its input VALUES in the
        # backward, so a block that overwrote its input would recompute from the sum and
        # differentiate the wrong function. Both want the same thing, which is why this is not
        # a flag: the block is a pure function of what it was handed. bf16 addition is
        # commutative, so it is `add(m, upd)` bit for bit, and the peak is unchanged -- two
        # copies live either way. The `z` residual needs no such care: it lands in the OPM
        # update's buffer and never writes `z` itself.
        #
        # A deep alignment arrives as a host tensor (the trunk's `msa_embed`) or as the
        # previous block's depth chunks, and stays chunks parked on the host: OPM and the update
        # each upload a chunk for their read, so the whole [depth, tokens, c_m] tensor never
        # exists on the device and the pair stack runs without it. Held there as a chunk list it
        # was 2.79 GB at 1536 tokens x 14191 rows, and triangle attention was refused beside it.
        if torch.is_tensor(m):
            m = list(msa_depth_chunks(m, park=True))
        upd = self.opm(m, None, None)
        # Training only (PairformerLayer's z_fp32_residual): the pair residual held in fp32.
        wide = self.z_fp32_residual and ops.taping()
        z = _z_residual(z, z, upd, True) if wide else ttnn.add_(upd, z)
        if self.has_msa_update and isinstance(m, list):
            zb = ttnn.typecast(z, ttnn.bfloat16) if z.dtype == ttnn.float32 else z
            m = msa_update_chunks(m, zb, self.pwa, self.msa_transition, attn_mask, park=True)
            if zb is not z:
                ttnn.deallocate(zb)
        elif self.has_msa_update:
            zc = ttnn.typecast(z, ttnn.bfloat16) if z.dtype == ttnn.float32 else ttnn.clone(z)
            upd = ttnn.reshape(self.pwa(m, zc, attn_mask), tuple(m.shape))
            m = ttnn.add_(upd, m)
            # Each residual leaves the previous `m` buffer free somewhere in the middle of the
            # heap, and the next one needs its whole width contiguous: at 960 tokens x 14191 rows
            # the transition's 1 743 790 080 B was refused with 4.4 GB free and 1.35 GB as the
            # largest run. Compacting between the two residuals coalesces that hole, the same call
            # OuterProductMean already makes before its own matmuls. Pure data movement, and only
            # where the residual is wide enough to be at risk -- below the budget this is the
            # single-shot path's untouched sequence of allocations.
            if m.logical_volume() * 2 > pwa_single_shot_bytes():
                m = ttnn.reallocate(m)
            upd = ttnn.reshape(self.msa_transition(m), tuple(m.shape))
            m = ttnn.add_(m, upd)
            ttnn.deallocate(upd)
        z = self.pair_stack(None, z, pair_mask, attn_mask, attn_mask)[1]
        return m, z


class MSAModule:
    """OF3 ``MSAModuleStack`` (4-block, ``opm_first=True``) device port. ``m, z -> z``
    (the reference discards ``m`` after the last block; the device path returns both so
    the trunk can reuse the constant ``m`` across cycles without re-running the
    embedder).

    Device-precision note (see docs/openfold3-port.md, "Precision"): the residual
    z-track gap is an intrinsic bf16 ill-conditioning limit at OF3's
    activation magnitude, NOT a kernel bug and NOT the
    softmax lever; the fp32-z-path fix is release-gated. The trunk accepts this
    degradation as a known, quantified real number and measures its propagation into
    s_trunk/z_trunk rather than chasing it further.
    """

    def __init__(self, state_dict, compute_kernel_config, transpose_bias: bool = True,
                 z_fp32_residual: bool = False):
        # z_fp32_residual fires only under a tape, and then `z` comes back fp32.
        self.blocks = [
            MSAModuleBlock(b, compute_kernel_config, transpose_bias=transpose_bias,
                           z_fp32_residual=z_fp32_residual)
            for b in remap_msa_module(state_dict, prefix="msa_module")
        ]

    def __call__(self, m, z, pair_mask=None, attn_mask=None):
        # Through the seam, for the same reason the 48-block pairformer goes through it: under
        # a tape these four blocks retain every intermediate they produce, and four MSA blocks
        # at crop 384 exhaust all 34.217 GB of a p300c on their own, before the template stack
        # or the trunk has run (perf/of3t_l1/out/base_384.json). Inference pays one `is None`
        # test per block.
        for block in self.blocks:
            m, z = ops.checkpoint_segment(
                lambda m_, z_, b=block: b(m_, z_, pair_mask, attn_mask), m, z)
        return m, z
