#!/usr/bin/env python3
"""S0, the kill gate for the whole fused-kernel route: re-drive ``ttnn.experimental.minimal_matmul``
through ``ttnn.generic_op``, using the wheel's own three kernel sources unmodified.

This is a transcription of ``minimal_matmul_program_factory.cpp`` at the ``v0.68.0`` tag (the wheel's
kernel sources are byte-identical to that tag, checked in the planning pass) into a Python
``ttnn.ProgramDescriptor``. No kernel edit, no design change, no tt-metal build. If the transcription
reproduces the native op's time and output, every later step is a dataflow edit on top of it; if it
does not, the route is dead and the task is a NO-GO.

PREDICTION, WRITTEN BEFORE THE RUN (state/triatt-fused-kernel-final.md 5):

    2.13-2.35 ms against the 2.127 ms MEASURED native qkv arm, and ``torch.equal`` on the output.
    > 2.40 ms, or not torch.equal: the whole route is dead.

Only the fixed case the fold issues is covered: bf16 in / bf16 out, interleaved DRAM, no bias, no
fused activation, no ternary, no all-gather fusion, N_chunks = 1.
"""

from __future__ import annotations

import collections
import itertools

import ttnn

from . import dest_guard

# tt_metal/hostdevcommon/api/hostdevcommon/common_values.hpp
INVALID, VALID = 0, 1
TILE_HW = 32

# Blackhole takes the default branch of detail::preferred_noc_for_dram_{read,write}
# (tt_metal/api/tt-metalium/kernel_types.hpp:126-138).
NOC_FOR_DRAM_READ = ttnn.NOC.NOC_0
NOC_FOR_DRAM_WRITE = ttnn.NOC.NOC_1

#: Bytes one TILE_HW x TILE_HW tile occupies, per dtype. sdpa_generic and softmax_generic
#: size their CBs from this same table -- see `tile_bytes`.
#:
#: A block format is not width x datums: bfloat8_b is 1024 mantissa bytes plus a 64-byte exponent
#: section, so 1088 and not 1024. tt-metal fixes both halves -- `tile_size()` returns
#: (256 * 4) + (16 * 4) in tt_metal/api/tt-metalium/tt_backend_api_types.hpp:107, and
#: `Tile::get_tile_size` builds tile_hw + aligned_exp_size in
#: tt_metal/impl/data_format/tile.cpp:79. 1024 here under-sizes every CB page by 6.25 %, which
#: hangs or corrupts rather than raising.
_TILE_BYTES = {ttnn.bfloat16: 2048, ttnn.float32: 4096, ttnn.bfloat8_b: 1088, ttnn.bfloat4_b: 576}

#: The storage dtypes a hand-transcribed fast path may take. `bfloat8_b` is here because every CB
#: page size in these transcriptions comes from `tile_bytes` and every tile size in their kernels
#: from `get_tile_size(cb)`, so there is no 2-bytes-an-element assumption in the dataflow for a
#: 1088-byte block-float tile to break. What the four gates below used to test was `== bfloat16`,
#: which is our own line rather than a kernel limit: `ttnn.experimental.minimal_matmul` has taken
#: BFLOAT8_B and BFLOAT4_B since before our pin.
FAST_DTYPES = frozenset({ttnn.bfloat16, ttnn.bfloat8_b})


def fast_dtypes_ok(*dtypes, dest=None) -> bool:
    """True when every READ operand dtype is one a fast path covers AND they are all the same.

    Uniformity is LOAD BEARING, but not for the reason first recorded here, and the difference
    decides whether it can ever be relaxed. The original note cited a measurement -- bfp8 q/k/v
    with a bf16 mask served, returned finite values and scored 12.55 rel_rms against 0.0267 for
    the bf16 control, 470x -- and read it as the SDPA kernel computing wrong values on a mixed
    operand set. That reading is confounded and the number does not support it.
    `perf/bfp8_sdpa/probe2.py::OPS` builds its arms in one process as `bf16`, then `bfp8` (bfp8
    mask), then `bfp8_qkv_bf16_mask` (bf16 mask) at IDENTICAL shapes, chunks, grid and q dtype,
    and warms every arm in `ORDER` before timing. `sdpa_generic.sdpa`'s cache key carried
    `str(q.dtype)` and no other operand's format, so the third arm collided with the second and
    ran a program compiled for a bfp8 mask -- wrong page size, and `check_uniform_dataformat`
    (`sdpa_generic.py:440`) compiled in for the wrong operand set. The 470x is that collision.
    `bfp8-accuracy-envelope` demonstrated the same mechanism independently on
    TT_BIO_TRIATT_BIAS_B8: 22.21 A interleaved after a base fold in one process against 0.92671 A
    for the identical flag alone, both digests reproducible, the solo one bit-identical to main.

    What IS established, and why the clause stays: several program caches on these paths key on a
    SUBSET of their operands' formats, so a mixed set can silently fetch a program built for a
    different one. `sdpa_generic.sdpa`'s key is fixed (it now carries q/k/v/mask/out), but
    `trimul_tail.py:252` still omits xb/wb/out, `swiglu_fused.py:191` omits w2 and
    `tenstorrent.py:2657` omits b. None of those three serves a call today, which is exactly why
    this clause has been holding them harmless. So uniformity is a guard over under-keyed caches,
    NOT a numerical limit of the kernels -- relax it only per path, once that path's cache key
    carries every operand it compiles against.

    On the SDPA path that re-scoring has since been done, in a fresh process (one program per key)
    rather than an interleaved A/B: `bfp8-accuracy-envelope` measured the mixed arm run alone as
    BIT-IDENTICAL to uniform bfp8 at 298 aa and at 512 aa, with 560 of 560 calls counted taking the
    downcast so it is not a silent null. A mixed dataformat into the fused SDPA computes the right
    answer. The clause stays anyway, because it is cheap and it still guards the three caches above,
    and because narrowing this path is the wrong SIGN on speed regardless (see below).

    The separate, unconfounded numbers: uniform bfp8 on the SDPA path scores 0.0283 rel_rms
    against 0.0267 bf16, a 5.7 % debit and fine -- but it is 0.7142x at B=64 and 0.8071x at
    B=512, i.e. the wrong SIGN on speed, because `sdpa_generic.cb_table` pins the five
    intermediate CB groups to bf16 unconditionally (`:231-233`) and the saved DRAM bytes come
    back as a per-tile unpack conversion on the math thread.
    `dest` is the DESTINATION format and is exempt from uniformity, because the precondition the
    paragraph above sets out is met for it: it is written through a circular buffer of its own,
    `_cb(2, .., tile_bytes(out.dtype), .., out.dtype)`, the accumulator it is packed from is a
    separate `interm_fmt` (fp32 under `fp32_dest_acc_en`) and not tied to it, and `_key` carries
    `str(t.dtype)` for EVERY output, so a narrowed destination gets its own program rather than a
    collision. The narrowing is therefore one rounding at the pack stage and touches no
    contraction. Passing `dest` is still a membership test; leaving it `None` is the old
    behaviour exactly, and a uniform call is unchanged either way.
    """
    seen = set(dtypes)
    if len(seen) != 1 or not seen <= FAST_DTYPES:
        return False
    return dest is None or dest in FAST_DTYPES


def tile_bytes(dtype):
    """Bytes one tile occupies in `dtype`, for a CB page size or a runtime arg."""
    try:
        return _TILE_BYTES[dtype]
    except KeyError:
        raise ValueError(f"no tile size for {dtype}: these transcriptions cover bf16, fp32 "
                         "and bfp8_b") from None

_CACHE: dict = {}

#: Descriptors already built for an address set, keyed `(entry serial, addresses)`, most recent
#: last. A program's runtime args are its buffer addresses and nothing else that varies, so the
#: descriptor `rebind` would build for addresses seen before is the one it built then, and a
#: launch whose buffers sit where an earlier launch's did skips the rebuild: ~107 us of list
#: writes and binding round-trips per rebind on pc (110 cores, 4 DM kernels), against one dict
#: lookup. Same descriptor, same program, same arithmetic -- bit-exact by construction. Whether it
#: HITS is the allocator's business: a fixed-shape loop that allocates in the same order lands on
#: the same addresses, and `BOUND_STATS` reads the rate. Capped by count at ~34 KB a descriptor,
#: so the worst case is ~140 MB of host RAM; a cycle longer than the cap only costs the lookup.
_BOUND: collections.OrderedDict = collections.OrderedDict()
_BOUND_MAX = 4096
_SERIAL = itertools.count()
BOUND_STATS = collections.Counter()


def bound_descriptor(entry, addrs):
    """The descriptor `entry` was given at `addrs` before, or None.

    Keyed on a serial `remember_bound` stamps on the entry rather than `id(entry)`: an id is
    reused once its dict dies, and a descriptor handed to a different program is a wrong launch.
    """
    key = (entry.get("serial"), addrs)
    pd = _BOUND.get(key)
    BOUND_STATS["hit" if pd is not None else "miss"] += 1
    if pd is not None:
        _BOUND.move_to_end(key)
    return pd


def remember_bound(entry, addrs, pd):
    if "serial" not in entry:
        entry["serial"] = next(_SERIAL)
    _BOUND[(entry["serial"], addrs)] = pd
    if len(_BOUND) > _BOUND_MAX:
        _BOUND.popitem(last=False)


def ttnn_cpp_root():
    """The directory holding ttnn's C++ ``cpp/`` tree, whichever way ttnn was installed.

    Kernel sources are pointed at in place so their sibling includes resolve, which means
    this path has to be right. The pip wheel vendors them at ``<pkg>/ttnn/cpp``; a source
    build imports ttnn from ``<checkout>/ttnn/ttnn`` and keeps them at ``<checkout>/ttnn/cpp``.
    Assuming the wheel layout produced ``<checkout>/ttnn/ttnn/ttnn/cpp/...`` on a source
    build, so every generic_op kernel failed to JIT-build with "No such file or directory"
    and four of the release gate's models could not fold at all.
    """
    import os
    import ttnn as _t
    from pathlib import Path
    root = Path(_t.__file__).resolve().parent
    candidates = [root / "ttnn", root.parent]
    metal_home = os.environ.get("TT_METAL_HOME")
    if metal_home:
        candidates.append(Path(metal_home) / "ttnn")
    for cand in candidates:
        if (cand / "cpp" / "ttnn" / "operations").is_dir():
            return cand
    return candidates[0]


def _kernel_dir(kind="minimal_matmul"):
    return ttnn_cpp_root() / "cpp/ttnn/operations/experimental" / kind / "device/kernels"


def ckc_args(ckc):
    """The four fields ``ComputeConfigDescriptor`` takes, read off a ``DeviceComputeKernelConfig``.

    ``get_compute_kernel_config_args`` also returns ``packer_l1_acc``, which the C++ factory
    destructures and never passes to ``ComputeConfig``; there is no field for it here either.
    """
    return (getattr(ckc, "math_fidelity", ttnn.MathFidelity.HiFi4),
            bool(getattr(ckc, "math_approx_mode", False)),
            bool(getattr(ckc, "fp32_dest_acc_en", False)),
            bool(getattr(ckc, "dst_full_sync_en", False)))


def _div_up(a, b):
    return (a + b - 1) // b


def _round_up(a, b):
    return _div_up(a, b) * b


def _build_core_order_for_axis(core, transpose, axis_length, noc, axis_is_x, initial_endpoint):
    """Transcription of ``build_core_order_for_axis``. ``core`` is (x, y)."""
    order = [initial_endpoint]
    cx, cy = core
    current = (cy if axis_is_x else cx) if transpose else (cx if axis_is_x else cy)
    increasing = noc == ttnn.NOC.NOC_0
    index_of_current = 0
    for w in range(1, axis_length):
        val = w if increasing else (axis_length - w)
        if transpose:
            wc = (cx, val) if axis_is_x else (val, cy)
        else:
            wc = (val, cy) if axis_is_x else (cx, val)
        if val == current:
            index_of_current = w
        order.append(wc)
    return order, index_of_current


def _cb(idx, core_grid, page_size, num_tiles, data_format):
    fmt = ttnn.CBFormatDescriptor(buffer_index=idx, data_format=data_format, page_size=page_size)
    return ttnn.CBDescriptor(
        total_size=num_tiles * page_size, core_ranges=core_grid, format_descriptors=[fmt])


def build(device, in0, in1, outs, cfg, ckc, defines=(), kernel_dir=None, m_k=None,
          noc_mode=None, n_widths=None, bias=None, extra=(), transpose=None, n_align=1):
    """The ProgramDescriptor for ``minimal_matmul(in0, in1) -> outs`` with block config ``cfg``.

    ``cfg`` is a 5-tuple ``(M_block, K_block, N_block, subblock_h, subblock_w)`` and a
    ``(grid_x, grid_y)``; ``ckc`` is ``(math_fidelity, math_approx_mode, fp32_dest_acc_en,
    dst_full_sync_en)``. ``outs`` is a list of output tensors, one per N chunk, so a single-output
    matmul and the three-way qkv split are the same code path. Everything else is read off the
    tensors, exactly as the C++ factory does.

    ``defines`` and ``kernel_dir`` are the only additions to the transcription: they let the two DM
    kernels come from ``tt_bio/kernels/triatt/`` with the head-major guards set, which is K1.
    ``m_k`` overrides the ``(M, K)`` the factory would infer from ``in0``'s shape, which a
    head-major activation reports wrongly: ``[S, 8, S, 32]`` is the same tile grid as
    ``[S*S, 256]`` but its last dim is 32.

    ``n_widths`` is the N tile count of each output chunk, for the case where they are not all
    the same -- a 512-wide projection and a 128-wide one sharing one pass over the activation.
    Only a differing LAST chunk is supported, which is what the kernel's ``MM_SPLIT_LAST_TILES``
    covers and what every call site needs. ``None`` means the stock equal split.

    ``bias`` is a [1, N] row added to every output row (the factory's FUSE_BIAS: the non-writing DM kernel
    reads its N block into c_4, the compute adds it in the epilogue). Its address is the DM kernels' args[1].

    ``extra`` are more tensors a patched DM kernel reads (mm_rope's cos / sin): their accessors follow the bias's in
    the compile-time args, their addresses come just before the outputs' in the runtime args.

    ``transpose`` overrides the factory's ``M > N`` pick of which axis of the grid carries N (True: N over the grid's
    rows). ``n_align`` pads N so every core's range is a whole number of ``n_align`` tiles (mm_gate needs whole N
    blocks a core); 1 is the factory's padding to the core count.

    ``noc_mode`` is for a DM kernel that issues transactions on the NOC it was NOT configured
    with. Under the default ``DM_DEDICATED_NOC`` the firmware only runs ``noc_local_state_init``
    for the kernel's own NOC, so a write on the other one never issues and the barrier spins
    forever -- MEASURED as a device hang on the first call, card 0, 2026-08-15.
    ``DM_DYNAMIC_NOC`` initialises both and arbitrates the command buffers atomically.
    """
    if not isinstance(outs, (list, tuple)):
        outs = [outs]
    out = outs[0]
    (M_block_tiles, K_block_tiles, N_block_tiles, subblock_h, subblock_w), (gx, gy) = cfg
    if M_block_tiles % subblock_h or N_block_tiles % subblock_w:   # the kernels run and write garbage (ls118: 5,4,2,2,2 inf)
        raise RuntimeError(f"subblock {subblock_h}x{subblock_w} does not tile the {M_block_tiles}x{N_block_tiles} block")
    math_fidelity, math_approx_mode, fp32_dest_acc_en, dst_full_sync_en = ckc
    defines = [(str(k), str(v)) for k, v in dict(defines).items()]

    core_grid = ttnn.CoreRangeSet(
        [ttnn.CoreRange(ttnn.CoreCoord(0, 0), ttnn.CoreCoord(gx - 1, gy - 1))])

    in0_shape = [int(d) for d in in0.padded_shape]
    in1_shape = [int(d) for d in in1.padded_shape]
    if m_k is None:
        K = in0_shape[-1]
        M = 1
        for d in in0_shape[:-1]:
            M *= d
    else:
        M, K = m_k
        vol = 1
        for d in in0_shape:
            vol *= d
        assert M * K == vol, (m_k, in0_shape)
    N = in1_shape[-1]

    M_tiles, K_tiles, N_tiles = M // TILE_HW, K // TILE_HW, N // TILE_HW
    N_chunks = len(outs)
    if n_widths is None:
        N_tiles_per_chunk = N_tiles // N_chunks
    else:
        assert len(n_widths) == N_chunks and sum(n_widths) == N_tiles, (n_widths, N_tiles)
        assert len(set(n_widths[:-1])) <= 1, ("only the last chunk may differ", n_widths)
        N_tiles_per_chunk = n_widths[0]
        if n_widths[-1] != n_widths[0]:
            defines = defines + [("MM_SPLIT_LAST_TILES", str(int(n_widths[-1])))]

    in0_tile_size = tile_bytes(in0.dtype)
    in1_tile_size = tile_bytes(in1.dtype)
    out_tile_size = tile_bytes(out.dtype)
    in2_tile_size = tile_bytes(bias.dtype) if bias is not None else in1_tile_size   # no bias: in1's format
    in3_tile_size = in1_tile_size          # no all-gather fusion, same fallback
    interm_fmt = ttnn.float32 if fp32_dest_acc_en else ttnn.bfloat16
    interm_tile_size = tile_bytes(interm_fmt)

    transpose = M > N if transpose is None else bool(transpose)
    in0_noc = NOC_FOR_DRAM_READ if transpose else NOC_FOR_DRAM_WRITE
    in0_risc = (ttnn.DataMovementProcessor.RISCV_0 if transpose
                else ttnn.DataMovementProcessor.RISCV_1)
    in1_noc = NOC_FOR_DRAM_WRITE if transpose else NOC_FOR_DRAM_READ
    in1_risc = (ttnn.DataMovementProcessor.RISCV_1 if transpose
                else ttnn.DataMovementProcessor.RISCV_0)
    in0_axis_cores = gx if transpose else gy
    in1_axis_cores = gy if transpose else gx

    padded_M_tiles = _round_up(M_tiles, in0_axis_cores)
    padded_N_tiles = _round_up(N_tiles, in1_axis_cores * n_align)
    padded_K_tiles = _round_up(K_tiles, K_block_tiles)
    M_tiles_per_core = padded_M_tiles // in0_axis_cores
    N_tiles_per_core = padded_N_tiles // in1_axis_cores
    K_blocks = padded_K_tiles // K_block_tiles
    M_blocks_per_core = _div_up(M_tiles_per_core, M_block_tiles)
    N_blocks_per_core = _div_up(N_tiles_per_core, N_block_tiles)

    in0_block = M_block_tiles * K_block_tiles
    in1_block = K_block_tiles * N_block_tiles
    out_block = M_block_tiles * N_block_tiles

    cbs = [
        _cb(0, core_grid, in0_tile_size, in0_block * 2, in0.dtype),
        _cb(1, core_grid, in1_tile_size, in1_block * 2, in1.dtype),
        _cb(2, core_grid, out_tile_size, out_block * 2, out.dtype),
        _cb(3, core_grid, interm_tile_size, out_block, interm_fmt),
    ]
    acc_in2 = []
    if bias is not None:
        defines = defines + [("FUSE_BIAS", "1")]
        cbs.append(_cb(4, core_grid, in2_tile_size, N_block_tiles * 2, bias.dtype))
        acc_in2 = list(ttnn.TensorAccessorArgs(bias).get_compile_time_args())

    # CreateSemaphore is called six times on the whole grid, so the ids are 0..5 in that order.
    sem_vals = [INVALID, INVALID, VALID, INVALID, INVALID, VALID]
    semaphores = [
        ttnn.SemaphoreDescriptor(id=i, core_ranges=core_grid, initial_value=v)
        for i, v in enumerate(sem_vals)]
    in0_sender_sem, in0_recv_sem, in0_valid_sem, in1_sender_sem, in1_recv_sem, in1_valid_sem = range(6)

    acc_in0 = list(ttnn.TensorAccessorArgs(in0).get_compile_time_args())
    acc_in1 = list(ttnn.TensorAccessorArgs(in1).get_compile_time_args())
    acc_out = [a for o in outs for a in ttnn.TensorAccessorArgs(o).get_compile_time_args()]

    in0_is_writer = not transpose
    in1_is_writer = transpose

    def dm_ct(tile_size, sems, is_writer, is_injector, acc_main, tail):
        return ([M_tiles, padded_M_tiles, K_tiles, padded_K_tiles, N_tiles, padded_N_tiles,
                 M_block_tiles, K_block_tiles, N_block_tiles, M_blocks_per_core, N_blocks_per_core,
                 tile_size, out_tile_size, in2_tile_size, *sems,
                 int(is_writer), int(is_injector), N_chunks, N_tiles_per_chunk] + tail
                + acc_main + acc_out + acc_in2 + acc_extra)

    in0_sems = [in0_sender_sem, in0_recv_sem, in0_valid_sem]
    in1_sems = [in1_sender_sem, in1_recv_sem, in1_valid_sem]

    def cr(a, b):
        return ttnn.CoreRangeSet([ttnn.CoreRange(ttnn.CoreCoord(*a), ttnn.CoreCoord(*b))])

    in0_sender_cores = cr((0, 0), (gx - 1, 0) if transpose else (0, gy - 1))
    in0_recv_cores = cr((0, 1) if transpose else (1, 0), (gx - 1, gy - 1))
    in1_sender_cores = cr((0, 0), (0, gy - 1) if transpose else (gx - 1, 0))
    in1_recv_cores = cr((1, 0) if transpose else (0, 1), (gx - 1, gy - 1))

    kd = _kernel_dir()
    dmd = kernel_dir or kd
    in0_src, in1_src = str(dmd / "dm_in0_sender.cpp"), str(dmd / "dm_in1_sender_out.cpp")
    compute_src = str(kd / "compute.cpp")          # never patched, always the wheel's own

    k_blocks_per_core = _div_up(K_blocks, in1_axis_cores if transpose else in0_axis_cores)

    acc_extra = [a for t in extra for a in ttnn.TensorAccessorArgs(t).get_compile_time_args()]
    extra_addrs = [t.buffer_address() for t in extra]
    in0_addr, in1_addr = in0.buffer_address(), in1.buffer_address()
    out_addrs = [o.buffer_address() for o in outs]
    bias_addr = bias.buffer_address() if bias is not None else 0

    rt = {"in0_sender": [], "in0_recv": [], "in1_sender": [], "in1_recv": [], "compute": []}
    for cx in range(gx):
        for cy in range(gy):
            core = (cx, cy)
            in0_idx = cx if transpose else cy
            in1_idx = cy if transpose else cx
            left_core, top_core = (0, cy), (cx, 0)

            in0_order, in0_i = _build_core_order_for_axis(
                core, transpose, in1_axis_cores, in0_noc, True,
                top_core if transpose else left_core)
            in1_order, in1_i = _build_core_order_for_axis(
                core, transpose, in0_axis_cores, in1_noc, False,
                left_core if transpose else top_core)

            def phys(c):
                p = device.worker_core_from_logical_core(ttnn.CoreCoord(c[0], c[1]))
                return int(p.x), int(p.y)

            in0_prev = phys(in0_order[max(in0_i - 1, 0)])
            in0_next = phys(in0_order[min(in0_i + 1, len(in0_order) - 1)])
            in1_prev = phys(in1_order[max(in1_i - 1, 0)])
            in1_next = phys(in1_order[min(in1_i + 1, len(in1_order) - 1)])

            M_start, M_end = M_tiles_per_core * in0_idx, M_tiles_per_core * (in0_idx + 1)
            N_start, N_end = N_tiles_per_core * in1_idx, N_tiles_per_core * (in1_idx + 1)
            defer_k = min(cy * k_blocks_per_core, K_blocks - 1)

            cc = ttnn.CoreCoord(cx, cy)
            a0 = [in0_addr, bias_addr, 0, int(core == in0_order[-1]),
                  in0_next[0], in0_next[1], in0_prev[0], in0_prev[1],
                  M_start, M_end, N_start, N_end, defer_k, *extra_addrs, *out_addrs]
            a1 = [in1_addr, bias_addr, int(core == in1_order[-1]),
                  in1_next[0], in1_next[1], in1_prev[0], in1_prev[1],
                  M_start, M_end, N_start, N_end, defer_k, *extra_addrs, *out_addrs]
            rt["in0_sender" if in1_idx == 0 else "in0_recv"].append((cc, a0))
            rt["in1_sender" if in0_idx == 0 else "in1_recv"].append((cc, a1))
            rt["compute"].append((cc, [M_start, M_end, N_start, N_end]))

    def dm_kernel(src, cores, ct, args, risc, noc):
        dmc = (ttnn.DataMovementConfigDescriptor(processor=risc, noc=noc)
               if noc_mode is None else
               ttnn.DataMovementConfigDescriptor(processor=risc, noc=noc, noc_mode=noc_mode))
        return ttnn.KernelDescriptor(
            kernel_source=src, source_type=ttnn.KernelDescriptor.SourceType.FILE_PATH,
            core_ranges=cores, compile_time_args=ct, runtime_args=args, defines=defines,
            config=dmc)

    kernels = [
        dm_kernel(in0_src, in0_sender_cores,
                  dm_ct(in0_tile_size, in0_sems, in0_is_writer, True, acc_in0, [in3_tile_size]),
                  rt["in0_sender"], in0_risc, in0_noc),
        dm_kernel(in0_src, in0_recv_cores,
                  dm_ct(in0_tile_size, in0_sems, in0_is_writer, False, acc_in0, [in3_tile_size]),
                  rt["in0_recv"], in0_risc, in0_noc),
        dm_kernel(in1_src, in1_sender_cores,
                  dm_ct(in1_tile_size, in1_sems, in1_is_writer, True, acc_in1, []),
                  rt["in1_sender"], in1_risc, in1_noc),
        dm_kernel(in1_src, in1_recv_cores,
                  dm_ct(in1_tile_size, in1_sems, in1_is_writer, False, acc_in1, []),
                  rt["in1_recv"], in1_risc, in1_noc),
        ttnn.KernelDescriptor(
            kernel_source=compute_src,
            source_type=ttnn.KernelDescriptor.SourceType.FILE_PATH,
            core_ranges=core_grid,
            compile_time_args=[K_blocks, M_block_tiles, K_block_tiles, N_block_tiles,
                               M_blocks_per_core, N_blocks_per_core, subblock_h, subblock_w],
            runtime_args=rt["compute"], defines=[("FUSE_BIAS", "1")] if bias is not None else [],
            config=ttnn.ComputeConfigDescriptor(
                math_fidelity=math_fidelity, math_approx_mode=math_approx_mode,
                fp32_dest_acc_en=fp32_dest_acc_en, dst_full_sync_en=dst_full_sync_en)),
    ]
    pd = ttnn.ProgramDescriptor(kernels=kernels, semaphores=semaphores, cbs=cbs)
    return {"pd": pd, "kernels": kernels, "cbs": cbs, "semaphores": semaphores, "rt": rt,
            "addrs": (in0_addr, in1_addr, tuple(out_addrs)) + ((bias_addr,) if bias is not None else ()),
            "n_chunks": N_chunks, "n_extra": len(extra),
            "dims": {"M_tiles": M_tiles, "K_tiles": K_tiles, "N_tiles": N_tiles,
                     "padded_M_tiles": padded_M_tiles, "padded_N_tiles": padded_N_tiles,
                     "M_blocks_per_core": M_blocks_per_core,
                     "N_blocks_per_core": N_blocks_per_core, "K_blocks": K_blocks,
                     "N_tiles_per_chunk": N_tiles_per_chunk,
                     "transpose_core_grid": transpose, "defines": defines}}


def _key(in0, in1, outs, cfg, ckc, defines, kernel_dir, m_k=None, noc_mode=None, n_widths=None, bias=None):
    if not isinstance(outs, (list, tuple)):
        outs = [outs]
    spec = lambda t: (str(t.padded_shape), str(t.dtype), str(t.memory_config()))
    return (spec(in0), spec(in1), tuple(spec(o) for o in outs),
            cfg, tuple(str(c) for c in ckc),
            tuple(sorted(dict(defines).items())), str(kernel_dir), m_k, str(noc_mode),
            None if n_widths is None else tuple(n_widths), None if bias is None else spec(bias))


def generic_minimal_matmul(device, in0, in1, outs, cfg, ckc, defines=(), kernel_dir=None,
                           m_k=None, noc_mode=None, n_widths=None, guard="gen", bias=None):
    """``minimal_matmul`` through ``generic_op``, descriptor cached per shape/config.

    `guard` is the dest_guard class this launch belongs to."""
    if not isinstance(outs, (list, tuple)):
        outs = [outs]
    cfg = (dest_guard.descriptor(cfg[0], ckc, guard), cfg[1])   # K block 1 under fp32 dest acc on Wormhole
    key = _key(in0, in1, outs, cfg, ckc, defines, kernel_dir, m_k, noc_mode, n_widths, bias)
    entry = _CACHE.get(key)
    if entry is None:
        entry = _CACHE[key] = build(device, in0, in1, outs, cfg, ckc, defines, kernel_dir, m_k,
                                    noc_mode, n_widths, bias)
    addrs = (in0.buffer_address(), in1.buffer_address(),
             tuple(o.buffer_address() for o in outs)) + ((bias.buffer_address(),) if bias is not None else ())
    if addrs != entry["addrs"]:
        pd = bound_descriptor(entry, addrs)
        if pd is None:
            remember_bound(entry, entry["addrs"], entry["pd"])    # the one `build` made, too
            rebind(entry, *addrs)
            remember_bound(entry, entry["addrs"], entry["pd"])
        else:
            # `rt` and the kernels keep the last REBUILT addresses; `rebind` rewrites every
            # address slot, so the next miss starts from them correctly.
            entry["pd"], entry["addrs"] = pd, addrs
    ttnn.generic_op([in0, in1, *outs], entry["pd"])
    return outs[0] if len(outs) == 1 else outs


def rebind(entry, in0_addr, in1_addr, out_addrs, bias_addr=None, extra_addrs=()):
    """Rewrite the buffer addresses in the cached per-core runtime args, in place.

    They sit at fixed indices: args[0] is the kernel's own input address and the last ``N_chunks``
    entries are the output addresses; args[1] is the bias's (`bias_addr`, built with one). 110 cores x 2 DM kernels, so a few hundred scalar writes plus
    the binding round-trip.
    """
    n = entry["n_chunks"]
    rt = entry["rt"]
    for name, addr in (("in0_sender", in0_addr), ("in0_recv", in0_addr),
                       ("in1_sender", in1_addr), ("in1_recv", in1_addr)):
        for _, a in rt[name]:
            a[0] = addr
            if bias_addr is not None:
                a[1] = bias_addr
            a[len(a) - n:] = list(out_addrs)
            if extra_addrs:
                a[len(a) - n - len(extra_addrs):len(a) - n] = list(extra_addrs)
    for k, name in zip(entry["kernels"][:4],
                       ("in0_sender", "in0_recv", "in1_sender", "in1_recv")):
        k.runtime_args = rt[name]
    entry["pd"] = ttnn.ProgramDescriptor(
        kernels=entry["kernels"], semaphores=entry["semaphores"], cbs=entry["cbs"])
    entry["addrs"] = (in0_addr, in1_addr, tuple(out_addrs)) + ((bias_addr,) if bias_addr is not None else ())
