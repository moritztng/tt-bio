"""The controller that fans one host's jobs out across that host's chips.

One worker process per chip leases jobs from it over HTTP on 127.0.0.1, so a run
of many targets or design shards uses every chip on the box. It is not a cluster
manager: it binds loopback only, and spreading work across machines is the job of
whatever runs on top (JapanFold, Slurm, a fifty-line loop). The HTTP interface a
platform drives and the protocol a worker speaks are the published contract,
docs/multi-host.md; ``examples/many_hosts.py`` drives four hosts with it.

Inputs travel to workers as bytes and outputs come back the same way unless a
worker proves it shares the submitter's filesystem, so the contract holds for a
worker in another container or mount namespace too."""

from __future__ import annotations

import base64
import hashlib
import json
import sqlite3
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from dataclasses import asdict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any


#: How long a leased job stays with a worker that stops heartbeating. A worker renews
#: its leases every ``LEASE_S / HEARTBEAT_PER_LEASE`` seconds from a thread of its own,
#: whatever the fold is doing, so a live worker keeps a job of any length, and a dead
#: one's job goes back in the queue two minutes after it died instead of thirty. The
#: same policy as JapanFold's API-to-host lease, one level up (docs/multi-host.md).
LEASE_S = 120.0
#: Renewals per lease: ten seconds between heartbeats at the default lease.
HEARTBEAT_PER_LEASE = 12
#: Workers a job is handed to before a lapsed lease fails it. A worker that stops
#: heartbeating mid-job is usually a hang the input causes, and the next chip hangs the
#: same way: JapanFold's 584-residue Boltz-2 folds took ~10 chips each to its 25 min cap
#: on 10-19 before one was failed. Two leases still cover a single chip dying.
MAX_LEASES = 2
#: How recently an idle worker must have polled to be left a job it has the weights for. An
#: idle worker polls every second, so five seconds is a live one that missed a poll or two.
IDLE_WARM_S = 5.0


def diffusion_precision(cfg: dict[str, Any]) -> str | None:
    """The run's diffusion precision: the one asked for, else fp32 for a guided OpenDDE run,
    else None (the model's default). Guidance re-docks the movable chains whenever x0 clashes,
    and bf16's clashier x0 turned that into compressed chains about 9x as often as upstream
    (docs/constraint-guidance.md), so guided runs stay fp32 in every mode."""
    if cfg.get("diffusion_precision"):
        return cfg["diffusion_precision"]
    if cfg.get("use_tfg_guidance") and cfg.get("model") in ("opendde", "opendde-abag"):
        return "fp32"
    return None


def run_config_hash(cfg: dict[str, Any]) -> str:
    """The part of a run's config that decides which weights a worker loads, hashed.

    A worker reloads exactly when this changes, and reports the one it holds as ``warm``, so
    the lease compares like with like. The model name alone was not that: Boltz-2's config
    carries no ``model`` key, so every Boltz-2 run was stored as model None and a worker with
    Boltz-2 resident never matched its own model's work, and ``--fast`` reloads under the
    same name."""
    keep = {k: cfg.get(k) for k in ("model", "conf_kwargs", "aff_kwargs", "fast", "method",
                                    "checkpoint")}
    # Only when set, so every config that does not choose a diffusion precision keeps the hash
    # it had before the option existed (a controller and its agents may run different versions).
    if prec := diffusion_precision(cfg):
        keep["diffusion_precision"] = prec
    return hashlib.sha256(json.dumps(keep, sort_keys=True, default=str).encode()).hexdigest()


def _json_response(handler: BaseHTTPRequestHandler, status: int, payload: dict[str, Any]) -> None:
    data = json.dumps(payload).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json")
    handler.send_header("Content-Length", str(len(data)))
    handler.end_headers()
    handler.wfile.write(data)


def _read_json(handler: BaseHTTPRequestHandler) -> dict[str, Any]:
    length = int(handler.headers.get("Content-Length") or "0")
    if length <= 0:
        return {}
    raw = handler.rfile.read(length)
    return json.loads(raw.decode("utf-8"))


# Map the engine's fine-grained stage words (emitted by the worker and the
# model's progress callback) to the coarse pipeline phase a biologist follows.
_STAGE_MAP = {
    "loading": "prepare", "featuriz": "prepare", "prep": "prepare",
    "msa": "msa",
    "trunk": "fold", "pairformer": "fold", "diffusion": "fold", "sampling": "fold",
    "affinity": "score", "confidence": "score",
    "saving": "save", "writing": "save",
}


def _coarse_stage(event: dict[str, Any]) -> str | None:
    """The coarse phase an event implies, or None if it isn't a stage signal."""
    # A model reload is announced as a bare "loading" event, before the job's
    # "start". Read only as a stage word it set nothing, so a task waiting on a
    # reload showed no phase and JapanFold's stall watchdog took it for wedged.
    if event.get("event") in ("start", "loading"):
        return "prepare"
    s = str(event.get("stage") or "").lower()
    for key, phase in _STAGE_MAP.items():
        if key in s:
            return phase
    return None


class ControllerStore:
    """SQLite-backed controller state."""

    def __init__(self, path: Path, lease_s: float = LEASE_S, max_leases: int = MAX_LEASES):
        self.path = path
        self.lease_s = float(lease_s)
        self.max_leases = int(max_leases)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=30000")
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS runs (
                    run_id TEXT PRIMARY KEY,
                    data TEXT NOT NULL,
                    out_dir TEXT NOT NULL,
                    result_dir TEXT NOT NULL,
                    status TEXT NOT NULL,
                    owner TEXT,
                    model TEXT,
                    config_json TEXT NOT NULL,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL
                );
                CREATE TABLE IF NOT EXISTS jobs (
                    run_id TEXT NOT NULL,
                    job_id TEXT NOT NULL,
                    name TEXT NOT NULL DEFAULT '',
                    input_b64 TEXT NOT NULL DEFAULT '',
                    sidecar_b64 TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL,
                    stage TEXT,
                    worker_id TEXT,
                    lease_until REAL,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    result_json TEXT,
                    outputs_json TEXT,
                    error TEXT,
                    updated_at REAL NOT NULL,
                    PRIMARY KEY (run_id, job_id)
                );
                CREATE TABLE IF NOT EXISTS workers (
                    worker_id TEXT PRIMARY KEY,
                    host TEXT NOT NULL,
                    accelerator TEXT NOT NULL,
                    device_id TEXT NOT NULL,
                    label TEXT NOT NULL,
                    model TEXT,
                    warm TEXT,
                    last_seen REAL NOT NULL
                );
                CREATE TABLE IF NOT EXISTS events (
                    seq INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_id TEXT NOT NULL,
                    worker_id TEXT,
                    event_json TEXT NOT NULL,
                    created_at REAL NOT NULL
                );
                -- A store lives as long as its agent and keeps every job and event, so each lookup
                -- below scanned a table that grows all day. Every lease ran five such scans of jobs
                -- under self._lock (50 ms at 2.7k jobs on a JapanFold agent after 18 h), 32 workers
                -- polling saturated the lock, heartbeats and progress queued behind it, and served
                -- OpenDDE folds slowed from 162 s to 218 s until the agent restarted.
                CREATE INDEX IF NOT EXISTS jobs_worker_status ON jobs (worker_id, status);
                CREATE INDEX IF NOT EXISTS jobs_status_lease ON jobs (status, lease_until);
                CREATE INDEX IF NOT EXISTS events_run_seq ON events (run_id, seq);
                """
            )
            # Migrate pre-existing tables that lack newer columns.
            for stmt in ("ALTER TABLE jobs ADD COLUMN stage TEXT",
                         "ALTER TABLE runs ADD COLUMN owner TEXT",
                         "ALTER TABLE runs ADD COLUMN model TEXT",
                         "ALTER TABLE workers ADD COLUMN model TEXT",
                         "ALTER TABLE workers ADD COLUMN warm TEXT",
                         "ALTER TABLE jobs ADD COLUMN sidecar_b64 TEXT NOT NULL DEFAULT ''"):
                try:
                    conn.execute(stmt)
                except sqlite3.OperationalError:
                    pass  # column already present

    def create_run(self, payload: dict[str, Any]) -> dict[str, Any]:
        run_id = payload.get("run_id") or uuid.uuid4().hex[:12]
        now = time.time()
        jobs = payload["jobs"]
        config = payload["config"]
        with self._lock, self._connect() as conn:
            # A run created again under its id (JapanFold's retry of a job on the same host) starts
            # over: the earlier attempt's job rows and events would otherwise answer for it.
            conn.execute("DELETE FROM jobs WHERE run_id = ?", (run_id,))
            conn.execute("DELETE FROM events WHERE run_id = ?", (run_id,))
            conn.execute(
                """
                INSERT OR REPLACE INTO runs
                    (run_id, data, out_dir, result_dir, status, owner, model, config_json, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    run_id,
                    payload["data"],
                    payload["out_dir"],
                    payload["result_dir"],
                    "running",
                    payload.get("owner"),  # opaque fairness key (hash of the user's session, never the secret)
                    config.get("model"),   # which model these jobs need — drives worker model-affinity
                    json.dumps(config),
                    now,
                    now,
                ),
            )
            for job in jobs:
                conn.execute(
                    """
                    INSERT OR IGNORE INTO jobs
                        (run_id, job_id, name, input_b64, sidecar_b64, status, updated_at)
                    VALUES (?, ?, ?, ?, ?, 'pending', ?)
                    """,
                    (
                        run_id,
                        job["id"],
                        job.get("name", ""),
                        job.get("input_b64", ""),
                        job.get("sidecar_b64", ""),
                        now,
                    ),
                )
            self.add_event(conn, run_id, None, {"event": "run", "run_id": run_id, "total": len(jobs)})
        return {"run_id": run_id, "total": len(jobs)}

    def add_event(self, conn: sqlite3.Connection, run_id: str, worker_id: str | None, event: dict[str, Any]) -> None:
        conn.execute(
            "INSERT INTO events (run_id, worker_id, event_json, created_at) VALUES (?, ?, ?, ?)",
            (run_id, worker_id, json.dumps(event), time.time()),
        )

    def lease(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Hand a worker its next jobs, all from one run.

        A worker that asks for work is holding none, so any job still leased to it is
        one it abandoned (a respawned process under the same id, a completion that
        never arrived) and goes back in the queue now. Otherwise its heartbeats would
        keep renewing a lease on work nobody is doing."""
        worker = payload["worker"]
        worker_id = worker["worker_id"]
        warm = worker.get("warm")  # run_config_hash of the weights this worker has resident
        batch_size = max(1, int(payload.get("batch_size") or 1))
        now = time.time()
        lease_until = now + self.lease_s
        with self._lock, self._connect() as conn:
            self._upsert_worker(conn, worker, now)
            conn.execute("UPDATE jobs SET lease_until=0 WHERE worker_id=? AND status='running'",
                         (worker_id,))
            self._fail_spent_leases(conn, now)
            # Work-conserving max-min fair share across users (owners). Devices in
            # use right now, per owner:
            load: dict[str, int] = {}
            for r in conn.execute(
                "SELECT r.owner AS owner, COUNT(*) AS n "
                "FROM jobs j JOIN runs r ON r.run_id = j.run_id "
                "WHERE j.status='running' AND j.lease_until >= ? GROUP BY r.owner",
                (now,),
            ):
                load[r["owner"]] = r["n"]
            # Every job that could be handed out now (queued, or a lease that
            # expired), oldest first.
            rows = conn.execute(
                """
                SELECT j.run_id, j.job_id, j.name, j.input_b64, j.sidecar_b64, j.updated_at, r.owner, r.model, r.config_json
                FROM jobs j
                JOIN runs r ON r.run_id = j.run_id
                WHERE r.status = 'running'
                  AND (j.status = 'pending' OR (j.status = 'running' AND j.lease_until < ?))
                ORDER BY j.updated_at, j.job_id
                """,
                (now,),
            ).fetchall()
            hashes: dict[str, str] = {}

            def cold(row):
                if row["run_id"] not in hashes:
                    hashes[row["run_id"]] = run_config_hash(json.loads(row["config_json"]))
                return hashes[row["run_id"]] != warm

            # Leave a job to an idle worker that already holds its weights. Ranking jobs for
            # the asking worker alone never did that: on a quiet fleet the first of 31 idle
            # chips to poll took every job, whatever it had loaded, and production reloaded
            # esmfold2-fast on 31 of 35 folds, 125 s of load for an 11 s fold. The warm
            # worker polls within a second, and one that is busy or silent is not counted,
            # so no job waits on a chip that cannot take it now.
            idle_warm = {r["warm"] for r in conn.execute(
                "SELECT w.warm FROM workers w WHERE w.warm IS NOT NULL AND w.worker_id != ? "
                "AND w.last_seen >= ? AND NOT EXISTS (SELECT 1 FROM jobs j WHERE "
                "j.worker_id = w.worker_id AND j.status = 'running' AND j.lease_until >= ?)",
                (worker_id, now - IDLE_WARM_S, now))}
            rows = [r for r in rows if not (cold(r) and hashes[r["run_id"]] in idle_warm)]
            if not rows:
                return {"jobs": [], "lease_s": self.lease_s}
            # Pick by, in order: (1) fairness — the owner using the fewest devices
            # right now; (2) model affinity — among equally-underserved owners,
            # prefer a job whose model this worker already has loaded, so it
            # doesn't reload; (3) oldest. So one user alone fills the cluster, many
            # users get a fair share, and each device tends to stay on one model
            # (reloading only when its model has no waiting work). A device idles
            # while a job waits only for the second an idle warm one takes to poll.
            # (4) Within one submission, the largest input first. A run's jobs share one
            # updated_at, so job_id (the file name) used to decide, and the biggest protein of a
            # batch could start last and run alone while every other chip idled: 32 proteins of
            # 98-585 aa on 8 cards ended on the 585-aa fold. Longest-first is the classic bound
            # for that tail. The input's size stands in for its cost (residues dominate a
            # YAML/FASTA); a retried job's newer updated_at still puts it behind.
            def rank(row):
                return (load.get(row["owner"], 0), cold(row), row["updated_at"],
                        -len(row["input_b64"]), row["job_id"])
            chosen = min(rows, key=rank)
            run_id = chosen["run_id"]
            config_json = chosen["config_json"]
            picked = sorted((row for row in rows if row["run_id"] == run_id), key=rank)[:batch_size]
            jobs = []
            for row in picked:
                conn.execute(
                    """
                    UPDATE jobs
                    SET status='running', worker_id=?, lease_until=?, attempts=attempts+1, updated_at=?
                    WHERE run_id=? AND job_id=?
                    """,
                    (worker_id, lease_until, now, row["run_id"], row["job_id"]),
                )
                jobs.append({
                    "id": row["job_id"],
                    "name": row["name"],
                    "input_b64": row["input_b64"],
                    **({"sidecar_b64": row["sidecar_b64"]} if row["sidecar_b64"] else {}),
                })
            return {"run_id": run_id, "config": json.loads(config_json), "jobs": jobs,
                    "lease_s": self.lease_s}

    def _upsert_worker(self, conn: sqlite3.Connection, worker: dict[str, Any], now: float) -> None:
        """Register/refresh a worker's heartbeat (last_seen) and resident model."""
        conn.execute(
            """
            INSERT INTO workers (worker_id, host, accelerator, device_id, label, model, warm, last_seen)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(worker_id) DO UPDATE SET
                host=excluded.host, accelerator=excluded.accelerator,
                device_id=excluded.device_id, label=excluded.label,
                model=excluded.model, warm=excluded.warm, last_seen=excluded.last_seen
            """,
            (worker["worker_id"], worker["host"], worker["accelerator"],
             str(worker["device_id"]), worker["label"], worker.get("model"),
             worker.get("warm"), now),
        )

    def heartbeat(self, payload: dict[str, Any]) -> dict[str, Any]:
        """A liveness ping a worker sends while it's busy computing (and so not
        leasing), so the fleet never shows an active worker as offline.

        It also renews the leases of the jobs this worker holds. Without that a job
        longer than the lease was handed to a second worker while the first was
        still computing it, and ``complete_job`` then discarded the first result
        because the lease had moved: a 1792-residue Protenix-v2 fold (45 min) never
        finished, it restarted on a new chip every 30 min. A worker that dies stops
        heartbeating, so its jobs still go back to the queue ``lease_s`` later.

        The answer carries ``lease_s`` so the worker paces its heartbeat to this
        controller's lease rather than to a constant of its own."""
        now = time.time()
        worker = payload["worker"]
        with self._lock, self._connect() as conn:
            self._upsert_worker(conn, worker, now)
            conn.execute(
                "UPDATE jobs SET lease_until=? WHERE worker_id=? AND status='running'",
                (now + self.lease_s, worker["worker_id"]))
        return {"ok": True, "lease_s": self.lease_s}

    def cancel_run(self, run_id: str) -> dict[str, Any]:
        """Cancel a run: stop new jobs being leased (run no longer 'running')
        and mark its unfinished jobs canceled. A job already on a chip runs to its
        end, and ``complete_job`` then drops its result."""
        now = time.time()
        with self._lock, self._connect() as conn:
            conn.execute("UPDATE runs SET status='canceled', updated_at=? WHERE run_id=?", (now, run_id))
            conn.execute(
                "UPDATE jobs SET status='canceled', lease_until=NULL, updated_at=? "
                "WHERE run_id=? AND status IN ('pending','running')", (now, run_id))
            self.add_event(conn, run_id, None, {"event": "run_done", "status": "canceled", "failed": 0})
        return {"ok": True}

    def run_status(self, run_id: str) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT status FROM runs WHERE run_id=?", (run_id,)).fetchone()
        return {"status": row["status"] if row else "missing"}

    def run_jobs(self, run_id: str) -> list[dict[str, Any]]:
        """Per-input snapshot for a run: each job's id, status and live phase.
        One cheap query regardless of event volume, so it scales to many inputs."""
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT job_id, status, stage FROM jobs WHERE run_id=? ORDER BY rowid",
                (run_id,),
            ).fetchall()
        return [{"id": r["job_id"], "status": r["status"], "stage": r["stage"]} for r in rows]

    def record_event(self, payload: dict[str, Any]) -> dict[str, Any]:
        run_id = payload["run_id"]
        worker_id = payload.get("worker_id")
        event = payload["event"]
        with self._lock, self._connect() as conn:
            self.add_event(conn, run_id, worker_id, event)
            if worker_id:
                now = time.time()
                # An event is also a sign of life — keep the heartbeat fresh.
                conn.execute("UPDATE workers SET last_seen=? WHERE worker_id=?", (now, worker_id))
                # Attribute the stage to this worker's currently-running job, so
                # each input's live phase is queryable. One job per worker at a
                # time (batch_size=1), so worker_id + running pins it exactly.
                phase = _coarse_stage(event)
                if phase:
                    conn.execute(
                        "UPDATE jobs SET stage=?, updated_at=? "
                        "WHERE run_id=? AND worker_id=? AND status='running'",
                        (phase, now, run_id, worker_id))
        return {"ok": True}

    def complete_job(self, payload: dict[str, Any]) -> dict[str, Any]:
        run_id = payload["run_id"]
        worker_id = payload["worker_id"]
        row = payload["result"]
        outputs = payload.get("outputs") or None
        status = row.get("status", "failed")
        now = time.time()
        with self._lock, self._connect() as conn:
            # Scope the completion to the worker that still holds the lease. If this
            # worker's lease had expired and the job was re-dispatched to another
            # worker, a late completion matches nothing and is ignored — so it can't
            # overwrite the new worker's result, nor flip a job the run already
            # canceled back to ok/failed.
            changed = conn.execute(
                """
                UPDATE jobs
                SET status=?, result_json=?, outputs_json=?, error=?, lease_until=NULL, updated_at=?
                WHERE run_id=? AND job_id=? AND worker_id=? AND status='running'
                """,
                (
                    status,
                    json.dumps(row),
                    json.dumps(outputs) if outputs else None,
                    row.get("error"),
                    now,
                    run_id,
                    row["id"],
                    worker_id,
                ),
            ).rowcount
            if not changed:
                return {"ok": True}
            event = payload.get("event")
            if event:
                self.add_event(conn, run_id, worker_id, event)
            self._finish_run(conn, run_id, now)
        return {"ok": True}

    def _fail_spent_leases(self, conn: sqlite3.Connection, now: float) -> None:
        """Fail each job whose lease lapsed on its last allowed worker, instead of handing
        a hang to one chip after another (``MAX_LEASES``)."""
        for row in conn.execute(
            "SELECT run_id, job_id FROM jobs WHERE status='running' AND lease_until < ? AND attempts >= ?",
            (now, self.max_leases),
        ).fetchall():
            error = (f"no result after {self.max_leases} workers: each stopped heartbeating "
                     f"(hung or died) while running this input")
            conn.execute(
                "UPDATE jobs SET status='failed', result_json=?, error=?, lease_until=NULL, updated_at=? "
                "WHERE run_id=? AND job_id=?",
                (json.dumps({"id": row["job_id"], "status": "failed", "error": error}), error, now,
                 row["run_id"], row["job_id"]),
            )
            self._finish_run(conn, row["run_id"], now)

    def _finish_run(self, conn: sqlite3.Connection, run_id: str, now: float) -> None:
        pending = conn.execute(
            "SELECT COUNT(*) AS n FROM jobs WHERE run_id=? AND status IN ('pending', 'running')",
            (run_id,),
        ).fetchone()["n"]
        if pending:
            return
        failed = conn.execute(
            "SELECT COUNT(*) AS n FROM jobs WHERE run_id=? AND status != 'ok'",
            (run_id,),
        ).fetchone()["n"]
        run_status = "failed" if failed else "ok"
        # Only conclude a run that's still running — never overwrite a
        # 'canceled' status set by cancel_run with a late job completion.
        changed = conn.execute(
            "UPDATE runs SET status=?, updated_at=? WHERE run_id=? AND status='running'",
            (run_status, now, run_id),
        ).rowcount
        if changed:
            self.add_event(conn, run_id, None, {"event": "run_done", "status": run_status, "failed": failed})

    def results(self, run_id: str) -> list[dict[str, Any]]:
        with self._connect() as conn:
            return [
                json.loads(row["result_json"])
                for row in conn.execute(
                    "SELECT result_json FROM jobs WHERE run_id=? AND result_json IS NOT NULL ORDER BY updated_at",
                    (run_id,),
                )
            ]

    def job_outputs(self, run_id: str, job_id: str) -> dict[str, str]:
        """Return the output files this job produced as {name: base64_bytes}."""
        with self._connect() as conn:
            row = conn.execute(
                "SELECT outputs_json FROM jobs WHERE run_id=? AND job_id=?",
                (run_id, job_id),
            ).fetchone()
        if not row or not row["outputs_json"]:
            return {}
        try:
            return json.loads(row["outputs_json"]) or {}
        except Exception:
            return {}

    def cluster(self, stale_after: float = 20.0) -> dict[str, Any]:
        """What this host advertises: its workers, how many can compute now, and
        run/job counts. Used for operator + platform status.

        A worker registers only once its chip has opened, so ``online_workers`` is
        the number of usable chips, not the number installed: a chip that fails to
        open never appears. Each worker also names the model it has resident and
        the jobs it holds. It heartbeats on every lease poll (~1 s when idle) and
        from its own thread while busy, so one not seen within ``stale_after``
        seconds is treated as gone.
        """
        now = time.time()
        with self._connect() as conn:
            workers = [dict(row) for row in conn.execute(
                "SELECT worker_id, host, accelerator, device_id, label, model, last_seen "
                "FROM workers ORDER BY host, device_id"
            )]
            held: dict[str, list[dict[str, str]]] = {}
            for row in conn.execute(
                "SELECT worker_id, run_id, job_id FROM jobs "
                "WHERE status='running' AND lease_until >= ?", (now,)):
                held.setdefault(row["worker_id"], []).append(
                    {"run_id": row["run_id"], "job_id": row["job_id"]})
            run_rows = conn.execute(
                "SELECT status, COUNT(*) AS n FROM runs GROUP BY status"
            ).fetchall()
            job_rows = conn.execute(
                "SELECT status, COUNT(*) AS n FROM jobs GROUP BY status"
            ).fetchall()
        for w in workers:
            w["idle_s"] = round(now - float(w["last_seen"]), 1)
            w["online"] = w["idle_s"] <= stale_after
            w["running"] = held.get(w["worker_id"], [])
        hosts: dict[str, dict[str, Any]] = {}
        for w in workers:
            if not w["online"]:
                continue
            h = hosts.setdefault(w["host"], {"host": w["host"], "devices": 0, "accelerators": set()})
            h["devices"] += 1
            h["accelerators"].add(w["accelerator"])
        host_list = sorted(
            ({"host": h["host"], "devices": h["devices"], "accelerators": sorted(h["accelerators"])}
             for h in hosts.values()),
            key=lambda h: h["host"],
        )
        return {
            "now": now,
            "workers": workers,
            "online_workers": sum(1 for w in workers if w["online"]),
            "total_workers": len(workers),
            "hosts": host_list,
            "runs": {row["status"]: row["n"] for row in run_rows},
            "jobs": {row["status"]: row["n"] for row in job_rows},
        }

    def events(self, run_id: str, after: int) -> dict[str, Any]:
        with self._connect() as conn:
            events = [
                {"seq": row["seq"], **json.loads(row["event_json"])}
                for row in conn.execute(
                    "SELECT seq, event_json FROM events WHERE run_id=? AND seq>? ORDER BY seq LIMIT 500",
                    (run_id, after),
                )
            ]
            run = conn.execute("SELECT status FROM runs WHERE run_id=?", (run_id,)).fetchone()
            totals = conn.execute(
                """
                SELECT
                  COUNT(*) AS total,
                  SUM(CASE WHEN status='ok' THEN 1 ELSE 0 END) AS ok,
                  SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) AS failed
                FROM jobs WHERE run_id=?
                """,
                (run_id,),
            ).fetchone()
        return {
            "events": events,
            "status": run["status"] if run else "missing",
            "total": totals["total"] or 0,
            "ok": totals["ok"] or 0,
            "failed": totals["failed"] or 0,
        }


class ControllerServer:
    """The HTTP face of :class:`ControllerStore`, on loopback only."""

    def __init__(self, port: int, db_path: Path, lease_s: float = LEASE_S, max_leases: int = MAX_LEASES):
        self.store = ControllerStore(db_path, lease_s, max_leases)
        store = self.store

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, fmt, *args):  # noqa: ANN001
                return

            def do_POST(self):  # noqa: N802
                try:
                    payload = _read_json(self)
                    if self.path == "/runs":
                        _json_response(self, 200, store.create_run(payload))
                    elif self.path == "/lease":
                        _json_response(self, 200, store.lease(payload))
                    elif self.path == "/events":
                        _json_response(self, 200, store.record_event(payload))
                    elif self.path == "/complete":
                        _json_response(self, 200, store.complete_job(payload))
                    elif self.path == "/heartbeat":
                        _json_response(self, 200, store.heartbeat(payload))
                    elif self.path.startswith("/runs/") and self.path.endswith("/cancel"):
                        _json_response(self, 200, store.cancel_run(self.path.split("/")[2]))
                    else:
                        _json_response(self, 404, {"error": "not found"})
                except Exception as exc:
                    _json_response(self, 500, {"error": str(exc)})

            def do_GET(self):  # noqa: N802
                # A store error (e.g. sqlite CANTOPEN on a full disk) must not
                # kill the handler thread: the client's poll would die with
                # RemoteDisconnected and take the whole run down with it.
                # Answer 503 instead — transient, retriable, run survives.
                try:
                    parsed = urllib.parse.urlparse(self.path)
                    if parsed.path == "/cluster":
                        _json_response(self, 200, store.cluster())
                    elif parsed.path == "/healthz":
                        _json_response(self, 200, {"ok": True})
                    elif parsed.path.startswith("/runs/") and parsed.path.endswith("/events"):
                        run_id = parsed.path.split("/")[2]
                        query = urllib.parse.parse_qs(parsed.query)
                        after = int((query.get("after") or ["0"])[0])
                        _json_response(self, 200, store.events(run_id, after))
                    elif parsed.path.startswith("/runs/") and parsed.path.endswith("/results"):
                        run_id = parsed.path.split("/")[2]
                        _json_response(self, 200, {"results": store.results(run_id)})
                    elif parsed.path.startswith("/runs/") and parsed.path.endswith("/status"):
                        _json_response(self, 200, store.run_status(parsed.path.split("/")[2]))
                    elif parsed.path.startswith("/runs/") and parsed.path.endswith("/jobs"):
                        _json_response(self, 200, {"jobs": store.run_jobs(parsed.path.split("/")[2])})
                    elif "/jobs/" in parsed.path and parsed.path.endswith("/outputs"):
                        parts = parsed.path.split("/")
                        # /runs/<run_id>/jobs/<job_id>/outputs
                        if len(parts) == 6 and parts[1] == "runs" and parts[3] == "jobs":
                            _json_response(self, 200, {"outputs": store.job_outputs(parts[2], parts[4])})
                        else:
                            _json_response(self, 404, {"error": "not found"})
                    else:
                        _json_response(self, 404, {"error": "not found"})
                except Exception as exc:
                    _json_response(self, 503, {"error": str(exc)})

        self.httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
        self.port = self.httpd.server_address[1]

    def serve_in_background(self) -> threading.Thread:
        thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        thread.start()
        return thread

    def shutdown(self) -> None:
        self.httpd.shutdown()
        self.httpd.server_close()


class ControllerUnreachable(RuntimeError):
    """The controller is down, or it is up with no worker able to compute.

    Its own class so the CLI can print it as an error instead of a traceback
    (``main._Cli.invoke``), the way ``DeviceInUseError`` already works. Nothing ran, so
    there is no result to report and no point continuing.
    """


class ControllerClient:
    def __init__(self, base_url: str, timeout: float = 120.0, read_attempts: int | None = None):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.read_attempts = self.READ_ATTEMPTS if read_attempts is None else read_attempts

    #: Attempts for a transient failure of an idempotent read, and the backoff between them.
    #: A co-tenant filling the shared disk makes the store raise, the handler answers 503
    #: (``do_GET`` below), and an unretried poll kills the run: that burst killed 58 folds on
    #: 2026-08-03. `predict` grew its own 5x backoff around ``events`` in response; the three
    #: fleet design paths (boltzgen, rfd3, pxdesign) never did, so they still died on it. The
    #: retry belongs here, on the one call every reader goes through, not at each loop.
    READ_ATTEMPTS = 5

    def _request(self, method: str, path: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        data = None if payload is None else json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            self.base_url + path,
            data=data,
            method=method,
            headers={"Content-Type": "application/json"},
        )
        # Every GET here is a read, so replaying one is free, and so is /complete: a
        # result settles once, from the lease holder, and a replay of one that landed
        # matches nothing (``complete_job``). Unretried, one dropped /complete left the
        # job running under a worker that heartbeats on, so the run never ended. A
        # replayed /lease would double-serve a job and a replayed /events duplicates a
        # line, so neither is retried. And only on a transient signal: a 4xx is the
        # controller's settled answer, so retrying a missing run would just spend the
        # backoff before giving the same reply.
        attempts = self.read_attempts if method == "GET" or path == "/complete" else 1
        for attempt in range(attempts):
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    return json.loads(resp.read().decode("utf-8"))
            except urllib.error.HTTPError as exc:
                body = exc.read().decode("utf-8", errors="replace")
                if exc.code < 500 or attempt == attempts - 1:
                    raise RuntimeError(f"controller error {exc.code}: {body}") from exc
            except urllib.error.URLError:
                if attempt == attempts - 1:
                    raise
            time.sleep(2 ** attempt)
        raise AssertionError("unreachable")  # the loop either returns or raises

    def create_run(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._request("POST", "/runs", payload)

    def lease(self, worker: dict[str, Any], batch_size: int) -> dict[str, Any]:
        return self._request("POST", "/lease", {"worker": worker, "batch_size": batch_size})

    def event(self, run_id: str, worker_id: str, event: dict[str, Any]) -> None:
        self._request("POST", "/events", {"run_id": run_id, "worker_id": worker_id, "event": event})

    def complete(
        self,
        run_id: str,
        worker_id: str,
        row: dict[str, Any],
        event: dict[str, Any],
        outputs: dict[str, str] | None = None,
    ) -> None:
        payload = {"run_id": run_id, "worker_id": worker_id, "result": row, "event": event}
        if outputs:
            payload["outputs"] = outputs
        self._request("POST", "/complete", payload)

    def heartbeat(self, worker: dict[str, Any]) -> dict[str, Any]:
        return self._request("POST", "/heartbeat", {"worker": worker})

    def cancel_run(self, run_id: str) -> dict[str, Any]:
        return self._request("POST", f"/runs/{run_id}/cancel", {})

    def run_status(self, run_id: str) -> str:
        try:
            return self._request("GET", f"/runs/{run_id}/status").get("status", "missing")
        except Exception:
            return "missing"

    def run_jobs(self, run_id: str) -> list[dict[str, Any]]:
        return self._request("GET", f"/runs/{run_id}/jobs").get("jobs", [])

    def cluster(self) -> dict[str, Any]:
        return self._request("GET", "/cluster")

    def events(self, run_id: str, after: int) -> dict[str, Any]:
        return self._request("GET", f"/runs/{run_id}/events?after={after}")

    def results(self, run_id: str) -> list[dict[str, Any]]:
        return self._request("GET", f"/runs/{run_id}/results").get("results", [])

    def job_outputs(self, run_id: str, job_id: str) -> dict[str, str]:
        return self._request("GET", f"/runs/{run_id}/jobs/{job_id}/outputs").get("outputs", {})


def connect_controller(url: str) -> tuple[ControllerClient, int]:
    """Open a client on ``url`` and refuse a controller that has no workers.

    Returns ``(client, online_workers)``. The four gating entrypoints share it: `embed
    --controller` and the boltzgen, rfd3 and pxdesign design paths. Each carried its own
    copy, which is how one condition ended up with two wordings and two exception types.

    Zero workers is a refusal, not a warning. A run created against an empty controller
    sits queued forever and the caller polls it forever.

    `predict --controller` (``_stream_via_controller``) deliberately does NOT gate here.
    It reads the same count for its progress display and stays lenient, because the
    platform submits through it and does its own admission control.
    """
    # One attempt for the probe. Nothing has started yet, so a wrong URL should say so
    # now rather than after the read backoff; the retry is for a run already committed.
    client = ControllerClient(url, read_attempts=1)
    try:
        online = int(client.cluster().get("online_workers") or 0)
    except Exception as exc:
        raise ControllerUnreachable(f"Cannot reach controller at {url}: {exc}") from exc
    if online < 1:
        raise ControllerUnreachable(
            f"No workers connected to {url}. Start a pool with `tt-bio controller`, "
            f"or start workers against it with `tt-bio worker --connect {url}`.")
    client.read_attempts = ControllerClient.READ_ATTEMPTS
    return client, online


class HttpProgressQueue:
    """Queue-like adapter that forwards worker progress to the controller."""

    def __init__(self, client: ControllerClient, run_id: str, worker_id: str):
        self.client = client
        self.run_id = run_id
        self.worker_id = worker_id

    def put_nowait(self, event: dict[str, Any]) -> None:
        try:
            self.client.event(self.run_id, self.worker_id, event)
        except Exception:
            pass


def job_payloads(jobs: list[Any]) -> list[dict[str, str]]:
    """Build self-contained job dicts that carry the input file bytes.

    Each entry is ``{"id": <stem>, "name": <filename>, "input_b64": <base64>}``
    so a worker can run the job without sharing a filesystem with the controller.
    An input staged from upstream Protenix / Mol-1 JSON also carries its sidecar
    (``sidecar_b64``): its MSAs live there, and a worker without it searches instead.
    """
    from tt_bio.protenix_json import sidecar_path

    payloads: list[dict[str, str]] = []
    for job in jobs:
        path = Path(job.path)
        side = sidecar_path(path)
        payloads.append({
            "id": job.id,
            "name": path.name,
            "input_b64": base64.b64encode(path.read_bytes()).decode("ascii"),
            **({"sidecar_b64": base64.b64encode(side.read_bytes()).decode("ascii")}
               if side is not None and side.exists() else {}),
        })
    return payloads


def worker_payload(worker: Any) -> dict[str, Any]:
    return asdict(worker) | {"label": worker.label}
