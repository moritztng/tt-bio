"""Protenix-v2 (ByteDance AF3 reproduction) modules on Tenstorrent.

Protenix-v2 is the same AF3 family as Boltz-2 (already ported in boltz2.py) and
shares tt_bio.tenstorrent primitives (AttentionPairBias, AdaLN,
ConditionedTransitionBlock, PairformerLayer, Transition). This module adds the
genuinely-new v2 pieces, built component-by-component and validated against the
real v2 reference (see scripts/protenix_*.py and tests/test_protenix.py).

Status (all on-device, validated vs real v2 golden; see tests/test_protenix_*.py):
- AtomFeaturization (c_l, p_lm)                          PCC > 0.9999
- AtomTransformer (3-block windowed atom attention)      PCC 0.999998
- AtomAttentionEncoder -> s_inputs (full InputFeatureEmbedder atom encoder) PCC 0.999999
- TrunkInput -> s_init, z_init                           PCC 0.999997
- 48-block Pairformer stack vs real trunk I/O            PCC s 0.993 / z 0.980
- full 10-cycle trunk (assembled)                        PCC s 0.991 / z 0.990
- DiffusionConditioning (pair/single)                    PCC 1.0 / 0.99999
- diffusion atom encoder(has_coords)                     PCC 0.99999
- 24-block token DiT (per-block)                         PCC 1.0 (torch) / 0.997 (bf16)
- diffusion atom decoder                                 PCC 0.99992
- ConfidenceHead (pae/pde ; plddt/resolved)              PCC 1.0 ; 0.93/0.77
EVERY v2 compute module validated on-device. ASSEMBLED into the top-level Protenix
class (load_from_checkpoint + fold): full on-device pipeline (atom encoder -> diffusion
atom cache -> 10-cycle Trunk -> diffusion conditioning -> EDM sampler) produces valid
structures within sample variance of the reference (scripts/protenix_fold_e2e.py,
scripts/protenix_predict.py -> PDB). Remaining (packaging): data-pipeline vendoring
(sequence/CCD -> feats dict), worker/CLI --model protenix-v2, unified README.
"""
import gc
import math
import os
import re
import sys
import torch
import ttnn

from . import protenix_weights as PW
from . import hostlane
from .envflags import env_flag
from .size_limits import restart_lighter
from .sample_chunks import denoise_in_chunks, resolve_sample_chunk_width
from .token_axis import bucket_multiple as _bucket_multiple, bounded_rows
from .protenix_weights import remap_adaln  # single source of all v2->tt-bio weight remaps
from . import ops
from .tenstorrent import (Module, CORE_GRID_MAIN, get_device, dram_peak,
                          MSA_CHUNK_SIZE, batched_matmul, dram_bytes, msa_depth_chunks, host_park,
                          host_unpark, msa_embed, msa_row_bucket, msa_rows_host, msa_rows_mask, msa_rows_table,
                          msa_rows_device, msa_upload_whole, msa_update_chunks, msa_embed_chunks,
                          MSA_JOIN_MAX_BYTES,
                          pair_row_blocks,
                          row_block_after_refusal, device_generation, accurate_softmax_site,
                          softmax_ckc, host_f64_softmax_site, site_softmax, stack_samples)
from . import tenstorrent as _T   # for the module-level A/B toggles, which must be read live

# The Protenix family's normal set (Protenix-v2, Protenix-v1, OpenDDE): the shared one plus transition_ws with
# ws_l1acc, which keeps each matmul's fp32 dest sum to 2 K tiles so bf16 weights at c_z 256 / 384 take the fused
# transition. Wormhole 11-set normal grade, normal vs this set, 44 paired folds each: Protenix-v2 PASS (spd-integrate
# gwa), OpenDDE PASS, same-seed top pose median 0.219 A vs the 1.335 A A/A floor, CA-lDDT -0.0004 [-0.0016, +0.0004],
# docking 25 -> 24 of 44 (spd-gap-small 2026-10-14); Blackhole Protenix-v2 PASS, 0.080 A vs 1.292 A (gwabh).
# Galaxy chip (1000 MHz) Protenix-v2 normal 79.1 -> 74.7 s; p150a OpenDDE normal -1.9 s.
# trimul_t1_c256 / _c384: the trimul input side as one kernel at c_z 256 (Protenix-v2) and 384 (OpenDDE); c_z 128
# (Protenix-v1) is untouched. Wormhole 11-set normal grade of the whole set against shared normal, 44 paired folds
# each (spd-gap-small gst1, 2026-10-14), PASS: same-seed top pose median Protenix-v2 0.093 A vs the 1.134 A A/A
# floor, OpenDDE 0.184 vs 1.335 A; CA-lDDT -0.0001 [-0.0006, +0.0003] / +0.0000 [-0.0001, +0.0002].
NORMAL_LEVERS = _T.NORMAL_LEVERS | {"transition_ws", "ws_l1acc", "trimul_t1_c256", "trimul_t1_c384"}
# The trimul output tail as one kernel (T2, its channel-major hand-off T2CM, and T2 at c_z 384), Protenix-v2 only:
# under T1 the normal tail otherwise runs LN + out-proj + gated multiply as three ops. Wormhole 11-set normal grade,
# normal set vs normal set + these, 44 paired folds (spd-gap-small gt2nwh, 2026-10-14): Protenix-v2 PASS, same-seed
# top pose median 0.041 A vs the 1.132 A A/A floor, CA-lDDT -0.0001 [-0.0004, +0.0001], docking 35 -> 35;
# OpenDDE FAIL (DockQ -0.0077 [-0.0225, -0.0000]), so OpenDDE keeps NORMAL_LEVERS. Not graded at c_z 128, so
# Protenix-v1 keeps NORMAL_LEVERS too (`load_from_checkpoint`). Galaxy chip (1000 MHz) Protenix-v2 normal -2.3 s.
T2_TAIL = frozenset({"trimul_t2", "trimul_t2cm", "trimul_t2w"})
# ws_chain: the transition's later hidden chunks add into the first in their fp32 dest instead of separate add
# passes over the pair. Wormhole 11-set grades, shipped set vs + ws_chain (spd-gap-small gwch, 2026-10-14), PASS:
# Protenix-v2 normal top pose median 0.080 A vs the 1.050 A A/A floor (37 paired folds), OpenDDE normal 0.241 vs
# 1.257 A (39), OpenDDE fast 0.625 vs 1.374 A (44); docking within one fold everywhere. Galaxy chip (1000 MHz)
# OpenDDE normal -3.7 s, fast -2.3 s, Protenix-v2 normal -0.7 s. Not graded at c_z 128, so Protenix-v1 stays off.
# Blackhole twin (gwchbh, 2026-10-15): Protenix-v2 normal PASS 0.080 A vs 1.177 A (44), OpenDDE fast PASS 0.369 vs
# 1.277 A (39); OpenDDE normal FAIL, so OpenDDE drops it on Blackhole normal (`opendde.BH_NORMAL_LEVERS`).
WS_CHAIN = frozenset({"ws_chain"})
# --fast takes trimul_t1_c256 too (Protenix-v2; c_z 128 Protenix-v1 is untouched, OpenDDE has its own set).
# Blackhole 11-set fast grade, fast vs fast+trimul_t1_c256, 43 paired folds (spd-gap-small g256bh, 2026-10-14), PASS:
# same-seed top pose median 0.125 A vs the 1.342 A A/A floor, CA-lDDT -0.0004 [-0.0010, +0.0001], docking 33 -> 33.
# Warm 512-token fast fold, paired: p150a (1350 MHz) Protenix-v2 -1.67 s. Blackhole only: on a Galaxy chip
# (1000 MHz, same chip, 3 paired folds, spd-gap-small pv2fr 2026-10-14) it costs +1.5 s (61.2 vs 59.7 s), so
# `mode_levers` leaves it out of the Wormhole fast set. Wormhole normal keeps it (-1.3 s there).
FAST_LEVERS = _T.FAST_LEVERS | {"trimul_t1_c256"}
WH_FAST_LEVERS = FAST_LEVERS - {"trimul_t1_c256"}
# triatt_ln + apb_ln: the pair LayerNorm fused into the projection that reads it (triangle attention's qkvgb, and the
# attention pair-bias), so the normed pair is never written to DRAM. Wormhole 11-set fast grade, Protenix-v2 fast vs
# fast + these, 44 paired folds (spd-gap-small gtaln, 2026-10-15), PASS: same-seed top pose median 0.335 A vs the
# 1.414 A A/A floor, CA-lDDT +0.0006 [-0.0003, +0.0022], docking 34 -> 35. Galaxy chip (1000 MHz, 5 paired folds,
# talnab): Protenix-v2 fast -2.90 s; OpenDDE then null (+0.23 s: its weight fit no core and the kernel declined; it
# takes triatt_ln alone since column groups, see opendde.NORMAL_LEVERS). Wormhole normal takes it
# too: 11-set normal grade, shipped Protenix-v2 normal set vs + these, 44 paired folds (gtalnn, 2026-10-15), PASS:
# top pose median 0.091 A vs the 0.946 A floor, CA-lDDT +0.0001 [-0.0001, +0.0003], docking 35 -> 35; -2.98 s.
TRIATT_LN = frozenset({"triatt_ln", "apb_ln"})
# ws_ln + ws_lofi: the transition's LayerNorm fused into the one-chunk SwiGLU kernel, which then runs at LoFi.
# Wormhole 11-set fast grade, shipped Protenix-v2 Wormhole fast set vs + these, 44 paired folds (spd-gap-small
# gwsfx, 2026-10-15), PASS: same-seed top pose median 0.471 A vs the 1.414 A A/A floor, CA-lDDT +0.0001
# [-0.0013, +0.0021], pLDDT -0.0056, docking 34 -> 34. Galaxy chip (1000 MHz, wsfx): -0.46 s, 4 of 4 pairs faster.
# Boltz-2 fast null there, so Protenix-v2 Wormhole --fast only.
# trimul_sig6 (the trimul gate sigmoid as a degree-6 polynomial) joins them. Wormhole 11-set fast grade, shipped
# Protenix-v2 Wormhole fast set vs + trimul_sig6, 44 paired folds (spd-gap-small gsig6, 2026-10-15), PASS: same-seed
# top pose median 0.333 A vs the 1.414 A A/A floor, CA-lDDT +0.0001 [-0.0013, +0.0016], docking 34 -> 35. Galaxy chip
# (1000 MHz, s6x): -0.40 s, 4 of 4 pairs faster. Blackhole not measured.
# ws_psilu (the SwiGLU silu on the packer thread, overlapping the matmuls) is bit-identical, so it needs no grade. At
# c_z 256 the LayerNorm prologue does not fit L1 beside the bfp8 weights, so this transition runs the plain kernel at
# LoFi: N512 6.00 -> 5.00 ms a call, equal to the math-thread silu (ws_attr, .107 chip 26, 2026-10-20). Galaxy chip
# (1000 MHz, psf): CIFs identical, steady pairs -0.14 / -0.74 / -0.53 s.
# dit_shoist (the token DiT's conditioning as three wide linears a step, each block reading its columns in place)
# too: Wormhole 11-set fast grade, 44 paired folds (spd-gap-small gshx, 2026-10-15), PASS: same-seed top pose median
# 0.256 A vs the 1.414 A floor, CA-lDDT +0.0014 [+0.0008, +0.0022], ipTM -0.0004, docking 34 -> 34. Galaxy chip 512 x 1
# (1000 MHz, shx2): 55.92 -> 54.70 s, 5 of 5 warm pairs faster. p150a 11-set fast grade, 44 paired folds (gshxbh,
# 2026-10-16), PASS: top pose median 0.623 A vs the 1.371 A floor, CA-lDDT +0.0071 [+0.0035, +0.0115], docking
# 34 -> 34; p150a 5 samples 37.46 -> 36.77 s (shxb). So it is Protenix-v2 --fast on both chips: SHOIST_FAST.
# ws_lofi is out of it since 2026-10-20: LoFi hangs Wormhole chips (tenstorrent.lofi_allowed), so the kernel runs
# HiFi2 there.
WS_FAST = frozenset({"ws_ln", "trimul_sig6", "ws_psilu"})
SHOIST_FAST = frozenset({"dit_shoist"})
# Wormhole --fast pair track: the transition's LayerNorm as the SwiGLU kernel's prologue on the resid path (ws_ln_resid
# under T1's L1 rule, ws_ln_t1l1, its residual seeded from the prologue's x row) and T1's g_out written bfp8
# (trimul_t1g8). Measured as one stack over the shipped Wormhole fast set, cdk2x2 512 x 1, Galaxy chip at AICLK 1000 MHz
# sampled in every fold, 4 paired warm folds in one process (spd-m-protenix-6 lnr, 2026-11-16): 42.24 -> 41.23 s
# steady (-0.91 s median over the three pairs after the on arm's JIT fold). The prologue alone was -0.07 s (null).
WH_PAIR_FAST = frozenset({"ws_ln_resid", "ws_ln_t1l1", "trimul_t1g8"})
# Wormhole normal stack: the tail reads trimul_x8's moved x as bfp8 (pair_x8t), T1's g_out bfp8 (trimul_t1g8), the DiT
# set OpenDDE grades on Wormhole (atom_mm16, dit_qbox, dit_mask_chain, dit_qkvf) and apb_cat. Each alone was 0.2-1.2 %;
# measured as one stack over the shipped Wormhole normal set, cdk2x2 512 x 1, Galaxy chip at AICLK 1000 MHz median in
# every fold, 4 paired warm folds in one process (spd-m-protenix-6 x8s2, 2026-11-16): 49.42 -> 48.14 s steady
# (-1.32 s median over the three pairs after the on arm's JIT fold).
WH_PAIR_NORMAL = frozenset({"pair_x8t", "trimul_t1g8", "atom_mm16", "dit_qbox", "dit_mask_chain", "dit_qkvf", "apb_cat"})
# triatt_k1: triangle attention's fused SDPA takes the whole row as one k chunk at 288-512 tokens (no rescale pass;
# op 1.13x at [512, 4, 512, 32] on a Galaxy chip). It fires only at those sizes, so it is graded on the 512-token
# truth set (perf/pfm_accuracy/set512.tsv), shipped Protenix-v2 Wormhole set vs + triatt_k1, 4 seeds, every fold's
# digest moved (spd-gap-small gk1s, 2026-10-18): fast PASS, 44 paired folds, same-seed top pose median 0.699 A vs the
# 1.408 A A/A floor; normal PASS, 43 paired folds, 0.321 A vs 1.262 A, docking 34 -> 34. cdk2x2 512 x 1 at 1000 MHz,
# 5 paired warm folds (k1): normal 64.15 -> 63.20 s, fast 54.07 -> 53.19 s, 5 of 5 faster each. Blackhole, same set vs the
# shipped Protenix-v2 Blackhole set of each mode (spd-m-protenix gk1bh, 2026-10-24), 44 paired folds each: fast PASS, 0.609 A
# vs the 1.492 A A/A floor, CA-lDDT +0.0001 [-0.0010, +0.0009], docking 36 -> 36; normal PASS, 0.391 A vs the 0.6 A bar
# (1.300 A floor), every interval covers 0, docking 36 -> 36. 9TY2 512 on a p300 chip at 1306-1343 MHz, ABBA x4 in separate
# processes (bhk1ab): warm median -0.35 s on ~34.3 s fast, -0.30 s on ~43 s normal, 24 of 24 pairs faster.
TRIATT_K1 = frozenset({"triatt_k1"})
# trimul_bres (the trimul einsum by bmm_res, b[c] resident in L1) in Protenix-v2's Wormhole normal set, as OpenFold3
# and ESMFold2 ship it. Normal mode's fp32 dest lets it fire as is, and it is bit-exact there: cdk2x2 512 x 1 on a
# Galaxy chip at 1000 MHz, paired warm folds (spd-m-protenix bresnormal, 2026-10-19), CIFs identical, -1.30 and
# -1.38 s (63.35 -> 62.01 s). Bit-exact on Blackhole too: p300c chip at 1350 MHz, 4 paired warm folds (bhab bres),
# CIFs identical, median -1.16 s (32.70 -> 30.72 s steady), so it rides on both chips.
BRES_NORMAL = frozenset({"trimul_bres"})
# ws_resid + ws_resid2: the transition's residual add folded into its last SwiGLU chunk's fp32 dest. Wormhole 512-token
# normal grade, shipped Protenix-v2 Wormhole normal set vs + these, 44 paired folds (spd-m-protenix grr2n, 2026-10-19),
# PASS: same-seed top pose median 0.608 A vs the 1.311 A A/A floor, every interval on the better side (CA-lDDT +0.0049
# [+0.0005, +0.0125]), docking 35 -> 36. cdk2x2 512 x 1 at 1000 MHz, paired warm folds (rr2n): median -0.55 s.
WS_RESID_NORMAL = frozenset({"ws_resid", "ws_resid2"})
# The normal-mode pair transition stack keyed on pair width, not on Protenix-v2 (`mode_levers`): ws_chain, ws_resid,
# ws_resid2 and ws_psilu (bit-identical). Graded at 256 above; Mol-1's 448 and 320 since pair_swiglu_ws tiles any
# even tile width. Op on a p300c chip at 1350 MHz, N 512, Mol-1 weights (perf/mol1_pairmix/transition_bench.py):
# 448 29.03 -> 19.22 ms, 320 17.44 -> 10.37 ms; rel err to float64 0.0093 -> 0.0099 and 0.0054 -> 0.0062.
WS_NORMAL = WS_CHAIN | WS_RESID_NORMAL | {"ws_psilu"}
WS_NORMAL_WIDTHS = frozenset({256, 320, 448})
# Blackhole takes TRIATT_LN and WS_RESID_NORMAL in Protenix-v2's normal set too. Blackhole 512-token normal grade, shipped
# Protenix-v2 Blackhole normal set vs + these as one stack (spd-m-protenix gbhn, 2026-10-20), PASS on 44 paired: top pose
# median 0.320 A vs the 0.6 A bar (1.369 A A/A floor), CA-lDDT +0.0018 [-0.0007, +0.0058], docking 35 -> 36. cdk2x2 512 x 1
# on a p300 chip at 1350 MHz, 4 paired warm folds in one process (bhab6): steady pairs -0.84 / -1.67 / -1.87 s on ~33 s.
# dit_qsplit (the token DiT's attention takes the q chunk that leaves the busiest core fewest rows) in Protenix-v2's
# normal set, as OpenFold3 ships it. It moves rows between cores, not arithmetic: cdk2x2 512 x 1 on a Galaxy chip at
# 1000 MHz, 6 paired warm folds (spd-m-protenix qsn2, 2026-10-19), CIFs identical, 6 of 6 faster, median -0.15 s
# (-0.03 to -0.37). Flat on p150a for OpenFold3, so it rides on both chips.
QSPLIT_NORMAL = frozenset({"dit_qsplit"})
# A multi-width trunk (Mol-1: 448 and 320) takes, besides WS_NORMAL, the Protenix-v2 normal levers whose property it
# shares: triangle attention's fused LayerNorm and one-chunk SDPA (TRIATT_LN, TRIATT_K1; each plans per width and
# declines a shape it does not tile), and the token DiT's q split and device-resident pair (dit_qsplit, pz_device), whose
# DiT is Protenix-v2's (c_token 768, 16 heads). Graded as one stack on Mol-1 (perf/mol1_pairmix/e2e_ab.sh STACK=1).
# Mol-1 Blackhole normal, 5sak chain 1 (448 tokens, 4449-row MSA, 20 cycles, 200 steps), base vs this set plus
# MOL1_BH and the triangle attention planner at 320/448, 3 seeds, p300c at AICLK median 1318-1343: warm fold 86.92 ->
# 69.92 s (median), same-seed all-atom lDDT 0.997-1.000 vs seed floor 0.970-0.992, pLDDT unchanged. Wormhole: see MOL1_WH.
WIDE_NORMAL = WS_NORMAL | TRIATT_LN | TRIATT_K1 | QSPLIT_NORMAL | {"pz_device"}
# triatt_ln_b8 (triatt_ln writes q, k, v bfp8; the head-major bias is narrowed after its permute; the SDPA keeps a
# bf16 destination) in Protenix-v2's Wormhole --fast set. Wormhole 512-token fast grade, shipped Protenix-v2 Wormhole
# fast set vs + triatt_ln_b8, 44 paired folds (spd-m-protenix gb8ln, 2026-10-19), PASS: same-seed top pose median
# 0.770 A vs the 1.435 A A/A floor, CA-lDDT -0.0006 [-0.0019, +0.0003], pLDDT -0.0002, docking 36 -> 36. The fold
# is the same on an 8x8 and an 8x9 core grid (g88). cdk2x2 512 x 1 on a Galaxy chip at 1000 MHz, 5 paired warm folds
# (b8f2): 54.28 -> 50.98 s median. triatt_ln_b8g adds the gate, which gated_out_proj reads at bfp8: same grade on top
# of triatt_ln_b8 (gb8g, 44 paired folds) PASS, top pose median 0.674 A vs the 1.325 A floor, CA-lDDT +0.0004
# [-0.0005, +0.0014], docking 36 -> 36; b8g on a Galaxy chip at 1000 MHz, 3 of 3 warm pairs faster, median -0.70 s.
# Blackhole is ungraded.
TRIATT_LN_B8_FAST = frozenset({"triatt_ln_b8", "triatt_ln_b8g"})
# trimul_gin_w8: the trimul in-projection holds its resident weights bfp8, so at c_z 256 it fits one launch and reads
# the normed pair once instead of twice. Each output tile is one core's full-K product, so the fold does not depend on
# the core grid. Wormhole 512-token fast grade, shipped Protenix-v2 Wormhole fast set vs + trimul_gin_w8, 44 paired
# folds (spd-m-protenix gw8g, 2026-10-19), PASS: same-seed top pose median 0.812 A vs the 1.399 A A/A floor, CA-lDDT
# +0.0010 [-0.0010, +0.0040], docking 35 -> 36. cdk2x2 512 x 1 on a Galaxy chip at 1000 MHz (gw8): steady warm pairs
# -0.22, -0.32 and -1.42 s. Blackhole is ungraded.
GIN_W8_FAST = frozenset({"trimul_gin_w8"})
# trimul_t1_c256 + trimul_t1w8 + trimul_t2g on Wormhole --fast: T1 holds its resident weights bfp8, so c_z 256 runs as
# one launch that reads z once (two bf16 channel-group launches cost +1.5 s here, see FAST_LEVERS), and trimul_t2g
# fuses the output tail of the calls T1 declines. Wormhole 512-token fast grade, shipped Protenix-v2 Wormhole fast set
# vs + these, 43 paired folds (spd-m-protenix gt1g, 2026-10-19), PASS: same-seed top pose median 0.791 A vs the
# 1.600 A A/A floor, CA-lDDT +0.0007 [-0.0005, +0.0019], docking 35 -> 35. cdk2x2 512 x 1 on a Galaxy chip at
# 1000 MHz, 3 paired warm folds (t1g): 47.0 -> 45.2 s, 3 of 3 faster. Blackhole is ungraded.
T1W8_FAST = frozenset({"trimul_t1_c256", "trimul_t1w8", "trimul_t2g"})
# opm_b8cfg: the bfp8 outer-product-mean contraction on opm_contract_config's plan at HiFi2. Kernel on a Galaxy chip at
# 1000 MHz, [16384, 4128]^2 (fidc): 33.3 -> 25.8 ms, f64 rel-RMS 0.0145 -> 0.0119 (the plan's K order). It pays only on
# deep MSAs: the 35-row page fixture contracts two K tiles and folds bit-identically (ob8c). Wormhole 512-token fast
# grade on real MSAs, shipped Protenix-v2 Wormhole fast set vs + opm_b8cfg, 44 paired folds (spd-m-protenix gob8c,
# 2026-10-19), PASS: same-seed top pose median 0.510 A vs the 1.600 A A/A floor, CA-lDDT +0.0003 [-0.0010, +0.0015],
# docking 36 -> 36. The plan is Wormhole's; Blackhole is ungraded.
OPM_B8CFG_FAST = frozenset({"opm_b8cfg"})
# trimul_x8: where the one-pass move back takes the triangle contraction's channel-major x, the contraction writes x
# bfp8, so the move reads and the contraction writes half the bytes. Kernel on a Galaxy chip at 1000 MHz, c 256 (x8op):
# 3.67 -> 3.34 ms/call, f64 rel-RMS 0.0044 -> 0.0080. Wormhole 512-token fast grade, shipped Protenix-v2 Wormhole fast
# set vs + trimul_x8, 44 paired folds (spd-m-protenix gx8f, 2026-10-26), PASS: same-seed top pose median 0.479 A vs the
# 1.508 A A/A floor, CA-lDDT -0.0001 [-0.0007, +0.0004], iRMSD -0.35 [-0.83, -0.01], docking 36 -> 36. cdk2x2 512 x 1
# on a Galaxy chip at 1000 MHz in one process (x8f): steady warm pairs -0.67 / -0.50 s. Wormhole 512-token normal grade,
# shipped Protenix-v2 Wormhole normal set vs + trimul_x8, 44 paired folds (gx8n, 2026-10-26), PASS: same-seed top pose median
# 0.324 A vs the 1.281 A A/A floor, every interval covers 0, ipTM -0.0001, docking 36 -> 36.
# In-process x3 at 1000 MHz (x8n): warm pairs -0.58 / -0.59 / -0.18 s on ~49.8 s. Blackhole runs the channel-major
# tail (T2CM), where x8 never fires.
X8_WH = frozenset({"trimul_x8"})
# Protenix-v2's Blackhole --fast set on top of FAST_LEVERS: triatt_ln (without apb_ln), its bfp8 q/k/v and gate, the
# pair SwiGLU at LoFi with its fused LN, the degree-6 trimul sigmoid, T1's bfp8 resident weights and trimul_bres.
# Blackhole 512-token fast grade, shipped Protenix-v2 Blackhole fast set vs + these as one stack (spd-m-protenix gbhf,
# 2026-10-19), PASS on 42 paired: top pose median 0.650 A vs the 1.345 A A/A floor, CA-lDDT -0.0013 [-0.0036, +0.0003],
# docking 34 -> 33. 9W8A lost its interface on 2 of 4 seeds; a 12-seed sweep (w8a) shows that target collapsing on
# ~2 of 12 seeds under every Protenix-v2 fast set, so it is the target, not this stack.
# cdk2x2 512 x 1 on a p300 chip at 1350 MHz, 4 paired warm folds in one process (bhab5): steady 28.85 -> 25.49 s median, -3.19 s.
# ws_psilu rides along bit-identically: pair SwiGLU kernel at N 512 c 256 4.08 -> 3.26 ms (wsk), and the fold's CIFs are
# identical with it on and off, steady warm pairs +0.39 / -0.76 / -0.78 s (psf, p300 at 1325 MHz mean).
# trimul_t1_dram: below 352 tokens T1 declined every call on the L1 path (0 served, 3384 declined per 256-token fold); on the
# DRAM path it serves. Never fires at 512. Blackhole 256-token fast grade vs the set above (spd-m-protenix gt1bhf, 2026-10-21),
# 44 paired folds over 4 seeds, PASS: same-seed top pose median 1.118 A vs the 4.872 A A/A floor, CA-lDDT +0.0008 [-0.0012,
# +0.0034], DockQ -0.012 [-0.028, -0.001], docking 22/44 -> 22/44. Separate processes on a p300 chip at 1350 MHz (bht1d):
# warm 12.47 / 11.87 / 12.05 / 12.11 -> 9.85 / 9.74 / 9.95 s.
# trimul_t1g8: T1 writes g_out bfp8 and the DRAM-bound fused tail reads it so. Device kernel seconds from a Tracy census of
# cdk2x2 512 x 1 on a p300 chip, AICLK 1350 MHz median in-run, the shipped Blackhole fast set written out (spd-m-protenix-6
# dcb, 2026-11-16): 18.26 -> 17.62 s, the tail 2.12 -> 1.66 s and T1 2.12 -> 1.99 s. Measured on device time because
# that host's wall clock moved +-2 s under load.
# edm_device (the EDM trajectory stays on the card, as Mol-1 and OF3 already run it on Blackhole). Blackhole 512-token fast
# grade vs the set above (spd-m-protenix-7 ge2, 2026-11-19), 44 paired folds over 4 seeds, PASS: same-seed top pose median
# 0.220 A vs the 0.6 A bar (1.318 A A/A floor), CA-lDDT +0.0002 [-0.0002, +0.0006], iRMSD -0.12 [-0.33, -0.004], docking
# 36/44 -> 36/44. Same folds, a p300 chip at 1325-1337 MHz median: paired warm fold -0.23 s median, -0.68 s mean, 10 of 11
# complexes faster; the diffusion stage alone 3.49 -> 3.05 s on cdk2x2 (sp, 4 paired warm folds).
BH_V2_FAST = frozenset({"triatt_ln", "ws_ln", "ws_lofi", "trimul_sig6", "trimul_t1w8", "trimul_bres_bh", "ws_psilu",
                        "trimul_t1_dram", "trimul_t1g8", "edm_device"}) | TRIATT_LN_B8_FAST
# dit_shoist and trimul_t1w8 (T1's resident weights bfp8, c_z 256 in one launch) in Protenix-v2's Wormhole normal set.
# Wormhole 512-token normal grade, shipped Protenix-v2 Wormhole normal set vs + both, 44 paired folds (spd-m-protenix
# gstn, 2026-10-20), PASS: same-seed top pose median 0.221 A vs the 0.6 A bar (1.145 A A/A floor), CA-lDDT +0.0002
# [-0.0003, +0.0008], iRMSD -0.30 [-0.85, -0.004], ipTM -0.009 [-0.022, -0.001], docking 36 -> 36; dit_shoist alone
# 0.077 A, every interval covers 0. cdk2x2 512 x 1 on a Galaxy chip at 1000 MHz, steady warm pairs: dit_shoist
# -0.72 / -0.61 / -1.01 s (shn), trimul_t1w8 -0.72 / -0.68 / -0.54 s (t1n). Blackhole is ungraded.
# transition_b8 + ws_b8_plain (bfp8 pair-transition weights in one chunk on the plain SwiGLU kernel): Wormhole 512-token
# normal grade vs the set above (spd-m-protenix gtbn, 2026-10-20), 42 paired folds over 4 seeds: same-seed top pose median
# 0.273 A vs the 0.6 A bar (1.254 A A/A floor), docking 35/42 -> 35/42, every interval covers 0. transition_b8 alone read 0.731 A.
# Separate processes on one Galaxy chip at 1000 MHz (tbx): 55.98 / 55.99 -> 53.36 / 53.21 s warm; transition_b8 alone 55.18 s.
# ws_psilu rides along bit-identically on that plain kernel: CIFs identical on 8 of 8 warm folds, separate processes on
# one Galaxy chip at 1000 MHz (psn): 53.36 / 53.24 / 53.72 / 53.24 -> 52.81 / 52.82 / 52.62 / 53.02 s warm.
# trimul_t1_dram: below 352 tokens the trimul loop runs from L1, where T1 declined; on the DRAM path T1 serves those folds
# too. Never fires at 512. Wormhole 256-token normal grade vs the set above (spd-m-protenix t1p, 2026-10-21), 44 paired folds
# over 4 seeds, PASS: same-seed top pose median 0.306 A vs the 0.6 A bar (3.271 A A/A floor), CA-lDDT -0.0010 [-0.0030,
# +0.0008], ipTM -0.0035, docking 23/44 -> 24/44. Same grid, 5 samples, two Galaxy chips at 1000 MHz: warm median 42.02 -> 35.45 s.
# trimul_t1_2g: T1 may hold 2 GiB of outputs, so it also serves c_z 256 from ~900 to 1152 tokens, where every call declined.
# Never fires at 512. 1024 tokens, warm, in-process A/B x2: Wormhole (1000 MHz) 257.8 / 259.1 -> 218.9 / 217.2 s, pLDDT 0.786 ->
# 0.788; Blackhole p300 (1275-1350 MHz) 124.7 / 121.7 -> 116.9 / 102.9 s. Op error at 768 and 1024 vs float64 matches the
# incumbent path (a rel-RMS 0.0037-0.0039 vs 0.0037 at HiFi4). No OOM at 1152 on a 12 GiB Wormhole chip.
# pz_device in normal mode: the conditioned pair stays on the chip for the fp32 DiT too (device LN, fp32 W_z). Wormhole
# 512-token normal grade vs the set above (spd-m-protenix gpzn, 2026-10-25), 44 paired folds over 4 seeds, PASS: same-seed
# top pose median 0.057 A vs the 0.6 A bar (1.296 A A/A floor), every interval covers 0, ipTM +0.0001, docking 36 -> 36.
# cdk2x2 512 x 1 on a Galaxy chip at 1000 MHz, in-process A/B x3 (pzn): warm -0.89 / -1.02 s on ~50.9 s.
WH_V2_NORMAL = frozenset({"dit_shoist", "trimul_t1w8", "transition_b8", "ws_b8_plain", "ws_psilu", "trimul_t1_dram",
                          "trimul_t1_2g", "pz_device"})
# transition_b8 + ws_b8_plain stay out of Protenix-v2's Blackhole normal set. Its fold is the same on every shipped BH
# grid (p150a and p300 native, forced 10x10; only a forced 8x8 moves it, spd-m-protenix gridclass2/3), and it saves ~1.2 s
# at 512, but it lowers confidence: Blackhole 512-token normal grade (gtbbh, 2026-10-25, 44 paired folds) ipTM -0.019
# [-0.044, -0.002], past the 0.005 normal bar. Most of it is 9W8A, which is bistable here (16 seeds: base collapses on
# 2, with the pair on 4), the rest -0.009 across the other ten complexes. Fast mode runs transition_b8 on both chips.
# trimul_t1w8 + ws_psilu: Blackhole 512-token normal grade vs that set with the stack still in (spd-m-protenix gt1wbhn,
# 2026-10-22), 44 paired folds over 4 seeds, PASS: same-seed top pose median 0.331 A vs the 0.6 A bar (1.410 A A/A floor),
# CA-lDDT +0.0001 [-0.0035, +0.0033], docking 36/44 -> 36/44, every interval covers 0. On today's base (gt1wg, p300 chip
# 2, 1325-1343 MHz median, separate processes x2) warm folds are -0.75 to -1.74 s on ~45 s and each arm's digest repeats
# across processes. ws_psilu is bit-identical by construction.
# dit_shoist alone fails Blackhole normal (spd-m-protenix gshbn2, 2026-10-24, 44 paired folds): top pose median 0.063 A,
# but CA-lDDT -0.0002 [-0.0003, -0.0001] excludes 0.
# pz_device in normal mode, as on Wormhole: Blackhole 512-token normal grade vs the set above (spd-m-protenix gpzbhn,
# 2026-10-25), 44 paired folds over 4 seeds, PASS: same-seed top pose median 0.080 A vs the 0.6 A bar (1.299 A A/A floor),
# CA-lDDT +0.0002 [+0.0001, +0.0004], ipTM +0.0002, docking 36 -> 36. 9TY2_512 on a p300 chip, in-process A/B x3 (bhpzn,
# AICLK not sampled): warm -0.47 / -0.18 s on ~26.4 s.
# edm_device in normal mode too (see BH_V2_FAST). Blackhole 512-token normal grade vs the set above (spd-m-protenix-7 ge2,
# 2026-11-20), first 4 of 11 complexes, 16 paired folds, PASS: same-seed top pose median 0.138 A vs the 0.6 A bar (1.308 A
# A/A floor), CA-lDDT +0.0006 [+0.0001, +0.0010], iRMSD -0.02 [-0.07, +0.02], docking 12/16 -> 12/16. Same folds, p300
# chips at 1306-1331 MHz median: paired warm fold -0.39 s median, -1.08 s mean, 9 of 12 faster; diffusion stage 5.65 ->
# 5.15 s on cdk2x2 (sp).
BH_V2_NORMAL = frozenset({"trimul_t1_2g", "trimul_t1w8", "ws_psilu", "pz_device", "edm_device"})
# Protenix-v2's Blackhole normal pair stack: T1 writes g_out bfp8 (trimul_t1g8), the contraction writes x bfp8 for the move
# back (trimul_x8) and the plain T2 tail reads that moved x as bfp8 (pair_x8t). x8 needs the row-major tail, so this mode
# drops T2CM (BH_NORMAL_DROP). Device kernel seconds from a Tracy census of cdk2x2 512 x 1 on a p300 chip, AICLK 1350 MHz
# median in-run, the shipped Blackhole normal set written out (spd-m-protenix-6 dcn/cmb, 2026-11-16): 22.44 -> 21.85 s;
# trimul_t1g8 alone 21.97 s.
BH_PAIR_NORMAL = frozenset({"trimul_t1g8", "trimul_x8", "pair_x8t"})
BH_NORMAL_DROP = frozenset({"trimul_t2cm"})
# dit_shoist_mm: the hoisted DiT conditioning linears on minimal_matmul (2 x 16 tile blocks, K block 1), same fidelity and
# float64 error as ttnn.linear's schedule (shm2). Wormhole 512-token grades vs the shipped Protenix-v2 Wormhole set of each
# mode, 44 paired folds each over 4 seeds (spd-m-protenix gshmn / gshmf, 2026-10-20), PASS: normal top pose median 0.096 A
# vs the 0.6 A bar (1.319 A A/A floor), docking 36 -> 36; fast 0.305 A (1.305 A floor), docking 37 -> 37; every interval
# covers 0. cdk2x2 512 x 1 on a Galaxy chip at 1000 MHz, in-process A/B (shx): median -0.25 s normal, -0.32 s fast.
# dit_step_mm: the DiT's per-step linears on minimal_matmul with blocks measured at Protenix-v2's shapes. Same grade
# against the set above (gsmn / gsmf, 2026-10-21), PASS: normal 0.080 A (1.368 A floor), docking 36 -> 36; fast 1.041 A
# (1.386 A floor), docking 37 -> 37, CA-lDDT +0.0013 and pLDDT +0.0010. Same A/B (stx): median -0.27 s normal, -0.16 s fast.
# Blackhole is ungraded for both.
DIT_MM_WH = frozenset({"dit_shoist_mm", "dit_step_mm"})
# trimul_t1_psig: T1's gate sigmoid on the packer thread, overlapping the next matmul block. Bit-identical by construction
# (same sigmoid_poly on the same values; in_t1 f64 errors equal at N 512), so it needs no grade. Op on a Galaxy chip at
# 1000 MHz (t1sig): 6.84 -> 6.41 ms/call, 6.27 -> 5.86 with bfp8 weights. Both chips, both modes: on a p300c chip at
# 1293-1337 MHz (t1psbh, 9TY2_512) normal is neutral (-0.04 s median of 4 warm pairs) and --fast -0.35 s, digests unchanged.
T1_PSIG = frozenset({"trimul_t1_psig"})
# triatt_q10: padded triangle attention may take a 10-tile q chunk at the k chunk the ranking already picks, so output
# bits cannot move (torch.equal). Op at Protenix-v2's mode sets on a Galaxy chip at 1000 MHz (spd-m-opendde q10h,
# 2026-10-22), ms/call: 4 heads 608 8.00 -> 6.98, 1184 60.54 -> 56.39; 8 heads 608 15.59 -> 14.68; nowhere slower. A
# 512-token fold never reaches it. Wormhole both modes; Blackhole ranks per grid and is unmeasured.
TRIATT_Q10_WH = frozenset({"triatt_q10"})
# pz_device + dit_mod16 on Wormhole --fast: the diffusion-conditioned pair stays on the chip (one device LN feeds the bf16
# DiT, no host round trip) and the bf16 AdaLN modulation and the DiT's gated residuals run as one addcmul each, as OpenDDE's
# DIT_SEAM. Normal mode takes pz_device too on both chips (WH_V2_NORMAL, BH_V2_NORMAL). Wormhole 512-token fast grade, shipped Protenix-v2 Wormhole
# fast set vs + both, 44 paired folds over 4 seeds (spd-m-protenix gpzf, 2026-10-23), PASS: same-seed top pose median
# 0.402 A vs the 1.497 A A/A floor, CA-lDDT +0.0013 [+0.0002, +0.0032], lRMSD -0.21 [-0.45, -0.02], docking 37/44 -> 37/44.
# cdk2x2 512 x 1 on a Galaxy chip at 1000 MHz (pzab), steady warm pairs -0.69 / -0.71 s. On a p300 chip (bhpzab, 9TY2_512,
# separate processes x2) the two runs read -1.2 and +1.4 s, inside the box's drift; ABBA x4 in separate processes (bhpzab2, AICLK
# 1337-1350 median) reads -0.53..-1.16 s per warm fold, median -0.83 s on ~36 s. Blackhole 512-token fast grade vs the shipped
# Blackhole fast set (gpzbh, 2026-10-24), 44 paired folds over 4 seeds, PASS: same-seed top pose median 0.413 A vs the 1.407 A
# A/A floor, CA-lDDT +0.0002 [-0.0006, +0.0013], docking 35/44 -> 36/44.
DIT_SEAM_FAST = frozenset({"pz_device", "dit_mod16"})
# Mol-1 (c_z 448: MSA pair stack, PairMixer, confidence; 320: Pairformer): T1 at both widths on trimul_tail.t1_fit's plans,
# on the DRAM route from 160 tokens and with the 2 GiB output budget, so it serves every size it can. Same arithmetic as
# the incumbent in-projection, layer_norm and gated moves: module rel_rms vs float64 0.0085 both ways at 256 and 512 tokens,
# c_z 320 and 448 (perf/spd_trimul/bench.py, p150a 1350 MHz, state/mol1/rows/mol1-perf-trimul.json). Blackhole only until
# measured on a Galaxy chip (Protenix-v2's two-group c_z 256 plan lost there in --fast), and normal mode only until --fast is.
# Plus the T2 output tail (t2w plan) and trimul_bres: module rel_rms 0.0092 (c_z 320) / 0.0096 (448). 5sak with its 4449-row
# MSA, 448 tokens, real weights, p150a 1325-1343 MHz median, graded stack vs + these, seeds 101-103: same-seed lDDT
# 0.996-1.000 vs the 0.970-0.991 seed floor, warm median 68.71 -> 63.94 s.
MOL1_T1 = frozenset({"trimul_t1_c320", "trimul_t1_c448", "trimul_t1_dram", "trimul_t1_2g"})
# Plus trunk_hifi2 (the trunk matmuls at HiFi2 over trunk_hifi3): 8cnh 509 tokens, p150a at AICLK 1350 (min 1343), 4 warm
# folds per arm interleaved: 85.9 -> 84.8 s; samples matched to the base fold at 0.218 A median (max 0.387) vs the 0.60 A bar
# and the 1.37 A sample floor, lDDT 0.996 (state/mol1/evidence/bh-trunk/ab512).
# Plus trimul_t1_part, which keeps c_z 448 on T1 at 1024 tokens instead of the chunk-32 channel loop and changes nothing
# below ~900 tokens: mol1-1024 (1000 tokens), p300 chip, warm 380.6 -> 344.1 s at AICLK 1262-1287 (min 1093); samples matched
# to the base fold at 0.088 A median vs the 0.60 A bar and the 1.27 A sample floor (state/mol1/evidence/bh-trunk/ab1024).
# Plus the fp32 diffusion stack, graded as one stack: dit_shoist (every DiT block's s-terms as three wide linears a step),
# atom_mm16 and adaln_mod (the atom transformer's gate sigmoid once per fold). perf/mol1/bh/ab.sh, qb2 p300 chip, 3 warm folds
# per arm, seeds 102-104: 256 tokens 31.23 -> 29.13 s at AICLK 1331-1337, samples matched to the base fold at 0.247 A median
# (max 0.767) vs the 2.24 A sample floor; 512 tokens 83.58 -> 80.97 s at 1306-1318, 0.150 A median (max 0.373) vs the 0.60 A
# bar and the 1.37 A floor. diffusion_bf16 on top fails the 256 grade (0.806 A median) for a further -0.2 s and stays out.
MOL1_DIT_BH = frozenset({"dit_shoist", "atom_mm16", "adaln_mod"})
# Plus ws_l1dest: transition_ws also serves the pair transitions whose residual update fits L1, the Pairformer's at 256
# tokens. mol1-256 (245 tokens) on a qb1 p150a at AICLK 1350, 5 warm folds per arm: 29.6 -> 27.25 s; samples matched to
# the base fold at 1.61 A median vs the 6.07 A seed floor, lDDT 0.964 vs 0.902. 512: 82.2 -> 81.6 s, 0.256 A median vs
# the 0.60 A bar and the 1.49 A floor; 1024 coords identical (state/mol1/evidence/bh-batch).
# Plus edm_device (the EDM trajectory stays on the card, the host only draws and stages each step): the host round trip
# left the device idle 1.2 s a fold at 256 and 1.4 s at 512 (state/mol1/evidence/bh/opgap.md). qb1 p150a at AICLK 1350
# (min 1343), 6 warm folds per arm interleaved on a loaded host: 256 31.58 -> 26.84 s, 512 82.88 -> 80.60 s; samples
# matched to the base fold at 0.265 A median vs the 4.70 A seed floor (256) and 0.167 A (max 0.53) vs the 0.60 A bar and
# the 1.35 A floor (512).
# Plus four levers the fleet won elsewhere that leave Mol-1's digest unchanged: atom_l1, trimul_t1_psig, inproj_split and
# trimul_t2cm. qb1 p150a at AICLK 1350, 5 warm folds per arm (state/mol1/evidence/bh/spdport.md): coords identical at
# 256 and 512, warm 29.71 -> 26.96 s (256, a noisy base) and 83.29 -> 82.20 s (512); flat against a quiet base.
# Plus dit_qkvf: each DiT block's attention reads the fused qkv projection and writes its heads concatenated, so the
# head split and the four-op head re-assembly (4.3 ms of the 32.4 ms step at 256) go. qb1 p150a at AICLK 1350, 3 warm
# folds per arm: 256 25.76 -> 24.72 s, 0.251 A median vs the 4.58 A seed floor; 512 78.31 -> 76.13 s, 0.163 A (max 0.54)
# vs the 0.60 A bar and the 1.35 A floor; 1024 293.1 -> 290.8 s, 0.08 A vs the 0.61 A floor (state/mol1/evidence/bh/b256.md).
# Plus trimul_t1split, bit-identical: one trimul call (qb2 p300c, AICLK 1200-1350) c_z 320 2.67 -> 2.45 ms at 256 tokens,
# 7.84 -> 7.00 at 512, 33.66 -> 30.23 at 1024; c_z 448 4.17 -> 4.01 ms at 256, flat at 512 and 1024
# (state/mol1/evidence/bh/mulroof.md).
# Plus dit_qbox + dit_mask_chain, bit-identical: the token DiT fp32 attention as per-core (sample, head, q chunk) boxes
# that hand the sample-broadcast mask core to core from 512 tokens. One call, 5 samples: 1024 1.495 -> 1.168 ms, 512
# 0.432 -> 0.410. qb1 p150a at AICLK 1350, 3 warm folds per arm, coords identical: 512 74.93 -> 74.23 s, 1024 294.28 ->
# 291.84 s (state/mol1/evidence/bh/diffstep.md).
MOL1_BH = MOL1_T1 | MOL1_DIT_BH | T1_PSIG | {"trimul_t2", "trimul_t2w", "trimul_bres", "trunk_hifi2", "trimul_t1_part",
                                            "ws_l1dest", "edm_device", "atom_l1", "inproj_split", "trimul_t2cm",
                                            "dit_qkvf", "trimul_t1split", "dit_qbox", "dit_mask_chain"}
# Mol-1 on Blackhole from 512 padded tokens (`size_levers`): bfp8 pair-transition weights in one chunk on the plain SwiGLU
# kernel, the reblock move back writing bfp8 and T1's resident weights in bfp8. Graded as one stack over MOL1_BH, qb1
# p150a at AICLK 1350, 5 warm folds per arm: 512 tokens 83.29 -> 75.23 s, samples matched to the base fold at 0.423 A
# median (max 2.15) vs the 0.60 A bar and the 1.33 A seed floor, lDDT 0.991 vs 0.964. At 256 the same stack reads 0.735 A
# and fails, so it stays off below 512.
# trimul_t1g8 (g_out bfp8) graded over the rest of this set, qb2 p300c ABBA: 512 67.75 -> 66.21 s at AICLK 1275-1300,
# 0.523 A median vs the 1.97 A seed floor; 1024 266.5 -> 260.3 s at 1237-1250, 0.091 A vs 0.538. At 256 it reads -0.8 %
# for 0.52 A of the 0.60 A bar, so it stays off there.
MOL1_BH_512 = frozenset({"transition_b8", "ws_b8_plain", "trimul_x8", "trimul_t1w8", "trimul_t1g8"})
SIZE_LEVERS_MIN_TOKENS = 512


def size_levers(state_dict):
    """The levers a checkpoint's normal mode adds from `SIZE_LEVERS_MIN_TOKENS` padded tokens: `MOL1_BH_512` for Mol-1
    on Blackhole in either mode, else none. None under a harness set (TT_BIO_LEVERS), which names the whole set."""
    if os.environ.get("TT_BIO_LEVERS") or _T.is_wormhole():
        return frozenset()
    widths = Trunk._pair_widths(state_dict)
    return MOL1_BH_512 if widths and widths <= WS_NORMAL_WIDTHS and 448 in widths else frozenset()


def _under_size_levers(method):
    """Run a fold entry point under the model's levers, plus its `size_levers` when the target pads to
    `SIZE_LEVERS_MIN_TOKENS` tokens or more."""
    import functools

    @functools.wraps(method)
    def run(self, feats, *a, **kw):
        f = feats[0] if isinstance(feats, (list, tuple)) else feats
        nt = int(f["atom_to_token_idx"].max()) + 1
        base, size = getattr(self, "_levers", frozenset()), getattr(self, "_size_levers", frozenset())
        big = size and -(-nt // TOKEN_PAD_MULTIPLE) * TOKEN_PAD_MULTIPLE >= SIZE_LEVERS_MIN_TOKENS
        with _T.levers(base | size if big else base):
            return method(self, feats, *a, **kw)
    return run


# Mol-1 on Wormhole normal: WIDE_NORMAL, the T1 set and Protenix-v2's Wormhole extras (DIT_MM_WH, TRIATT_Q10_WH, X8_WH,
# BRES_NORMAL, T1_PSIG), graded as one stack on a Galaxy chip at 1000 MHz (state/mol1/evidence/perf-wh): 8cnh 509 tokens,
# 20 cycles / 200 steps / 5 samples, warm 272.4 -> 194.1 s per prediction (-29 %; WIDE_NORMAL alone 227.1, + MOL1_T1
# 206.9); samples matched to the base fold's 0.269 A median (max 0.937) vs the 0.60 A bar and the 1.442 A sample floor,
# all-atom lDDT 0.996 vs 0.965. T2 (trimul_t2, t2w) is not graded on Wormhole at 320/448 and stays out.
# Plus trimul_t1_3g, which keeps c_z 448 on T1 at 1024 tokens (2.63 GiB of outputs, over trimul_t1_2g's 2 GiB) instead
# of the chunk-32 channel loop, and changes nothing below ~900 tokens. Its A/B: state/mol1/evidence/wh1024-host.
MOL1_WH = MOL1_T1 | DIT_MM_WH | TRIATT_Q10_WH | X8_WH | BRES_NORMAL | T1_PSIG | {"trimul_t1_3g"}
# Mol-1 --fast: its tuned normal set plus the levers that pay at Mol-1 widths on that chip. Wormhole takes the bfp8
# weights Blackhole normal takes from 512 tokens, plus trimul_gin_w8 and opm_b8cfg; Blackhole takes the shared
# FAST_LEVERS, which cost Wormhole +12.5 s on 9DBP. Of the bfp8 pair stack Protenix-v2 grades into its --fast sets,
# triangle attention cost Mol-1 0.04-0.05 ipTM on both chips and flipped 9W8A seed 103 off its interface on Wormhole,
# and ws_ln, trimul_sig6 and dit_mod16 bought nothing on Wormhole, so Mol-1 takes none of it.
# Times and the accuracy grade: state/mol1/evidence/fast/ROOT.md.
MOL1_WH_FAST = MOL1_BH_512 | GIN_W8_FAST | OPM_B8CFG_FAST
MOL1_BH_FAST = FAST_LEVERS
from .eltwise_fusion import scale_add, norm_residual, gated_add


class _Sig(tuple):
    """An atom transformer output gate that already went through its sigmoid (`adaln_mod`)."""


def _sigmoid_own(t):
    out = ttnn.sigmoid(t)
    ttnn.deallocate(t)
    return out


def _gated_residual(res, x, gate):
    """`res + x * sigmoid(gate)`: one addcmul when the gate's sigmoid was taken once per fold (`_Sig`)."""
    if isinstance(gate, _Sig):
        return gated_add(res, x, gate[0])
    return ttnn.add(ttnn.multiply(x, gate, input_tensor_b_activations=[ttnn.UnaryOpType.SIGMOID]), res)


def mode_levers(state_dict):
    """The mode's lever set for a Protenix checkpoint: `FAST_LEVERS` under --fast, else `NORMAL_LEVERS`,
    plus `T2_TAIL`, `WS_CHAIN` and `QSPLIT_NORMAL` for Protenix-v2 (c_z 256), the one width their normal grades cover; Wormhole --fast takes
    `WH_FAST_LEVERS`, and Wormhole adds `TRIATT_LN`, `DIT_MM_WH`, `TRIATT_Q10_WH` and `X8_WH` to both Protenix-v2 modes and `WS_FAST`, `TRIATT_LN_B8_FAST`, `GIN_W8_FAST`, `T1W8_FAST`,
    `OPM_B8CFG_FAST`, `WH_PAIR_FAST` to its --fast and `WH_V2_NORMAL`, `WH_PAIR_NORMAL` to its normal mode; Blackhole adds `BH_V2_FAST` to Protenix-v2's --fast and `BH_V2_NORMAL`, `BH_PAIR_NORMAL` to its normal mode, which drops `BH_NORMAL_DROP`. Protenix-v2 takes `BRES_NORMAL`, `TRIATT_LN` and `WS_RESID_NORMAL` in normal mode, `SHOIST_FAST` and `DIT_SEAM_FAST` under --fast and `T1_PSIG` and `TRIATT_K1` in both modes on both chips.
    Mol-1 (pair widths 448 and 320) adds `WIDE_NORMAL` to its normal mode, plus `MOL1_BH` on Blackhole and `MOL1_WH` on Wormhole;
    its --fast is that normal set plus `MOL1_BH_FAST` or `MOL1_WH_FAST`."""
    widths = Trunk._pair_widths(state_dict)
    v2 = widths == {256}
    wh = _T.is_wormhole()
    # The levers that need a width their kernels tile, not Protenix-v2 itself, are keyed on the trunk widths they are
    # graded at: Mol-1 (448 and 320) takes WIDE_NORMAL in normal mode, and the trimul set graded on each chip.
    ws = WIDE_NORMAL if widths and widths <= WS_NORMAL_WIDTHS and not v2 else frozenset()
    m1 = (MOL1_WH if wh else MOL1_BH) if ws and 448 in widths else frozenset()
    wh_both = TRIATT_LN | DIT_MM_WH | TRIATT_Q10_WH | X8_WH if v2 and wh else frozenset()
    wh_v2 = WS_FAST | TRIATT_LN_B8_FAST | GIN_W8_FAST | T1W8_FAST | OPM_B8CFG_FAST | WH_PAIR_FAST
    fast = WH_FAST_LEVERS | wh_both | (wh_v2 if v2 else frozenset()) if wh else FAST_LEVERS | (BH_V2_FAST if v2 else frozenset())
    if m1:
        fast = NORMAL_LEVERS | ws | m1 | (MOL1_WH_FAST if wh else MOL1_BH_FAST)
    return _T.model_levers((NORMAL_LEVERS | T2_TAIL | WS_CHAIN | QSPLIT_NORMAL | BRES_NORMAL | TRIATT_LN | WS_RESID_NORMAL | T1_PSIG | TRIATT_K1
                            | (WH_V2_NORMAL | WH_PAIR_NORMAL if wh else BH_V2_NORMAL | BH_PAIR_NORMAL) if v2 else NORMAL_LEVERS | ws)
                           - (BH_NORMAL_DROP if v2 and not wh else frozenset()) | wh_both | m1,
                           fast | SHOIST_FAST | DIT_SEAM_FAST | T1_PSIG | TRIATT_K1 if v2 else fast)


# How many diffusion samples a single batched denoise carries by default. The batched
# denoise holds a (chunk, n_heads, NT, NT) attention score tensor per DiT block, so the
# per-step footprint grows linearly in the chunk -- 80 MB per sample per block at
# NT=1095 in fp32. Defaulting an omitted chunk size to "all n_sample at once" made a
# 50-sample fold of a 1095-token target ask for 4 GB in one allocation. Callers that
# know their headroom can raise it; `tt-bio predict --max_parallel_samples` exposes it.
DEFAULT_MAX_PARALLEL_SAMPLES = 5

# Row-chunk the trunk's MSA representation once it exceeds this many bytes.
#
# Set so that no target is left near the whole path's OOM boundary, because that boundary cannot
# be predicted from this tensor's size. Measured on AbAg-XM:
#     9lwc  0.618 GiB, 285 tokens  -> folds on the whole path
#     9d72  1.783 GiB, 682 tokens  -> refused 1909293056 B on the whole path
# The whole path's peak is driven by PairWeightedAveraging's intermediates, which scale with
# tokens^2; `m_feat` only correlates with that. So a size threshold near the boundary is tuning a
# variable that is not the cause. 0.25 GiB is below the panel's smallest target (0.618 GiB), which
# means every AbAg-XM target chunks and none of them sits near the edge.
#
# Deciding this from *free DRAM at the start of the block* was tried and REVERTED -- see
# _msa_take_whole_path. Chunking m_feat is bit-exact either way (Trunk._msa.update_msa, verified
# by the 9lwc md5 check), so this threshold trades only speed, never numbers.
#
# Cost, measured, and NOT a flat multiplier -- the chunked path's fixed cost scales with the
# target: 9lwc 194 s, 9d72 836 s. 125 of 164 targets already exceeded the old 1.0 GiB gate, and
# the remaining 39 (0.618-0.999 GiB) now chunk too. Chunking all 164 also makes the dataset
# uniform: one code path for every target rather than a mix differing by one bf16 step.
#
# NOTE this threshold does NOT make every target fit. 9lof (2.603 GiB, 754 tokens) chunks and
# still OOMs, in OuterProductMean rather than here -- see OuterProductMean in tenstorrent.py.
#
# A Blackhole part has 32 GiB and has never needed this, but deep-MSA targets there will now
# chunk too. That is numerically inert; it is NOT perf-measured on Blackhole yet.
MSA_ROW_CHUNK_BUDGET_BYTES = 1 << 28      # 0.25 GiB



TOKEN_PAD_MULTIPLE = _bucket_multiple("protenix-v2")
# 32 today, and the comment here said 64 until 2026-09-08. `bucket_multiple` returns
# `BUCKET_EXCEPTIONS.get(model, TOKEN_BUCKET)`, `TOKEN_BUCKET` is 32 and `BUCKET_EXCEPTIONS` is
# empty, so protenix-v2's 64 went away with its exception entry and only this comment still
# claimed it. Worth stating because the wrong width silently rewrites any L1 arithmetic done
# against this axis: the first pass of the OpenDDE ending-transpose census read Nsw off 64 and
# got the wrong buffer.
#
# 32 is the tile, so 32 is all correctness needs, and it is never the wider pad: strictly cheaper
# at N % 64 in 33..63 (N=580 pads to 608 against 640, +9.9 % pair area against +21.8 %) and
# identical everywhere else, 298 and 512 included. The open accuracy question 64 was held for --
# multi-seed evidence at N in 65..96, after one bad 76-residue fold at 32's width (6.6630 A
# against 1.5688 A at 128, one target, one seed, on a metric a diffusion sampler can flip by
# basin) -- is still registered in state/protenix-opendde-token-bucket-flip-measure.md.
#
# VALIDITY RANGE, measured, as GOALS.md SIZE GENERALITY requires of a threshold constant:
#   N % 64 == 0   0 %. Both bucketing sites early-out, the fold is byte-identical.
#   298 aa        +4.82 % protenix-v2, +5.97 % opendde (298 -> 320, +15.3 % pair area).
#   512 aa        noise. opendde -0.101 s over 8 interleaved pairs, protenix-v2 byte-identical.
#   20 aa         -17.9 % throughput on trpcage (20 -> 64, 10.2x pair area on an 810 ms fold).
# perf/tokenbucket/{px,od}298_paired.json, od512_paired.json, perfquiet/readings.tsv. The cost is
# padded pair area at fold sizes and per-call overhead only at smoke sizes, which is why pad
# multiple 32 recovers 2.6 points of 16 at 20 aa and would recover nothing at 298.


def _token_pad_multiple() -> int:
    """The bucket width, overridable for the pad-invariance test.

    A correctly masked bucket must give the same answer at every pad amount, so folding one
    target at two different multiples and comparing is what separates "the mask leaks" from
    "bf16 reassociated over a different contraction length". Same reason
    TT_BIO_MSA_ROW_CHUNK_BUDGET_BYTES is overridable: the override IS the acceptance test.
    """
    v = os.environ.get("TT_BIO_PROTENIX_TOKEN_PAD_MULTIPLE")
    return int(v) if v else TOKEN_PAD_MULTIPLE


def _pad_poison() -> float:
    """Fill value for the padded region's CONTINUOUS features. 0.0 in production.

    The acceptance test for the mask: fold one target twice with different poison and compare the
    trunk's own fingerprints. A correctly masked bucket cannot let the padded region reach a real
    token, so the real region's output has to be bit-identical whatever is in the padding. This is
    the RFD3 p23 method -- same logical input, different padding -- and it is the only way to tell
    a leaking mask from a target whose fold is merely sensitive to the trunk's arithmetic.
    """
    from .token_axis import pad_poison
    v = os.environ.get("TT_BIO_PROTENIX_PAD_POISON")
    return float(v) if v else pad_poison()


def _token_bucket() -> bool:
    """Pad the TRUNK's token axis out to a tile multiple, masked, and slice back on exit.

    On by default. Both the stock and the fused SDPA are MEASURED to read the padded key columns
    at a bias of zero (perf/bucketing_audit/fused_sdpa_ragged_probe.py: relative error 0.914
    ragged against 0.038 aligned), so without this protenix-v2 / opendde / opendde-abag present a
    ragged token axis to the triangle attention on every call at an unaligned N -- 1208 of 1208 at
    N=98. The padding is proven inert rather than assumed so: two poison values give bit-identical
    trunk fingerprints.

    At an N that is already a multiple of TOKEN_PAD_MULTIPLE the pad is 0 and both bucketing sites
    early-out, so this costs exactly nothing there and changes no number. Set the flag to 0 to get
    the ragged path back for an A/B.
    """
    from .token_axis import bucket_enabled
    return bucket_enabled() and env_flag("TT_BIO_PROTENIX_TOKEN_BUCKET", True)


def bucketed_width(N: int, mult: int | None = None) -> int:
    """The width `bucketed_pairformer` will actually run an axis of length `N` at.

    Callers that size something else off the same axis need this rather than their own copy of the
    arithmetic: OpenDDE's refiner prewarms its fused input-weight cache from the width it is about
    to run at, and a prewarm at the unpadded width warms an entry the call then does not use.

    This is the FLAGGED wrapper -- `token_axis.bucketed_width` is the arithmetic.
    """
    from .token_axis import bucketed_width as _w
    return _w(N, mult or _token_pad_multiple()) if _token_bucket() else N


def bucketed_pairformer(pf, s, z, dev, mult: int | None = None, extra_attn_bias=None, keep_padded=False):
    """`token_axis.bucketed_pairformer` under this family's flag and multiple.

    The mechanism lives in token_axis.py next to the census; this is the two lines that decide
    whether protenix-v2 / opendde / opendde-abag use it and how wide.
    """
    from .token_axis import bucketed_pairformer as _bp
    return _bp(pf, s, z, dev, bucketed_width(int(z.shape[1]), mult), extra_attn_bias, keep_padded)


def _msa_take_whole_path(nbytes):
    """Can the full-depth MSA path afford `nbytes`, or must it row-chunk?

    A plain threshold, deliberately, after the alternative was measured and failed.

    Deciding from real free DRAM -- `get_memory_view(...).total_bytes_free_per_bank * num_banks`
    at the top of the block, requiring some multiple of `nbytes` to be free -- looks strictly
    better and is not. The check point and the allocation point are far apart: PWA allocates its
    own projections and per-head weights in between, so free-at-check-time overstates
    free-at-allocation-time by more than the margin. Measured, with a 3x requirement: 9d72's
    1.778 GiB representation saw ~10 GiB free, passed the test, took the whole path, and died on
    the next 1.778 GiB request -- a fold that the fixed 1.0 GiB threshold had been completing in
    882 s. The free-DRAM gate made a working target fail.

    Predicting the peak correctly would mean modelling every intervening allocation, which is a
    model that rots the moment PWA changes. A measured constant does not.

    The env override still wins, because it is the acceptance test for the chunked path: forcing
    the budget to 0 makes a SMALL target chunk so its output can be compared byte-for-byte
    against the same target folded whole. `predict` runs the fold in a spawned worker, so this
    has to be an env var -- a value set on the parent's module object would not reach it.
    """
    v = os.environ.get("TT_BIO_MSA_ROW_CHUNK_BUDGET_BYTES")
    return nbytes <= (int(v) if v else MSA_ROW_CHUNK_BUDGET_BYTES)


_TRUNK_TAP_CALL = 0     # one increment per Trunk._msa call, i.e. per recycling cycle
_HOST_TAP_SEEN = {}     # tag prefix -> how many host taps written, to bound a 200-step sampler


def trunk_tap(tag, t, always=False):
    """Fingerprint a trunk tensor, when TT_BIO_TRUNK_TAP names a file to append to.

    Six probes each proved a component of the chunked MSA path bit-exact while the full fold kept
    diverging, which is the signature of a difference that only exists in the composition. Guessing
    at components cannot find that; comparing the trunk's own intermediates between two runs can.

    Fields are pipe-delimited on purpose. The first version wrote `shape=(1, 8722, 285, 128)` in a
    space-separated line, a reader split on whitespace and indexed a fixed field, and so compared
    shape fragments instead of hashes -- reporting vacuous "identical" for two entire passes. A
    delimiter that cannot occur inside a value removes that failure mode at the source.

    Records a sha256 of the tensor's exact bytes rather than the tensor itself: m_feat is ~0.7 GiB
    for a small target, so dumping it per block per cycle would be hundreds of GB, while a hash
    localises the FIRST differing tensor just as precisely. Costs one device->host transfer per tap,
    so it is gated behind the env var and further limited by TT_BIO_TRUNK_TAP_CYCLES (default 2).

    Enable it in BOTH arms of a comparison: then whatever it perturbs, it perturbs identically, and
    the comparison stays honest (see the observer effect that invalidated an earlier measurement)."""
    path = os.environ.get("TT_BIO_TRUNK_TAP")
    if not path:
        return
    # `always` taps ignore the per-cycle budget: the trunk's exit and the first diffusion steps are
    # a handful of tensors, and they are the ones that say whether a divergence that is absent from
    # cycle 0's MSA blocks has appeared by the time diffusion starts.
    if not always and _TRUNK_TAP_CALL >= int(os.environ.get("TT_BIO_TRUNK_TAP_CYCLES", "2")):
        return
    import hashlib
    # The MSA representation is a LIST of depth chunks on the chunked path. Hash the chunks in
    # order, which gives the same fingerprint the concatenated tensor would.
    parts = t if isinstance(t, list) else [t]
    shape = (f"list[{len(parts)}]{tuple(parts[0].shape)}" if isinstance(t, list)
             else tuple(t.shape))
    # Upcast before hashing: to_torch hands back bfloat16 for a bf16 device tensor and numpy has no
    # bfloat16 dtype, so .numpy() raises. float32 is a lossless widening of bf16, so the hash is
    # still an exact fingerprint of the device bytes.
    _h = hashlib.sha256()
    for _p in parts:
        _h.update(ttnn.to_torch(_p).to(torch.float32).contiguous().numpy().tobytes())
    h = _h.hexdigest()[:16]
    try:
        with open(path, "a") as fp:
            fp.write(f"cycle{_TRUNK_TAP_CALL}|{tag}|{shape}|{h}\n")
    except OSError:
        pass


def trunk_tap_host(tag, t, limit=2):
    """Same fingerprint as trunk_tap, for a HOST torch tensor.

    The EDM sampler keeps its coordinate stream on the host between steps (denoise takes and returns
    host tensors), so the diffusion side cannot be tapped with the device helper. Bounded to the
    first `limit` calls per tag prefix so a 200-step sampler does not write 200 lines."""
    path = os.environ.get("TT_BIO_TRUNK_TAP")
    if not path:
        return
    import hashlib
    n = _HOST_TAP_SEEN.get(tag.split("[")[0], 0)
    if n >= limit:
        return
    _HOST_TAP_SEEN[tag.split("[")[0]] = n + 1
    h = hashlib.sha256(t.detach().to(torch.float32).contiguous().numpy().tobytes()).hexdigest()[:16]
    try:
        with open(path, "a") as fp:
            fp.write(f"host|{tag}|{tuple(t.shape)}|{h}\n")
    except OSError:
        pass


def _msa_row_chunk_size():
    """Chunk width, with a test-only env override (same rationale as the budget above).

    Set it larger than the MSA depth to force the chunked branch to emit exactly ONE chunk.
    That is the bisect that separates "chunking granularity changes the numbers" from "the
    chunk-path plumbing changes the numbers": with one chunk the arithmetic is the whole
    path's, so any remaining difference is the slice/reshape/concat wrapper, not the split."""
    v = os.environ.get("TT_BIO_MSA_ROW_CHUNK_SIZE")
    return int(v) if v else MSA_CHUNK_SIZE

def _window_q(x, N, NP, nq=32):
    """Window the query axis into local blocks: (N,C)|(1,N,C) -> (NP//nq, nq, C), right-padded
    to NP. Shared by the atom-encoder and diffusion atom-cache windowing."""
    x = ttnn.reshape(x, (1, N, x.shape[-1])) if len(x.shape) == 2 else x
    x = ttnn.to_layout(x, ttnn.ROW_MAJOR_LAYOUT)
    x = ttnn.pad(x, [[0, 0], [0, NP - N], [0, 0]], 0.0)
    return ttnn.to_layout(ttnn.reshape(x, (NP // nq, nq, x.shape[-1])), ttnn.TILE_LAYOUT)


_UPLOAD_REFUSED_ROWS = {}  # host m shape -> depth-chunk rows, once DRAM refused its whole upload or the OPM over it
_TEMPLATE_ROWS_REFUSED = {}  # pair shape -> row block the template residual settled at

# AtomTransformer attention over a SUPERSET key window, ON. The key window of query block i is
# atoms [32i - 48, 32i + 80): it does not start on a tile, which is why K and V were windowed by a
# row-major gather (bf16) or a per-sample slice loop (fp32), ~14-18 ms of the 29 ms module at 730
# tokens and 5 samples on a Wormhole chip (state/lpx-sdpa.md, atomwin2). The superset is the five
# whole tiles i-2 .. i+2 (160 keys); its 16 slack keys on each side and every invalid key take a
# -1e9 bias folded once per fold into the per-block pair bias, so they get exactly zero weight and
# the attention is the same function. K and V become five tile-aligned block slices and one concat.
# Not bit-exact: the softmax and attn@v reduce over 160 keys instead of 128.
# `TT_BIO_ATOM_SUPERSET_WINDOW=0` restores the windowed path.
_ATOM_SUPERSET = env_flag("TT_BIO_ATOM_SUPERSET_WINDOW", True)
# The superset path's head split and merge in TILE layout: Q|K|V share one zero-led row frame and
# one nlp_create_qkv_heads splits them, nlp_concat_heads merges the output. Same values in the
# same places as the ROW_MAJOR pad/permute round trips it replaces (perf/spd_attn/atom_steps.py:
# those were ~10 of the 18 ms fp32 module on a Wormhole chip). "0" restores the round trips.
_ATOM_TILE_HEADS = env_flag("TT_BIO_ATOM_TILE_HEADS", True)
# The fp32 superset attention as ONE SDPA program (sdpa_generic with fp32 q, k, v, mask and output,
# spd-diffusion's dit_sdpa32 recipe) in place of matmul + scale_add + softmax + matmul. Closer to a
# float64 reference than the four ops (rel rms 0.0217 vs 0.0265); graded on the 11-set x 4 seeds,
# same-seed top-pose deviation median 0.047 A (WH). Inert in bf16, where atom_sdpa covers the same site.
_ATOM_SDPA32 = env_flag("TT_BIO_ATOM_SDPA32", True)
# Under atom_sdpa or atom_sdpa32 with TILE heads, the reader takes K and V straight from the head frame as
# sliding windows (sdpa_generic `kv_window`) instead of the 5 slices + concat that copy every frame row 5
# times, and Q from its frame rows the same way. Bit-exact: same tiles, same program. In bf16 it is the wheel's own fused SDPA at atom_sdpa's
# config (q 32, k 160, the main grid, `_ATOM_SDPA_CKC`), driven through generic_op.
_ATOM_KV_WINDOW = env_flag("TT_BIO_ATOM_KV_WINDOW", True)
_ATOM_SDPA32_CKC = (ttnn.MathFidelity.HiFi4, False, True, False)   # fidelity, approx exp, fp32 dest, dst full sync
_ATOM_SDPA_CKC = (ttnn.MathFidelity.HiFi2, True, False, False)     # atom_sdpa's `_sdpa_ckc` as that tuple
ATOM_SUPERSET_STATS = [0, 0]  # (attention calls on the superset window, on the windowed path)

_WIN_KV_IDX = {}  # (gen,NP,nq,nk) -> (1, nb*nk) uint32 gather index, device tensor on the
                  # CURRENT mesh. gen = tenstorrent.device_generation(): a model switch closes
                  # the mesh and this module-level dict survives, so entries from an older
                  # generation point at a closed MeshDevice and throw SubDeviceManagerTracker
                  # ("remote-only") on the next fold. Keyed + pruned by generation instead.


def _window_kv(x, N, NP, nq=32, nk=128, pad_left=48):
    """Window the key/value axis into overlapping local blocks: (N,C)|(1,N,C) -> (NP//nq, nk, C)
    with a left pad of (nk-nq)/2. A SINGLE ttnn.embedding gather (window i, key j <- padded row
    i*nq+j). Replaces an nb-element ttnn.slice loop + nb-way ttnn.concat that DEADLOCKS the device
    at large nb (e.g. Wormhole, seq>~64 atoms): nb slices + concat -> ~2*nb dispatched ops that
    never complete. Same gather the AtomTransformer KV-windowing uses; bit-identical semantics."""
    x = ttnn.reshape(x, (1, N, x.shape[-1])) if len(x.shape) == 2 else x
    C = x.shape[-1]; nb = NP // nq; Lp = pad_left + NP + nk
    x = ttnn.to_layout(x, ttnn.ROW_MAJOR_LAYOUT)
    x = ttnn.pad(x, [[0, 0], [pad_left, Lp - pad_left - N], [0, 0]], 0.0)
    if x.dtype == ttnn.float32:
        # embedding only accepts bf16 tables. Build the same overlapping windows from
        # four block-aligned slices so the full-fp32 diffusion path stays on device
        # without quantizing the atom stream back to bf16.
        blocks_per_window = nk // nq
        x = ttnn.slice(x, [0, 0, 0], [1, NP + nk - nq, C])
        x = ttnn.reshape(x, (nb + blocks_per_window - 1, nq, C))
        x = ttnn.concat([
            ttnn.slice(x, [i, 0, 0], [i + nb, nq, C])
            for i in range(blocks_per_window)
        ], dim=1)
        return ttnn.to_layout(x, ttnn.TILE_LAYOUT)
    x = ttnn.reshape(x, (Lp, C))                                   # gather table (Lp, C)
    gen = device_generation()
    if _WIN_KV_IDX and next(iter(_WIN_KV_IDX))[0] != gen:
        _WIN_KV_IDX.clear()
    idx = _WIN_KV_IDX.get((gen, NP, nq, nk))
    if idx is None:
        ii = (torch.arange(nb).reshape(nb, 1) * nq + torch.arange(nk).reshape(1, nk)).reshape(1, nb * nk)
        idx = ttnn.from_torch(ii.to(torch.int32), layout=ttnn.ROW_MAJOR_LAYOUT,
                              device=get_device(), dtype=ttnn.uint32)
        _WIN_KV_IDX[(gen, NP, nq, nk)] = idx
    x = ttnn.embedding(idx, x, layout=ttnn.ROW_MAJOR_LAYOUT, memory_config=ttnn.DRAM_MEMORY_CONFIG)
    x = ttnn.reshape(x, (nb, nk, C))                               # (nb, nk, C)
    return ttnn.to_layout(x, ttnn.TILE_LAYOUT)


# ---------------------------------------------------------------------------
# M-aware (multiplicity-batched) windowing helpers.
# Carries the multiplicity M as a real leading batch dim through the windowed
# attention, mirroring boltz2.AtomDiffusion.sample. Selected by
# DiffusionModule.supports_multiplicity; the M=1 path above is bit-exact and
# untouched. Design proven in pure
# torch by tests/test_windowing_multiplicity.py + tests/test_windowing_m_shapes.py:
# fold M into the windowed-attention block dim B = M*nb via a LEADING-M 3D pad
# (per-sample right-pad on dim 1 of (M,N,C), then reshape to (M*nb, ...)). Sample
# k's nb windows are blocks k*nb..k*nb+nb-1 (no cross-sample bleed). Sample-
# invariant tensors (cond, biases) keep their leading dim of 1 and are BROADCAST
# over M by the consuming add; only the per-atom/per-token single embeddings, which
# AdaLN consumes elementwise, carry a real M dim. Replicating the pair biases
# instead (ttnn.concat of M copies) is numerically identical but costs M times the
# bias in DRAM, which is what made the batched path OOM on large targets.
# ---------------------------------------------------------------------------


def _window_q_m(x, M, N, NP, nq=32):
    """M-aware query windowing: (M,N,C) -> (M*nb, nq, C), per-sample right-pad to NP
    via a leading-M 3D pad on dim 1, then reshape to fold M into the block dim."""
    x = ttnn.to_layout(x, ttnn.ROW_MAJOR_LAYOUT)
    x = ttnn.pad(x, [[0, 0], [0, NP - N], [0, 0]], 0.0)            # (M, NP, C), per-sample
    return ttnn.to_layout(ttnn.reshape(x, (M * (NP // nq), nq, x.shape[-1])), ttnn.TILE_LAYOUT)



def _window_kv_m(x, M, N, NP, nq=32, nk=128, pad_left=48):
    """M-aware KV windowing: (M,N,C) -> (M*nb, nk, C). Loops the verified M=1
    _window_kv gather per sample and concats along dim 0 (correct-by-construction:
    the ttnn.embedding gather's per-row semantics don't extend cleanly to a 3D
    (M,Lp,C) table, so reuse the M=1 gather M times -- the gather is cheap relative
    to attention). Sample k's nb windows land at blocks k*nb..k*nb+nb-1, matching
    _window_q_m's layout (no cross-sample bleed)."""
    cols = [_window_kv(x[k:k + 1], N, NP, nq, nk, pad_left) for k in range(M)]  # each (nb, nk, C)
    return ttnn.to_layout(ttnn.concat(cols, dim=0), ttnn.TILE_LAYOUT)          # (M*nb, nk, C)


# Build the 139-dim relative-position one-hot by scattering into an fp32 result instead of
# materialising int64 one-hots and an int64 cat (`_generate_relp`). Bit-exact; ON by default.
# RELP_STATS is [scatter_calls, legacy_calls] -- a perf arm that flips the flag and serves zero
# calls is an A/A pair mislabelled as an A/B, and only the counter says which happened.
_RELP_SCATTER = True
RELP_STATS = [0, 0]


class _KeyedWeights:
    """Mixin: cached weight-upload-by-key + linear / layernorm by key, reading a flat
    {name: torch.Tensor} dict ``self._w``. Weights upload ONCE (TILE/bf16) and are cached
    in ``self._wc`` -- reused across recycle cycles, sampling steps, and folds (the model
    stays resident). The protenix submodules all share this instead of each re-implementing
    the cache + ttnn.linear/layer_norm wrappers. Requires self._w + self.compute_kernel_config."""

    def _w_tt(self, key, transpose=True):
        cache = self.__dict__.setdefault("_wc", {})
        v = cache.get((key, transpose))
        if v is None:
            w = self._w[key]
            v = ttnn.from_torch(w.t().contiguous() if transpose else w,
                                layout=ttnn.TILE_LAYOUT, device=get_device(),
                                dtype=getattr(self, "dtype", ttnn.bfloat16))
            cache[(key, transpose)] = v
        return v

    def _up(self, t):
        """Upload an activation/host tensor (per call, not cached).

        A float32 tensor bound for bf16 is rounded by torch first: torch and ttnn round the same
        way, so the device tensor is identical, and ttnn tilizes bf16 4x faster than it converts
        and tilizes float32 (0.66 against 2.73 s for the 730-token MSA feature)."""
        return _T.upload(self._host_cast(t), getattr(self, "dtype", ttnn.bfloat16))

    def _host_cast(self, t):
        """The host half of `_up`: the torch rounding to bf16, on its own so the host lane can do it."""
        if getattr(self, "dtype", ttnn.bfloat16) == ttnn.bfloat16 and t.dtype == torch.float32:
            t = t.to(torch.bfloat16)
        return t

    def _opm_from_host(self, opm, t, z, mask=None, n_msa=None):
        """`z + opm(t)` for a host-resident `t` [1, depth, tokens, c]: `t` uploaded whole, or, if
        DRAM refuses that upload or the OPM that reads it, as host-tiled depth chunks that
        OuterProductMean uploads one at a time (its chunk-list input).

        Both refusals are fragmentation, not a full chip. protenix-v2 at 1408 tokens against 8192
        alignment rows was refused the upload itself (2952790016 B, 596 MiB per bank free, 202 MiB
        largest block). At 1280 tokens against 14743 rows the 2.4 GB upload lands and OPM's own
        160 MiB depth slice of it is then refused with 10 MiB largest free block per bank: the
        whole `m` is still on the chip beside OPM's full-depth projections. The chunk list is the
        form every later MSA block already hands OPM, and it is not bit-exact against the
        whole-depth product (it reassociates the depth sum), so it runs only after a refusal. The
        memo skips the refused attempt on later recycling cycles. `mask`/`n_msa` are a sampled
        cycle's row mask and drawn row count, as for a device `m`.

        OPM gives back its own partial buffers before a refusal leaves it, and adds its residual
        out of place until a successful join, so the chunked retry reads the same `z`. A refusal
        that did consume `z` is raised as it is rather than retried on a freed buffer."""
        def whole():
            d = self._up(t)
            try:
                return opm(d, mask, n_msa, residual=z)
            finally:
                ttnn.deallocate(d)

        def chunked(r):
            if not z.is_allocated():
                raise RuntimeError("protenix msa: OPM was refused after it consumed its residual; "
                                   "the depth-chunked retry has no pair to add to")
            return opm([ttnn.from_torch(t[:, s:s + r].contiguous(), layout=ttnn.TILE_LAYOUT,
                                        dtype=getattr(self, "dtype", ttnn.bfloat16))
                        for s in range(0, t.shape[1], r)], mask, n_msa, residual=z)

        return _T.row_block_after_refusal(_UPLOAD_REFUSED_ROWS, tuple(t.shape), whole, chunked,
                                          MSA_CHUNK_SIZE, "protenix msa upload")

    def _lin(self, x, wkey, bkey=None, activation=None):
        # `narrow_proj` is where the template z projection lands, at [1,298,320,256] @ [256,64].
        return ops.linear(x, self._w_tt(wkey),
                          bias=(self._w_tt(bkey, False) if bkey else None),
                          activation=activation,
                          compute_kernel_config=self.compute_kernel_config,
                          dtype=getattr(self, "dtype", ttnn.bfloat16),
                          core_grid=CORE_GRID_MAIN, narrow_proj=True)

    def _ln(self, x, wkey, bkey=None, l1=False):
        """`l1` for a norm whose consumers are narrow projections of the whole tensor: they
        are bound by reading it, so an L1-resident result is the lever.

        A headroom multiple of 1.5 and no per-core reserve, unlike the two pair sites in
        tenstorrent.py, and that is measured rather than inherited
        (perf/protenix_tpl_l1/results.md, tests/test_template_l1_consumer_margin.py). 1.5
        always leaves per_core * (1 - 1/1.5) = 510805 B/bank free whatever the grid or the
        shape; the one consumer inside the window needs 308736 at 506 tokens, the largest
        shape it admits; and the window opens with L1 EMPTY -- a real 496-token fold reads
        the full 1461760 B/bank free at all ten recycling cycles, where the Boltz-2 crash
        needed 247 KB/core of other live buffers on top of the tensor. Passing
        `_PAIR_L1_CONSUMER_RESERVE` here would refuse 464..506 tokens to fix a clash this
        site does not have. 1.5 is a floor, not a ceiling: below 1.2524 the guaranteed free
        drops under that 308736.
        """
        return ops.layer_norm(x, self._w_tt(wkey, False),
                              (self._w_tt(bkey, False) if bkey else None),
                              epsilon=1e-5,
                              compute_kernel_config=self.compute_kernel_config,
                              l1_headroom=1.5 if (l1 and _T._TEMPLATE_L1_NORM) else None)


def n_blocks(state_dict, prefix):
    """1 + max block index under `prefix` + '.blocks.<i>.', or 0 when the stack is absent.

    Block counts come from the weights rather than from a constant. The v2 family ships at
    several depths -- Protenix-v2 and OpenDDE 24 DiT / 3 atom blocks, PXDesign's generator
    16 / 4, the Protenix mini variants 8 / 1 -- and a hardcoded depth silently drops blocks
    (too few) or builds them from empty dicts (too many). `Trunk` already derived its
    pairformer depth this way; this generalises it to the other four stacks.
    """
    pat = re.compile(re.escape(prefix) + r"\.blocks\.(\d+)\.")
    idx = {int(m.group(1)) for k in state_dict if (m := pat.match(k))}
    return 1 + max(idx) if idx else 0


#: Build the atom attention windows in TILE layout, every sample in one pass (`AtomTransformer.
#: _windows_tiled`), instead of a ROW_MAJOR pad/reshape/permute round trip per sample. Pure data
#: movement: the windows, the K transpose and the head merge are the same values in the same places.
#: On by default: the 730-token fold's digests match the round trip on Wormhole, torch.equal on p150a.
ATOM_WINDOWS_TILED = env_flag("TT_BIO_ATOM_WINDOWS_TILED", True)
_HEADS_SPLIT_REFUSED: set = set()


class AtomTransformer(_KeyedWeights, Module):
    """Protenix AtomTransformer = DiffusionTransformer(cross_attention_mode=True),
    3 blocks, local windowed attention (n_queries=32, n_keys=128). Fully on-device.

    Each block: AttentionPairBias(double AdaLN q/kv, windowed attn w/ pair bias +
    mask_trunked validity, per-head linear_g gate + output sigmoid(linear_a_last(s))
    gate) -> residual -> ConditionedTransitionBlock -> residual. Validated vs the
    real v2 golden_qout (PCC>0.9999). Reference: transformer.py AtomTransformer.
    """
    N_HEADS = 4
    HEAD_DIM = 32
    N_QUERIES = 32
    N_KEYS = 128
    PAD_LEFT = 48  # (n_keys - n_queries) // 2

    def __init__(self, n_blocks, state_dict, compute_kernel_config, dtype=ttnn.bfloat16):
        super().__init__(state_dict, compute_kernel_config)
        self.dtype = dtype
        self.n_blocks = n_blocks
        self._w = {k: v for k, v in self.weights.data.items()}
        # OFF: bf16 arrives here too, 2.14x accuracy for 2.46x cost at [33,4,32,128].
        self._softmax_ckc = softmax_ckc("protenix.atom_transformer")
        self._softmax_f64 = host_f64_softmax_site("protenix.atom_transformer")
        self._kv_widx = {}  # cached KV-window gather indices, keyed by NP
        self._zeros = {}    # zero row blocks of the superset frame, keyed by shape and dtype
        self._tile_heads = _ATOM_TILE_HEADS
        # atom_sdpa lever: the bf16 superset attention runs as one fused SDPA (bf16 mask, never bfp8: the
        # -1e9 entries would share a block exponent with the bias and flush it).
        self._sdpa = _T.lever("atom_sdpa") and dtype == ttnn.bfloat16 and _ATOM_SUPERSET
        self._sdpa_ckc = ttnn.WormholeComputeKernelConfig(
            math_fidelity=ttnn.MathFidelity.HiFi2, math_approx_mode=True,
            fp32_dest_acc_en=False, packer_l1_acc=False)
        self._sdpa32 = _ATOM_SDPA32 and dtype == ttnn.float32 and _ATOM_SUPERSET
        self._kvwin = _ATOM_KV_WINDOW
        # atom_k1: the fp32 linears on k1_linear's program (one K tile per dest pass on Wormhole).
        self._k1 = _T.lever("atom_k1") and dtype == ttnn.float32
        # atom_mm16: the fp32 superset attention's linears on bf16 operands with fp32 accumulation. The
        # adaLN outputs, q/k/v, the gate and the swiglu hidden are written bf16; the two output projections,
        # the residual stream and the superset bias stay fp32.
        self._mm16 = _T.lever("atom_mm16") and self._sdpa32 and self._tile_heads

    def _w16(self, key, transpose=True):
        cache = self.__dict__.setdefault("_wc16", {})
        v = cache.get((key, transpose))
        if v is None:
            w = self._w[key]
            v = cache[(key, transpose)] = ttnn.from_torch(w.t().contiguous() if transpose else w,
                                                          layout=ttnn.TILE_LAYOUT, device=get_device(),
                                                          dtype=ttnn.bfloat16)
        return v

    def _lin(self, x, wkey, bkey=None, activation=None, dtype=None):
        """`dtype`: what an `atom_mm16` linear (a bf16 `x`) writes, bf16 unless given."""
        if self._mm16 and x.dtype == ttnn.bfloat16:
            return _T.k1_linear(x, self._w16(wkey), self._w16(bkey, False) if bkey else None,
                                dtype=dtype or ttnn.bfloat16, activation=activation,
                                compute_kernel_config=self.compute_kernel_config)
        w = self._w_tt(wkey)
        # One K tile leaves the program no K blocking to choose: those keep the shared path.
        if not self._k1 or int(w.padded_shape[0]) <= 32:
            return super()._lin(x, wkey, bkey, activation)
        return _T.k1_linear(x, w, self._w_tt(bkey, False) if bkey else None, dtype=self.dtype,
                            activation=activation, compute_kernel_config=self.compute_kernel_config)

    def _lin_g(self, q_norm, apb):
        """The attention gate's linear: no narrow-projection offer and the input's dtype, as before."""
        key = apb + "attention.linear_g.weight"
        if self._k1 or self._mm16:
            return self._lin(q_norm, key)
        return ttnn.linear(q_norm, self._w_tt(key), compute_kernel_config=self.compute_kernel_config,
                           core_grid=CORE_GRID_MAIN)

    def _adaln_mod(self, pre):
        # Cache the AdaLN module per prefix: constructing it re-uploads its 4 weights
        # (ttnn.from_torch) every call, which for the diffusion enc/decoder means thousands
        # of redundant device writes per fold (2 AdaLN x 3 blocks x 200 steps). Building once
        # and replaying is bit-identical and cuts that dispatch (and is a prerequisite for
        # trace capture, which forbids writes). Keyed by prefix.
        from .tenstorrent import AdaLN
        cache = self.__dict__.setdefault("_adaln_cache", {})
        ada = cache.get(pre)
        if ada is None:
            sub = {k[len(pre):]: v for k, v in self._w.items() if k.startswith(pre)}
            ada = AdaLN(False, remap_adaln(sub), self.compute_kernel_config, dtype=self.dtype)
            cache[pre] = ada
        return ada

    def _adaln(self, a, s, pre, s_terms=None, dtype=None):
        return self._adaln_mod(pre)(a, s, s_terms=s_terms, dtype=dtype)

    @staticmethod
    def _prefixes(b):
        P = f"diffusion_transformer.blocks.{b}."
        return P + "attention_pair_bias.", P + "conditioned_transition_block."

    def cond_terms(self, s):
        """Every term of every block that reads only the conditioning `s`: the three AdaLN
        (scale, shift) pairs and the two output gates, pre-sigmoid. In the diffusion
        enc/decoder `s` is the atom conditioning c_la, fixed for the whole fold and shared by
        every sample, yet these were computed for each of the M samples at every step: 8
        projections and 3 layer norms of (M,N,128) per block. Computed once here, at the
        leading dim `s` has, they broadcast over M in the block's binary ops. Same ops on the
        same values, so the result does not change.

        `adaln_mod` on an fp32 stack: the sigmoids run here too, once per fold, so every apply is one
        addcmul (the AdaLN modulation and both gated residuals) instead of a multiply with a fused sigmoid
        and an add. Every shipped --fast set that names adaln_mod runs this stack bf16 (`diffusion_bf16`)."""
        sig = self.dtype == ttnn.float32 and _T.lever("adaln_mod")
        terms = []
        for b in range(self.n_blocks):
            apb, ctb = self._prefixes(b)
            t = {
                "a": self._adaln_mod(apb + "layernorm_a.").s_terms(s),
                "kv": self._adaln_mod(apb + "layernorm_kv.").s_terms(s),
                "ctb": self._adaln_mod(ctb + "adaln.").s_terms(s),
                "gate": self._lin(s, apb + "linear_a_last.weight", apb + "linear_a_last.bias"),
                "cg": self._lin(s, ctb + "linear_s.weight", ctb + "linear_s.bias"),
            }
            if sig:
                for k in ("a", "kv", "ctb"):
                    t[k] = _T._SigTerms((_sigmoid_own(t[k][0]), t[k][1]))
                for k in ("gate", "cg"):
                    t[k] = _Sig((_sigmoid_own(t[k]),))
            terms.append(t)
        return terms

    def _windows_q(self, x, N, NP):
        H, dh = self.N_HEADS, self.HEAD_DIM
        x = ttnn.to_layout(x, ttnn.ROW_MAJOR_LAYOUT)
        x = ttnn.pad(x, [[0, 0], [0, NP - N], [0, 0]], 0.0)
        x = ttnn.reshape(x, (NP // self.N_QUERIES, self.N_QUERIES, H, dh))
        x = ttnn.permute(x, (0, 2, 1, 3))
        return ttnn.to_layout(x, ttnn.TILE_LAYOUT)

    def _kv_window_idx(self, nb, nq, nk, NP):
        """Constant gather indices for the sliding KV windows: window i, key j sources
        padded row i*nq+j. Built once per NP (replaces the per-window slice loop)."""
        idx = self._kv_widx.get(NP)
        if idx is None:
            import torch
            ii = (torch.arange(nb).reshape(nb, 1) * nq + torch.arange(nk).reshape(1, nk)).reshape(1, nb * nk)
            idx = ttnn.from_torch(ii.to(torch.int32), layout=ttnn.ROW_MAJOR_LAYOUT,
                                  device=self.device, dtype=ttnn.uint32)
            self._kv_widx[NP] = idx
        return idx

    def _windows_kv(self, x, N, NP):
        # Sliding KV windows via a SINGLE gather (ttnn.embedding) instead of nb slice ops +
        # concat: window i, key j = padded row i*nq+j (indices precomputed, fixed per NP).
        H, dh, nq, nk = self.N_HEADS, self.HEAD_DIM, self.N_QUERIES, self.N_KEYS
        nb = NP // nq
        x = ttnn.to_layout(x, ttnn.ROW_MAJOR_LAYOUT)
        Lp = self.PAD_LEFT + NP + nk
        x = ttnn.pad(x, [[0, 0], [self.PAD_LEFT, Lp - self.PAD_LEFT - N], [0, 0]], 0.0)
        if x.dtype == ttnn.float32:
            blocks_per_window = nk // nq
            x = ttnn.slice(x, [0, 0, 0], [1, NP + nk - nq, H * dh])
            x = ttnn.reshape(x, (nb + blocks_per_window - 1, nq, H * dh))
            x = ttnn.concat([
                ttnn.slice(x, [i, 0, 0], [i + nb, nq, H * dh])
                for i in range(blocks_per_window)
            ], dim=1)
        else:
            x = ttnn.reshape(x, (Lp, H * dh))                      # gather table (Lp, H*dh)
            idx = self._kv_window_idx(nb, nq, nk, NP)              # (1, nb*nk) uint32
            x = ttnn.embedding(idx, x, layout=ttnn.ROW_MAJOR_LAYOUT, memory_config=ttnn.DRAM_MEMORY_CONFIG)
            x = ttnn.reshape(x, (nb, nk, H, dh))
        x = ttnn.reshape(x, (nb, nk, H, dh))
        x = ttnn.permute(x, (0, 2, 1, 3))
        return ttnn.to_layout(x, ttnn.TILE_LAYOUT)

    def _superset(self):
        """(lead, W): left pad of the superset key axis and its width, both whole tiles."""
        nq = self.N_QUERIES
        lead = -(-self.PAD_LEFT // nq) * nq
        return lead, -(-(lead - self.PAD_LEFT + self.N_KEYS) // nq) * nq

    def _superset_bias(self, z, mask_trunked, nb):
        """Pair bias z (B*nb, H, nq, nk) + window validity (B'*nb, nq, nk, host) -> the superset
        bias (B, H*nb, nq, W), heads-major to match `_attention_superset`'s scores.

        Built on the host from the device z: once per fold, and the key-axis shift by 16 is not a
        tile-aligned pad on the device. Valid entries keep z's exact value. For the fused SDPA the
        bias is pre-divided by the scale, which that kernel applies to the mask too."""
        H, nq, nk = self.N_HEADS, self.N_QUERIES, self.N_KEYS
        lead, W = self._superset()
        sl = lead - self.PAD_LEFT
        zh = ttnn.to_torch(z).float()
        B = zh.shape[0] // nb
        pad = torch.where(mask_trunked.float() < 0.5, -1e9, 0.0).reshape(-1, nb, 1, nq, nk)
        zz = torch.nn.functional.pad((zh.reshape(B, nb, H, nq, nk) + pad).permute(0, 2, 1, 3, 4),
                                     (sl, W - nk - sl), value=-1e9)
        dtype = z.dtype
        if self._sdpa:
            zz, dtype = zz.clamp(min=-1e4) * self.HEAD_DIM ** 0.5, ttnn.bfloat16
        elif self._sdpa32:
            zz = zz.clamp(min=-1e4) * self.HEAD_DIM ** 0.5
        return ttnn.from_torch(zz.reshape(B, H * nb, nq, W).contiguous(), dtype=dtype,
                               layout=ttnn.TILE_LAYOUT, device=self.device)

    def _attention_superset(self, q_norm, kv_norm, apb, N, NP, zs):
        """Windowed attention for (M, N, c) inputs over the superset key window. Q is
        (M, H*nb, nq, dh); K/V are (M, H*nb, W, dh), built from the padded key rows as W/nq
        block-shifted slices of one (M*H, nb + W/nq - 1, nq, dh) tensor."""
        H, dh, nq = self.N_HEADS, self.HEAD_DIM, self.N_QUERIES
        lead, W = self._superset()
        M, nb, S = q_norm.shape[0], NP // nq, W // nq
        nbk = nb + S - 1

        def heads(x, front, rows):                       # (M, N, H*dh) -> (M, H, rows, dh)
            x = ttnn.to_layout(x, ttnn.ROW_MAJOR_LAYOUT)
            x = ttnn.pad(x, [[0, 0], [front, rows - front - N], [0, 0]], 0.0)
            x = ttnn.permute(ttnn.reshape(x, (M, rows, H, dh)), (0, 2, 1, 3))
            return ttnn.to_layout(x, ttnn.TILE_LAYOUT)

        def win(x):                                      # (M*H, nbk, nq, dh) -> (M*H, nb, W, dh)
            return ttnn.concat([ttnn.slice(x, [0, j, 0, 0], [M * H, j + nb, nq, dh]) for j in range(S)], dim=2)

        def windows(x):
            return ttnn.reshape(win(ttnn.reshape(heads(x, lead, nbk * nq), (M * H, nbk, nq, dh))), (M, H * nb, W, dh))

        Q = self._lin(q_norm, apb + "attention.linear_q.weight", apb + "attention.linear_q.bias")
        if self._tile_heads and _T.lever("atom_kvcat"):
            # K and V read the same kv_norm: one linear over their stacked weights writes [K | V].
            kv = apb + "attention.linear_kv.weight"
            if kv not in self._w:
                self._w[kv] = torch.cat([self._w[apb + "attention.linear_k.weight"],
                                         self._w[apb + "attention.linear_v.weight"]], 0)
            KV = (self._lin(kv_norm, kv),)
        else:
            KV = (self._lin(kv_norm, apb + "attention.linear_k.weight"),
                  self._lin(kv_norm, apb + "attention.linear_v.weight"))
        if self._tile_heads:
            # Rows [lead, lead + NP) of the frame are Q's; key window i is frame tile rows i .. i+S-1.
            x = ttnn.pad(ttnn.concat([Q, *KV], dim=-1), [[0, 0], [0, NP - N], [0, 0]], 0.0)
            x = ttnn.concat([self._zero_rows(M, lead, x), x, self._zero_rows(M, nbk * nq - lead - NP, x)], dim=1)
            q, k, v = ttnn.experimental.nlp_create_qkv_heads(
                ttnn.reshape(x, (M, 1, nbk * nq, 3 * H * dh)), num_heads=H, num_kv_heads=H,
                transpose_k_heads=False, memory_config=ttnn.DRAM_MEMORY_CONFIG)    # each (M, H, nbk*nq, dh)
            if (self._sdpa or self._sdpa32) and self._kvwin:
                Qs, Ks, Vs = q, k, v                     # frames, read as windows by the kernel
            else:
                Qs = ttnn.reshape(ttnn.slice(q, [0, 0, lead, 0], [M, H, lead + NP, dh]), (M, H * nb, nq, dh))
                Ks, Vs = (ttnn.reshape(win(ttnn.reshape(t, (M * H, nbk, nq, dh))), (M, H * nb, W, dh)) for t in (k, v))
        else:
            Qs = ttnn.reshape(heads(Q, 0, NP), (M, H * nb, nq, dh))
            Ks, Vs = (windows(t) for t in KV)
        kvw = (nb, W, lead, nq) if self._tile_heads and self._kvwin and (self._sdpa or self._sdpa32) else None
        if self._sdpa and kvw is None:
            o = _T.fused_sdpa(Qs, Ks, Vs, attn_mask=zs, scale=dh ** -0.5,
                              program_config=_T._sdpa_program_config(nq, W),
                              compute_kernel_config=self._sdpa_ckc)
        elif self._sdpa or self._sdpa32:
            from . import sdpa_generic as SG
            kc = W
            if self._sdpa32:
                g = self.device.compute_with_storage_grid_size()
                grid, ckc = (g.x, g.y), _ATOM_SDPA32_CKC
                # Wormhole: a W-key chunk accumulates W/32 PV tiles in the fp32 dest and writes an occasional
                # wrong value (-4.8 for -0.02, perf/spd_wherr/sdpa_probe.py --window); one key tile per chunk does not.
                if self.device.arch() == ttnn.Arch.WORMHOLE_B0:
                    kc = 32
            else:
                grid, ckc = tuple(_T.COMPUTE_GRID_MAIN), _ATOM_SDPA_CKC
            o = ttnn.allocate_tensor_on_device(ttnn.Shape([M, H * nb, nq, dh]), Qs.dtype,
                                               ttnn.TILE_LAYOUT, self.device, ttnn.DRAM_MEMORY_CONFIG)
            SG.sdpa(self.device, Qs, Ks, Vs, zs, o, nq, kc, grid, ckc, dh ** -0.5, kv_window=kvw)
        else:
            sc = batched_matmul(Qs, ttnn.permute(Ks, (0, 1, 3, 2)),
                                compute_kernel_config=self.compute_kernel_config)
            sc = scale_add(sc, dh ** -0.5, zs)           # zs broadcasts over M at a leading 1
            o = batched_matmul(site_softmax(sc, dim=-1, compute_kernel_config=self._softmax_ckc,
                                            host_f64=self._softmax_f64),
                               Vs, compute_kernel_config=self.compute_kernel_config)
        ATOM_SUPERSET_STATS[0] += 1
        if self._tile_heads:
            o = ttnn.experimental.nlp_concat_heads(ttnn.reshape(o, (M, H, NP, dh)), memory_config=ttnn.DRAM_MEMORY_CONFIG)
            return ttnn.slice(ttnn.reshape(o, (M, NP, H * dh)), [0, 0, 0], [M, N, H * dh])
        o = ttnn.permute(ttnn.reshape(o, (M, H, NP, dh)), (0, 2, 1, 3))
        o = ttnn.reshape(o, (M, NP, H * dh))
        o = ttnn.slice(ttnn.to_layout(o, ttnn.ROW_MAJOR_LAYOUT), [0, 0, 0], [M, N, H * dh])
        return ttnn.to_layout(o, ttnn.TILE_LAYOUT)

    def _zero_rows(self, M, rows, like):
        """A cached (M, rows, C) zero tensor of `like`'s dtype and width, TILE layout."""
        key = (M, rows, like.shape[-1], like.dtype)
        z = self._zeros.get(key)
        if z is None:
            z = self._zeros[key] = ttnn.zeros((M, rows, like.shape[-1]), dtype=like.dtype,
                                               layout=ttnn.TILE_LAYOUT, device=self.device)
        return z

    def _pair_bias(self, p, apb):
        """Atom-pair attention bias: LayerNorm(p, weight only) -> linear_nobias_z -> permute
        to (nb,H,nq,nk). Pure function of p; in the diffusion enc/decoder p is constant across
        sampling steps, so this is precomputed once per fold (see _precompute_biases)."""
        z = ttnn.layer_norm(p, weight=self._w_tt(apb + "layernorm_z.weight", False), epsilon=1e-5,
                            compute_kernel_config=self.compute_kernel_config)
        z = self._lin(z, apb + "linear_nobias_z.weight")          # (nb,nq,nk,H)
        return ttnn.permute(z, (0, 3, 1, 2))                       # (nb,H,nq,nk)

    def _attention(self, q_norm, kv_norm, p, apb, N, NP, pad_bias, z_pre=None):
        H, dh = self.N_HEADS, self.HEAD_DIM
        Q = self._lin(q_norm, apb + "attention.linear_q.weight", apb + "attention.linear_q.bias")
        K = self._lin(kv_norm, apb + "attention.linear_k.weight")
        V = self._lin(kv_norm, apb + "attention.linear_v.weight")
        if ATOM_WINDOWS_TILED:
            Qb, KbT, Vb = self._windows_tiled(Q, K, V, 1, N, NP)
        else:
            Qb = self._windows_q(Q, N, NP); Kb = self._windows_kv(K, N, NP); Vb = self._windows_kv(V, N, NP)
            KbT = ttnn.permute(Kb, (0, 1, 3, 2))
        z = z_pre if z_pre is not None else self._pair_bias(p, apb)   # precomputed (fixed p) or inline
        sc = batched_matmul(Qb, KbT, compute_kernel_config=self.compute_kernel_config)
        sc = scale_add(sc, dh ** -0.5, z)
        sc = ttnn.add(sc, pad_bias)
        o = batched_matmul(site_softmax(sc, dim=-1, compute_kernel_config=self._softmax_ckc,
                                        host_f64=self._softmax_f64),
                           Vb, compute_kernel_config=self.compute_kernel_config)
        if ATOM_WINDOWS_TILED:
            return self._merge_heads(o, 0, N, NP)
        o = ttnn.permute(o, (0, 2, 1, 3))
        o = ttnn.reshape(o, (NP, H * dh))
        o = ttnn.slice(ttnn.to_layout(o, ttnn.ROW_MAJOR_LAYOUT), [0, 0], [N, H * dh])
        return ttnn.to_layout(o, ttnn.TILE_LAYOUT)

    def _block(self, a, s, p, b, N, NP, pad_bias, z_pre=None, terms=None):
        apb, ctb = self._prefixes(b)
        t = terms or {}
        q_norm = self._adaln(a, s, apb + "layernorm_a.", t.get("a"))
        kv_norm = self._adaln(q_norm, s, apb + "layernorm_kv.", t.get("kv"))
        o = self._attention(q_norm, kv_norm, p, apb, N, NP, pad_bias, z_pre=z_pre)
        g = self._lin_g(q_norm, apb)
        o = ttnn.multiply(o, g, input_tensor_b_activations=[ttnn.UnaryOpType.SIGMOID])
        attn = self._lin(o, apb + "attention.linear_o.weight")
        gate = t["gate"] if t else self._lin(s, apb + "linear_a_last.weight", apb + "linear_a_last.bias")
        a1 = _gated_residual(a, attn, gate)
        an = self._adaln(a1, s, ctb + "adaln.", t.get("ctb"))
        b1 = self._lin(an, ctb + "linear_nobias_a1.weight", activation="silu")
        b2 = self._lin(an, ctb + "linear_nobias_a2.weight")
        out = self._lin(ttnn.multiply(b1, b2), ctb + "linear_nobias_b.weight")
        cg = t["cg"] if t else self._lin(s, ctb + "linear_s.weight", ctb + "linear_s.bias")
        return _gated_residual(a1, out, cg)

    def _make_pad_bias(self, mask_trunked):
        pad = torch.where(mask_trunked < 0.5, torch.full_like(mask_trunked, -1e9),
                          torch.zeros_like(mask_trunked)).unsqueeze(1)  # (nb,1,nq,nk)
        return ttnn.from_torch(pad, layout=ttnn.TILE_LAYOUT, device=self.device, dtype=self.dtype)

    def precompute_biases(self, p, mask_trunked):
        """Per-block atom-pair bias + the pad bias -- both pure functions of (p, mask_trunked),
        which are FIXED across diffusion sampling steps. Compute once per fold; replay via
        __call__(bias_cache=...) to avoid recomputing them every step (24->1 per fold)."""
        z_pre = [self._pair_bias(p, f"diffusion_transformer.blocks.{b}.attention_pair_bias.")
                 for b in range(self.n_blocks)]
        if _ATOM_SUPERSET:
            # The pad bias is folded into each block's superset bias; merge_conds reads None.
            zs = [self._superset_bias(z, mask_trunked, mask_trunked.shape[0]) for z in z_pre]
            for z in z_pre:
                ttnn.deallocate(z)
            return (zs, None)
        return (z_pre, self._make_pad_bias(mask_trunked))


    def _windows_tiled(self, Q, K, V, M, N, NP):
        """Q windows, transposed K windows and V windows of M samples, in TILE layout throughout.

        Q, K, V are (M, N, H*dh). Window i holds queries [i*nq, (i+1)*nq) and keys
        [i*nq - PAD_LEFT, i*nq - PAD_LEFT + nk), zeros outside the sequence. nq is one tile row, so
        once K|V are shifted by PAD_LEFT (the only step that is not tile aligned) every window is
        nk/nq consecutive tile rows: nk/nq slices and one concat build all of them. The head split
        and the K transpose are one `nlp_create_qkv_heads`. Returns q (M*nb, H, nq, dh),
        kT (M*nb, H, dh, nk), v (M*nb, H, nk, dh), what `_windows_q_m` / `_windows_kv_m` give.
        """
        H, dh, nq, nk = self.N_HEADS, self.HEAD_DIM, self.N_QUERIES, self.N_KEYS
        nb, C, r = NP // nq, H * dh, nk // nq
        rm = lambda x: ttnn.to_layout(x, ttnn.ROW_MAJOR_LAYOUT)
        tile = lambda x: ttnn.to_layout(x, ttnn.TILE_LAYOUT)
        q = tile(ttnn.pad(rm(Q), [[0, 0], [0, NP - N], [0, 0]], 0.0))                  # (M, NP, C)
        q = ttnn.reshape(q, (M * nb, 1, nq, C))
        kv = ttnn.concat([K, V], dim=-1)                                                # (M, N, 2C)
        kv = tile(ttnn.pad(rm(kv), [[0, 0], [self.PAD_LEFT, NP + nk - nq - self.PAD_LEFT - N], [0, 0]], 0.0))
        kv = ttnn.reshape(kv, (M, nb + r - 1, nq, 2 * C))
        kv = ttnn.concat([ttnn.slice(kv, [0, j, 0, 0], [M, j + nb, nq, 2 * C]) for j in range(r)], dim=2)
        kv = ttnn.reshape(kv, (M * nb, 1, nk, 2 * C))
        key = (tuple(q.padded_shape), str(q.dtype))
        if key not in _HEADS_SPLIT_REFUSED:
            try:
                return ttnn.experimental.nlp_create_qkv_heads(
                    q, kv, num_heads=H, num_kv_heads=H, transpose_k_heads=True,
                    memory_config=ttnn.DRAM_MEMORY_CONFIG)
            except RuntimeError as e:                                                   # e.g. a dtype it does not take
                _HEADS_SPLIT_REFUSED.add(key)
                print(f"[tt-bio] nlp_create_qkv_heads refused atom windows {key}: {e}; splitting heads "
                      f"by slices", file=sys.stderr, flush=True)
        B = M * nb
        heads = lambda x, c0, n: ttnn.concat(
            [ttnn.slice(x, [0, 0, 0, c0 + h * dh], [B, 1, n, c0 + (h + 1) * dh]) for h in range(H)], dim=1)
        return heads(q, 0, nq), ttnn.transpose(heads(kv, 0, nk), -2, -1), heads(kv, C, nk)

    def _merge_heads(self, o, M, N, NP):
        """(M*nb, H, nq, dh) attention output -> (M, N, H*dh), or (N, H*dh) at M == 0."""
        C = self.N_HEADS * self.HEAD_DIM
        o = ttnn.experimental.nlp_concat_heads(o, memory_config=ttnn.DRAM_MEMORY_CONFIG)  # (M*nb, 1, nq, C)
        if M == 0:
            o = ttnn.reshape(o, (NP, C))
            o = ttnn.slice(ttnn.to_layout(o, ttnn.ROW_MAJOR_LAYOUT), [0, 0], [N, C])
        else:
            o = ttnn.reshape(o, (M, NP, C))
            o = ttnn.slice(ttnn.to_layout(o, ttnn.ROW_MAJOR_LAYOUT), [0, 0, 0], [M, N, C])
        return ttnn.to_layout(o, ttnn.TILE_LAYOUT)

    # --- M-aware (multiplicity-batched) path --------------------------------------
    # Mirrors the M=1 _block/_attention but carries M as the leading batch dim. The
    # sample-invariant s (c_la) is replicated (AdaLN needs it elementwise); the
    # precomputed pair bias is NOT -- it stays (nb,H,nq,nk) and is broadcast over M in
    # _attention_m. Q windowing is batched (leading-M 3D pad -> (M*nb,...)); KV windowing loops
    # the verified M=1 gather per sample and concats (correct-by-construction). The
    # attention output recovers per-sample atoms via reshape (M,NP,...) -> slice dim 1 :N.
    # See module-level _window_q_m / _window_kv_m docstrings for the no-bleed proof.

    def _windows_q_m(self, x, M, N, NP):
        H, dh = self.N_HEADS, self.HEAD_DIM
        x = ttnn.to_layout(x, ttnn.ROW_MAJOR_LAYOUT)
        x = ttnn.pad(x, [[0, 0], [0, NP - N], [0, 0]], 0.0)            # (M, NP, H*dh)
        x = ttnn.reshape(x, (M * (NP // self.N_QUERIES), self.N_QUERIES, H, dh))
        x = ttnn.permute(x, (0, 2, 1, 3))                              # (M*nb, H, nq, dh)
        return ttnn.to_layout(x, ttnn.TILE_LAYOUT)

    def _windows_kv_m(self, x, M, N, NP):
        # Loop the verified M=1 _windows_kv gather per sample; concat along dim 0.
        cols = [self._windows_kv(x[k:k + 1], N, NP) for k in range(M)]  # each (nb, H, nk, dh)
        return ttnn.to_layout(ttnn.concat(cols, dim=0), ttnn.TILE_LAYOUT)      # (M*nb, H, nk, dh)

    def _attention_m(self, q_norm, kv_norm, p, apb, N, NP, M, pad_bias, z_pre=None):
        H, dh = self.N_HEADS, self.HEAD_DIM
        Q = self._lin(q_norm, apb + "attention.linear_q.weight", apb + "attention.linear_q.bias")
        K = self._lin(kv_norm, apb + "attention.linear_k.weight")
        V = self._lin(kv_norm, apb + "attention.linear_v.weight")
        if ATOM_WINDOWS_TILED:
            Qb, KbT, Vb = self._windows_tiled(Q, K, V, M, N, NP)
        else:
            Qb = self._windows_q_m(Q, M, N, NP); Kb = self._windows_kv_m(K, M, N, NP); Vb = self._windows_kv_m(V, M, N, NP)
            KbT = ttnn.permute(Kb, (0, 1, 3, 2))
        z = z_pre if z_pre is not None else self._pair_bias(p, apb)
        sc = batched_matmul(Qb, KbT, compute_kernel_config=self.compute_kernel_config)
        if z.shape[0] != sc.shape[0]:
            # z is the sample-INVARIANT precomputed bias, still (nb,H,nq,nk). Fold the
            # (M*nb, H) leading dims into (M, nb*H) so the add broadcasts it over M --
            # the last two dims are untouched, so both reshapes are free in tile layout.
            # Replicating z instead cost M copies of the whole per-block bias in DRAM.
            nb, g = sc.shape[0] // M, sc.shape[1] * (sc.shape[0] // M)
            sc = ttnn.reshape(scale_add(ttnn.reshape(sc, (M, g, sc.shape[2], sc.shape[3])),
                                        dh ** -0.5,
                                        ttnn.reshape(z, (1, g, z.shape[2], z.shape[3]))),
                              (M * nb, H, sc.shape[2], sc.shape[3]))
        else:
            sc = scale_add(sc, dh ** -0.5, z)
        sc = ttnn.add(sc, pad_bias)
        o = batched_matmul(site_softmax(sc, dim=-1, compute_kernel_config=self._softmax_ckc,
                                        host_f64=self._softmax_f64),
                           Vb, compute_kernel_config=self.compute_kernel_config)
        if ATOM_WINDOWS_TILED:
            return self._merge_heads(o, M, N, NP)
        o = ttnn.permute(o, (0, 2, 1, 3))                       # (M*nb, nq, H, dh)
        o = ttnn.reshape(o, (M, NP, H * dh))                    # (M, NP, H*dh)
        o = ttnn.slice(ttnn.to_layout(o, ttnn.ROW_MAJOR_LAYOUT), [0, 0, 0], [M, N, H * dh])  # (M, N, H*dh)
        return ttnn.to_layout(o, ttnn.TILE_LAYOUT)

    def _block_m(self, a, s, p, b, N, NP, M, pad_bias, z_pre=None, terms=None, zs=None):
        apb, ctb = self._prefixes(b)
        t = terms or {}
        # atom_mm16: the kv adaLN reads the fp32 q_norm and writes bf16; q/g read one bf16 copy of it.
        lo = ttnn.bfloat16 if self._mm16 and zs is not None else None
        q_norm = self._adaln(a, s, apb + "layernorm_a.", t.get("a"))
        kv_norm = self._adaln(q_norm, s, apb + "layernorm_kv.", t.get("kv"), dtype=lo)
        if lo is not None:
            q_norm = ttnn.typecast(q_norm, lo)
        if zs is not None:
            o = self._attention_superset(q_norm, kv_norm, apb, N, NP, zs)
        else:
            o = self._attention_m(q_norm, kv_norm, p, apb, N, NP, M, pad_bias, z_pre=z_pre)
        g = self._lin_g(q_norm, apb)
        o = ttnn.multiply(o, g, input_tensor_b_activations=[ttnn.UnaryOpType.SIGMOID])
        attn = self._lin(o, apb + "attention.linear_o.weight", dtype=self.dtype)
        gate = t["gate"] if t else self._lin(s, apb + "linear_a_last.weight", apb + "linear_a_last.bias")
        a1 = _gated_residual(a, attn, gate)
        an = self._adaln(a1, s, ctb + "adaln.", t.get("ctb"), dtype=lo)
        b1 = self._lin(an, ctb + "linear_nobias_a1.weight", activation="silu")
        b2 = self._lin(an, ctb + "linear_nobias_a2.weight")
        out = self._lin(ttnn.multiply(b1, b2), ctb + "linear_nobias_b.weight", dtype=self.dtype)
        cg = t["cg"] if t else self._lin(s, ctb + "linear_s.weight", ctb + "linear_s.bias")
        return _gated_residual(a1, out, cg)

    def __call__(self, a, s, p, mask_trunked, bias_cache=None, multiplicity=1, terms=None):
        """a,s: (1,N,c_atom) at M=1, (M,N,c_atom) at M>1; p: (nb,nq,nk,c_atompair) shared;
        mask_trunked: (nb,nq,nk) host. bias_cache = optional (per-block z_pre, pad_bias)
        from precompute_biases() (shared across samples). terms = optional cond_terms(s), the
        per-block terms that read only `s`; when given, `s` itself is not read. multiplicity
        (M): when >1 and supports_multiplicity is on, run the M-aware batched path (one
        batched forward per block); else the M=1 per-sample path. Returns (1,N,c_atom) at
        M=1, (M,N,c_atom) at M>1."""
        tb = (lambda b: terms[b]) if terms is not None else (lambda b: None)
        N = a.shape[1] if multiplicity == 1 else a.shape[1]
        NP = ((N + self.N_QUERIES - 1) // self.N_QUERIES) * self.N_QUERIES
        if _ATOM_SUPERSET:
            # One path for every M: the superset bias is (1 or M, H*nb, nq, W) and broadcasts
            # over the samples in the score add, and only s needs a real M dim (AdaLN).
            s_m = s if (terms is not None or s.shape[0] == multiplicity) else ttnn.to_layout(
                ttnn.concat([s] * multiplicity, dim=0), ttnn.TILE_LAYOUT)
            x = a
            for b in range(self.n_blocks):
                zs = bias_cache[0][b] if bias_cache is not None else self._superset_bias(
                    self._pair_bias(p, f"diffusion_transformer.blocks.{b}.attention_pair_bias."),
                    mask_trunked, NP // self.N_QUERIES)
                x = self._block_m(x, s_m, None, b, N, NP, multiplicity, None, terms=tb(b), zs=zs)
            return x
        ATOM_SUPERSET_STATS[1] += self.n_blocks
        if multiplicity == 1:
            z_pre, pad_bias = bias_cache if bias_cache is not None else (None, self._make_pad_bias(mask_trunked))
            x = a
            for b in range(self.n_blocks):
                x = self._block(x, s, p, b, N, NP, pad_bias, z_pre=(z_pre[b] if z_pre is not None else None),
                                terms=tb(b))
            return x
        # M-aware. Only the per-atom single s needs a real M dim (AdaLN is elementwise);
        # the pair bias z_pre is broadcast over M in _attention_m rather than replicated,
        # and p is read ONLY when there is no precomputed z_pre, so replicate it lazily.
        z_pre, pad_bias = bias_cache if bias_cache is not None else (None, self._make_pad_bias(mask_trunked))
        # Sample batching (one target, M samples) hands in a shared s/p/bias with a leading
        # dim of 1 and they are replicated here. Prediction batching (M different targets,
        # protenix._merge_conds) hands in tensors that already carry the M members, so pass
        # those straight through -- same shapes, no copy.
        nb_ = NP // self.N_QUERIES
        s_m = s if (terms is not None or s.shape[0] == multiplicity) else ttnn.to_layout(
            ttnn.concat([s] * multiplicity, dim=0), ttnn.TILE_LAYOUT)                         # (M,N,c_atom)
        p_m = p if (z_pre is not None or p.shape[0] == multiplicity * nb_) else ttnn.to_layout(
            ttnn.concat([p] * multiplicity, dim=0), ttnn.TILE_LAYOUT)                         # (M*nb,nq,nk,c_ap)
        # pad_bias is (nb,1,nq,nk) -- H-broadcast, so ~H times smaller than z_pre; keep the
        # replication here so the (sc + z) + pad add order matches the M=1 path exactly.
        if pad_bias.shape[0] != multiplicity * nb_:
            pad_bias = ttnn.to_layout(ttnn.concat([pad_bias] * multiplicity, dim=0), ttnn.TILE_LAYOUT)
        x = a
        for b in range(self.n_blocks):
            x = self._block_m(x, s_m, p_m, b, N, NP, multiplicity, pad_bias,
                                z_pre=(z_pre[b] if z_pre is not None else None), terms=tb(b))
        return x


class AtomFeaturization(Module):
    """Protenix AtomAttentionEncoder.prepare_cache (has_coords=False path).

    Builds the per-atom single embedding c_l and the windowed atom-pair embedding
    p_lm from reference features. Pure linears + arcsinh + elementwise — no
    attention. Reference: protenix/model/modules/transformer.py prepare_cache.

      c_l = W_pos(ref_pos) + W_charge(arcsinh(ref_charge)) + W_f([mask|elem|name])
      c_l *= ref_mask
      p_lm = W_d(d_lm)*v_lm*mask_trunked + W_invd(1/(1+sum d_lm^2))*v_lm + W_v(v_lm)
    """

    def __init__(self, state_dict, compute_kernel_config, dtype=ttnn.bfloat16):
        super().__init__(state_dict, compute_kernel_config)
        self.dtype = dtype
        # nn.Linear weights are (out, in); _lin/ttnn.linear want (in, out).
        self.w_ref_pos = self.torch_to_tt("linear_no_bias_ref_pos.weight", dtype=dtype)
        self.w_ref_charge = self.torch_to_tt("linear_no_bias_ref_charge.weight", dtype=dtype)
        self.w_f = self.torch_to_tt("linear_no_bias_f.weight", dtype=dtype)
        self.w_d = self.torch_to_tt("linear_no_bias_d.weight", dtype=dtype)
        self.w_invd = self.torch_to_tt("linear_no_bias_invd.weight", dtype=dtype)
        self.w_v = self.torch_to_tt("linear_no_bias_v.weight", dtype=dtype)

    def _lin_nb(self, x, w):
        return ops.linear(x, w, compute_kernel_config=self.compute_kernel_config,
                          dtype=self.dtype, core_grid=CORE_GRID_MAIN)

    def c_l(self, ref_pos, ref_charge_asinh, ref_mask, f_in):
        """All inputs are device tensors. ref_charge_asinh is arcsinh(charge)[...,1],
        ref_mask is [...,1], f_in is cat([mask|element|name_chars]) -> [...,449]."""
        c = ttnn.add(self._lin_nb(ref_pos, self.w_ref_pos),
                     self._lin_nb(ref_charge_asinh, self.w_ref_charge))
        c = ttnn.add(c, self._lin_nb(f_in, self.w_f))
        return ttnn.mul(c, ref_mask)

    def p_lm(self, d_lm, v_lm, invd, mask_trunked):
        """Windowed atom-pair embedding. d_lm/v_lm/invd/mask_trunked are flattened
        to [n_blocks*n_queries*n_keys, *] device tensors (last-dim linears)."""
        p = ttnn.mul(ttnn.mul(self._lin_nb(d_lm, self.w_d), v_lm), mask_trunked)
        p = ttnn.add(p, ttnn.mul(self._lin_nb(invd, self.w_invd), v_lm))
        p = ttnn.add(p, self._lin_nb(v_lm, self.w_v))
        return p


class AtomAttentionEncoder(_KeyedWeights, Module):
    """Protenix InputFeatureEmbedder atom encoder (has_coords=False) -> s_inputs.

    featurization (AtomFeaturization) -> p_lm augmentation (windowed c_l projections
    + small_mlp) -> AtomTransformer -> relu(linear_q) + mean atom->token aggregate
    -> a; then s_inputs = cat([a, restype, profile, deletion_mean]) (c_s_inputs=449).
    Validated vs the real v2 golden s_inputs. Reference: transformer.py
    AtomAttentionEncoder.forward + embedders.py InputFeatureEmbedder.forward.
    """
    NQ, NK, PAD_LEFT, C_ATOMPAIR = 32, 128, 48, 16

    def __init__(self, state_dict, compute_kernel_config):
        super().__init__(state_dict, compute_kernel_config)
        self.feat = AtomFeaturization(self.weights, compute_kernel_config)
        self.atx = AtomTransformer(3, self.scope("atom_transformer"), compute_kernel_config)
        self._w = {k: v for k, v in self.weights.data.items()}

    def _win_q(self, x, N, NP):
        return _window_q(x, N, NP, self.NQ)

    def _win_kv(self, x, N, NP):
        return _window_kv(x, N, NP, self.NQ, self.NK, self.PAD_LEFT)

    def _augment_plm(self, p, c_l, N, NP):
        # p: (nb,nq,nk,16); add windowed c_l projections + small_mlp. c_l: (1,N,128).
        clq = ttnn.relu(self._win_q(c_l, N, NP))            # (nb,nq,128)
        clk = ttnn.relu(self._win_kv(c_l, N, NP))           # (nb,nk,128)
        cl = ttnn.unsqueeze(self._lin(clq, "linear_no_bias_cl.weight"), 2)   # (nb,nq,1,16)
        cm = ttnn.unsqueeze(self._lin(clk, "linear_no_bias_cm.weight"), 1)   # (nb,1,nk,16)
        p = ttnn.add(ttnn.add(p, cl), cm)
        m = self._lin(ttnn.relu(p), "small_mlp.1.weight")
        m = self._lin(ttnn.relu(m), "small_mlp.3.weight")
        m = self._lin(ttnn.relu(m), "small_mlp.5.weight")
        return ttnn.add(p, m)

    def __call__(self, ref_pos, ref_charge_asinh, ref_mask, f_in, d_lm, v_lm, invd,
                 mask_trunked, atom_to_token_mean, *token_feats):
        """All tensors on device except mask_trunked (host, for the attn pad bias) and
        atom_to_token_mean ((N_token,N) host averaging matrix). p_lm built in windowed
        flat form then reshaped to (nb,nq,nk,16).

        `token_feats` are the per-token channels concatenated onto the pooled atom
        embedding. Protenix-v2 and OpenDDE pass (restype, profile, deletion_mean) for
        c_s_inputs=449; PXDesign's InputFeatureEmbedderDesign passes a different set and
        then projects (tt_bio.pxdesign.model). Only the concat differs, so only the concat
        is parameterised."""
        N = ref_pos.shape[1] if len(ref_pos.shape) == 3 else ref_pos.shape[0]
        NP = ((N + self.NQ - 1) // self.NQ) * self.NQ
        nb = NP // self.NQ
        c_l = self.feat.c_l(ref_pos, ref_charge_asinh, ref_mask, f_in)        # (1,N,128) or (N,128)
        if len(c_l.shape) == 2:
            c_l = ttnn.reshape(c_l, (1, c_l.shape[0], c_l.shape[1]))
        mt_dev = ttnn.from_torch(mask_trunked.reshape(-1, 1), layout=ttnn.TILE_LAYOUT,
                                 device=self.device, dtype=ttnn.bfloat16)
        p_flat = self.feat.p_lm(d_lm, v_lm, invd, mt_dev)                    # (nb*nq*nk,16)
        p = ttnn.reshape(p_flat, (nb, self.NQ, self.NK, self.C_ATOMPAIR))
        p = self._augment_plm(p, c_l, N, NP)
        q_out = self.atx(c_l, c_l, p, mask_trunked.reshape(nb, self.NQ, self.NK))  # (1,N,128)
        q = ttnn.relu(self._lin(q_out, "linear_no_bias_q.weight"))           # (1,N,384)
        q = ttnn.reshape(q, (N, q.shape[-1]))
        a = ttnn.matmul(atom_to_token_mean, q, compute_kernel_config=self.compute_kernel_config,
                        core_grid=CORE_GRID_MAIN)                            # (N_token,384)
        return ttnn.concat([a, *token_feats], dim=-1)                        # (N_token,449) for v2


class DiffusionModule(_KeyedWeights):
    """Protenix-v2 diffusion denoiser (one EDM-preconditioned step).

    denoise(x_noisy, t_hat, cond) -> denoised coords, where cond holds the fixed
    trunk conditioning (s_trunk, s_inputs, pair_z, c_l, p_lm, atom->token matrix S,
    mask_trunked). Composition (validated end-to-end vs the real v2 reference across
    the full sigma schedule, PCC 0.99961..1.0; scripts/protenix_traj_replay.py,
    tests/test_protenix_traj.py):

      single cond  : LN(cat[s_trunk,s_inputs])->W_s + LN(fourier(log(t/sd)/4))->W_n,
                     + transition_s1 + transition_s2  -> s_single
      atom encoder : c_la = c_l + S @ W_s(LN(s_trunk)); q = c_la + W_r(x/sqrt(sd^2+t^2));
                     p = p_lm + windowed(W_cl(relu c_la)) + windowed(W_cm(...)) + small_mlp;
                     AtomTransformer; a_tok = meanpool_atom->token(relu W_q(q_out))
      a_tok += W_s(LN(s_single))   [diffusion_module.linear_no_bias_s]
      token DiT    : 24-block AttentionPairBias(token-level, per-block pair bias from
                     LN(pair_z)) + s-gate sigmoid(linear_a_last(s)) + ConditionedTransition
      a = LN(a)    [diffusion_module.layernorm_a]
      atom decoder : q = S @ W_a(a) + q_skip; AtomTransformer; r = W_out(LN(q))
      EDM precond  : denoised = x/(1+sr^2) + t/sqrt(1+sr^2)*r,  sr = t/sigma_data(16)

    The 24-block token DiT runs ON-DEVICE (device_dit=True): each block's pair bias is
    a pure function of the trunk pair_z, so the 24 biases are precomputed once per fold
    (_dit_block_biases) and replayed every sampling step (AttentionPairBias bias_precomputed)
    rather than recomputed; the atom-encoder conditioning and atom-transformer pair/pad
    biases are likewise hoisted once per fold. A host fp32 DiT fallback is kept (device_dit
    =False) for the strict per-step parity test, which builds no precomputed device bias.
    Everything runs on-device (ttnn, HiFi4). The coordinate-sensitive diffusion uses fp32
    by default to match the reference boundary across the conditioning cache, atom encoder and
    transformers, token DiT, and atom decoder. Set PROTENIX_DIFFUSION_FP32_DEVICE=0 to A/B bf16.
    The --fast mode still applies only to the trunk (see Protenix.__init__)."""

    SIGMA_DATA = 16.0
    NQ, NK, PAD_LEFT = 32, 128, 48
    # DIT_BLOCKS is Protenix-v2's / OpenDDE's depth and stays here as the documented default;
    # the depth actually used is read off the checkpoint in __init__ (PXDesign-d 16, Protenix
    # mini 8). head_dim 48 x 16 heads = c_token 768 in every family member measured, so those
    # two are genuinely constant.
    DIT_BLOCKS, DIT_HEAD_DIM, DIT_N_HEADS = 24, 48, 16
    supports_multiplicity = True   # ON: verified on qb2 card0

    def __init__(self, diffusion_state_dict, device, compute_kernel_config, diffusion_fp32=None):
        """diffusion_state_dict: {key: tensor} for diffusion_module.* (prefix stripped).
        diffusion_fp32: explicit override; None falls back to PROTENIX_DIFFUSION_FP32_DEVICE."""
        import torch.nn.functional as F  # noqa: F401  (used in DiT)
        self._w = dict(diffusion_state_dict)
        self.dev = device
        self.compute_kernel_config = compute_kernel_config
        self._diffusion_fp32 = (env_flag("PROTENIX_DIFFUSION_FP32_DEVICE", True)
                                 if diffusion_fp32 is None else diffusion_fp32)
        self.dtype = ttnn.float32 if self._diffusion_fp32 else ttnn.bfloat16
        # Depths from the weights. For protenix-v2 and OpenDDE these resolve to the class
        # defaults (24/3/3), so this is a no-op for both shipped models.
        self.DIT_BLOCKS = n_blocks(self._w, "diffusion_transformer") or self.DIT_BLOCKS
        nbE = n_blocks(self._w, "atom_attention_encoder.atom_transformer.diffusion_transformer") or 3
        nbD = n_blocks(self._w, "atom_attention_decoder.atom_transformer.diffusion_transformer") or 3
        self.atxE = AtomTransformer(nbE, {k[len("atom_attention_encoder.atom_transformer."):]: v
                                        for k, v in self._w.items()
                                        if k.startswith("atom_attention_encoder.atom_transformer.")},
                                    compute_kernel_config, dtype=self.dtype)
        self.atxD = AtomTransformer(nbD, {k[len("atom_attention_decoder.atom_transformer."):]: v
                                        for k, v in self._w.items()
                                        if k.startswith("atom_attention_decoder.atom_transformer.")},
                                    compute_kernel_config, dtype=self.dtype)
        self._wc = {}  # device-weight cache (upload once; reused across all sampling steps)
        from .tenstorrent import AdaLN, AttentionPairBias, Transition
        C = "diffusion_conditioning."
        self._cond_transitions = [
            Transition(PW.remap_transition({k[len(C + nm + "."):]: v for k, v in self._w.items()
                                                if k.startswith(C + nm + ".")}), compute_kernel_config,
                       dtype=self.dtype)
            for nm in ("transition_s1", "transition_s2")]
        # On-device token DiT: per-block AdaLN + AttentionPairBias (compute_pair_bias=False,
        # fed the precomputed UNSCALED bias as the SDPA mask -> matches the host math exactly;
        # these primitives handle the head_dim=48 tile padding). s-gate + conditioned-transition
        # are raw ttnn (protenix's ctb differs from tt-bio's ConditionedTransitionBlock).
        # Full on-device fp32 diffusion. The GPU reference disables autocast for the
        # entire sampling score model, while its trunk remains under bf16 autocast. Match that
        # exact boundary: the conditioning cache, atom encoder/transformer, token DiT, and atom
        # decoder all use ttnn float32. This stays on the device and keeps the existing traced
        # device_dit path. The paired HSA accuracy and performance gates passed; bf16 remains
        # available as an explicit A/B opt-out through PROTENIX_DIFFUSION_FP32_DEVICE=0.
        self._dit_fp32 = self._diffusion_fp32
        self._dit_dtype = ttnn.bfloat16 if _T.lever("dit_bf16") else self.dtype
        self._dit_ckc = compute_kernel_config   # HiFi4 + fp32_dest_acc_en: dtype is on the tensors
        self.device_dit = True
        DT = "diffusion_transformer."
        sub = lambda pfx: {k[len(pfx):]: v for k, v in self._w.items() if k.startswith(pfx)}
        # dit_sdpa32: the fp32 DiT's attention as one SDPA program on a token axis padded by
        # sdpa32_rows; _token_dit_device pads and slices, finish_bias builds the padded mask.
        self._dit_sdpa32 = _T.lever("dit_sdpa32") and self._dit_dtype == ttnn.float32
        # dit_mm16 (fp32 DiT) / dit_b8 (bf16 DiT): the DiT's linears at lower operand formats.
        self._dit_lp = _T.dit_lowp(self._dit_dtype, self._dit_ckc)
        self._dit = []
        for b in range(self.DIT_BLOCKS):
            A = DT + f"blocks.{b}.attention_pair_bias."
            Cc = DT + f"blocks.{b}.conditioned_transition_block."
            self._dit.append((
                AdaLN(False, remap_adaln(sub(A + "layernorm_a.")), self._dit_ckc, dtype=self._dit_dtype),
                AttentionPairBias(self.DIT_HEAD_DIM, self.DIT_N_HEADS, True, False,
                                  PW.remap_attention_pair_bias(sub(A)), self._dit_ckc,
                                  dtype=self._dit_dtype, fp32_raw_matmul_attention=True,
                                  softmax_site="protenix.token_dit"),
                AdaLN(False, remap_adaln(sub(Cc + "adaln.")), self._dit_ckc, dtype=self._dit_dtype),
                A, Cc))
            # dit_sdpa: the bf16 DiT's attention takes the fused SDPA (the token-DiT branch)
            # rather than the explicit matmul/softmax/matmul chain.
            self._dit[-1][1].token_dit = _T.lever("dit_sdpa") and self._dit_dtype == ttnn.bfloat16
            self._dit[-1][1].sdpa32 = self._dit_sdpa32
            if self._dit_lp is not None:
                self._dit[-1][1].enable_lowp(self._dit_lp)
        # dit_bpad: the bf16 fused-SDPA DiT runs its whole token axis at `dit_bias_pad_len` (rows are
        # independent everywhere but the attention, whose staged bias masks the new keys).
        self._dit_bpad = (_T.lever("dit_bpad") and not self._dit_sdpa32
                          and all(apb.token_dit for (_, apb, _, _, _) in self._dit))


    def _up_dit(self, t):
        """Upload an activation/host tensor at the DiT dtype (fp32 when the gate is on)."""
        return _T.upload(t, self._dit_dtype)

    def _w_tt_dit(self, key, transpose=True, dtype=None):
        """Dedicated DiT weight-upload cache at the DiT dtype (or `dtype`)."""
        dtype = self._dit_dtype if dtype is None else dtype
        cache = self.__dict__.setdefault("_wc_dit", {})
        v = cache.get((key, transpose, dtype))
        if v is None:
            w = self._w[key]
            v = ttnn.from_torch(w.t().contiguous() if transpose else w,
                                layout=ttnn.TILE_LAYOUT, device=get_device(), dtype=dtype)
            cache[(key, transpose, dtype)] = v
        return v

    def _w_tt_lp(self, key):
        """A DiT weight, transposed and rounded via bf16 on the host to `_dit_lp.w`."""
        cache = self.__dict__.setdefault("_wc_dit_lp", {})
        v = cache.get(key)
        if v is None:
            v = ttnn.from_torch(self._w[key].t().contiguous().float().to(torch.bfloat16),
                                layout=ttnn.TILE_LAYOUT, device=get_device(), dtype=self._dit_lp.w)
            cache[key] = v
        return v

    def _ln_dit(self, x, wkey, bkey=None):
        """Layer norm at the DiT dtype (used for the DiT-output layernorm_a when fp32)."""
        return ops.layer_norm(x, self._w_tt_dit(wkey, False, self.dtype),
                              (self._w_tt_dit(bkey, False, self.dtype) if bkey else None),
                              epsilon=1e-5, compute_kernel_config=self._dit_ckc)

    def _atom_cond(self, cond):
        """Hoist the t-INDEPENDENT diffusion conditioning out of the per-step denoise.
        The single-conditioning base, the atom-encoder single c_la, and the windowed
        atom-pair p (+ small_mlp) depend ONLY on the trunk outputs -- not on x_noisy or
        t_hat -- yet were recomputed every sampling step (200x). They are the same kind
        of fixed conditioning already hoisted for the DiT (dit_z / pair bias). Compute
        once per fold; store resident device tensors in cond. Idempotent."""
        import torch
        if "c_la_dev" in cond:
            return
        s_trunk = cond["s_trunk"].float(); s_inputs = cond["s_inputs"].float()
        c_l = cond["c_l"].float(); p_lm = cond["p_lm"].float(); S = cond["S"].float()
        N = c_l.shape[0]; NT = s_inputs.shape[0]
        NP = ((N + self.NQ - 1) // self.NQ) * self.NQ
        T = self._up
        E = "atom_attention_encoder."
        # single-conditioning base (the t-dependent fourier term + transitions stay per-step)
        cond["ss_base"] = self._lin(self._ln(T(torch.cat([s_trunk, s_inputs], -1)),
                                    "diffusion_conditioning.layernorm_s.weight"),
                                    "diffusion_conditioning.linear_no_bias_s.weight")
        # atom-encoder single c_la and windowed atom-pair p (+ small_mlp)
        sp = self._lin(self._ln(T(s_trunk), E + "layernorm_s.weight"), E + "linear_no_bias_s.weight")
        c_la = ttnn.add(T(c_l), ttnn.matmul(T(S), sp, compute_kernel_config=self.compute_kernel_config, core_grid=CORE_GRID_MAIN))
        clq = ttnn.relu(self._winq(c_la, N, NP)); clk = ttnn.relu(self._winkv(c_la, N, NP))
        p = ttnn.add(ttnn.add(T(p_lm), ttnn.unsqueeze(self._lin(clq, E + "linear_no_bias_cl.weight"), 2)),
                     ttnn.unsqueeze(self._lin(clk, E + "linear_no_bias_cm.weight"), 1))
        mm = self._lin(ttnn.relu(p), E + "small_mlp.1.weight")
        mm = self._lin(ttnn.relu(mm), E + "small_mlp.3.weight")
        mm = self._lin(ttnn.relu(mm), E + "small_mlp.5.weight")
        cond["c_la_dev"] = c_la
        cond["p_dev"] = ttnn.add(p, mm)
        # atom->token mean-pool matrix and S onehot, resident (re-uploaded every step otherwise)
        Smean = S.t().contiguous() / (S.sum(0, keepdim=True).t() + 1e-6)
        cond["Smean_dev"] = T(Smean)
        cond["S_dev"] = T(S)
        # atom-transformer (enc + dec) pair/pad biases: pure functions of p (=p_dev, fixed) and
        # the window mask -> precompute once; replayed every step via bias_cache.
        mtf = cond["mask_trunked"].float()
        cond["atxE_bias"] = self.atxE.precompute_biases(cond["p_dev"], mtf)
        cond["atxD_bias"] = self.atxD.precompute_biases(cond["p_dev"], mtf)
        self._atom_terms(cond)

    def _atom_terms(self, cond):
        """Both atom transformers' conditioning terms (AtomTransformer.cond_terms) from c_la,
        once per fold. They are 8 tensors of c_la's shape per block, 48 at the shipped depths
        (145 MB in fp32 at 5,919 atoms), so they are kept only while that is a small share of
        the free DRAM; otherwise each step recomputes them as before."""
        c_la = cond["c_la_dev"]
        c3 = c_la if len(c_la.shape) == 3 else ttnn.reshape(c_la, (1, c_la.shape[0], c_la.shape[-1]))
        n_terms = 8 * (self.atxE.n_blocks + self.atxD.n_blocks)
        need = n_terms * _T._padded_bytes(tuple(c3.shape), 4 if self.dtype == ttnn.float32 else 2)
        if need * 20 > _T.dram_free():
            cond["atxE_terms"] = cond["atxD_terms"] = None
            return
        cond["atxE_terms"] = self.atxE.cond_terms(c3)
        cond["atxD_terms"] = self.atxD.cond_terms(c3)

    def denoise(self, x_noisy, t_hat, cond):
        """x_noisy (1,N,3) host at M=1, (M,N,3) at M>1; t_hat scalar host tensor (1,); cond dict with host
        tensors s_trunk (NT,c_s), s_inputs (NT,449), pair_z (NT,NT,c_z), c_l (N,128),
        p_lm (nb,nq,nk,16), S (N,NT) atom->token onehot, mask_trunked (nb,nq,nk).
        Returns denoised coords (1,N,3) at M=1, (M,N,3) at M>1 host tensor."""
        import torch.nn.functional as F
        _M = x_noisy.shape[0]
        if _M > 1 and getattr(self, "supports_multiplicity", False):
            return self._denoise_multiplicity(x_noisy, t_hat, cond)
        self._atom_cond(cond)   # idempotent: t-independent conditioning, computed once per fold
        s_inputs = cond["s_inputs"]
        sd = self.SIGMA_DATA
        N = cond["c_l"].shape[0]; NT = s_inputs.shape[0]
        T = self._up
        E = "atom_attention_encoder."
        mt = cond["mask_trunked"].float()
        c_la = cond["c_la_dev"]; p = cond["p_dev"]   # hoisted (resident across all steps)

        # 1) single conditioning: cached base + per-step fourier(t_hat), then transitions
        wf = self._w["diffusion_conditioning.fourier_embedding.w"]; bf = self._w["diffusion_conditioning.fourier_embedding.b"]
        tp = torch.log(t_hat / sd) / 4
        fou = torch.cos(2 * torch.pi * (tp.unsqueeze(-1) * wf + bf))
        nn_ = self._lin(self._ln(T(fou), "diffusion_conditioning.layernorm_n.weight"),
                        "diffusion_conditioning.linear_no_bias_n.weight")
        ss = ttnn.reshape(ttnn.add(cond["ss_base"], nn_), (1, NT, cond["ss_base"].shape[-1]))
        for t in self._cond_transitions:   # prebuilt once (weights resident)
            ss = ttnn.add(ss, ttnn.reshape(t(ss), tuple(ss.shape)))
        s_single = ss

        # 2) atom encoder: only the coordinate-dependent path (c_la / p come from cond)
        r_noisy = x_noisy / torch.sqrt(torch.tensor(sd ** 2) + t_hat ** 2).reshape(-1, 1, 1)
        q_l = ttnn.add(c_la, self._lin(T(r_noisy[0]), E + "linear_no_bias_r.weight"))
        q_out = self.atxE(ttnn.reshape(q_l, (1, N, 128)), ttnn.reshape(c_la, (1, N, 128)), p, mt,
                          bias_cache=cond.get("atxE_bias"), terms=cond.get("atxE_terms"))
        a_tok = ttnn.matmul(cond["Smean_dev"], ttnn.reshape(ttnn.relu(self._lin(q_out, E + "linear_no_bias_q.weight")), (N, 768)),
                            compute_kernel_config=self.compute_kernel_config, core_grid=CORE_GRID_MAIN)
        q_skip = q_out; c_skip = c_la; p_skip = p
        a_tok = ttnn.add(a_tok, ttnn.reshape(
            self._lin(self._ln(ttnn.reshape(s_single, (NT, s_single.shape[-1])), "layernorm_s.weight"),
                      "linear_no_bias_s.weight"), (NT, 768)))

        # 3) token DiT (fp32 host; precision-limited on-device, see class docstring)
        # per-block pair bias depends only on pair_z (fixed across steps) -> precomputed once
        if self.device_dit and cond.get("dit_z") is not None:
            if "dit_block_biases" not in cond:   # precompute per-block pair biases ONCE per fold
                cond["dit_block_biases"] = self._dit_block_biases(
                    cond["dit_z"], cond.get("structural_pair_attn_bias"))
            a_t = self._token_dit_device(ttnn.reshape(a_tok, (1, NT, 768)), s_single,
                                         cond["dit_block_biases"], NT)
            if self._dit_fp32:
                a_t = self._ln_dit(a_t, "layernorm_a.weight")
            else:
                a_t = self._ln(a_t, "layernorm_a.weight")
        else:  # host fp32 fallback (max fidelity / no precomputed device bias)
            a_h = torch.Tensor(ttnn.to_torch(ttnn.reshape(a_tok, (1, NT, 768)))).float().reshape(NT, 768)
            s_h = torch.Tensor(ttnn.to_torch(s_single)).float().reshape(NT, s_single.shape[-1])
            biases = cond.get("dit_biases") or self._dit_pair_biases(
                cond["pair_z"].float(), cond.get("structural_pair_attn_bias"))
            a_h = self._token_dit(a_h, s_h, biases, NT)
            a_t = self._ln(T(a_h.reshape(1, NT, 768)), "layernorm_a.weight")

        # 4) atom decoder
        DE = "atom_attention_decoder."
        q = ttnn.add(ttnn.matmul(cond["S_dev"], self._lin(ttnn.reshape(a_t, (NT, 768)), DE + "linear_no_bias_a.weight"),
                                 compute_kernel_config=self.compute_kernel_config, core_grid=CORE_GRID_MAIN),
                     ttnn.reshape(q_skip, (N, 128)))
        qd = self.atxD(ttnn.reshape(q, (1, N, 128)), ttnn.reshape(c_skip, (1, N, 128)), p_skip, mt,
                       bias_cache=cond.get("atxD_bias"), terms=cond.get("atxD_terms"))
        qn = self._ln(qd, DE + "layernorm_q.weight")
        # The device tensor the coordinate update comes off, kept before the host
        # round-trip. `to_torch` is where a tape ends, so a training step that wants a
        # gradient into the denoiser has to seed HERE; the EDM preconditioning below is
        # affine in this tensor, so the seed is an exact scalar rescale and not an
        # approximation. Inference reads the same bytes it always did.
        _r_dev = self._lin(qn, DE + "linear_no_bias_out.weight")
        self.last_r_update_device = _r_dev
        # The host read is where the tape ends, deliberately, so it reads the VALUE. Handing a
        # taped tensor to `ttnn.to_torch` raises, which is the right default -- it is how an
        # accidental gradient drop gets caught -- but here the boundary is the point: a caller
        # that wants the gradient seeds `last_r_update_device` above.
        r_update = torch.Tensor(ttnn.to_torch(getattr(_r_dev, "value", _r_dev)))
        r_update = r_update.float().reshape(1, N, 3)[:, :N]

        # EDM preconditioning
        sr = (t_hat / sd).reshape(-1, 1, 1)
        return (1.0 / (1.0 + sr ** 2)) * x_noisy[:, :N] + (t_hat.reshape(-1, 1, 1) / torch.sqrt(1.0 + sr ** 2)) * r_update

    # ---------------------------------------------------------------------------
    # ttnn TRACE of the denoise device stream (opt-in via fold(trace=True)).
    # Protenix diffusion warm is per-step DISPATCH-bound (~400 op launches/step,
    # L-independent): capturing the device stream once per fold and replaying it
    # collapses the per-step host dispatch. The two per-step-varying host inputs
    # (fourier(t_hat) and the scaled coords) are staged into fixed device buffers;
    # the fold-fixed conditioning (cond) stays resident. device_dit path only.
    # The captured graph reads cond's device buffers, so the cached trace is
    # valid for that cond only: it is keyed on N AND cond's identity token, and
    # a new fold's cond forces a recapture even at the same atom count.
    # ---------------------------------------------------------------------------
    def _denoise_device(self, r_noisy_dev, fou_dev, cond):
        """Pure on-device denoise (device_dit path). r_noisy_dev (N,3) and fou_dev
        (1,fdim) are device tensors (the per-step host inputs, already uploaded);
        returns r_update (1,N,3) on device (pre EDM-precond). No host round-trips."""
        s_inputs = cond["s_inputs"]
        N = cond["c_l"].shape[0]; NT = s_inputs.shape[0]
        E = "atom_attention_encoder."
        mt = cond["mask_trunked"].float()
        c_la = cond["c_la_dev"]; p = cond["p_dev"]
        nn_ = self._lin(self._ln(fou_dev, "diffusion_conditioning.layernorm_n.weight"),
                        "diffusion_conditioning.linear_no_bias_n.weight")
        ss = ttnn.reshape(ttnn.add(cond["ss_base"], nn_), (1, NT, cond["ss_base"].shape[-1]))
        for t in self._cond_transitions:
            ss = ttnn.add(ss, ttnn.reshape(t(ss), tuple(ss.shape)))
        s_single = ss
        q_l = ttnn.add(c_la, self._lin(r_noisy_dev, E + "linear_no_bias_r.weight"))
        q_out = self.atxE(ttnn.reshape(q_l, (1, N, 128)), ttnn.reshape(c_la, (1, N, 128)), p, mt,
                          bias_cache=cond.get("atxE_bias"), terms=cond.get("atxE_terms"))
        a_tok = ttnn.matmul(cond["Smean_dev"], ttnn.reshape(ttnn.relu(self._lin(q_out, E + "linear_no_bias_q.weight")), (N, 768)),
                            compute_kernel_config=self.compute_kernel_config, core_grid=CORE_GRID_MAIN)
        q_skip = q_out; c_skip = c_la; p_skip = p
        a_tok = ttnn.add(a_tok, ttnn.reshape(
            self._lin(self._ln(ttnn.reshape(s_single, (NT, s_single.shape[-1])), "layernorm_s.weight"),
                      "linear_no_bias_s.weight"), (NT, 768)))
        if "dit_block_biases" not in cond:
            cond["dit_block_biases"] = self._dit_block_biases(
                cond["dit_z"], cond.get("structural_pair_attn_bias"))
        a_t = self._token_dit_device(ttnn.reshape(a_tok, (1, NT, 768)), s_single, cond["dit_block_biases"], NT)
        if self._dit_fp32:
            a_t = self._ln_dit(a_t, "layernorm_a.weight")
        else:
            a_t = self._ln(a_t, "layernorm_a.weight")
        DE = "atom_attention_decoder."
        q = ttnn.add(ttnn.matmul(cond["S_dev"], self._lin(ttnn.reshape(a_t, (NT, 768)), DE + "linear_no_bias_a.weight"),
                                 compute_kernel_config=self.compute_kernel_config, core_grid=CORE_GRID_MAIN),
                     ttnn.reshape(q_skip, (N, 128)))
        qd = self.atxD(ttnn.reshape(q, (1, N, 128)), ttnn.reshape(c_skip, (1, N, 128)), p_skip, mt,
                       bias_cache=cond.get("atxD_bias"), terms=cond.get("atxD_terms"))
        qn = self._ln(qd, DE + "layernorm_q.weight")
        return ttnn.reshape(self._lin(qn, DE + "linear_no_bias_out.weight"), (1, N, 3))

    def _host_tt(self, x):
        """Host-resident ttnn tensor (no device) for copy_host_to_device_tensor staging."""
        return ttnn.from_torch(x.float(), layout=ttnn.TILE_LAYOUT, dtype=self.dtype)

    def _release_trace(self):
        tr = getattr(self, "_trace", None)
        if tr is not None:
            try:
                ttnn.release_trace(self.dev, tr["tid"])
            except Exception:
                pass
            self._trace = None

    @staticmethod
    def _cond_token(cond):
        """Identity token for one fold's conditioning.

        A captured trace bakes in the DEVICE BUFFERS of the cond it was recorded
        against (c_la_dev, p_dev, S_dev, dit_z, the per-block DiT biases), so it
        is valid for that cond only. Keying the cached trace on the atom count N
        alone let a second fold of a same-size target replay the FIRST fold's
        conditioning out of buffers that fold had already released -- silently
        wrong coordinates, no error. The token is a bare object stored on the
        cond dict, so the trace holds no device memory alive.
        """
        tok = cond.get("_trace_token")
        if tok is None:
            tok = cond["_trace_token"] = object()
        return tok

    def _capture_trace(self, fou, r_noisy, cond, N, M):
        """Capture one denoise's device stream at (N, M) against `cond`. The two per-step
        inputs live in persistent device buffers that each replay overwrites."""
        fou_dev = self._up(fou); r_dev = self._up(r_noisy)   # persistent input buffers
        if M == 1:
            run = lambda: self._denoise_device(r_dev, fou_dev, cond)
        else:
            run = lambda: self._denoise_device_m(r_dev, fou_dev, cond, M)
        _ = run()                                            # warmup / compile
        _ = run()                                            # 2nd warmup: populate any lazy caches
        ttnn.synchronize_device(self.dev)
        tid, out = _T.capture_trace(self.dev, run)
        self._trace = {"N": N, "M": M, "tid": tid, "in_fou": fou_dev, "in_r": r_dev, "out": out,
                       "cond": self._cond_token(cond)}
        return self._trace

    def rollout_ok(self, cond, M):
        """Whether `rollout_device` can run this fold: the traced path's own conditions (device DiT,
        biases resident), one chunk of one target."""
        self._atom_cond(cond)
        if not (self.device_dit and cond.get("dit_z") is not None) or "_members" in cond:
            return False
        if "dit_block_biases" not in cond:
            cond["dit_block_biases"] = self._dit_block_biases(
                cond["dit_z"], cond.get("structural_pair_attn_bias"))
        return all(b.storage_type() == ttnn.StorageType.DEVICE for b in cond["dit_block_biases"])

    def rollout_device(self, x, cond, n_step, draw, progress_fn=None):
        """The whole EDM trajectory with the coordinates resident on the card (lever ``edm_device``).

        `draw(k)` returns step k's (R, tr, eps, t_hat, sigma_t, eta) from the host RNG in the order
        the host loop draws them, so the random stream is unchanged. The host stages them and
        enqueues the step; a captured step centres, rotates, translates and noises the
        coordinates, denoises, and takes the EDM step in fp32 (`edm_device_step_reference`'s order,
        no atom mask: every Protenix atom is real). Nothing is read back until the last step, so
        the device runs the steps back to back instead of idling 6-10 ms on each host round trip
        (state/mol1/evidence/bh/opgap.md). `x` (M, N, 3) host; returns the final coordinates."""
        from .edm_device import edm_step_scalars, matmul_f32
        dev, f32 = self.dev, ttnn.float32
        M, N = x.shape[0], x.shape[1]
        self._release_trace()                    # this path does not use the denoise-only trace
        ckc = ttnn.init_device_compute_kernel_config(
            dev.arch(), math_fidelity=ttnn.MathFidelity.HiFi4, fp32_dest_acc_en=True, packer_l1_acc=False)
        host = lambda t, dt=f32: ttnn.from_torch(t.float().contiguous(), layout=ttnn.TILE_LAYOUT, dtype=dt)
        up = lambda t: ttnn.to_device(host(t), dev)

        def inputs(k):
            R, tr, eps, t_hat, sigma_t, eta = draw(k)
            sc = edm_step_scalars(t_hat, sigma_t, self.SIGMA_DATA, float(eta))
            fou = self._fourier(torch.tensor([t_hat], dtype=torch.float32))
            return ([host(torch.tensor(v, dtype=torch.float64).reshape(1, 1, 1)) for v in sc],
                    host(fou, self.dtype), host(R), host(tr), host(eps))

        x_dev = up(x)
        mrow = up(torch.full((M, 1, N), 1.0 / N))
        first = inputs(0)
        st_sc = [ttnn.to_device(v, dev) for v in first[0]]
        st = [ttnn.to_device(v, dev) for v in first[1:]]     # fou, R, tr, eps

        def stage(ins):
            for src, dst in zip(ins[0] + list(ins[1:]), st_sc + st):
                ttnn.copy_host_to_device_tensor(src, dst)

        def zero_pad(t):
            """`t` with its tile padding zeroed. The fill works in place on this ttnn (it hands back
            the input's buffer), so the result is freed only where it is a separate buffer."""
            z = ttnn.fill_implicit_tile_padding(t, 0.0)
            return z, (z.buffer_address() != t.buffer_address())

        def step():
            inv_s, c_skip, c_out, inv_t, h = st_sc
            fou, R, tr, eps = st
            x0, x0_own = zero_pad(x_dev)                        # the mean contracts over the atom tiles
            mean = matmul_f32(mrow, x0, ckc)                    # (M, 1, 3)
            xc = ttnn.subtract(x0, mean)
            xr = matmul_f32(xc, R, ckc)
            xa = ttnn.add(xr, tr)
            xn = ttnn.add(xa, eps)
            r0 = ttnn.multiply(xn, inv_s)
            r, r_own = zero_pad(r0)                             # the denoise reads what an upload holds
            rd = ttnn.typecast(r, self.dtype) if self.dtype != f32 else r
            out = (self._denoise_device(ttnn.reshape(rd, (N, 3)), fou, cond) if M == 1
                   else self._denoise_device_m(rd, fou, cond, M))
            ru = ttnn.typecast(out, f32) if out.dtype != f32 else out
            if ru is not out:
                ttnn.deallocate(out)
            a = ttnn.multiply(xn, c_skip)
            b = ttnn.multiply(ttnn.reshape(ru, (M, N, 3)), c_out)
            xd = ttnn.add(a, b)
            d0 = ttnn.subtract(xn, xd)
            d = ttnn.multiply(d0, inv_t)
            hd = ttnn.multiply(d, h)
            xnew = ttnn.add(xn, hd)
            ttnn.copy(xnew, x_dev)
            for y in (mean, xc, xr, xa, xn, r0, ru, a, b, xd, d0, d, hd, xnew):
                ttnn.deallocate(y)
            for y, own in ((x0, x0_own), (r, r_own), (rd, rd is not r)):
                if own:
                    ttnn.deallocate(y)

        tid = None
        try:
            for k in range(n_step):
                if progress_fn:
                    progress_fn("diffusion", step=k, total=n_step)
                if k:
                    stage(inputs(k))
                if tid is not None:
                    ttnn.execute_trace(dev, tid, cq_id=0, blocking=False)
                    continue
                step()
                if k + 1 < n_step:
                    tid = ttnn.begin_trace_capture(dev, cq_id=0)
                    try:
                        step()
                        ttnn.end_trace_capture(dev, tid, cq_id=0)
                    except Exception as e:
                        print(f"  [protenix diffusion] edm_device trace capture failed, steps run eagerly: {e}")
                        try:
                            ttnn.end_trace_capture(dev, tid, cq_id=0)
                        except Exception:
                            pass
                        ttnn.release_trace(dev, tid)
                        tid = None
            return torch.Tensor(ttnn.to_torch(x_dev)).float().reshape(M, N, 3)
        finally:
            if tid is not None:
                ttnn.release_trace(dev, tid)
            for y in [x_dev, mrow, *st_sc, *st]:
                ttnn.deallocate(y)

    def denoise_traced(self, x_noisy, t_hat, cond):
        """Traced equivalent of denoise (device_dit path), at any sample count M. Falls back
        to denoise when the device_dit precomputed bias path is unavailable, when a bias is
        parked on the host, or for a chunk whose M differs from the captured one (the short
        tail of a chunked step), so a step never recaptures."""
        self._atom_cond(cond)
        if not (self.device_dit and cond.get("dit_z") is not None):
            return self.denoise(x_noisy, t_hat, cond)
        if "dit_block_biases" not in cond:
            cond["dit_block_biases"] = self._dit_block_biases(
                cond["dit_z"], cond.get("structural_pair_attn_bias"))
        if any(b.storage_type() != ttnn.StorageType.DEVICE for b in cond["dit_block_biases"]):
            # A trace cannot hold the upload of a parked bias.
            return self.denoise(x_noisy, t_hat, cond)
        N = cond["c_l"].shape[0]; M = x_noisy.shape[0]
        fou, r_noisy = self._step_inputs(x_noisy, t_hat)
        fou = fou.contiguous()
        r_noisy = (r_noisy[0] if M == 1 else r_noisy).contiguous()   # M=1 captures at (N,3)
        tr = getattr(self, "_trace", None)
        if tr is None or tr["N"] != N or tr.get("cond") is not self._cond_token(cond):
            if tr is not None:
                self._release_trace()
            tr = self._capture_trace(fou, r_noisy, cond, N, M)
        elif tr["M"] != M:
            return self.denoise(x_noisy, t_hat, cond)
        ttnn.copy_host_to_device_tensor(self._host_tt(fou), tr["in_fou"])
        ttnn.copy_host_to_device_tensor(self._host_tt(r_noisy), tr["in_r"])
        ttnn.execute_trace(self.dev, tr["tid"], cq_id=0, blocking=False)
        return self._precondition(x_noisy, t_hat, torch.Tensor(ttnn.to_torch(tr["out"])).float(), M, N)

    # --- windowing helpers (atom encoder p augmentation) ---
    def _winq(self, x, N, NP):
        return _window_q(x, N, NP, self.NQ)

    def _winkv(self, x, N, NP):
        return _window_kv(x, N, NP, self.NQ, self.NK, self.PAD_LEFT)

    def _dit_pair_biases(self, pair_z, extra_attn_bias=None):
        """Per-block DiT attention pair bias linear_z(LN(LN(pair_z))). Depends only on the
        trunk pair_z (fixed across all sampling steps), so it is computed ONCE per fold and
        reused every diffusion step -- the dominant host cost otherwise. Returns 24 tensors
        of shape (n_heads, NT, NT)."""
        import torch.nn.functional as F
        gP = lambda k: self._w["diffusion_transformer." + k].float()
        z_h = F.layer_norm(pair_z, (pair_z.shape[-1],))
        biases = []
        for b in range(self.DIT_BLOCKS):
            A = f"blocks.{b}.attention_pair_bias."
            zb = F.layer_norm(z_h, (z_h.shape[-1],)) * gP(A + "layernorm_z.weight")
            bias = F.linear(zb, gP(A + "linear_nobias_z.weight")).permute(2, 0, 1)
            if extra_attn_bias is not None:
                bias = bias + extra_attn_bias.float().unsqueeze(0)
            biases.append(bias)
        return biases

    def _token_dit(self, a_h, s_h, biases, NT):
        import torch.nn.functional as F
        nbk, hd, nh = self.DIT_BLOCKS, self.DIT_HEAD_DIM, self.DIT_N_HEADS
        gP = lambda k: self._w["diffusion_transformer." + k].float()
        def adaln(a, s, pre):
            an = F.layer_norm(a, (a.shape[-1],)); sn = F.layer_norm(s, (s.shape[-1],)) * gP(pre + "layernorm_s.weight")
            return torch.sigmoid(F.linear(sn, gP(pre + "linear_s.weight"), gP(pre + "linear_s.bias"))) * an + F.linear(sn, gP(pre + "linear_nobias_s.weight"))
        for b in range(nbk):
            A = f"blocks.{b}.attention_pair_bias."; Cc = f"blocks.{b}.conditioned_transition_block."
            an = adaln(a_h, s_h, A + "layernorm_a.")
            bias = biases[b]
            Q = F.linear(an, gP(A + "attention.linear_q.weight"), gP(A + "attention.linear_q.bias")).reshape(NT, nh, hd).permute(1, 0, 2)
            K = F.linear(an, gP(A + "attention.linear_k.weight")).reshape(NT, nh, hd).permute(1, 0, 2)
            V = F.linear(an, gP(A + "attention.linear_v.weight")).reshape(NT, nh, hd).permute(1, 0, 2)
            o = torch.einsum("hij,hjd->hid", torch.softmax(torch.einsum("hid,hjd->hij", Q, K) / (hd ** 0.5) + bias, -1), V).permute(1, 0, 2).reshape(NT, nh * hd)
            o = o * torch.sigmoid(F.linear(an, gP(A + "attention.linear_g.weight"))); attn = F.linear(o, gP(A + "attention.linear_o.weight"))
            attn = torch.sigmoid(F.linear(s_h, gP(A + "linear_a_last.weight"), gP(A + "linear_a_last.bias"))) * attn; ao = attn + a_h
            an2 = adaln(ao, s_h, Cc + "adaln."); bb = F.silu(F.linear(an2, gP(Cc + "linear_nobias_a1.weight"))) * F.linear(an2, gP(Cc + "linear_nobias_a2.weight"))
            a_h = torch.sigmoid(F.linear(s_h, gP(Cc + "linear_s.weight"), gP(Cc + "linear_s.bias"))) * F.linear(bb, gP(Cc + "linear_nobias_b.weight")) + ao
        return a_h

    def _dit_z_device(self, pair_z):
        """Upload LN(pair_z) once per fold as (1,NT,NT,c_z) for the on-device DiT; each block's
        AttentionPairBias (compute_pair_bias=True) derives its own pair bias from it (matching
        the validated trunk-pairformer convention, incl. the head-dim scaling)."""
        import torch.nn.functional as F
        z_h = F.layer_norm(pair_z, (pair_z.shape[-1],)).unsqueeze(0).contiguous()
        return _T.upload(z_h, self._dit_dtype, self.dev)

    def _dit_block_biases(self, z_dev, extra_attn_bias=None):
        """Per-block DiT attention pair biases, computed ONCE per fold from z_dev=LN(pair_z).
        Each block's bias is a pure function of pair_z (fixed across all sampling steps), so
        recomputing the NxNxc_z layer_norm+linear every step (24 blocks x n_step) was the
        dominant diffusion cost. Precompute here; replay via AttentionPairBias(bias_precomputed
        =True). Mirrors the host _dit_pair_biases / the _atom_cond hoist."""
        extra = None
        if extra_attn_bias is not None:
            # AttentionPairBias scales projected masks by sqrt(head_dim) to
            # compensate ttnn SDPA's mask scaling. Match it for this direct bias.
            extra = self._up_dit(extra_attn_bias.float().reshape(
                1, 1, extra_attn_bias.shape[-2], extra_attn_bias.shape[-1])
                * self.DIT_HEAD_DIM ** 0.5)
        # A step's attention holds about three tensors of a bias's shape (scores, the biased
        # scores, the softmax) beside one bias uploaded for its read: keep that free, park the
        # rest. At 2987 structural tokens the 24 biases are 13.9 GB of fp32 on a 12 GiB chip.
        NT = int(z_dev.shape[-2])
        if self._dit_sdpa32:
            NT = _T.sdpa32_rows(NT)
        # dit_bpad: each bias staged once at the DiT's padded token axis (`_token_dit_device`).
        to = _T.dit_bias_pad_len(NT) if self._dit_bpad else NT
        one = _T._padded_bytes((1, self.DIT_N_HEADS, to, to),
                               4 if self._dit_dtype == ttnn.float32 else 2)
        reserve = 4 * one
        # Each DRAM reading drains the pipeline, and 48 of them cost a 20-residue fold 100 ms.
        # When every bias fits beside the reserve, one reading settles all the placements.
        fits = _T.dram_free() >= reserve + len(self._dit) * one
        place = (lambda b, reserve: b) if fits else _T.place_by_reserve
        biases = []
        for (_, apb, _, _, _) in self._dit:
            b = apb.compute_bias(z_dev)
            if extra is not None:
                b = ttnn.add(b, extra)
            fb = apb.finish_bias(b)
            if fb is not b:
                ttnn.deallocate(b)
            biases.append(place(_T.pad_dit_bias(fb, NT, to), reserve))
        # z_dev's only reader was this loop, and the room it frees takes parked biases back.
        ttnn.deallocate(z_dev)
        if not fits:
            biases = [place(b, reserve) for b in biases]
        parked = sum(b.storage_type() != ttnn.StorageType.DEVICE for b in biases)
        if parked:
            print(f"[dit] {parked} of {len(biases)} pair biases parked on the host at "
                  f"{NT} tokens, uploaded for each read", flush=True)
        dram_peak(f"dit pair biases placed ({parked} parked)")
        return biases

    def _token_dit_device(self, a_t, s_t, biases, NT):
        """On-device 24-block token DiT (ttnn). a_t (M,NT,768), s_t (M,NT,384); biases = list
        of per-block precomputed (1,n_heads,NT,NT) pair biases (from _dit_block_biases, fixed
        across steps). Mirrors host _token_dit; reuses AdaLN + AttentionPairBias. When
        PROTENIX_DIFFUSION_FP32_DEVICE=1 the full diffusion stack, including this DiT,
        runs in ttnn fp32.

        **M is free here.** Every verb in the loop is a batched matmul against a 2-D weight or
        a broadcasting binary, so a leading sample axis needs no case of its own; the biases
        stay (1,n_heads,NT,NT) and broadcast over M in the QK-scale add rather than being
        replicated, which at NT=1095 in fp32 is 1.9 GB per copy saved. `_denoise_multiplicity`
        used to call a `_token_dit_device_m` whose body was byte-identical to this one."""
        ckc = self._dit_ckc
        if self._dit_fp32:   # inputs are already fp32; typecast is trace-safe and idempotent
            a_t = ttnn.typecast(a_t, self._dit_dtype)
            s_t = ttnn.typecast(s_t, self._dit_dtype)
        wtt = self._w_tt_dit if self._dit_fp32 else self._w_tt
        NP = (_T.sdpa32_rows(NT) if self._dit_sdpa32 else
              _T.dit_bias_pad_len(NT) if self._dit_bpad else NT)
        if NP != NT:
            # Rows are independent everywhere but the attention, whose mask hides the new keys.
            a_t, s_t = (ttnn.pad(x, [(0, 0)] * (len(x.shape) - 2) + [(0, NP - NT), (0, 0)], value=0.0)
                        for x in (a_t, s_t))

        def linb(x, wk, bk=None, act=None):
            return ttnn.linear(x, wtt(wk), bias=(wtt(bk, False) if bk else None), activation=act,
                               compute_kernel_config=_T.silu_ckc(ckc) if act == "silu" else ckc,
                               core_grid=CORE_GRID_MAIN)
        lp = self._dit_lp
        # dit_mm16 / dit_b8: each adaLN writes lp.act, read only by linears; the transition's two
        # hidden linears write bf16, their product lp.mid into linear_nobias_b, which writes lp.out.
        ln_dt = lp.act if lp else None

        def linlp(x, wk, dtype, act=None):
            return lp.linear(x, self._w_tt_lp(wk), dtype=dtype, activation=act)
        # dit_shoist: every block's s-terms as three wide linears a step, read in place (`addcmul_at`).
        wide = self._dit_shoist(s_t) if _T.lever("dit_shoist") else None
        W = lambda t, j: _T._ColWin(t, j * 768, 768)  # noqa: E731

        def gated(x, y, j, wk, bk):
            out = _T._win_addcmul(x, y, W(wide[2], j)) if wide else None
            if out is None and _T.lever("dit_mod16") and x.dtype == ttnn.bfloat16:
                g = ttnn.sigmoid(linb(s_t, wk, bk))
                out = ttnn.addcmul(x, y, g, value=1.0)
                ttnn.deallocate(g)
            if out is None:
                out = gated_add(x, y, ttnn.sigmoid(linb(s_t, wk, bk)))
            return out
        for _bi, ((adaln_a, apb, ctb_adaln, A, Cc), bias) in enumerate(zip(self._dit, biases)):
            terms = (lambda j: _T._SigTerms((W(wide[0], j), W(wide[1], j)))) if wide else (lambda j: None)
            b = adaln_a(a_t, s_t, dtype=ln_dt, s_terms=terms(2 * _bi))
            bias_dev = _T.host_unpark(bias)
            attn = apb(b, bias_dev, bias_precomputed=True)
            if bias_dev is not bias:
                ttnn.deallocate(bias_dev)
            dram_peak(f"dit[M={a_t.shape[0]}] block {_bi}")
            ao = gated(a_t, attn, 2 * _bi, A + "linear_a_last.weight", A + "linear_a_last.bias")
            an2 = ctb_adaln(ao, s_t, dtype=ln_dt, s_terms=terms(2 * _bi + 1))
            if lp:
                bb = ttnn.multiply(linlp(an2, Cc + "linear_nobias_a1.weight", ttnn.bfloat16, "silu"),
                                   linlp(an2, Cc + "linear_nobias_a2.weight", ttnn.bfloat16), dtype=lp.mid)
            else:
                bb = ttnn.multiply(linb(an2, Cc + "linear_nobias_a1.weight", act="silu"),
                                   linb(an2, Cc + "linear_nobias_a2.weight"))
            a_t = gated(ao, linlp(bb, Cc + "linear_nobias_b.weight", lp.out) if lp
                        else linb(bb, Cc + "linear_nobias_b.weight"), 2 * _bi + 1,
                        Cc + "linear_s.weight", Cc + "linear_s.bias")
        if wide:
            for t in wide:
                ttnn.deallocate(t)
        a_t = a_t[:, :NT, :] if NP != NT else a_t
        return ttnn.typecast(a_t, self.dtype) if a_t.dtype != self.dtype else a_t

    def _dit_shoist(self, s_t):
        """`dit_shoist`: `(sigmoid scales, shifts, sigmoid gates)` of all 24 blocks as three wide
        linears off this step's `s_t`, two 768-column windows a block in order (attention, transition).
        The adaLN terms take the s-norm's gamma folded into their weights (`AdaLN.folded_weights`),
        as Boltz-2's hoisted conditioning does."""
        dt = s_t.dtype
        ws = self.__dict__.setdefault("_dit_shoist_w", {})
        if dt not in ws:
            sw, sb, bw, gw, gb = [], [], [], [], []
            for adaln_a, _apb, ctb_adaln, A, Cc in self._dit:
                for ad in (adaln_a, ctb_adaln):
                    w_sc, b_sc, w_sb = ad.folded_weights()
                    sw.append(w_sc); sb.append(b_sc); bw.append(w_sb)
                for pre in (A + "linear_a_last.", Cc + "linear_s."):
                    gw.append(self._w[pre + "weight"].t()); gb.append(self._w[pre + "bias"])
            up = lambda t: ttnn.from_torch(t.float().contiguous(), dtype=dt, layout=ttnn.TILE_LAYOUT,  # noqa: E731
                                           device=self.dev)
            ws[dt] = (up(torch.cat(sw, 1)), up(torch.cat(sb, 0).reshape(1, -1)), up(torch.cat(bw, 1)),
                      up(torch.cat(gw, 1)), up(torch.cat(gb, 0).reshape(1, -1)))
        w_sc, b_sc, w_sb, w_g, b_g = ws[dt]
        ckc = self._dit_ckc
        s_hat = ttnn.layer_norm(s_t, epsilon=1e-5, compute_kernel_config=ckc)
        lin = lambda x, w, b=None, act=None: ttnn.linear(  # noqa: E731
            x, w, bias=b, activation=act, compute_kernel_config=ckc, core_grid=CORE_GRID_MAIN)
        sig = _T.mm_sigmoid(ckc)
        if _T.lever("dit_shoist_mm") and sig == "sigmoid":
            # ttnn.linear's own schedule reads these [N, 384] x [384, 36864] at ~57 GB/s; a 2 x 16 tile block per core
            # runs 2.2x (fp32) / 2.0x (bf16) faster at the same fidelity and the same float64 error (shm2, WH). K block 1
            # only: minimal_matmul returned elements off by 4-8 at fp32 with K block >= 2 and at bf16 with K block 12.
            gx, gy = _T.COMPUTE_GRID_MAIN
            cfg = ttnn.MinimalMatmulConfig(M_block_size=2, K_block_size=1,
                                           N_block_size=16, subblock_h=1, subblock_w=4,
                                           compute_with_storage_grid_size=ttnn.CoreCoord(gx, gy))
            lin = lambda x, w, b=None, act=None: ttnn.experimental.minimal_matmul(  # noqa: E731
                x, w, bias_tensor=b, compute_kernel_config=ckc, dtype=dt, config=cfg,
                fused_activation=ttnn.UnaryWithParam(ttnn.UnaryOpType.SIGMOID) if act else None)
        out = (lin(s_hat, w_sc, b_sc, sig), lin(s_hat, w_sb), lin(s_t, w_g, b_g, sig))
        ttnn.deallocate(s_hat)
        return out


    def _denoise_multiplicity(self, x_noisy, t_hat, cond):
        """M-aware batched denoise (gated by supports_multiplicity). Mirrors denoise() but
        carries the leading M batch dim through the atom encoder, token DiT, and atom
        decoder. Shared conditioning (cond: c_la_dev, p_dev, Smean_dev, S_dev, atxE_bias,
        atxD_bias, dit_block_biases) is sample-invariant, so it keeps its leading dim of 1
        and is broadcast over M; only the coordinate stream x_noisy carries M.
        Returns denoised coords (M,N,3) host."""
        self._atom_cond(cond)
        M = x_noisy.shape[0]
        N = cond["c_l"].shape[0]
        fou, r_noisy = self._step_inputs(x_noisy, t_hat)
        r_dev = self._denoise_device_m(self._up(r_noisy), self._up(fou), cond, M)
        return self._precondition(x_noisy, t_hat, torch.Tensor(ttnn.to_torch(r_dev)).float(), M, N)

    def _step_inputs(self, x_noisy, t_hat):
        """The two per-step host inputs of the device denoise: fourier(t_hat) (1,fdim) and
        the scaled noisy coordinates (M,N,3)."""
        sd = self.SIGMA_DATA
        r_noisy = x_noisy / torch.sqrt(torch.tensor(sd ** 2) + t_hat ** 2).reshape(-1, 1, 1)
        return self._fourier(t_hat), r_noisy

    def _fourier(self, t_hat):
        """fourier(t_hat), (1, fdim): the noise level's embedding, the step's other host input."""
        wf = self._w["diffusion_conditioning.fourier_embedding.w"]
        bf = self._w["diffusion_conditioning.fourier_embedding.b"]
        tp = torch.log(t_hat / self.SIGMA_DATA) / 4
        return torch.cos(2 * torch.pi * (tp.unsqueeze(-1) * wf + bf))

    def _precondition(self, x_noisy, t_hat, r_update, M, N):
        """EDM preconditioning of the network output (t_hat broadcasts over M)."""
        sd = self.SIGMA_DATA
        r_update = r_update.reshape(M, N, 3)[:, :N]
        sr = (t_hat / sd).reshape(-1, 1, 1)
        return (1.0 / (1.0 + sr ** 2)) * x_noisy[:, :N] + (t_hat.reshape(-1, 1, 1) / torch.sqrt(1.0 + sr ** 2)) * r_update

    def _pool_mats(self, cond, M):
        """The atom->token mean-pool and token->atom broadcast matrices with a sample axis of
        M. ttnn matmul has no batch broadcast for its first operand, so they are replicated;
        the copies depend only on the fold and M, so they are made once per fold rather than
        at every step. A merged cond (protenix._merge_conds) already carries one per member."""
        key = ("_pool_m", M)
        if key not in cond:
            N = cond["c_l"].shape[0]; NT = cond["s_inputs"].shape[0]
            sm, s = cond["Smean_dev"], cond["S_dev"]
            cond[key] = (sm if len(sm.shape) == 3 else stack_samples([ttnn.reshape(sm, (1, NT, N))] * M),
                         s if len(s.shape) == 3 else stack_samples([ttnn.reshape(s, (1, N, NT))] * M))
        return cond[key]

    def _denoise_device_m(self, r_noisy_dev, fou_dev, cond, M):
        """The device half of one batched denoise: (M,N,3) scaled coordinates and (1,fdim)
        fourier features, both already on the device, -> r_update (M,N,3) on the device,
        before preconditioning. No host transfer, so it can be captured as a trace."""
        s_inputs = cond["s_inputs"]
        N = cond["c_l"].shape[0]; NT = s_inputs.shape[0]
        E = "atom_attention_encoder."
        mt = cond["mask_trunked"].float()
        c_la = cond["c_la_dev"]; p = cond["p_dev"]
        # c_la_dev is 2D (N,128) (see _atom_cond) and sample-invariant, so it is kept at
        # (1,N,128) and broadcast over M. Merged it is already (M,N,128).
        c_la_1 = c_la if len(c_la.shape) == 3 else ttnn.reshape(c_la, (1, N, 128))
        Smean_m, S_m = self._pool_mats(cond, M)

        # 1) single conditioning: shared (t-independent base + per-step fourier(t_hat)).
        nn_ = self._lin(self._ln(fou_dev, "diffusion_conditioning.layernorm_n.weight"),
                        "diffusion_conditioning.linear_no_bias_n.weight")
        _ssb = cond["ss_base"]
        _cs = _ssb.shape[-1]
        ss = (ttnn.add(_ssb, ttnn.reshape(nn_, (1, 1, _cs))) if len(_ssb.shape) == 3
              else ttnn.reshape(ttnn.add(_ssb, nn_), (1, NT, _cs)))
        for t in self._cond_transitions:
            ss = ttnn.add(ss, ttnn.reshape(t(ss), tuple(ss.shape)))
        s_single = ss   # (1, NT, c) shared across M

        # 2) atom encoder: coordinate-dependent path with M-leading q_l.
        q_l = ttnn.add(self._lin(r_noisy_dev, E + "linear_no_bias_r.weight"), c_la_1)  # (M,N,128)
        q_out = self.atxE(q_l, c_la_1, p, mt,
                          bias_cache=cond.get("atxE_bias"), multiplicity=M,
                          terms=cond.get("atxE_terms"))   # (M,N,128)
        qo_lin = ttnn.relu(self._lin(q_out, E + "linear_no_bias_q.weight"))   # (M,N,768)
        a_tok = ttnn.matmul(Smean_m, qo_lin, compute_kernel_config=self.compute_kernel_config,
                            core_grid=CORE_GRID_MAIN)                         # (M,NT,768)
        _Ms = s_single.shape[0]                       # 1 when shared, M when merged
        s_bias = ttnn.reshape(
            self._lin(self._ln(ttnn.reshape(s_single, (_Ms * NT, s_single.shape[-1])),
                               "layernorm_s.weight"),
                      "linear_no_bias_s.weight"), (_Ms, NT, 768))
        a_tok = ttnn.add(a_tok, s_bias)                                       # (M,NT,768), s_bias bcast

        # 3) token DiT (device_dit path): M-leading a_t; per-block biases broadcast.
        if self.device_dit and cond.get("dit_z") is not None:
            if "dit_block_biases" not in cond:
                cond["dit_block_biases"] = self._dit_block_biases(
                    cond["dit_z"], cond.get("structural_pair_attn_bias"))
            # The per-block pair bias is sample-invariant, so it is passed UNREPLICATED and
            # broadcast over M in the QK-scale add. Replicating it (M copies of 24 x
            # (n_heads,NT,NT)) was the multiplicity path's dominant allocation: 1.9 GB per
            # copy at NT=1095 in fp32, i.e. ~9.6 GB at M=5.
            # s_single depends on the step, not the sample: every DiT term that reads only it
            # (the AdaLN scale/shift and both output gates) runs once at a leading dim of 1 and
            # broadcasts over M, instead of M times on replicated copies.
            a_t = self._token_dit_device(ttnn.reshape(a_tok, (M, NT, 768)), s_single,
                                         cond["dit_block_biases"], NT)
            a_t = (self._ln_dit if self._dit_fp32 else self._ln)(a_t, "layernorm_a.weight")
        else:
            biases = cond.get("dit_biases") or self._dit_pair_biases(
                cond["pair_z"].float(), cond.get("structural_pair_attn_bias"))
            a_h = torch.stack([self._token_dit(
                torch.Tensor(ttnn.to_torch(ttnn.reshape(a_tok[m:m + 1], (1, NT, 768)))).float().reshape(NT, 768),
                torch.Tensor(ttnn.to_torch(s_single)).float().reshape(NT, s_single.shape[-1]),
                biases, NT) for m in range(M)], 0)
            a_t = self._ln(self._up(a_h.reshape(M, NT, 768)), "layernorm_a.weight")

        # 4) atom decoder: q = S_dev @ lin(a_t) + q_out.
        DE = "atom_attention_decoder."
        a_lin = self._lin(ttnn.reshape(a_t, (M, NT, 768)), DE + "linear_no_bias_a.weight")
        q = ttnn.add(ttnn.matmul(S_m, a_lin, compute_kernel_config=self.compute_kernel_config,
                                 core_grid=CORE_GRID_MAIN), q_out)            # (M,N,128)
        qd = self.atxD(q, c_la_1, p, mt,
                       bias_cache=cond.get("atxD_bias"), multiplicity=M,
                       terms=cond.get("atxD_terms"))      # (M,N,128)
        qn = self._ln(qd, DE + "layernorm_q.weight")
        return self._lin(qn, DE + "linear_no_bias_out.weight")


class ConfidenceHead:
    """Protenix-v2 ConfidenceHead -> per-atom pLDDT (and pae/pde logits).

    z = z_trunk + s1(s_inputs)[:,None] + s2(s_inputs)[None] + distance-embed(coords);
    4-block confidence Pairformer (on-device) -> s_single, z; heads (host linears):
    plddt = LN(s_single[atom->token]) . plddt_weight[atom_to_tokatom_idx]. Validated vs
    the real v2 reference (pae/pde PCC 1.0; plddt PCC ~0.93). Reference confidence_head."""

    def __init__(self, conf_state_dict, device, compute_kernel_config, gated_move=False,
                 softmax_scope="protenix"):
        import re
        from .tenstorrent import Pairformer
        self._w = dict(conf_state_dict)
        self.dev = device
        self.compute_kernel_config = compute_kernel_config
        nb = 1 + max(int(re.search(r"pairformer_stack\.blocks\.(\d+)\.", k).group(1))
                     for k in self._w if k.startswith("pairformer_stack.blocks."))
        comb = {}
        for i in range(nb):
            bsd = {k[len(f"pairformer_stack.blocks.{i}."):]: v for k, v in self._w.items()
                   if k.startswith(f"pairformer_stack.blocks.{i}.")}
            for kk, vv in PW.remap_pairformer_block(bsd).items():
                comb[f"layers.{i}.{kk}"] = vv
        b0 = "pairformer_stack.blocks.0."
        nhp = self._w[b0 + "tri_att_start.linear.weight"].shape[0]
        chpa = self._w[b0 + "tri_att_start.mha.linear_q.weight"].shape[0] // nhp
        apb_nh = self._w[b0 + "attention_pair_bias.linear_nobias_z.weight"].shape[0]
        self.pf = Pairformer(nb, chpa, nhp, 384 // apb_nh, apb_nh, True, comb,
                             compute_kernel_config, gated_move=gated_move,
                             accurate_softmax=accurate_softmax_site(f"{softmax_scope}.confidence", default=True))
        # The single track runs on the host in fp32 (`_s_path`); the device runs the pair track and hands back each
        # block's pair bias. The 4-block stack amplifies any bf16 rounding of s 3-7x per block, so a bf16 or tf32 s
        # path reads pLDDT 0.01-0.06 off upstream fp32, while z in bf16 costs nothing (state/mol1/evidence/whl4/ROOT.md).
        self._biases = []
        for b in self.pf.blocks:
            b.s_on_host = self._biases
        self._bias_scale = [b.attention_pair_bias._bias_scale for b in self.pf.blocks]

    def _g(self, k):
        return self._w[k].float()

    def _bias(self, k):
        return self._w[k].float() if k in self._w else 0.0

    def confidence(self, s_inputs, s_trunk, z_trunk, coords, feats):
        """Full confidence forward -> dict with per-atom pLDDT, mean pLDDT, and the token-token
        PAE / PDE matrices (Angstrom). All inputs host tensors; coords (N_atom,3). Recipe
        validated vs the real v2 reference (pae/pde PCC 1.0, plddt ~0.93;
        scripts/protenix_confidence_parity.py)."""
        return self.confidence_samples(s_inputs, s_trunk, z_trunk, [coords], feats)[0]

    def confidence_samples(self, s_inputs, s_trunk, z_trunk, coords, feats, keep_logits=False):
        """`confidence` for every sample in `coords`, one dict each, bit-identical to calling it
        per sample. The host work is what the chip waited on: 24 s of a 730-token, 5-sample
        Protenix-v2 fold on Wormhole sat idle ahead of the confidence pairformers. So the
        sample-invariant part of z is built once, and each sample's host-side z build and the
        previous sample's host heads run while the chip runs a pairformer. One sample's
        tensors are on the chip at a time, as before: the previous result is read back before
        the next input is uploaded."""
        import torch
        import torch.nn.functional as F
        N = s_trunk.shape[0]
        # Tilized on the host, off the device's critical path, and cast to bf16 by torch first (the
        # same round-to-nearest-even ttnn applies, ~4x faster to tilize); only the copy waits.
        H = lambda x: ttnn.from_torch(x.to(torch.bfloat16), layout=ttnn.TILE_LAYOUT, dtype=ttnn.bfloat16)
        s_t = F.layer_norm(torch.clamp(s_trunk, -512, 512), (384,)) * self._g("input_strunk_ln.weight") + self._bias("input_strunk_ln.bias")
        z_base = (z_trunk + F.linear(s_inputs, self._g("linear_no_bias_s1.weight")).unsqueeze(1)
                  + F.linear(s_inputs, self._g("linear_no_bias_s2.weight")).unsqueeze(0))
        mask = feats["distogram_rep_atom_mask"].bool()

        def z_of(x):
            xr = x.reshape(-1, 3)[mask]
            d = torch.cdist(xr, xr)
            oh = ((d.unsqueeze(-1) >= self._g("lower_bins")) & (d.unsqueeze(-1) < self._g("upper_bins"))).float()
            return (z_base + F.linear(oh, self._g("linear_no_bias_d.weight"))
                    + F.linear(d.unsqueeze(-1), self._g("linear_no_bias_d_wo_onehot.weight")))

        def read(held):
            so, zo, dev_biases = held
            zf = torch.Tensor(ttnn.to_torch(zo)).float().reshape(N, N, -1)
            biases = [torch.Tensor(ttnn.to_torch(b)) for b in dev_biases]
            for t in (so, zo, *dev_biases):
                ttnn.deallocate(t)
            return self._s_path(s_t, biases), zf

        out, held = [], None
        s_h = ttnn.from_torch(s_t.unsqueeze(0).float(), layout=ttnn.TILE_LAYOUT, dtype=ttnn.float32)
        for x in coords:
            z_h = H(z_of(x).unsqueeze(0))                  # host, while the chip runs the last pairformer
            done = read(held) if held is not None else None
            held = (*bucketed_pairformer(self.pf, ttnn.to_device(s_h, self.dev), ttnn.to_device(z_h, self.dev),
                                         self.dev), self._take_biases())
            if done is not None:
                out.append(self._heads(*done, feats, keep_logits))  # host, while the chip runs this one
        out.append(self._heads(*read(held), feats, keep_logits))
        return out

    def _take_biases(self):
        """This sample's per-block pair biases, as the device left them, and an empty list for the next."""
        out = list(self._biases)
        self._biases.clear()
        return out

    def _s_path(self, s, biases):
        """The confidence Pairformer's single track on the host in fp32: per block, upstream's AttentionPairBias
        on s (with the device's pair bias, (1,H,Np,Np) scaled by `_bias_scale`) and its single Transition."""
        import torch
        import torch.nn.functional as F
        N, C = s.shape
        for i, b in enumerate(biases):
            p = f"pairformer_stack.blocks.{i}."
            a, t = p + "attention_pair_bias.", p + "single_transition."
            b = torch.as_tensor(b).float().reshape(-1, *b.shape[-3:])[0, :, :N, :N] / self._bias_scale[i]
            H = b.shape[0]
            x = F.layer_norm(s, (C,), self._g(a + "layernorm_a.weight"), self._g(a + "layernorm_a.bias"))
            heads = lambda w, bias=None: F.linear(x, self._g(a + w), bias).reshape(N, H, -1).transpose(0, 1)  # noqa: E731
            q = heads("attention.linear_q.weight", self._g(a + "attention.linear_q.bias"))
            k, v = heads("attention.linear_k.weight"), heads("attention.linear_v.weight")
            o = torch.softmax(q @ k.transpose(-1, -2) * q.shape[-1] ** -0.5 + b, -1) @ v
            o = o.transpose(0, 1).reshape(N, C) * torch.sigmoid(F.linear(x, self._g(a + "attention.linear_g.weight")))
            s = s + F.linear(o, self._g(a + "attention.linear_o.weight"))
            x = F.layer_norm(s, (C,), self._g(t + "layernorm1.weight"), self._g(t + "layernorm1.bias"))
            s = s + F.linear(F.silu(F.linear(x, self._g(t + "linear_no_bias_a.weight")))
                             * F.linear(x, self._g(t + "linear_no_bias_b.weight")), self._g(t + "linear_no_bias.weight"))
        return s

    def _heads(self, s_single, zf, feats, keep_logits=False):
        """pae / pde / plddt heads on the host from the pairformer's (s_single, z)."""
        import torch
        import torch.nn.functional as F
        pae_logits = F.linear(F.layer_norm(zf, (zf.shape[-1],)) * self._g("pae_ln.weight") + self._bias("pae_ln.bias"),
                              self._g("linear_no_bias_pae.weight"))                          # (N,N,n_bins)
        pde_logits = F.linear(F.layer_norm(zf + zf.transpose(0, 1), (zf.shape[-1],)) * self._g("pde_ln.weight") + self._bias("pde_ln.bias"),
                              self._g("linear_no_bias_pde.weight"))                          # (N,N,n_bins)
        return self._postprocess(pae_logits, pde_logits, self._plddt_logits(s_single, feats), feats, keep_logits)

    def _plddt_logits(self, s_single, feats):
        """The plddt head on the host in fp32, from the pairformer's (N, 384) single track: it reads the per-token
        part of the small channels, which a bf16 gather or layer norm on the device erases."""
        import torch
        import torch.nn.functional as F
        a2t = feats["atom_to_token_idx"].long(); a2ta = feats["atom_to_tokatom_idx"].long()
        aln = F.layer_norm(s_single[a2t], (384,)) * self._g("plddt_ln.weight") + self._bias("plddt_ln.bias")
        return torch.einsum("nc,ncb->nb", aln, self._g("plddt_weight")[a2ta])                # (N_atom, n_bins)

    # ---------------------------------------------------------------------------
    # Device-resident confidence path (opt-in). The host path (confidence())
    # builds z on host, UPLOADS (1,N,N,256) to the device Pairformer, then
    # DOWNLOADS (s_single, zf) and runs the pae/pde/plddt heads on host -- a
    # full (N,N,256) device<->host round-trip every sample. On large N the host
    # side dominates confidence (measured 53% of 355 ms @N=256 on BH 'pc'; the
    # device Pairformer is only 116 ms). This path keeps z_base resident: the
    # sample-invariant z_base = z_trunk + s1(s_inputs)[:,None] + s2(s_inputs)
    # [None,:] is computed ONCE on device, and per-sample only the (N,3) coords
    # are uploaded; the distance-embed + Pairformer + pae/pde/plddt heads all
    # run on device (plddt on the host from the downloaded (N,384) single track), and
    # only the small finals (pae/pde (N,N,64), s (N,384)) are downloaded. Feature-detected + gated behind
    # TT_PROTENIX_CONF_DEVICE, on by default: it passed the normal-mode grade on
    # Wormhole (11 complexes x 4 seeds) for Protenix-v2 (pLDDT within 0.003 per
    # complex) and for OpenDDE (coordinates unchanged, CA-lDDT +0.0009).
    # ---------------------------------------------------------------------------
    def device_confidence_enabled(self):
        """True if TT_PROTENIX_CONF_DEVICE (default on) asks for it AND the installed
        ttnn exposes every op the device path needs. Otherwise confidence() runs its host heads."""
        if not env_flag("TT_PROTENIX_CONF_DEVICE", True):
            return False
        import ttnn
        need = ("clamp", "ge", "lt", "sqrt", "embedding", "layer_norm", "linear",
                "matmul", "softmax", "permute")
        return all(hasattr(ttnn, k) for k in need)

    def _wtt(self, key, transpose=True):
        """Upload a confidence weight once (TILE/bf16), cached on the instance."""
        cache = self.__dict__.setdefault("_wtt_cache", {})
        v = cache.get(key)
        if v is None:
            import ttnn
            w = self._w[key]
            v = ttnn.from_torch(w.t().contiguous() if transpose else w,
                                layout=ttnn.TILE_LAYOUT, device=self.dev, dtype=ttnn.bfloat16)
            cache[key] = v
        return v

    def _dev_lin(self, x, wkey, bias=False):
        import ttnn
        b = None
        if bias:
            b = self._wtt(wkey.replace(".weight", ".bias"), False) if (wkey.replace(".weight", ".bias") in self._w) else None
        return ttnn.linear(x, self._wtt(wkey), bias=b,
                           compute_kernel_config=self.compute_kernel_config, core_grid=CORE_GRID_MAIN)

    def _device_resident(self, s_inputs, s_trunk, z_base_dev, feats):
        """Build the sample-invariant device tensors ONCE per fold: s_t, the
        coords gather index (which atoms pass distogram_rep_atom_mask), and the
        plddt per-atom-type weight table. z_base itself (z_trunk + s1 + s2) is
        passed in already-uploaded as a RESIDENT bf16 device tensor (computed
        fp32 on host once via z_base_device -- bf16-accumulating it on device
        regresses the pairformer input at small N; see the parity harness).
        Idempotent via a cached tag on z_base_dev."""
        import torch, torch.nn.functional as F, ttnn
        cache = self.__dict__.setdefault("_dev_res", {})
        tag = id(z_base_dev)
        if cache.get("tag") == tag:
            return cache
        T = lambda x: ttnn.from_torch(x.float(), layout=ttnn.TILE_LAYOUT, device=self.dev, dtype=ttnn.bfloat16)
        N = s_trunk.shape[0]
        s_t_h = F.layer_norm(torch.clamp(s_trunk, -512, 512), (384,)) * self._g("input_strunk_ln.weight") + self._bias("input_strunk_ln.bias")
        s_t = ttnn.from_torch(s_t_h.unsqueeze(0).float(), layout=ttnn.TILE_LAYOUT, device=self.dev,
                              dtype=ttnn.float32)                         # (1,N,384), fp32 like the head's track
        # Distance bins in fp32, so the bin of every pair is the host path's (the edges are bf16-exact).
        F32 = lambda k: ttnn.from_torch(self._g(k).reshape(1, 1, 1, -1), layout=ttnn.TILE_LAYOUT,
                                        device=self.dev, dtype=ttnn.float32)
        lb4, ub4 = F32("lower_bins"), F32("upper_bins")
        cache.update(tag=tag, s_t=s_t, s_t_h=s_t_h.float(), z_base=z_base_dev, lb4=lb4, ub4=ub4, N=N)
        return cache

    def drop_device_resident(self):
        """Free what _device_resident cached for this fold, z_base included. Held, the next fold's
        trunk ran beside them and its pair transition was refused DRAM at c730."""
        for v in self.__dict__.pop("_dev_res", {}).values():
            if isinstance(v, ttnn.Tensor):
                ttnn.deallocate(v)

    def z_base_device(self, s_inputs, s_trunk, z_trunk):
        """Build the sample-invariant z_base = z_trunk + s1(s_inputs)[:,None] +
        s2(s_inputs)[None,:] in fp32 on host (precision-safe -- bf16-accumulating
        it on device regresses the pairformer input at small N), then upload as
        bf16 ONCE. Returned as a resident (1,N,N,256) device tensor; reuse across
        samples so the (N,N,256) upload is paid once per fold, not per sample."""
        return self.z_base_upload(self.z_base_host(s_inputs, z_trunk))

    def z_base_host(self, s_inputs, z_trunk):
        """The host half of `z_base_device`: z_base summed in fp32, then rounded to the bf16 it is
        uploaded in. torch rounds as ttnn's upload does, so the device tensor is the same, and ttnn
        tilizes bf16 several times faster than it converts fp32. fold() runs this on the host lane
        during the diffusion, so the chip no longer waits for it when the confidence head starts."""
        import torch, torch.nn.functional as F
        z_base = (z_trunk + F.linear(s_inputs, self._g("linear_no_bias_s1.weight")).unsqueeze(1)
                  + F.linear(s_inputs, self._g("linear_no_bias_s2.weight")).unsqueeze(0)).unsqueeze(0)
        return z_base.float().to(torch.bfloat16).contiguous()

    def z_base_upload(self, z_base):
        """z_base on the device, or kept on the host above `concat_host_bytes()`.

        There each sample uploads its own copy and builds its pair into it (`_pair_embed_rows`),
        so the confidence pairformer runs beside one pair tensor, as the trunk does. Resident, the
        2 GiB z_base of protenix-v2 at 2048 tokens left no single block for the distance embed's
        2 GiB sum on a 12 GiB Wormhole chip in any mode."""
        import ttnn
        if z_base.numel() * 2 > _T.concat_host_bytes():
            return z_base
        return _T.upload(z_base, ttnn.bfloat16, self.dev)

    def confidence_device(self, s_inputs, s_trunk, z_base_dev, coords, feats):
        """Device-resident confidence forward. z_base_dev is the RESIDENT bf16
        device tensor from z_base_device() (z_trunk + s1 + s2, fp32-computed once
        and uploaded once per fold). coords is a host (N_atom,3) tensor
        (per-sample). Returns the same dict as confidence(). Mirrors confidence()
        exactly except the per-sample distance-embed + Pairformer + pae/pde/
        plddt heads run on device (bf16) and only the final logits are
        downloaded -- the (N,N,256) z never round-trips per sample."""
        return self.confidence_device_samples(s_inputs, s_trunk, z_base_dev, [coords], feats)[0]

    def confidence_device_samples(self, s_inputs, s_trunk, z_base_dev, coords, feats, keep_logits=False):
        """`confidence_device` for each of `coords`. Each sample's logits are read off the chip as
        soon as it has them, and their untilize and post-processing (softmaxes, pTM/ipTM) run on
        the host lane while the chip computes the next sample instead of between them. Same values
        in the same order; only the host work moves."""
        confs = []
        for c in coords:
            logits = self._confidence_device_logits(s_inputs, s_trunk, z_base_dev, c, feats)
            reads = [hostlane.read(t) for t in logits]
            for t in logits:
                ttnn.deallocate(t)
            confs.append(hostlane.submit(self._postprocess_read, reads, self._dev_res["s_t_h"], feats, keep_logits))
        return [f.result() for f in confs]

    def _pair_embed(self, z_base, rc, dist):
        """z_base + linear_no_bias_d(onehot bins of dist) + linear_no_bias_d_wo_onehot(dist), a new
        tensor. dist is the host (1,R,N) fp32 distance block of rows of z_base."""
        d = ttnn.from_torch(dist, layout=ttnn.TILE_LAYOUT, device=self.dev, dtype=ttnn.float32)
        d3 = ttnn.unsqueeze(d, -1)                                           # (1,R,N,1)
        ge = ttnn.ge(d3, rc["lb4"])                                          # (1,R,N,39)
        lt = ttnn.lt(d3, rc["ub4"])
        oh = ttnn.typecast(ttnn.multiply(ge, lt), ttnn.bfloat16)             # AND, 0/1 exact in bf16
        d3 = ttnn.typecast(d3, ttnn.bfloat16)
        z = ttnn.add(z_base, self._dev_lin(oh, "linear_no_bias_d.weight"))
        return ttnn.add(z, self._dev_lin(d3, "linear_no_bias_d_wo_onehot.weight"))

    def _pair_embed_rows(self, z, rc, dist, rows=128):
        """`_pair_embed` written into z itself, `rows` rows at a time: block I reads only z's rows
        I, so each sum takes their place (`_T._write_rows`) and no second pair tensor exists."""
        N, C = int(z.shape[1]), int(z.shape[3])
        for r0 in range(0, N, rows):
            r1 = min(N, r0 + rows)
            zr = ttnn.slice(z, (0, r0, 0, 0), (1, r1, N, C))
            blk = self._pair_embed(zr, rc, dist[:, r0:r1].contiguous())
            ttnn.deallocate(zr)
            _T._write_rows(z, blk, r0)

    def _postprocess_read(self, reads, s_t, feats, keep_logits=False):
        """`_postprocess` of one sample's logits and pair biases as `hostlane.read` returned them; the single
        track runs here (`_s_path`) from the head's input s_t."""
        pae, pde, *biases = (torch.Tensor(h.to_torch()) for h in reads)
        N = s_t.shape[0]
        return self._postprocess(pae.float().reshape(N, N, -1), pde.float().reshape(N, N, -1),
                                 self._plddt_logits(self._s_path(s_t, biases), feats), feats, keep_logits)

    def _confidence_device_logits(self, s_inputs, s_trunk, z_base_dev, coords, feats):
        """The device half of `confidence_device`: enqueued, not read. Returns the pae and pde
        logits (1,N,N,64) and the pairformer's fp32 single track (N,384) on the device, still in
        their device shapes (a tiled reshape would move data the host reshape does not); the plddt
        head runs on the host from the latter (`_plddt_logits`)."""
        import torch, ttnn
        # Tapped because the trunk and the diffusion stream are, and this was not: three AbAg-XM
        # targets fail ~1300 s in, long after the trunk, at refused sizes that match no trunk
        # tensor. Without a tag here the last thing TT_BIO_DRAM_PEAK reports is the final edm
        # step, which cannot distinguish "died in confidence" from "died after it".
        dram_peak("confidence: enter")
        rc = self._device_resident(s_inputs, s_trunk, z_base_dev, feats)
        N = rc["N"]
        dram_peak(f"confidence: resident built [N={N}]")
        # ---- per-sample distance-embed on device ----
        # The distances are the host path's own fp32 cdist. In bf16 on the device, |x|^2 + |y|^2 -
        # 2 x.y cancels: 40 A from the origin |x|^2 is ~1600, where bf16 steps by 8 A^2, so a 3.8 A
        # neighbour pair (14.4 A^2) came out anywhere from 0 to ~5 A and pLDDT fell 0.046 at c730.
        xr = coords.float().reshape(-1, 3)[feats["distogram_rep_atom_mask"].bool()]
        dist = torch.cdist(xr, xr).reshape(1, N, N)
        if isinstance(rc["z_base"], torch.Tensor):                           # held on the host
            z = _T.upload(rc["z_base"], ttnn.bfloat16, self.dev)
            self._pair_embed_rows(z, rc, dist)
        else:
            z = self._pair_embed(rc["z_base"], rc, dist)
        # ---- confidence Pairformer: the pair track on the device, its blocks' pair biases for `_s_path` ----
        so, zo = bucketed_pairformer(self.pf, ttnn.clone(rc["s_t"]), z, self.dev)  # (1,N,384),(1,N,N,c_z)
        ttnn.deallocate(so)
        biases = self._take_biases()
        # ---- heads on device ----
        zof = ttnn.reshape(zo, (1, N, N, zo.shape[-1]))                      # c_z: 256 v2, 128 v1
        pae_ln = ttnn.layer_norm(zof, weight=self._wtt("pae_ln.weight", False),
                                 bias=(self._wtt("pae_ln.bias", False) if "pae_ln.bias" in self._w else None),
                                 epsilon=1e-5, compute_kernel_config=self.compute_kernel_config)
        pae_logits = self._dev_lin(pae_ln, "linear_no_bias_pae.weight")      # (1,N,N,64)
        ttnn.deallocate(pae_ln)
        zot = ttnn.permute(zof, (0, 2, 1, 3))                                # transpose token axes
        # The symmetrising add feeds nothing but this norm, so it folds into the norm's
        # own kernel (tt_bio/eltwise_fusion.py).
        pde_ln = norm_residual(zof, zot, weight=self._wtt("pde_ln.weight", False),
                               bias=(self._wtt("pde_ln.bias", False) if "pde_ln.bias" in self._w else None),
                               epsilon=1e-5, compute_kernel_config=self.compute_kernel_config)
        pde_logits = self._dev_lin(pde_ln, "linear_no_bias_pde.weight")      # (1,N,N,64)
        for t in (pde_ln, zot, zof):
            ttnn.deallocate(t)
        dram_peak("confidence: heads done, before download")
        # ---- the logits and biases are downloaded; the caller runs the single track and plddt on the host ----
        return (pae_logits, pde_logits, *biases)

    def _postprocess(self, pae_logits, pde_logits, plddt_logits, feats, keep_logits=False):
        """Shared host-side post-processing: softmax over bins -> expected
        distance (pae/pde) and expected plddt; pTM/ipTM from the pae logits.
        Identical to the tail of confidence() so device/host paths share it.
        keep_logits also returns the three logit tensors (fp32, host), which the upstream
        output writer (tt_bio.protenix_output) reads; two (N,N,64) per sample, so opt-in."""
        import torch

        def _expected(probs, max_a=32.0):
            nb = probs.shape[-1]
            return probs @ ((torch.arange(nb, dtype=torch.float32) + 0.5) / nb * max_a)
        # One softmax of the pae logits feeds pae, pTM/ipTM and the chain keys, and every bin
        # reduction is a matmul: the broadcast multiply-sum and the (N,N,nb) subsets cost ~1 s
        # per c730 sample on the host, which the chip waited for after its last sample.
        probs = torch.softmax(pae_logits.float(), -1)
        pae = _expected(probs)
        pde = _expected(torch.softmax(pde_logits.float(), -1))
        ptm, iptm = self._ptm_iptm(pae_logits, feats.get("asym_id"), probs=probs)
        plddt_atom = _expected(torch.softmax(plddt_logits.float(), -1), 1.0)
        out = {"plddt": float(plddt_atom.mean()), "plddt_atom": plddt_atom, "pae": pae, "pde": pde,
               "ptm": ptm, "iptm": iptm}
        out.update(self._chain_confidence(pae_logits, feats.get("asym_id"), probs=probs))
        if keep_logits:
            out.update(pae_logits=pae_logits.float(), pde_logits=pde_logits.float(),
                       plddt_logits=plddt_logits.float())
        return out

    @staticmethod
    def _ptm_iptm(pae_logits, asym_id, max_a: float = 32.0, has_frame=None, probs=None):
        """Predicted TM-score (pTM) and interface pTM (ipTM) from the PAE bin logits,
        the standard AlphaFold formula. pTM = max over alignment frame i of the mean
        predicted TM to all tokens j; ipTM restricts j to *other* chains (via asym_id).
        Returns (ptm, iptm); iptm is 0.0 for single-chain inputs.

        ``has_frame`` is the per-token mask of tokens that actually HAVE an alignment
        frame, and both reductions are a max over i, so a token without one can win the
        max and set the score. AlphaFold's Eq. 17 takes the max over frames, not over
        tokens; upstream OpenFold3 spells that out by zeroing a frameless row before the
        max (``core/metrics/confidence.py:154``) and builds the mask from the predicted
        coordinates with ``get_token_frame_atoms``. It rejects three kinds of token: an
        ATOMIZED one -- a ligand or a modified residue -- whose three frame atoms subtend
        an angle outside [25, 155] degrees, one with a frame atom missing, and one whose
        three frame atoms are not all in the same chain.

        Default ``None`` means "every token has a frame", which is what this function
        assumed before the argument existed. That is exactly right for a structure of
        standard residues, where upstream's mask is all-ones by construction, and it is
        why the four models that do not pass one are unchanged: measured 0.0 difference on
        a monomer and on an all-standard two-chain complex, against upstream's own
        ``compute_ptm`` in float64 (``perf/of3t_d10_d107/d10_rule_vs_upstream.py``). With
        eight frameless tokens in that same complex the mask is worth 3.853e-03 on pTM and
        reorders the samples.

        ``probs`` is ``softmax(pae_logits)`` when the caller already has it.
        """
        import torch

        N, _, nb = pae_logits.shape
        centers = (torch.arange(nb, dtype=torch.float32) + 0.5) * (max_a / nb)
        if probs is None:
            probs = torch.softmax(pae_logits.float(), -1)                   # (N,N,nb)
        n = max(N, 19)
        d0 = 1.24 * (n - 15) ** (1.0 / 3.0) - 1.8
        tm_per_bin = 1.0 / (1.0 + (centers / d0) ** 2)                      # (nb,)
        e_tm = probs @ tm_per_bin                                           # (N,N) E[TM] per pair
        frame = (None if has_frame is None else
                 has_frame.reshape(-1).bool().to(e_tm.device))
        if frame is not None and frame.numel() != N:
            raise ValueError(
                f"has_frame has {frame.numel()} entries for {N} tokens. A frame mask that "
                f"does not line up with the PAE axis would silently mask the wrong tokens")

        def _max_over_frames(row, mask):
            # Upstream zeroes the row rather than dropping it, and E[TM] is non-negative,
            # so the two forms agree -- including when every token is masked, where both
            # give 0.0.
            return float(row.masked_fill(~mask, 0.0).max() if mask is not None
                         else row.max())

        ptm = _max_over_frames(e_tm.mean(dim=-1), frame)
        iptm = 0.0
        if asym_id is not None:
            a = asym_id.long().reshape(-1)
            if a.numel() == N and int(a.unique().numel()) > 1:
                cross = a[:, None] != a[None, :]                           # (N,N) different-chain
                denom = cross.sum(dim=-1).clamp(min=1)
                row = (e_tm * cross.float()).sum(dim=-1) / denom
                # A token with no cross-chain partner contributes 0 to upstream's max (its
                # numerator is empty), so restricting to `valid` here is the same reduction
                # written the other way round. The frame mask has to be subset with it.
                valid = cross.any(dim=-1)
                iptm = (_max_over_frames(row[valid],
                                         None if frame is None else frame[valid])
                        if bool(valid.any()) else 0.0)
        return round(ptm, 6), round(iptm, 6)

    @staticmethod
    def _chain_confidence(pae_logits, asym_id, max_a: float = 32.0, centers=None, has_frame=None,
                          probs=None):
        """The chain-level confidence keys, protenix's `calculate_chain_based_ptm`.

        `chain_ptm[c]` is pTM computed inside chain c alone, so its TM normalisation uses that
        chain's own token count rather than the complex's -- which is why it cannot be read off
        the global pTM. `chain_iptm[c]` averages, over the chain pairs that involve c, the ipTM
        of that pair computed on those two chains alone; for a two-chain complex both chains
        therefore carry the same number. A binder filter reads exactly these two, as
        `ptm_binder` and `iptm_binder`. Both lists are indexed by the sorted unique `asym_id`,
        so the binder is the last entry when the binder is the last chain.

        `pair_chains_iptm[i][j]` (i, j = chain positions 0, 1, ...) is the matrix both reductions are taken over, kept instead of
        dropped: selectivity-aware scoring and hallucination score one named interface of a
        multi-chain complex, which a per-chain average cannot express. It is the FULL square
        matrix, diagonal included -- Boltz-2's shape, whose writer reads `pci[i][i]` for
        `chains_ptm` (`tt_bio.main._pair_chains`), so one consumer reads either model. The
        diagonal is that chain's own `chain_ptm`. Every entry carries protenix's per-subset TM
        normalisation, so the numbers are comparable within a model and not across models,
        exactly as the global pTM/ipTM already are. None of it is new computation.

        Returns `{}` when there are no chain pairs (single chain, or no `asym_id`).

        OpenFold3, OpenBind-0 and RF3 reduce their own PAE logits through this too, so every
        model on the platform reports the matrix the same way. `centers` overrides the uniform
        bin centres for a head binned otherwise (RF3's `bin_midpoints`), and `has_frame` [N] is
        the frame mask their global pTM/ipTM take the max over: a token without an alignment
        frame (an atomized ligand atom that fails the angle test) cannot win a row max here
        either. None means every token has a frame, which holds for standard residues.
        ``probs`` is ``softmax(pae_logits)`` when the caller already has it.
        """
        import torch

        if asym_id is None:
            return {}
        a = asym_id.long().reshape(-1)
        ids = [int(x) for x in torch.unique(a)]
        if a.numel() != pae_logits.shape[0] or len(ids) < 2:
            return {}
        nb = pae_logits.shape[-1]
        if centers is None:
            centers = (torch.arange(nb, dtype=torch.float32) + 0.5) * (max_a / nb)
        if probs is None:
            probs = torch.softmax(pae_logits.float(), -1)
        frame = (torch.ones(a.numel(), dtype=torch.bool) if has_frame is None
                 else has_frame.bool().reshape(-1))

        # E[TM] depends on a subset only through its token count (the TM normalisation), so the
        # bins are reduced once per distinct count over the whole (N,N), and each subset slices
        # the (N,N) result: nb times less to copy than slicing the probabilities.
        e_tm = {}

        def pair_tm(mask):
            """E[TM] per token pair, restricted to `mask` and normalised on its own count."""
            n = max(int(mask.sum()), 19)
            if n not in e_tm:
                d0 = 1.24 * (n - 15) ** (1.0 / 3.0) - 1.8
                e_tm[n] = probs @ (1.0 / (1.0 + (centers / d0) ** 2))
            return e_tm[n][mask][:, mask]

        def row_max(row, mask):
            # Zeroing a frameless row is upstream's form; E[TM] >= 0, so it cannot win.
            return float(row.masked_fill(~frame[mask], 0.0).max())

        chain_ptm = [row_max(pair_tm(a == c).mean(dim=-1), a == c) for c in ids]
        pair = {(c, c): p for c, p in zip(ids, chain_ptm)}     # diagonal: the chain's own pTM
        for i, ci in enumerate(ids):
            for cj in ids[i + 1:]:
                m = (a == ci) | (a == cj)
                cross = (a[m][None, :] != a[m][:, None])
                row = (pair_tm(m) * cross).sum(-1) / (1e-8 + cross.sum(-1))
                pair[ci, cj] = pair[cj, ci] = row_max(row, m)
        chain_iptm = [sum(pair[c, o] for o in ids if o != c) / (len(ids) - 1) for c in ids]
        # Keyed by chain position, not by the asym_id value: OpenFold3's asym_id starts at 1.
        return {"chain_ptm": [round(x, 6) for x in chain_ptm],
                "chain_iptm": [round(x, 6) for x in chain_iptm],
                "pair_chains_iptm": {i: {j: round(pair[ci, cj], 6) for j, cj in enumerate(ids)}
                                     for i, ci in enumerate(ids)}}

    def plddt(self, s_inputs, s_trunk, z_trunk, coords, feats):
        """Mean pLDDT in [0,1] (back-compat thin wrapper over confidence())."""
        return self.confidence(s_inputs, s_trunk, z_trunk, coords, feats)["plddt"]


# Byte gate for the row-blocked DiffusionConditioning pair chain in _diffusion_pair_cond.
# The unblocked chain holds the LN'd z ([Ns,Ns,c_z]) and the channel concat ([Ns,Ns,c_z'+128])
# full-size; on a churned Wormhole heap those are the requests that get refused (measured:
# 9i3p's [1902,1920,256] bf16 = 1.87 GiB concat refused at 7.5 GiB used / 4.5 free). 9ivj
# (2.27 GiB z) folds unblocked with 2.4 GiB headroom; 9i3p (2.61) does not, so the gate sits
# at 2.5 GiB and only the two largest structural-scale cells take the blocked path. Every op
# in the chain is row-local (layer_norm/linear per position, channel concat), so the blocks
# are in the same tile-replan equivalence class as the chunked pair track.
PAIRCOND_BLOCK_BYTES = int(os.environ.get("TT_BIO_PAIRCOND_BLOCK_BYTES", 5 * 2 ** 28))  # 2.5 GiB

#: The diffusion pair-conditioning projections never force ``core_grid``. Passing a core grid
#: selects ttnn's 1D in1-multicast matmul, and on these N*N-row fp32 projections (fp32 dest, packer
#: L1 accumulation) one core's compute intermittently stalls and every other core waits on it
#: through the in1 multicast handshake. It was first caught on protenix-v1's 4-tile projection
#: (perf/pxv1/hang_watcher_capture.txt; 24/24 folds clean without the grid against 7/24 with it)
#: and then on protenix-v2's 8-tile one, so it is not a width effect. Measured on qb2 chip 3,
#: 2026-10-14, with perf/spd/nocdeadlock/paircond_repro.py at 730 tokens: the forced grid hung
#: within 50 calls, without it 1000/1000 ran clean, and with the grid but packer_l1_acc off also
#: 1000/1000 (that arm loses precision, so it is not the fix). Upstream: tt-metal#58653.
#: PROTENIX_PAIRCOND_MM_FORCE_GRID=1 restores the forced grid for A/B or bisection.


def paircond_mm_kw(compute_kernel_config, dtype):
    """ttnn.linear kwargs for a diffusion pair-conditioning projection.

    ONE place decides the ``core_grid`` policy for every projection in that branch (relpe, the
    OpenDDE z_trunk compression and linear_no_bias_z, each on the whole and the row-blocked path),
    so no twin of a fixed call keeps the old program.
    """
    kw = dict(compute_kernel_config=compute_kernel_config, dtype=dtype)
    if env_flag("PROTENIX_PAIRCOND_MM_FORCE_GRID", False):
        kw["core_grid"] = CORE_GRID_MAIN
    return kw


def _pz_cond_probe(pz, z_in_sha):
    """TT_PROTENIX_PZPROBE=<dir> (default off): attribute run-to-run pair_z divergence.
    Reads the just-written device pz back TWICE and records shas of the z_trunk input and
    pz. z_in differs across runs -> seed is upstream (trunk). z_in same, pz differs across
    runs, readback_equal -> the cond-prep compute is racy. readback not equal -> the DRAM
    readback of those addresses is not stable. Returns the first readback (host, fp32)."""
    out = os.environ.get("TT_PROTENIX_PZPROBE")
    if not out:
        return Protenix._to_host(pz)
    import hashlib
    import json
    import pathlib

    import torch

    r1 = ttnn.to_torch(pz)
    r2 = ttnn.to_torch(pz)
    eq = bool(torch.equal(r1, r2))
    b1 = r1.to(torch.float32).numpy().tobytes()
    rec = {
        "z_in_sha16": z_in_sha,
        "pz_sha16": hashlib.sha256(b1).hexdigest()[:16],
        "readback_equal": eq,
        "readback_maxdiff": 0.0 if eq else float((r1.float() - r2.float()).abs().max()),
        "pz_absmax": float(r1.float().abs().max()),
    }
    p = pathlib.Path(out)
    p.mkdir(parents=True, exist_ok=True)
    (p / "pz_cond_probe.json").write_text(json.dumps(rec, indent=2))
    return r1.float()




class Protenix:
    """Top-level Protenix-v2 structure predictor on Tenstorrent (inference-only).

    fold(feats) composes the validated submodules into the full forward:
      InputFeatureEmbedder atom encoder      -> s_inputs (per-token, c_s_inputs=449)
      diffusion atom-cache (AtomFeaturization) -> c_l, p_lm  (t-independent)
      Trunk (10-cycle recycling)             -> s_trunk, z_trunk
      EDM ancestral sampler (edm_sample, DiffusionModule denoiser) -> atom coords

    Every submodule is validated on-device vs the real v2 reference in
    tests/test_protenix*.py; the full diffusion is
    validated end-to-end (sampler draws structures within the reference's sample
    variance). feats is a dict of model-ready tensors (from the v2 data pipeline)."""

    def __init__(self, model_state_dict, compute_kernel_config, device=None, c_z=None,
                 msa_update_first=False, diffusion_fp32=None, gated_move=False,
                 softmax_scope="protenix", levers=None, size_levers=()):
        """diffusion_fp32: explicit per-instantiation override for the coordinate-sensitive
        diffusion stack's precision; None falls back to PROTENIX_DIFFUSION_FP32_DEVICE (default
        fp32). Callers that share this class across models (e.g. OpenDDE) should pass this
        explicitly rather than rely on the env-var default, which is scoped to Protenix-v2.

        softmax_scope: which model owns the two Pairformer construction sites this class builds
        (the 48-block trunk and the confidence head). OpenDDE instantiates this class, so those
        sites are shared, and per-construction-site alone would tie an OpenDDE softmax decision
        to Protenix-v2's. Same hazard as diffusion_fp32 above, same fix: the caller names itself.

        levers: the precision levers (`tenstorrent.LEVERS`) this model builds and folds under,
        active only inside its own build and fold. `load_from_checkpoint` passes the mode's set,
        and then `--fast` means those levers and nothing else. None is the empty set.
        size_levers: added to them for a target that pads to `SIZE_LEVERS_MIN_TOKENS` or more (`size_levers`)."""
        import tt_bio.tenstorrent as _TT
        self._levers = _TT.parse_levers(levers or ())
        self._size_levers = frozenset(size_levers) - self._levers
        with _TT.levers(self._levers, also=self._size_levers):
            self._build(model_state_dict, compute_kernel_config, device, c_z, msa_update_first,
                        diffusion_fp32, gated_move, softmax_scope)

    def _build(self, model_state_dict, compute_kernel_config, device, c_z, msa_update_first,
               diffusion_fp32, gated_move, softmax_scope):
        from .tenstorrent import get_device
        import tt_bio.tenstorrent as _TT
        self._w = model_state_dict
        # The `lofi` / `acc_off` levers reach every stage through this one config.
        compute_kernel_config = _TT.lpx_compute_kernel_config(compute_kernel_config)
        self.compute_kernel_config = compute_kernel_config
        self.dev = device or get_device()
        self._c_z = c_z
        # Pair-conditioning shapes DRAM refused whole -> the rows they settled at.
        self._paircond_rows_refused: dict = {}
        def under(pfx):
            return {k[len(pfx):]: v for k, v in self._w.items() if k.startswith(pfx)}
        resolved_diffusion_fp32 = (env_flag("PROTENIX_DIFFUSION_FP32_DEVICE", True)
                                   if diffusion_fp32 is None else diffusion_fp32)
        if diffusion_fp32 is None and _TT.lever("diffusion_bf16"):
            resolved_diffusion_fp32 = False
        # `--fast` is the lever set, not the global bfp8 flag: build every stage with it off.
        _TT.set_fast_mode(False)
        self.input_aae = AtomAttentionEncoder(under("input_embedder.atom_attention_encoder."), compute_kernel_config)
        diffusion_dtype = ttnn.float32 if resolved_diffusion_fp32 else ttnn.bfloat16
        self.diff_feat = AtomFeaturization(under("diffusion_module.atom_attention_encoder."),
                                            compute_kernel_config, dtype=diffusion_dtype)
        # The trunk gets its OWN compute kernel config, so its matmul fidelity cannot reach the
        # diffusion module, which runs fp32 on purpose and does need all four mantissa passes.
        self.trunk = Trunk(model_state_dict, _TT.trunk_compute_kernel_config(compute_kernel_config),
                           c_z=self._c_z, msa_update_first=msa_update_first,
                           gated_move=gated_move, softmax_scope=softmax_scope)
        self.diffusion = DiffusionModule(under("diffusion_module."), self.dev, compute_kernel_config,
                                          diffusion_fp32=resolved_diffusion_fp32)
        self.confidence_head = ConfidenceHead(under("confidence_head."), self.dev,
                                              compute_kernel_config, gated_move=gated_move,
                                              softmax_scope=softmax_scope)

    @classmethod
    def load_from_checkpoint(cls, path, compute_kernel_config=None, device=None, diffusion_fp32=None,
                             levers=None):
        """Load a v2 checkpoint (.pt) and build the model. Untrusted weights are read
        with weights_only=True. diffusion_fp32 is the per-run precision (`--diffusion_precision`);
        None keeps the mode's default (fp32 unless PROTENIX_DIFFUSION_FP32_DEVICE=0, bf16 under
        the `diffusion_bf16` lever). levers: None takes the mode's set for this checkpoint (`mode_levers`). A harness grading a lever set through the serving
        path sets TT_BIO_LEVERS (`parse_levers` grammar, e.g. `fast-lofi`); no user does."""
        import tt_bio.tenstorrent as _TT
        import torch
        import ttnn
        from .tenstorrent import get_device
        dev = device or get_device()
        ckc = compute_kernel_config or ttnn.init_device_compute_kernel_config(
            dev.arch(), math_fidelity=ttnn.MathFidelity.HiFi4, fp32_dest_acc_en=True, packer_l1_acc=True)
        ck = torch.load(path, map_location="cpu", weights_only=True)
        ck = ck.get("model", ck)
        sd = {k[len("module."):] if k.startswith("module.") else k: v for k, v in ck.items()}
        from .mol1_constraint import fold_weights
        fold_weights(sd)
        # gated_move=True: the E6 fused chunk+gate forward move serves 2416 of 2416 trimul
        # channel moves at c_z=256 and is torch.equal to the sequence it replaces, so it is
        # the shipped path. Scoped to this entry point -- OpenDDE builds Protenix directly
        # and passes its own flag.
        size = ()
        if levers is None:
            levers, size = mode_levers(sd), size_levers(sd)
        return cls(sd, ckc, dev, gated_move=True, diffusion_fp32=diffusion_fp32, levers=levers, size_levers=size)

    def _tt(self, x):
        return _T.upload(x, ttnn.bfloat16, self.dev)

    @staticmethod
    def _to_host(t, shape=None, fp32=True):
        """Download a device tensor to host. `fp32=False` keeps the bf16 the device held, for
        call sites whose consumers only cast it back (the OpenDDE z_trunk seam): bf16 -> fp32 is
        lossless, so the upcast is 402 MB of host writes that buy nothing. Default stays fp32."""
        import torch
        h = torch.Tensor(_T.download(t))
        if fp32:
            h = h.float()
        return h.reshape(shape) if shape is not None else h

    @staticmethod
    def _generate_relp(feats, r_max=32, s_max=2):
        """RelativePositionEncoder feature (reference embedders.generate_relp): one-hot of
        clipped residue/token/chain offsets + same-entity. dims 2(r_max+1)+2(r_max+1)+1+
        2(s_max+1) = 139. Model-side; lets the data pipeline emit only the index features."""
        import torch
        import torch.nn.functional as F
        asym = feats["asym_id"].long(); res = feats["residue_index"].long()
        ent = feats["entity_id"].long(); tok = feats["token_index"].long(); sym = feats["sym_id"].long()
        sc = (asym[:, None] == asym[None, :]).long()
        sr = (res[:, None] == res[None, :]).long()
        se = (ent[:, None] == ent[None, :]).long()
        d_res = torch.clip(res[:, None] - res[None, :] + r_max, 0, 2 * r_max) * sc + (1 - sc) * (2 * r_max + 1)
        d_tok = torch.clip(tok[:, None] - tok[None, :] + r_max, 0, 2 * r_max) * sc * sr + (1 - sc * sr) * (2 * r_max + 1)
        d_ch = torch.clip(sym[:, None] - sym[None, :] + s_max, 0, 2 * s_max) * se + (1 - se) * (2 * s_max + 1)
        if not _RELP_SCATTER:
            RELP_STATS[1] += 1
            return torch.cat([F.one_hot(d_res, 2 * (r_max + 1)), F.one_hot(d_tok, 2 * (r_max + 1)),
                              se[..., None], F.one_hot(d_ch, 2 * (s_max + 1))], dim=-1).float()
        # Same result, built directly in fp32. `F.one_hot` on an int64 index returns int64, so the
        # cat above materialises 2.6 GB of int64 for a 550 MB fp32 answer at Ns=995; scattering into
        # the result touches only the 550 MB. Bit-exact by construction: every value written is 0.0
        # or 1.0 at exactly the column one_hot would have set. MEASURED torch.equal True at both
        # axes, 0.329 s/fold at 512 aa (perf/oddeb200/screen_hostglue.json).
        RELP_STATS[0] += 1
        d1 = 2 * (r_max + 1)
        out = torch.zeros(*d_res.shape, 2 * d1 + 1 + 2 * (s_max + 1))
        out.scatter_(-1, d_res.unsqueeze(-1), 1.0)
        out.scatter_(-1, (d_tok + d1).unsqueeze(-1), 1.0)
        out[..., 2 * d1] = se.to(out.dtype)
        out.scatter_(-1, (d_ch + 2 * d1 + 1).unsqueeze(-1), 1.0)
        return out

    @staticmethod
    def _atom_pair_feats(ref_pos, ref_space_uid, n_real=None):
        """Algorithm 5 lines 1-3 (reference update_input_feature_dict): windowed atom-pair
        feats from ref_pos + ref_space_uid (NQ=32, NK=128, pad_left=48). Validated vs the
        reference (d_lm exact, v_lm/mask exact). Returns d_lm (nb,NQ,NK,3), v_lm (nb,NQ,NK,1),
        mask_trunked (nb,NQ,NK). n_real: atoms past it are padding (zero position, uid 0, the
        values the reference pads with) and the mask drops them as queries and keys."""
        import torch
        import torch.nn.functional as F
        N = ref_pos.shape[0]; NQ, NK, PADL = 32, 128, 48
        R = N if n_real is None else n_real
        nb = (N + NQ - 1) // NQ; NP = nb * NQ; qpad = NP - N
        ruid = ref_space_uid.long()
        qpos = F.pad(ref_pos.float(), (0, 0, 0, qpad)).reshape(nb, NQ, 3)
        quid = F.pad(ruid, (0, qpad), value=0).reshape(nb, NQ)              # pad value 0 (reference)
        pad_right = int((nb - 0.5) * NQ + NK / 2 - N + 0.5)
        kpos_p = F.pad(ref_pos.float(), (0, 0, PADL, pad_right))
        kuid_p = F.pad(ruid, (PADL, pad_right), value=0)
        kpos = torch.stack([kpos_p[b * NQ:b * NQ + NK] for b in range(nb)], 0)   # (nb,NK,3)
        kuid = torch.stack([kuid_p[b * NQ:b * NQ + NK] for b in range(nb)], 0)   # (nb,NK)
        d_lm = qpos[:, :, None, :] - kpos[:, None, :, :]                         # (nb,NQ,NK,3)
        v_lm = (quid[:, :, None] == kuid[:, None, :]).float().unsqueeze(-1)      # (nb,NQ,NK,1)
        qidx = torch.arange(NP).reshape(nb, NQ); qval = (qidx < R).float()
        kglob = torch.stack([torch.arange(b * NQ - PADL, b * NQ - PADL + NK) for b in range(nb)], 0)
        kval = ((kglob >= 0) & (kglob < R)).float()
        mask_trunked = qval[:, :, None] * kval[:, None, :]                      # (nb,NQ,NK)
        return d_lm, v_lm, mask_trunked

    @staticmethod
    def _pair_feat_rows(d_lm, v_lm):
        """The windowed pair feats as the (nb*nq*nk, *) rows AtomFeaturization.p_lm reads."""
        d = d_lm.reshape(-1, 3)
        return d, v_lm.reshape(-1, 1), 1.0 / (1.0 + (d ** 2).sum(-1, keepdim=True))

    def _embedder_atoms(self, feats, fi):
        """Host inputs of the input embedder's atom encoder (`input_aae`), the atom axis padded
        to `bounded_rows(N)`. Every op in that encoder compiles per atom count, so a raw count
        compiled a fresh set of kernels for each protein new to a host (~13 s of an OpenDDE fold
        on WH). Padded atoms carry zero features and mask, the pair mask drops them as queries
        and keys, and the atom->token mean gives them zero weight; the output is per token, so
        nothing after the encoder sees them. Returns (device args, host mask_trunked, Mmat)."""
        import torch.nn.functional as F
        N, S = fi["N"], fi["S"]
        Mmat = S.t() / (S.t().sum(-1, keepdim=True) + 1e-6)
        atoms = [feats["ref_pos"], fi["ref_charge_asinh"], feats["ref_mask"].reshape(N, 1), fi["f_in"]]
        NA = bounded_rows(N)
        if NA == N or "d_lm" in feats:
            return atoms + [fi["d"], fi["v"], fi["invd"]], fi["mt"], Mmat
        atoms = [F.pad(x, (0, 0, 0, NA - N)) for x in atoms]
        d_lm, v_lm, mt = self._atom_pair_feats(atoms[0], F.pad(feats["ref_space_uid"], (0, NA - N)),
                                               n_real=N)
        return atoms + list(self._pair_feat_rows(d_lm, v_lm)), mt.float(), F.pad(Mmat, (0, NA - N))

    def _atom_feat_inputs(self, feats):
        """Build the per-atom feature tensors shared by both atom encoders. Accepts the
        canonical protenix input_feature_dict: d_lm/v_lm/mask_trunked are computed from
        ref_pos + ref_space_uid (model-side, Algorithm 5) when not already provided."""
        import torch
        N = feats["ref_pos"].shape[0]
        f_in = torch.cat([feats["ref_mask"].reshape(N, 1), feats["ref_element"].reshape(N, 128),
                          feats["ref_atom_name_chars"].reshape(N, 256)], dim=-1)
        if "d_lm" in feats and "v_lm" in feats:
            d_lm, v_lm = feats["d_lm"], feats["v_lm"]
            mt = feats.get("mask_trunked")
            if mt is None:
                mt = feats["pad_info"]["mask_trunked"]
        else:
            d_lm, v_lm, mt = self._atom_pair_feats(feats["ref_pos"], feats["ref_space_uid"])
        nb, nq, nk, _ = d_lm.shape
        d, v, invd = self._pair_feat_rows(d_lm, v_lm)
        a2t = feats["atom_to_token_idx"].long(); NT = int(a2t.max()) + 1
        S = torch.zeros(N, NT); S[torch.arange(N), a2t] = 1.0
        return dict(N=N, NT=NT, nb=nb, nq=nq, nk=nk, f_in=f_in, d=d, v=v, invd=invd,
                    mt=mt.float(), a2t=a2t, S=S, ref_charge_asinh=torch.arcsinh(feats["ref_charge"]).reshape(N, 1))

    def _diffusion_pair_cond(self, z_trunk_tt, relp, device=False):
        """DiffusionConditioning pair branch (computed once; t-independent):
        zc = LN(concat[z_trunk, relpe(relp)]); pz = linear_z(zc); pz += transition_z1 +
        transition_z2. Reference diffusion_module.diffusion_conditioning. Validated
        PCC ~1.0 (scripts/protenix_diffcond_parity.py). Returns conditioned pair_z host, and
        frees `z_trunk_tt`, whose only reader this is.

        When c_z_pair_diffusion < c_z (OpenDDE: pair-diffusion channel compressed to 128 vs
        the shared Trunk's c_z=384; Protenix-v2 keeps them equal, 256==256, no compression),
        the reference (DiffusionConditioning.prepare_cache / compress_pair_z) first LN+projects
        z_trunk down to c_z_pair_diffusion via layernorm_z_trunk/linear_no_bias_z_trunk, BEFORE
        concatenating with relpe -- gated on those keys' presence so Protenix-v2 is unchanged."""
        from .tenstorrent import Transition
        C = "diffusion_module.diffusion_conditioning."
        T = self.diffusion._up
        _z_sha = None
        if os.environ.get("TT_PROTENIX_PZPROBE"):
            import hashlib as _hl

            _z_sha = _hl.sha256(ttnn.to_torch(z_trunk_tt).to(torch.float32).numpy().tobytes()).hexdigest()[:16]
        _pcdbg = os.environ.get("TT_PROTENIX_PAIRCOND_DEBUG")
        if _pcdbg:
            import pathlib as _pl
            _d = _pl.Path(os.environ.get("TT_PROTENIX_PAIRCOND_DEBUG_DIR", "/tmp/issue9"))
            _d.mkdir(parents=True, exist_ok=True)
            torch.save({"z_trunk": ttnn.to_torch(z_trunk_tt), "relp": relp,
                        "dtype": str(self.diffusion.dtype)},
                       _d / "paircond_inputs.pt")
            print(f"[pcdbg] dumped paircond inputs shape={tuple(z_trunk_tt.shape)} "
                  f"dtype={self.diffusion.dtype}", flush=True)

        def _sync(tag):
            if _pcdbg:
                ttnn.synchronize_device(self.dev)
                with open(os.path.join(os.environ.get("TT_PROTENIX_PAIRCOND_DEBUG_DIR", "/tmp/issue9"),
                                       "pcdbg_markers.log"), "a") as _f:
                    _f.write(f"{tag} done\n")

        _w_relpe = self._w[C + "relpe.linear_no_bias.weight"]
        w_relpe = T(_w_relpe.t().contiguous())
        N, W = int(relp.shape[0]), int(relp.shape[1])
        z_in = z_trunk_tt
        z_trunk_tt = ttnn.reshape(z_trunk_tt, (N, W, -1))
        cz = int(z_trunk_tt.shape[-1])
        compress = C + "linear_no_bias_z_trunk.weight" in self._w
        transitions = []
        for nm in ("transition_z1", "transition_z2"):
            sub = {k[len(C + nm + "."):]: v for k, v in self._w.items() if k.startswith(C + nm + ".")}
            transitions.append((nm, Transition(PW.remap_transition(sub), self.compute_kernel_config,
                                               dtype=self.diffusion.dtype)))

        def _relpe(rp):
            out = ttnn.linear(T(rp), w_relpe,
                              **paircond_mm_kw(self.compute_kernel_config, self.diffusion.dtype))
            _sync("relpe linear")
            return out

        def _cast(zt):
            if not self.diffusion._diffusion_fp32 or zt.dtype == self.diffusion.dtype:
                return zt
            out = ttnn.typecast(zt, self.diffusion.dtype)
            _sync("typecast")
            return out

        def _z_proj(zt):
            # OpenDDE's compression of z_trunk to c_z_pair_diffusion (see the docstring).
            zn = ttnn.layer_norm(zt, weight=T(self._w[C + "layernorm_z_trunk.weight"]),
                                 epsilon=1e-5, compute_kernel_config=self.compute_kernel_config)
            _w_zt = self._w[C + "linear_no_bias_z_trunk.weight"]
            out = ttnn.linear(zn, T(_w_zt.t().contiguous()),
                              **paircond_mm_kw(self.compute_kernel_config, self.diffusion.dtype))
            ttnn.deallocate(zn)
            return out

        def _cond(zt, rp):
            zc = ttnn.concat([zt, rp], dim=-1)
            _sync("concat")
            zc = ttnn.layer_norm(zc, weight=T(self._w[C + "layernorm_z.weight"]), epsilon=1e-5,
                                 compute_kernel_config=self.compute_kernel_config)
            _sync("layernorm_z")
            # No forced core grid: see paircond_mm_kw for the multicast deadlock this avoids.
            _w_z = self._w[C + "linear_no_bias_z.weight"]
            pb = ttnn.linear(zc, T(_w_z.t().contiguous()),
                             **paircond_mm_kw(self.compute_kernel_config, self.diffusion.dtype))
            ttnn.deallocate(zc)
            _sync("linear_z")
            return pb

        def _chain(zt, rp):
            """cast, compress, concat + LN + projection, both transitions: every step is
            per (i, j) position, so a row block of the output is this chain on that block."""
            zf = _cast(zt)
            zp = _z_proj(zf) if compress else zf
            _sync("z_trunk LN+proj")
            if zf is not zt and zp is not zf:
                ttnn.deallocate(zf)
            relpe = _relpe(rp)
            pz = _cond(zp, relpe)
            ttnn.deallocate(relpe)
            if zp is not zt:
                ttnn.deallocate(zp)
            # keep the pair tensor 4D (1,n,N,c) so Transition uses its chunked H/W path
            # (the 3D path doesn't chunk pair tensors -> OOM at large N).
            pz = ttnn.reshape(pz, (1, int(pz.shape[0]), N, pz.shape[-1]))
            for nm, t in transitions:
                pz = t(pz, add_to_input=True)
                _sync(nm)
            return pz

        def _whole():
            pz = _chain(z_trunk_tt, relp)
            # `device` (the pz_device lever): the conditioned pair stays on the chip for `_pair_z_seam`.
            return pz if device and _z_sha is None else _pz_cond_probe(pz, _z_sha)

        def _rows(rb):
            # Row-blocked chain (see PAIRCOND_BLOCK_BYTES): no full-size relpe, cast, LN'd z,
            # channel concat or transition ever materializes. Each finished block goes to the
            # host, which is where the conditioned pair is returned. OpenDDE's structural pair
            # at 1536 residues (2987 tokens) wanted a 2300133376 B fp32 relpe before any block.
            blocks = []
            for s in range(0, N, rb):
                e = min(s + rb, N)
                zt = z_trunk_tt if e - s == N else z_trunk_tt[s:e]
                pb = _chain(zt, relp[s:e])
                if zt is not z_trunk_tt:
                    ttnn.deallocate(zt)
                blocks.append(Protenix._to_host(pb).reshape(e - s, N, -1))
                ttnn.deallocate(pb)
            return torch.cat(blocks, dim=0)

        rb = max(32, (256 * 2 ** 20) // (W * cz * 2) // 32 * 32)
        if N * W * cz * 2 > PAIRCOND_BLOCK_BYTES and self.diffusion.dtype == ttnn.bfloat16:
            pz = _rows(rb)
        else:
            # The fp32 diffusion (Protenix's default) never takes the byte gate above, so the
            # whole chain runs until DRAM refuses it: protenix-v2 at 1300 tokens on a Wormhole
            # chip was refused the 3.25 GiB fp32 layernorm_z of the [N,N,512] concat.
            pz = _T.row_block_after_refusal(
                self._paircond_rows_refused, (N, W, cz, str(self.diffusion.dtype)),
                _whole, _rows, rows=rb, tag="protenix pair conditioning")
        # The input pair's only reader was this chain.
        ttnn.deallocate(z_in)
        return pz

    def _plm_z_term(self, pair_z, a2t, nb, nq, nk):
        """broadcast_token_to_local_atom_pair: W_z(LN_z(z_trunk)) gathered into windowed
        atom-pair blocks (nb,nq,nk,16). The diffusion atom-encoder's p_lm cache adds this
        trunk-pair-z term (reference transformer.py prepare_cache, r_l path)."""
        import torch.nn.functional as F
        E = "diffusion_module.atom_attention_encoder."
        lnz = F.layer_norm(pair_z, (pair_z.shape[-1],)) * self._w[E + "layernorm_z.weight"]
        return self._plm_gather(F.linear(lnz, self._w[E + "linear_no_bias_z.weight"]), a2t, nb)

    @staticmethod
    def _plm_gather(ztok, a2t, nb):
        """The (NT,NT,16) token-pair term gathered into the windowed atom-pair blocks (nb,nq,nk,16)."""
        import torch
        N = a2t.shape[0]; NQ, NK, PADL = 32, 128, 48; NP = nb * NQ
        aq = torch.cat([a2t, torch.zeros(NP - N, dtype=torch.long)]).reshape(nb, NQ)
        ak_src = torch.cat([torch.zeros(PADL, dtype=torch.long), a2t,
                            torch.zeros(PADL + NP + NK, dtype=torch.long)])
        ak = torch.stack([ak_src[b * NQ:b * NQ + NK] for b in range(nb)], 0)   # (nb,nk)
        return torch.stack([ztok[aq[b][:, None].expand(NQ, NK), ak[b][None, :].expand(NQ, NK)]
                            for b in range(nb)], 0)                            # (nb,nq,nk,16)

    def _pz_device(self):
        """Whether the conditioned pair stays on the chip (`_pair_z_seam`): the pz_device lever, for a
        device DiT. The pair conditioning writes the DiT's own dtype, bf16 or normal mode's fp32."""
        return _T.lever("pz_device") and self.diffusion.device_dit

    def _pair_z_seam(self, pz, NT, a2t, nb, nq, nk):
        """The conditioned pair's diffusion consumers: (p_lm z term, cond entries).

        A host `pz` (the default, or the row-blocked conditioning) feeds `_plm_z_term` and the DiT
        as before. A device `pz` (`_pz_device`) never leaves the chip: one device LN is the DiT's
        LN(pair_z) and, times the encoder's LN gain folded into W_z, the 16-wide z term, which is
        the only thing downloaded. At OpenDDE's 1216-token structural axis that replaces a 757 MB
        fp32 download, two host LNs and a 378 MB upload with a 95 MB download."""
        D = self.diffusion
        if isinstance(pz, torch.Tensor):
            pair_z = pz.reshape(NT, NT, -1)
            cond = {"pair_z": pair_z}
            if D.device_dit:
                cond["dit_z"] = D._dit_z_device(pair_z)
            else:
                cond["dit_biases"] = D._dit_pair_biases(pair_z)
            return self._plm_z_term(pair_z, a2t, nb, nq, nk), cond
        E = "diffusion_module.atom_attention_encoder."
        ln = ttnn.layer_norm(pz, epsilon=1e-5, compute_kernel_config=D._dit_ckc)
        ttnn.deallocate(pz)
        w = (self._w[E + "linear_no_bias_z.weight"].float() * self._w[E + "layernorm_z.weight"].float()).t()
        w_tt = ttnn.from_torch(w.contiguous(), dtype=D._dit_dtype, layout=ttnn.TILE_LAYOUT, device=D.dev)
        zt = ttnn.linear(ln, w_tt, compute_kernel_config=D._dit_ckc, dtype=ttnn.float32)
        ttnn.deallocate(w_tt)
        ztok = torch.Tensor(_T.download(zt)).float().reshape(NT, NT, -1)
        ttnn.deallocate(zt)
        return self._plm_gather(ztok, a2t, nb), {"pair_z": None, "dit_z": ln}

    @_under_size_levers
    def fold_many(self, feats_list, *, n_step=200, seed=None, progress_fn=None,
                  return_confidence=False, n_cycles=None):
        """Fold B targets with ONE batched diffusion trajectory. Returns a list of B coord
        tensors (1,N,3), or (coords, confs) when return_confidence.

        The trunk runs per target: its pair ops already fill the grid at production N, so a
        batch dimension buys nothing there (measured: per-prediction cost at B=8 is 0.93x for
        the pair transition and 1.07x for tri-attention). The diffusion is the opposite -- its
        tensors are atom- and token-sized and leave the grid idle -- so the B conditionings are
        stacked on the sampler's multiplicity axis and one denoise per step covers all B.

        All targets must share the atom count and the token count; bucket before calling.
        Each member draws its own host RNG stream, so member b sees exactly the noise
        fold(feats_list[b], seed=seed) would have drawn alone.
        """
        B = len(feats_list)
        if B > 1:
            _T.program_cache_for(tuple(_T.input_shapes(f) for f in feats_list), self.dev)
        if B == 1:
            out = self.fold(feats_list[0], n_step=n_step, n_sample=1, seed=seed,
                            progress_fn=progress_fn, return_confidence=return_confidence,
                            n_cycles=n_cycles)
            return ([out[0]], [out[1]]) if return_confidence else [out]
        conds, auxs = [], []
        for feats in feats_list:
            cond, aux = self._trunk_cond(feats, progress_fn=progress_fn, n_cycles=n_cycles, seed=seed)
            conds.append(cond)
            auxs.append(aux)
        merged = merge_conds(self.diffusion, conds)
        N = auxs[0]["N"]
        # One batched forward per step: the merged conditioning covers all B members, so the
        # per-step chunking knob (max_parallel_samples) does not apply here -- a chunk would
        # slice the coordinate stream but not the conditioning. DRAM is the limit on B.
        coords = edm_sample(self.diffusion, merged, N, n_step=n_step, multiplicity=B,
                            max_parallel_samples=B, member_seeds=[seed] * B,
                            progress_fn=progress_fn)
        out = [coords[b:b + 1] for b in range(B)]
        from .esmc import _free_ttnn_tensors
        _free_ttnn_tensors((merged, conds))     # sampler state, as in fold()
        if not return_confidence:
            return out
        if progress_fn:
            progress_fn("confidence")
        confs = [self._confidence_for(auxs[b], feats_list[b], out[b][0]) for b in range(B)]
        return out, confs

    def _confidence_for(self, aux, feats, coords):
        """Confidence head for one prediction's coords (N,3). Same device/host split and the
        same NT>=128 gate fold() uses, and like fold() it frees the resident tensors after."""
        s_inputs, s_trunk, z_trunk = aux["s_inputs"], aux["s_trunk"], aux["z_trunk"].result()
        if self.confidence_head.device_confidence_enabled() and aux["NT"] >= 128:
            z_base_dev = self.confidence_head.z_base_device(s_inputs, s_trunk, z_trunk)
            try:
                return self.confidence_head.confidence_device(s_inputs, s_trunk, z_base_dev, coords, feats)
            finally:
                self.confidence_head.drop_device_resident()
        return self.confidence_head.confidence(s_inputs, s_trunk, z_trunk, coords, feats)

    def _trunk_host_inputs(self, feats, NT):
        """relp and `Trunk.host_inputs`: the host-only part of the trunk's input, for the lane."""
        relp = feats["relp"] if "relp" in feats else self._generate_relp(feats)
        return relp, self.trunk.host_inputs(feats, relp, feats["token_bonds"], NT)

    def _trunk_cond(self, feats, *, progress_fn=None, n_cycles=None, seed=None):
        """Trunk plus the t-independent diffusion conditioning for one target: everything
        fold() does before the sampler. Returns (cond, aux); aux carries what the confidence
        head needs. fold() and fold_many() share this so a batched fold runs the same trunk
        as a single one."""
        if os.environ.get("TT_PROTENIX_DUMP_FEATS"):
            import pathlib as _pl
            _d = _pl.Path(os.environ.get("TT_PROTENIX_PAIRCOND_DEBUG_DIR", "/tmp/issue9"))
            _d.mkdir(parents=True, exist_ok=True)
            torch.save(feats, _d / "feats_dump.pt")
        st = self._trunk_stage(feats, progress_fn=progress_fn, n_cycles=n_cycles, seed=seed)
        fi, s_inputs, c_l, p_lm, relp = st["fi"], st["s_inputs"], st["c_l"], st["p_lm"], st["relp"]
        N, NT, nb, nq, nk = fi["N"], fi["NT"], fi["nb"], fi["nq"], fi["nk"]
        mt = fi["mt"]; S = fi["S"]
        s_trunk_tt, z_tt = st["s_trunk_tt"], st["z_tt"]
        s_trunk = self._to_host(s_trunk_tt, (NT, s_trunk_tt.shape[-1]))
        # Raw trunk z, for the confidence head only. Read now, while z_tt exists, but untilized on
        # the host lane: the chip goes straight on to the pair conditioning. aux carries a Future.
        C_Z = self.trunk.C_Z
        z_trunk = hostlane.to_torch(ttnn.from_device(z_tt), lambda z: z.float().reshape(NT, NT, C_Z))
        # diffusion pair conditioning (once, t-independent): conditioned pair_z
        pz = self._diffusion_pair_cond(z_tt, relp, device=self._pz_device())
        # diffusion p_lm cache also carries the (conditioned) pair-z broadcast to atom pairs; the DiT
        # pair input is t-independent, so LN(pair_z) is made once (or the host biases of the fp32 fallback)
        z_term, pz_cond = self._pair_z_seam(pz, NT, fi["a2t"], nb, nq, nk)
        p_lm = p_lm + z_term
        # 4) EDM sampler
        cond = {"s_trunk": s_trunk, "s_inputs": s_inputs, "c_l": c_l,
                "p_lm": p_lm, "S": S, "mask_trunked": mt.float(), **pz_cond}
        return cond, dict(N=N, NT=NT, s_inputs=s_inputs, s_trunk=s_trunk, z_trunk=z_trunk)

    def _trunk_stage(self, feats, *, progress_fn=None, n_cycles=None, seed=None, msa_sample=None):
        """Input embedder, the diffusion's atom cache (c_l, p_lm) and the trunk, with the trunk's
        host inputs on the host lane: everything before the trunk is read back. Protenix and
        OpenDDE (which diffuses on its own token axis) both start here. Returns a dict with fi,
        s_inputs, c_l, p_lm, relp and the resident s_trunk_tt, z_tt. msa_sample: the trunk's
        per-cycle alignment draw when the caller has its own rule (OpenDDE), else the lever's."""
        fi = self._atom_feat_inputs(feats)
        N, NT, nb, nq, nk = fi["N"], fi["NT"], fi["nb"], fi["nq"], fi["nk"]
        mt = fi["mt"]
        tt = self._tt
        # The trunk's host-only inputs (relp, padding, template and MSA features) are built on the
        # host lane while the chip runs the input embedder and the diffusion atom cache below.
        trunk_host = hostlane.submit(self._trunk_host_inputs, feats, NT)
        # 1) s_inputs (input embedder atom encoder)
        atoms, emb_mt, Mmat = self._embedder_atoms(feats, fi)
        dm = feats["deletion_mean"]; dm = dm.reshape(-1, 1) if dm.dim() == 1 else dm
        s_inputs_tt = self.input_aae(*map(tt, atoms), emb_mt, tt(Mmat),
                                     tt(feats["restype"]), tt(feats["profile"]), tt(dm))
        s_inputs = self._to_host(s_inputs_tt)[:NT]
        # 2) diffusion atom cache (c_l, p_lm) -- t-independent and gate-controlled
        dtt = self.diffusion._up
        mt_dev = dtt(mt.reshape(-1, 1).float())
        c_l = self._to_host(self.diff_feat.c_l(dtt(feats["ref_pos"]), dtt(fi["ref_charge_asinh"]),
                                               dtt(feats["ref_mask"].reshape(N, 1)), dtt(fi["f_in"])), (N, 128))
        p_lm = self._to_host(self.diff_feat.p_lm(dtt(fi["d"]), dtt(fi["v"]), dtt(fi["invd"]), mt_dev),
                             (nb, nq, nk, 16))
        # 3) trunk
        import tt_bio.tenstorrent as _TT
        relp, host = trunk_host.result()
        # Under the msa_sample lever every cycle reads its own random alignment rows, drawn from
        # the fold seed as upstream's MSAModule draws them from its seeded global generator. v2
        # lineage only, told by its template stack as in `trunk_recycles`: Protenix-v2, OpenDDE and
        # Mol-1 (mol/config/data.py min_size 1, sample_cutoff 16384) draw 1..n rows a cycle; v0.5.0
        # draws between 2048 and n and keeps 2048 (configs_data.py), a rule not built here.
        if msa_sample is None and _TT.lever("msa_sample") and self.trunk.TPL:
            gen = torch.Generator()
            msa_sample = (None, gen.manual_seed(seed) if seed is not None else gen)
        s_trunk_tt, z_tt = self.trunk(feats, s_inputs, relp, feats["token_bonds"],
                                      progress_fn=progress_fn, n_cycles=n_cycles, host=host,
                                      msa_sample=msa_sample)
        return dict(fi=fi, s_inputs=s_inputs, c_l=c_l, p_lm=p_lm, relp=relp,
                    s_trunk_tt=s_trunk_tt, z_tt=z_tt)

    def _confidence_start(self, s_inputs, z_trunk, NT):
        """The device confidence head's z_base, summed on the host lane while the sampler runs, or
        None when this fold takes the host heads. `z_trunk` is a host-lane Future of the trunk pair.
        The device head starts at 128 tokens, where the host path's per-sample (N,N,c_z) round
        trip starts to cost (~23 ms at 38 tokens)."""
        ch = self.confidence_head
        if not (ch.device_confidence_enabled() and NT >= 128):
            return None
        return hostlane.submit(lambda: ch.z_base_host(s_inputs, z_trunk.result()))

    def _confidences(self, s_inputs, s_trunk, z_trunk, z_base, coords, feats, keep_logits=False):
        """One confidence dict per sample in `coords`: on the device when `_confidence_start` gave
        a z_base, else the host heads. `z_trunk` is a host-lane Future of the trunk pair.
        keep_logits adds each sample's pae/pde/plddt logits and the fold's distogram contact
        probabilities, everything the upstream output writer needs."""
        ch = self.confidence_head
        if z_base is None:
            confs = ch.confidence_samples(s_inputs, s_trunk, z_trunk.result(), coords, feats, keep_logits)
        else:
            z_base_dev = ch.z_base_upload(z_base.result())
            try:
                confs = ch.confidence_device_samples(s_inputs, s_trunk, z_base_dev, coords, feats, keep_logits)
            finally:
                ch.drop_device_resident()
        if keep_logits:
            from .protenix_output import contact_probs
            contact = contact_probs(self.distogram_logits(z_trunk.result()))
            for c in confs:
                c["contact_probs"] = contact
        return confs

    def distogram_logits(self, z_trunk):
        """Upstream's DistogramHead on the host trunk pair (N,N,c_z): L(z) + L(z)^T, (N,N,64).
        It reads the trunk and feeds nothing back, so no coordinate depends on it."""
        import torch.nn.functional as F
        d = F.linear(z_trunk.float(), self._w["distogram_head.linear.weight"].float(),
                     self._w["distogram_head.linear.bias"].float())
        return d + d.transpose(0, 1)

    @_under_size_levers
    def fold(self, feats, *, n_step=200, n_sample=1, seed=None, progress_fn=None,
             return_confidence=False, n_cycles=None, trace=False,
             max_parallel_samples=None, gamma0=None, step_scale=None, return_logits=False, draws=None):
        """Run the full pipeline. feats: model-ready tensor dict. n_cycles = trunk recycling
        iterations (default 10, protenix-v2's spec; fewer trades accuracy for speed). Returns
        coords (n_sample, N, 3) host tensor; if return_confidence, returns (coords, conf) where
        conf is a dict {plddt (mean, float), plddt_atom (N_atom,), pae (N,N), pde (N,N),
        ptm, iptm} for n_sample==1, or a list of such dicts (one per sample) for n_sample>1.
        return_logits adds pae_logits / pde_logits / plddt_logits and contact_probs to each conf
        (`_confidences`), the input of the upstream output layout. draws: one iterator of upstream
        sampler draws per sample (`edm_sample`), for grading against an upstream trajectory.
        trace=True replays a captured ttnn trace of the denoise stream (lossless; faster on
        dispatch-bound diffusion, e.g. -22% warm at L256). Requires the device to have been
        opened with get_device(trace="protenix").

        gamma0 / step_scale are the sampler's churn and step-size knobs. None keeps
        `edm_sample`'s protenix-v2 defaults (0.8 and 1.5). They are arguments because they are
        a property of the CHECKPOINT, not of this class: the distilled v0.5.0 mini models ship
        `gamma0: 0, step_scale_eta: 1.0` in their own model config and produce nonsense under
        the v2 pair at the handful of steps they are meant to run."""
        import torch
        if trace:
            import tt_bio.tenstorrent as _TTd
            _TTd.require_trace_region("fold(trace=True)")
        _T.program_cache_for(_T.input_shapes(feats), self.dev)
        cond, _aux = self._trunk_cond(feats, progress_fn=progress_fn, n_cycles=n_cycles, seed=seed)
        N, NT = _aux["N"], _aux["NT"]
        s_inputs, s_trunk, z_trunk = _aux["s_inputs"], _aux["s_trunk"], _aux["z_trunk"]
        # The device confidence head's sample-invariant z_base is built on the host lane while the
        # diffusion runs; the chip used to wait for it, and for z_trunk's untilize, at its entry.
        z_base = self._confidence_start(s_inputs, z_trunk, NT) if return_confidence else None
        import os as _os, time as _time
        if _os.environ.get("TT_PROTENIX_DBG_COND"):
            self._dbg_cond = cond
        _dump_dir = _os.environ.get("TT_PROTENIX_DUMP")
        _dump_fn = None
        if _dump_dir:
            # Optional intermediate capture for determinism/parity debugging: dumps the
            # trunk conditioning once and every sampler frame (noise + per-step coords).
            import pathlib as _pl

            import ttnn as _tn

            _dd = _pl.Path(_dump_dir)
            _dd.mkdir(parents=True, exist_ok=True)
            for _k, _v in sorted(cond.items()):
                try:
                    _t = _tn.to_torch(_v) if isinstance(_v, _tn.Tensor) else _v
                    torch.save(_t, _dd / f"cond_{_k}.pt")
                except Exception as _e:
                    (_dd / f"cond_{_k}.txt").write_text(f"{type(_v)}: {_e}")

            def _dump_fn(_step, _x, _dd=_dd):
                _nm = "noise.pt" if _step == -1 else f"x_step{_step:04d}.pt"
                torch.save(_x.detach().cpu().clone(), _dd / _nm)

        _prof = _os.environ.get("TT_PROTENIX_PROFILE")
        # Multiplicity batching: when the device denoise carries the multiplicity dim
        # (DiffusionModule.supports_multiplicity, flipped on once the batched denoise is
        # parity-verified), draw all n_sample samples in ONE batched trajectory
        # (boltz2.AtomDiffusion.sample pattern). Until then, fall back to the per-sample
        # loop (bit-exact with the prior path). max_parallel_samples caps the per-step
        # batched denoise chunk (OOM safety); None = n_sample (one batched forward).
        _sampler = {k: v for k, v in (("gamma0", gamma0), ("step_scale", step_scale))
                    if v is not None}
        if n_sample > 1 and draws is None and getattr(self.diffusion, "supports_multiplicity", False):
            _mps = DEFAULT_MAX_PARALLEL_SAMPLES if max_parallel_samples is None else max_parallel_samples
            if _prof:
                import ttnn as _tn; _tn.synchronize_device(self.diffusion.dev); _ts = _time.time()
            coords = edm_sample(self.diffusion, cond, N, n_step=n_step, multiplicity=n_sample,
                                 max_parallel_samples=_mps, seed=seed, trace=trace,
                                 progress_fn=progress_fn, **_sampler)
            if _prof:
                import ttnn as _tn; _tn.synchronize_device(self.diffusion.dev); print(f"[PROF] edm_sample[batch={n_sample}] {_time.time()-_ts:.3f}s", flush=True)
        else:
            coords = []
            for k in range(n_sample):
                sd_seed = None if seed is None else seed + k
                if _prof:
                    import ttnn as _tn; _tn.synchronize_device(self.diffusion.dev); _ts = _time.time()
                coords.append(edm_sample(self.diffusion, cond, N, n_step=n_step, seed=sd_seed,
                                         trace=trace, progress_fn=progress_fn, dump_fn=_dump_fn,
                                         draws=None if draws is None else draws[k], **_sampler)[0])
                if _prof:
                    import ttnn as _tn; _tn.synchronize_device(self.diffusion.dev); print(f"[PROF] edm_sample[{k}] {_time.time()-_ts:.3f}s", flush=True)
            coords = torch.stack(coords, 0)
        # The conditioning is sampler state: the confidence head reads the trunk's host s and z
        # and the coordinates, never `cond`. Held through it, the DiT pair, its per-block biases
        # and the atom-pair track left protenix-v2 on 3abq at 1536 with 8.77 of 12 GiB in use
        # before the confidence pairformer, and its trimul was refused at every chunk width.
        if not _os.environ.get("TT_PROTENIX_DBG_COND"):
            from .esmc import _free_ttnn_tensors
            _free_ttnn_tensors(cond)
        if return_confidence:
            if progress_fn:
                progress_fn("confidence")
            # Per-sample confidence so callers can rank samples (best-of-N) and
            # report pTM/ipTM/pLDDT per sample. n_sample==1 returns a single dict
            # (back-compat); n_sample>1 returns a list aligned with coords.
            confs = self._confidences(s_inputs, s_trunk, z_trunk, z_base, list(coords), feats,
                                      keep_logits=return_logits)
            return coords, (confs[0] if n_sample == 1 else confs)
        return coords


def msa_cycle_rows(msa, n_cycles, depth, generator):
    """Per recycling cycle, the alignment rows OpenDDE's MSAModule reads (opendde
    model/msa_sampling.py subsample_msa_feature_dict_valid_first): rows holding any non-gap token
    in random order, then all-gap rows in random order, the first `depth` of them; one fresh draw
    per cycle from `generator`. msa: [depth_total, tokens] token ids, real columns only. None
    when the whole alignment fits, where a draw would only reorder rows the module sums over."""
    import torch
    if msa.shape[0] <= depth:
        return None
    valid = (msa != 31).any(-1)
    v_idx, i_idx = valid.nonzero().squeeze(-1), (~valid).nonzero().squeeze(-1)
    out = []
    for _ in range(n_cycles):
        pick = v_idx[torch.randperm(v_idx.numel(), generator=generator)][:depth]
        if pick.numel() < depth:
            extra = i_idx[torch.randperm(i_idx.numel(), generator=generator)][:depth - pick.numel()]
            pick = torch.cat([pick, extra])
        out.append(pick)
    return out


def deeper_than_before(depths, first=0):
    """The cycles, numbered from `first`, that read more alignment rows than every cycle before them
    in `depths`: where a refusal can land that the cycles already run did not meet. The trunk keeps
    its carry on the host before each, so a refused cycle resumes there instead of at `first`."""
    out, deepest = set(), depths[0] if depths else 0
    for i, d in enumerate(depths[1:], first + 1):
        if d > deepest:
            out.add(i)
            deepest = d
    return out


# Upstream Protenix's inference cap on the rows one cycle reads (configs_data.py msa.sample_cutoff.test).
MSA_SAMPLE_CUTOFF = 16384


def msa_cycle_rows_random(n_rows, n_cycles, generator, cutoff=MSA_SAMPLE_CUTOFF):
    """Per recycling cycle, the alignment rows Protenix v2's MSAModule reads at inference
    (protenix/model/utils.py sample_indices with strategy "random", lower bound 1): a depth k drawn
    uniformly from 1..n_rows, then the first k of a random permutation, at most `cutoff`. Drawn in
    upstream's order, randint then randperm, so the same CPU generator state gives the same rows."""
    import torch
    out = []
    for _ in range(n_cycles):
        k = int(torch.randint(1, n_rows + 1, (1,), generator=generator).item())
        out.append(torch.randperm(n_rows, generator=generator)[:k][:cutoff])
    return out


def trunk_recycles(state_dict):
    """Recycling count this checkpoint was trained for, read off the checkpoint.

    The v0.5.0 release (protenix-v1 and its distilled minis) ships `model.N_cycle: 4` and a
    template embedder with an EMPTY pairformer stack. protenix-v2 and OpenDDE ship 10 and a
    2-block stack. So the template depth separates the two lineages, and it is the same signal
    `Trunk.__call__` gates the template contribution on -- one fact read once, not a second
    hardcoded copy of a per-model number. Mol-1 (`model.N_cycle: 20`) is the one checkpoint whose
    pair track changes width inside the stack, so its width adapters identify it.

    The CLI resolves the same default from `main.RECYCLING_STEPS`, keyed by model id, because it
    has to answer before any weights are loaded. The two must agree.
    """
    if any(k.startswith("pairformer_stack.adapters.") for k in state_dict):
        return 20
    return 4 if n_blocks(state_dict, "template_embedder.pairformer_stack") == 0 else 10


def unique_slots(xs):
    """(distinct, slot): the distinct tensors of xs in first-seen order, and for each element of xs
    the index of its equal in `distinct` (torch.equal, so exact). The template embedder runs one
    stack per distinct template and still sums one term per slot."""
    distinct, slot = [], []
    for x in xs:
        j = next((j for j, d in enumerate(distinct) if torch.equal(d, x)), None)
        if j is None:
            j = len(distinct)
            distinct.append(x)
        slot.append(j)
    return distinct, slot


class Trunk(_KeyedWeights):
    """Protenix-v2 trunk: s_inputs -> (s_trunk, z_trunk) over 10 recycling cycles.

    Each cycle: z = z_init + linear_z_cycle(LN(z)); z += template_embedder(z);
    z = msa_module(z, m); s = s_init + linear_s_cycle(LN(s)); (s,z) = pairformer48(s,z).
    Composes TrunkInput + 48-block Pairformer + template embedder (nt templates x 2
    pair-only blocks) + 4-block MSA module, all reusing tt_bio.tenstorrent primitives
    with v2 weights (tt_bio.protenix_weights remaps). Validated vs the real v2 reference
    (PCC s 0.991 / z 0.990; scripts/protenix_trunk_assembly.py). Reference:
    protenix/model/protenix.py get_pairformer_output."""

    N_CYCLES = 10      # class fallback; __init__ derives the real one (see trunk_recycles)
    C_Z = 256          # Protenix-v2 default; instances override via __init__(c_z=...)
    TRI_HEAD_DIM = 32  # constant across c_z variants (Protenix-v2 256/8 heads, OpenDDE 384/12)

    def __init__(self, model_state_dict, compute_kernel_config, c_z=None,
                 msa_update_first=False, gated_move=False, softmax_scope="protenix"):
        """model_state_dict: full v2-family model dict with the 'module.' prefix STRIPPED.
        c_z: pair channel width. None reads it off the weights (`layernorm_z_cycle`, the
        recycling norm every v2-family trunk carries), which is 256 for Protenix-v2, 384 for
        OpenDDE and 128 for every PXDesign-pinned Protenix. Head_dim is fixed at 32, so
        n_tri_heads follows as c_z // 32. Pass a value only to override the weights."""
        from .tenstorrent import (get_device, Pairformer, PairformerLayer,
                                   OuterProductMean, PairWeightedAveraging, Transition)
        self._w = model_state_dict
        self.compute_kernel_config = compute_kernel_config
        self.dev = get_device()
        self.C_Z = c_z or self._derive_c_z(model_state_dict) or self.C_Z
        self._msa_update_first = msa_update_first
        n_tri_heads = self.C_Z // self.TRI_HEAD_DIM
        self._wc = {}  # cached device weights (upload once; reused every recycle cycle)
        ti_keys = ("linear_no_bias_sinit", "linear_no_bias_zinit1", "linear_no_bias_zinit2",
                   "linear_no_bias_token_bond", "relative_position_encoding")
        ti_sd = {k: v for k, v in self._w.items() if any(k.startswith(p) for p in ti_keys)}
        self.trunk_input = TrunkInput(ti_sd, compute_kernel_config)
        # Pairformer depth from the weights (Protenix-v2 and OpenDDE 48, Protenix mini 16).
        # n_blocks anchors the prefix, so template_embedder.pairformer_stack and
        # confidence_head.pairformer_stack cannot leak into this count.
        nb_pf = n_blocks(self._w, "pairformer_stack")
        comb, pf_heads = {}, []
        for i in range(nb_pf):
            blk = {k[len(f"pairformer_stack.blocks.{i}."):]: v for k, v in self._w.items()
                   if k.startswith(f"pairformer_stack.blocks.{i}.")}
            for k, v in PW.remap_pairformer_block(blk).items():
                comb[f"layers.{i}.{k}"] = v
            # Heads per block off its own weights: Mol-1's PairMixer blocks have no triangle
            # attention (0) and its other blocks run at c_z 320 (10 heads), not the resident 448.
            ta = blk.get("tri_att_start.linear.weight")
            pf_heads.append(0 if ta is None else int(ta.shape[0]))
        # Mol-1's pair-width adapters: before_block_<i> and after_blocks (PW.remap_pair_adapters).
        comb.update(PW.remap_pair_adapters(self._w, "pairformer_stack.", nb_pf))
        # Mol-1 (the two-width trunk) carries the single track in fp32 end to end (`PairformerLayer` s_fp32): its
        # confidence head reads the small channels' per-token part, which a bf16 store erases. One-width trunks keep
        # the bf16 track they shipped with; on them fp32 cost 12-21 % a call at the perf gate's sizes
        # (state/mol1/evidence/confperf/ROOT.md).
        self.PF = Pairformer(nb_pf, self.TRI_HEAD_DIM, pf_heads, 384 // 16, 16, True, comb,
                             compute_kernel_config, gated_move=gated_move,
                             s_fp32=len(self._pair_widths(model_state_dict)) > 1,
                             accurate_softmax=accurate_softmax_site(f"{softmax_scope}.trunk", default=True))
        # Template embedder: pair-only PairformerLayers, count from the weights. Protenix-v2
        # has 2. Every PXDesign-pinned Protenix variant ships a template embedder that is only
        # its five projections (layernorm_v, layernorm_z, linear_no_bias_{a,u,z}) with NO
        # pairformer stack, so 0 is a real answer and _template's `for pl in self.TPL` loop
        # correctly degenerates to the projections alone.
        nb_tpl = n_blocks(self._w, "template_embedder.pairformer_stack")
        self.N_CYCLES = trunk_recycles(self._w)
        self.TPL = [PairformerLayer(32, 2, None, None, False,
                    PW.remap_msa_pair_stack({k[len(f"template_embedder.pairformer_stack.blocks.{b}."):]: v
                                             for k, v in self._w.items()
                                             if k.startswith(f"template_embedder.pairformer_stack.blocks.{b}.")}),
                    compute_kernel_config, gated_move=gated_move) for b in range(nb_tpl)]
        # Noisy structure embedder: `protenix_mini_tmpl_v0.5.0` and nothing else on this
        # branch. It is the entire difference between `mini_tmpl` and `mini_default` -- eleven
        # tensors, same 1612 elsewhere -- and it is what the "tmpl" in the name means: the
        # target's CB geometry entering the pair representation directly, not through the
        # template embedder (whose pairformer stack is empty in every v0.5.0 variant). A
        # checkpoint without the keys gets None and nothing changes.
        self.NSE = None
        if any(k.startswith("noisy_structure_embedder.") for k in self._w):
            self.NSE = Transition(PW.remap_transition(
                {k[len("noisy_structure_embedder.transition_out."):]: v
                 for k, v in self._w.items()
                 if k.startswith("noisy_structure_embedder.transition_out.")}),
                compute_kernel_config)
        # MSA module: count from the weights (Protenix-v2 4, Protenix mini 1).
        self.MSA = []
        nb_msa = n_blocks(self._w, "msa_module")
        for i in range(nb_msa):
            P = f"msa_module.blocks.{i}."
            sub = lambda pp: {k[len(pp):]: v for k, v in self._w.items() if k.startswith(pp)}
            # scale_bias=True because this family's reference divides the WHOLE linear_out
            # output by the pair norm, `proj_o.bias` included (Protenix's
            # openfold_local/model/outer_product_mean.py and OpenDDE's
            # model/triangular/layers.py both do, at the same weight names). The default False
            # is Boltz's convention -- it divides the raw outer product before proj_o, so the
            # bias belongs at full strength there. Left at the default, this op added the bias
            # once per MSA row: 76x too large on a 76-deep MSA, a constant per-channel offset
            # that the 48-block Pairformer then amplifies 7.86x. Measured on 7ROA 136 aa:
            # the op goes from PCC 0.985883 to 0.999989 and the shipped fold's
            # z_post_pairformer from 0.947762 to 0.991964.
            opm = OuterProductMean(PW.remap_outer_product_mean(sub(P + "outer_product_mean_msa.")), compute_kernel_config,
                                   scale_bias=True)
            pl = PairformerLayer(self.TRI_HEAD_DIM, n_tri_heads, None, None, False,
                                 PW.remap_msa_pair_stack(sub(P + "pair_stack.")),
                                 compute_kernel_config, gated_move=gated_move)
            has = any(k.startswith(P + "msa_stack.") for k in self._w)
            pwa = tm = None
            if has:
                pwa = PairWeightedAveraging(8, 8, PW.remap_pair_weighted_averaging(sub(P + "msa_stack.msa_pair_weighted_averaging.")), compute_kernel_config)
                tm = Transition(PW.remap_transition(sub(P + "msa_stack.transition_m.")), compute_kernel_config)
            self.MSA.append((opm, pwa, tm, pl))

    @staticmethod
    def _derive_c_z(state_dict):
        """Pair width off the weights, or None when the trunk keys are absent.

        Same principle as `n_blocks`: a width the caller has to remember to pass can disagree
        with the checkpoint it is passed alongside, and c_z spans 128/256/384 across the
        v2-family checkpoints tt-bio loads. `layernorm_z_cycle` is the per-recycle pair norm,
        so its length is c_z by construction and `__call__` already depends on the key.
        """
        w = state_dict.get("layernorm_z_cycle.weight")
        return int(w.shape[0]) if w is not None else None

    @staticmethod
    def _pair_widths(state_dict):
        """Every pair width the trunk's Pairformer runs at, off each block's pair transition norm: {c_z} for a
        one-width stack, {448, 320} for Mol-1's; {c_z} without block keys, empty without trunk keys."""
        w = {int(v.shape[0]) for k, v in state_dict.items()
             if k.startswith("pairformer_stack.blocks.") and k.endswith("pair_transition.layernorm1.weight")}
        c_z = Trunk._derive_c_z(state_dict)
        return w or ({c_z} if c_z else set())

    def _template(self, z3, tpl_a, tslot, pmask_tt=None, attn_tt=None):
        # tpl_a: one device tensor per DISTINCT template, each already `linear_no_bias_a(at)`;
        # tslot[t] names template t's entry (`unique_slots`). Equal inputs give equal stack
        # outputs, so each distinct template runs the 2-block stack once and the mean still adds
        # one term per slot in slot order, the same adds as running every slot. Without real
        # templates the features are one gap slot and three identical ALA slots: 2 stacks, not 4.
        # The projection is cycle-invariant, so the caller hoists it out of the recycling
        # loop (see Trunk.__call__); passing the raw host feature concat here is a bug.
        # nt template projections read this whole normed pair tensor to write two tiles of
        # width each, so one L1-resident copy serves all of them: 2180.7 -> 853.1 us on the
        # four-template region, `torch.equal`.
        # nt template projections read this whole normed pair tensor to write two tiles of width
        # each, so they are source-bound and one L1-resident copy serves all of them. They are
        # taken TOGETHER, above the block loop, and `zn` is freed before the first block runs:
        # the two PairformerLayers between consecutive templates need their own circular buffers,
        # and holding 48.82 MB of L1 across them makes their trimul throw.
        zn = self._ln(z3, "template_embedder.layernorm_z.weight",
                      "template_embedder.layernorm_z.bias", l1=True)
        vs = []
        for ta in tpl_a:
            a = host_unpark(ta)
            vs.append(ttnn.add(a, self._lin(zn, "template_embedder.linear_no_bias_z.weight"),
                               memory_config=ttnn.DRAM_MEMORY_CONFIG))
            if a is not ta:
                ttnn.deallocate(a)
        ttnn.deallocate(zn)
        for i, v in enumerate(vs):
            for pl in self.TPL:
                v = pl(None, v, pmask_tt, attn_tt, attn_tt)[1]
            vs[i] = self._ln(v, "template_embedder.layernorm_v.weight", "template_embedder.layernorm_v.bias")
        u = vs[tslot[0]]
        for i in tslot[1:]:
            u = ttnn.add(u, vs[i])
        u = ttnn.multiply(u, 1.0 / (1e-7 + len(tslot)))
        # z + linear_u(relu(u)), the embedder's residual. Per pair position, so after DRAM refuses
        # the single pass it runs in row blocks and the old z is freed at the join: at 1536 tokens
        # the c_z=384 projection alone is 1811939328 B, refused beside z with a 96 MiB/bank run.
        res = lambda zr, ur: ttnn.add(
            zr, self._lin(ttnn.relu(ur), "template_embedder.linear_no_bias_u.weight"))
        return row_block_after_refusal(
            _TEMPLATE_ROWS_REFUSED, tuple(z3.padded_shape), lambda: res(z3, u),
            lambda rows: pair_row_blocks(res, (z3, u), rows, consume=z3),
            rows=256, tag="protenix template")

    def _noisy_structure_dist(self, feat, N):
        """The cycle-invariant half of `NoisyStructureEmbedder`: the binned CB distogram.

        `protenix/model/modules/pairformer.py:986` (the `v0.5.0+pxd` fork). A 39-bin one-hot
        of the pairwise CB distance, masked to the pairs where both tokens have a real
        coordinate, with the pair mask appended as a fortieth channel, then projected to
        c_z/2. It depends only on the input coordinates, so like the template projection it is
        built and uploaded once per fold rather than once per recycling cycle.

        `add_noise` is upstream's training-time augmentation and is 0 at inference.
        Returns None when the caller supplies no structure, which is upstream's own
        all-zero-mask branch: it multiplies the update out to zero, so skipping it is the
        same arithmetic without the traffic.
        """
        import torch
        if self.NSE is None or "struct_cb_coords" not in feat:
            return None
        mask = feat["struct_cb_mask"].bool().reshape(-1)
        if not bool(mask.any()):
            return None
        x = feat["struct_cb_coords"].float().reshape(N, 3)
        # The bin edges are checkpoint parameters, not recomputed: `bins` is
        # linspace(3.25, 50.75, 39) and `upper_bins` is it shifted up one with a 1e6 tail.
        bins = self._w["noisy_structure_embedder.bins"].float()
        upper = self._w["noisy_structure_embedder.upper_bins"].float()
        d = torch.cdist(x, x)[..., None]
        pair = (mask[:, None] & mask[None, :]).float()[..., None]
        onehot = ((d > bins) & (d < upper)).float() * pair
        feats40 = torch.cat([onehot, pair], dim=-1).unsqueeze(0)
        return self._lin(self._up(feats40),
                         "noisy_structure_embedder.linear_struct.weight")

    def _noisy_structure(self, z3, d_proj):
        """The per-cycle half: concat the projected pair state with the projected distogram
        and run the output transition. `z = transition_out(cat(linear_z(LN(z)), d))`."""
        zp = self._lin(self._ln(z3, "noisy_structure_embedder.layernorm_z.weight",
                                "noisy_structure_embedder.layernorm_z.bias"),
                       "noisy_structure_embedder.linear_z.weight")
        cat = ttnn.concat([zp, d_proj], dim=-1)
        ttnn.deallocate(zp)
        out = self.NSE(cat)
        ttnn.deallocate(cat)
        return out

    def _msa(self, z3, m_feat, pmask_tt=None, attn_tt=None, rows=None):
        """The MSA module's blocks on `z3`. `m_feat` is the pristine m, a device or a host tensor.
        rows=(mask, depth) says only the first `depth` rows of `m_feat`, a tensor or a list of depth
        chunks, are alignment rows (a cycle's sampled rows padded to its bucket); OuterProductMean
        masks the rest."""
        opm_mask, n_msa = rows if rows is not None else (None, None)
        def update_msa(m, z, pwa, transition):
            if pwa is None:
                return m
            if isinstance(m, list):
                # Already chunked: transform each chunk in place of the list, parked chunks
                # back to the host.
                return msa_update_chunks(m, z, pwa, transition, attn_tt,
                                         park=m[0].storage_type() != ttnn.StorageType.DEVICE)
            D = m.shape[1]                                  # MSA depth
            # Row-chunk the MSA depth axis when the representation is too big to hold several
            # copies of. Unchunked, PairWeightedAveraging's FIRST op is an out-of-place
            # layer_norm over the whole tensor, so a second full copy has to exist alongside
            # the input; measured on a 12 GiB Wormhole part, that allocation is exactly what
            # a deep-MSA target dies on (9qqf refused 2.494 GiB with m_feat = 2.494 GiB).
            #
            # This is bit-exact, not an approximation: nothing in this path reduces along the
            # depth axis. PWA's weights come from `z` alone (linear(z,...) then softmax), its
            # matmul contracts the TOKEN axis, its head accumulation is over heads, and
            # layer_norm/Transition are per-row over channels. So each output row depends only
            # on its own input row and on z, and partitioning the rows cannot change any
            # accumulation order. (OuterProductMean is the opposite case -- its reduction IS
            # over depth -- which is why it stays full-depth below and must not be chunked.)
            if _msa_take_whole_path(D * m.shape[2] * m.shape[3] * 2):
                m_up = self._up(m) if torch.is_tensor(m) else m   # host offload + forced whole
                m2 = ttnn.add(m_up, ttnn.reshape(
                    pwa(m_up, ttnn.clone(z), attn_tt), tuple(m_up.shape)))
                dram_peak("trunk msa block: after pwa add")
                trunk_tap("whole:after_pwa", m2)
                out = ttnn.add(
                    m2, ttnn.reshape(transition(m2), tuple(m2.shape)))
                trunk_tap("whole:after_transition", out)
                if m_up is not m:
                    ttnn.deallocate(m_up)
                return out
            # A host-resident pristine (deep-MSA offload) streams up one chunk at a time; a
            # device one is sliced, and those slices are not ours to free.
            parts = msa_update_chunks(msa_depth_chunks(m, _msa_row_chunk_size()), z, pwa,
                                      transition, attn_tt, own=torch.is_tensor(m),
                                      park=torch.is_tensor(m))
            # Return the CHUNKS, not a concatenation of them. The terminal concat used to need a
            # third full-size buffer (source + parts + destination) and that 3x peak is what made
            # 9d72 OOM at 1.78 GiB m_feat even with chunking on. Every downstream consumer is
            # chunk-wise -- PWA and Transition are per-row, and OuterProductMean now takes the
            # list and joins only its c=32 projections -- so the contiguous tensor is never needed.
            return parts

        # DO NOT make update_msa's first add in-place on the tensor passed in. `m_feat` is
        # built ONCE outside the recycling loop in __call__ and this method is re-entered for
        # every cycle, so the caller's buffer has to survive intact; mutating it would corrupt
        # cycles 2..n_cycles. That is a numerical change, not an allocation change, and it
        # would not show up as an OOM -- only as wrong coordinates. The chunked path above is
        # safe because it slices (a copy) and mutates only the slice.
        global _TRUNK_TAP_CALL
        if torch.is_tensor(m_feat):     # host-resident pristine (deep-MSA offload)
            trunk_tap_host("msa_enter:m_feat", m_feat)
        else:
            trunk_tap("msa_enter:m_feat", m_feat)
        trunk_tap("msa_enter:z3", z3)
        for _bi, (opm, pwa, tm, pl) in enumerate(self.MSA):
            dram_peak(f"trunk msa block {_bi} enter")
            # OpenDDE refreshes the MSA before OPM. Protenix-v2 retains the
            # ordering its checkpoint was trained with.
            if self._msa_update_first:
                m_feat = update_msa(m_feat, z3, pwa, tm)
            if torch.is_tensor(m_feat):
                # Protenix-order block 0 reads the pristine m with OPM, from one transient upload
                # or its depth chunks; update_msa below streams from host.
                z3 = self._opm_from_host(opm, m_feat, z3, opm_mask, n_msa)
            else:
                z3 = opm(m_feat, opm_mask, n_msa, residual=z3)
            dram_peak("trunk msa block: after opm")
            if not self._msa_update_first:
                m_feat = update_msa(m_feat, z3, pwa, tm)
            z3 = pl(None, z3, pmask_tt, attn_tt, attn_tt)[1]
            dram_peak(f"trunk msa block {_bi} done")
            if not torch.is_tensor(m_feat):
                trunk_tap(f"block{_bi}:m_feat", m_feat)
            trunk_tap(f"block{_bi}:z3", z3)
        # The per-cycle chunk list is dead once the blocks are done: __call__ keeps the original
        # contiguous m_feat and re-derives the chunks next cycle (§34.1 -- the caller's copy must
        # stay pristine, so it is never freed here). A host-resident pristine needs no freeing.
        if isinstance(m_feat, list):
            for _c in m_feat:
                ttnn.deallocate(_c)
        _TRUNK_TAP_CALL += 1
        return z3

    def host_inputs(self, feat, relp, token_bonds, n_real):
        """Everything the trunk builds from its inputs on the host alone: the token-axis padding,
        the template features, the MSA feature, each rounded to the dtype it is uploaded in. No
        device call, so fold() runs it on the host lane while the chip computes the input
        embedder; __call__ only uploads what this returns."""
        import torch
        import torch.nn.functional as F
        N = n_real
        # Bucket the TOKEN axis. Everything below then runs at the padded N and the exit slices
        # back, so no site inside this method needs to know the real length -- only the three
        # reduce-over-tokens families need the masks: TriangleMultiplication (contracts a token
        # axis), TriangleAttention (softmax over one) and PairWeightedAveraging (its matmul
        # contracts the token axis). OuterProductMean reduces over MSA DEPTH, so a padded token
        # cannot reach a real pair through it, and the transitions/norms/linears are per-token.
        from .token_axis import pad_amount, token_pad_masks_torch
        # Mol-1-constraint widens the token-bond projection by its condition channels (mol1_constraint.py),
        # so the masks ride beside the bonds; all zero when the input names no constraint.
        token_bonds = token_bonds.unsqueeze(-1)
        width = self.trunk_input._w["linear_no_bias_token_bond.weight"].shape[1]
        cp = feat.get("constraint_pair")
        if width > 1:
            token_bonds = torch.cat([token_bonds, cp.to(token_bonds) if cp is not None
                                     else token_bonds.new_zeros(N, N, width - 1)], -1)
        elif cp is not None:
            raise ValueError("site / contact / exclusion constraints need the Mol-1-constraint weights")
        pad = pad_amount(N, _token_pad_multiple()) if _token_bucket() else 0
        m1 = pm_pad = at_pad = None
        if pad:
            N = n_real + pad
            q = _pad_poison()
            relp = F.pad(relp, (0, 0, 0, pad, 0, pad), value=q)
            token_bonds = F.pad(token_bonds, (0, 0, 0, pad, 0, pad), value=q)
            feat = dict(feat)
            # -1 matches no real chain, so the padded rows and columns are never "same chain".
            feat["asym_id"] = F.pad(feat["asym_id"], (0, pad), value=-1)
            # Index-valued features keep a safe pad: a poisoned one_hot index would just crash.
            for k in ("template_aatype", "msa"):
                if k in feat:
                    feat[k] = F.pad(feat[k], (0, pad))
            for k in ("has_deletion", "deletion_value"):
                if k in feat:
                    feat[k] = F.pad(feat[k], (0, pad), value=q)
            for k in ("template_pseudo_beta_mask", "template_backbone_frame_mask"):
                if k in feat:
                    feat[k] = F.pad(feat[k], (0, pad, 0, pad), value=q)
            for k in ("template_distogram", "template_unit_vector"):
                if k in feat:
                    feat[k] = F.pad(feat[k], (0, 0, 0, pad, 0, pad), value=q)
            # Outer-product pair mask and additive -1e9 attention mask, both from the shared
            # helper -- the reasons they are that shape and not simpler are recorded there.
            m1, pm_pad, at_pad = token_pad_masks_torch(n_real, N)
        # template feature concat (per template). Offline (no-template) inference omits
        # template_* entirely -> nt=0, template embedder skipped (the reference's
        # use_template=False path carries all-zero template geometry, a negligible update).
        asym = feat["asym_id"]; mc = (asym[:, None] == asym[None, :]).float()
        # pm is the real-region pair mask when bucketing, so every template feature is 0 in a
        # padded row or column. asym_id = -1 already makes `mc` False against a real chain, but
        # -1 == -1 is True in the pad-by-pad block, and pm is what covers that.
        pm = torch.ones(N, N) if not pad else (m1[0][:, None] * m1[0][None, :])
        nt = feat["template_aatype"].shape[0] if "template_aatype" in feat else 0
        te_at = []
        for t in range(nt):
            dg = feat["template_distogram"][t] * mc[..., None] * pm[..., None]
            pb = (feat["template_pseudo_beta_mask"][t] * mc * pm).unsqueeze(-1)
            aa = F.one_hot(feat["template_aatype"][t].long(), 32).float()
            aai = aa[None].expand(N, N, 32); aaj = aa[:, None].expand(N, N, 32)
            uv = feat["template_unit_vector"][t] * mc[..., None] * pm[..., None]
            bb = (feat["template_backbone_frame_mask"][t] * mc * pm).unsqueeze(-1)
            te_at.append(torch.cat([dg, pb, aai, aaj, uv, bb], -1))
        te_at, tslot = unique_slots(te_at)
        # msa feature
        # Built in bf16, the dtype it is uploaded in: the one-hot and has_deletion are exact and
        # torch rounds deletion_value as the fp32 upload did, so the device tensor is identical,
        # and at 730 tokens x 9,947 rows the host build and tilize drop from 3.3 s to 1.0 s.
        bf = torch.bfloat16
        msa = F.one_hot(feat["msa"].long(), 32).to(bf)
        ms = torch.cat([msa, feat["has_deletion"].to(bf).unsqueeze(-1),
                        feat["deletion_value"].float().to(bf).unsqueeze(-1)], -1).unsqueeze(0)
        relp_g = (self.trunk_input.relp_index(relp)
                  if _T.lever("relp_gather") and getattr(self.trunk_input, "dtype", ttnn.bfloat16) == ttnn.bfloat16
                  else None)
        return dict(N=N, pad=pad, feat=feat, relp=self._host_cast(relp), relp_g=relp_g,
                    token_bonds=self._host_cast(token_bonds),
                    pm_pad=pm_pad, at_pad=at_pad, nt=nt, tslot=tslot,
                    te_at=[self._host_cast(t.unsqueeze(0)) for t in te_at], ms=ms)

    def __call__(self, feat, s_inputs, relp, token_bonds, progress_fn=None, n_cycles=None, host=None,
                 msa_sample=None):
        """feat: dict with template_* / msa / has_deletion / deletion_value / asym_id (host
        tensors). s_inputs (N,449), relp (N,N,139), token_bonds (N,N) host. n_cycles is the
        number of recycling iterations (default: the checkpoint's own, via trunk_recycles --
        10 for protenix-v2/OpenDDE, 4 for the v0.5.0 lineage). msa_sample=(depth, generator)
        gives every cycle its own random alignment rows, as the reference MSAModules do: `depth`
        rows valid-first for OpenDDE (msa_cycle_rows), or depth None for Protenix's uniformly
        random depth (msa_cycle_rows_random); None feeds the whole alignment to every cycle.
        `host` is `host_inputs` of the
        same feat, relp and token_bonds, already built (fold() builds it on the host lane while
        the chip runs the input embedder); None builds it here. Returns
        (s_trunk (N,384), z_trunk (1,N,N,256)) as ttnn tensors."""
        import torch
        import torch.nn.functional as F
        n_real = s_inputs.shape[0]
        if host is None:
            host = self.host_inputs(feat, relp, token_bonds, n_real)
        N, pad, feat, nt, ms = host["N"], host["pad"], host["feat"], host["nt"], host.pop("ms")
        pmask_tt = attn_tt = None
        if pad:
            s_inputs = F.pad(s_inputs, (0, 0, 0, pad), value=_pad_poison())
            pmask_tt, attn_tt = self._up(host["pm_pad"]), self._up(host["at_pad"])
        relp_g = host.get("relp_g")
        s_init, z_init = self.trunk_input(self._up(s_inputs),
                                          relp_g if relp_g is not None else self._up(host["relp"]),
                                          self._up(host["token_bonds"]))
        # te_at is cycle-invariant: upload + project it once here instead of re-uploading
        # ~57 MB x nt on every recycle cycle inside _template. Per-fold local on purpose:
        # N varies between targets, so never cache this on self.
        tpl_a = [self._lin(self._up(t), "template_embedder.linear_no_bias_a.weight")
                 for t in host.pop("te_at")]
        nse_d = self._noisy_structure_dist(feat, N)
        # The MSA representation is this trunk's DRAM limiter on a 12 GiB part: it scales as
        # depth * tokens, and a deep-MSA target OOMs right here. Tag the upload and the
        # projection SEPARATELY, with shape and dtype, because the two are the same number of
        # bytes under different readings (34->64 padded channels in fp32 vs c_m channels in
        # bf16) and only the tensor's own dtype tells them apart. No-op without TT_BIO_DRAM_PEAK.
        # Tag WITHOUT binding the intermediates to locals. Naming them measurably changes what
        # is measured: ttnn frees a buffer when its last Python reference drops, so hoisting
        # `_up(ms)` and the projection into locals kept ~3.7 GiB alive past the point the
        # original expression frees it, and moved the OOM to a different allocation.
        dram_peak(f"trunk msa pre-upload [ms={tuple(ms.shape)} {ms.dtype}"
                  f" -> dtype={getattr(self, 'dtype', ttnn.bfloat16)}]")
        # Deep-MSA offload: every read of the pristine m_feat is row-local (PWA/Transition per
        # row, OPM per chunk), so past 1 GiB of feature `msa_embed` builds it one depth chunk at a
        # time on the host and update_msa streams it back up a chunk at a time. Neither the whole
        # `ms` upload nor a full-size device copy of m_feat enters the per-cycle peak. Below that,
        # m_feat stays on the chip up to `MSA_JOIN_MAX_BYTES`, a size decided by the input alone.
        s_m = self._lin(self._up(s_inputs), "msa_module.linear_no_bias_s.weight")
        m_key = (N, ms.shape[1] * N * self._w["msa_module.linear_no_bias_m.weight"].shape[0] * 2)
        m_proj = lambda x: ttnn.add(self._lin(x, "msa_module.linear_no_bias_m.weight"), s_m)
        n_cycles = self.N_CYCLES if n_cycles is None else n_cycles
        rows = table = next_rows = None
        if msa_sample is not None:
            depth, gen = msa_sample
            msa = feat["msa"][:, :n_real]
            rows = (msa_cycle_rows_random(msa.shape[0], n_cycles, gen) if depth is None
                    else msa_cycle_rows(msa, n_cycles, depth, gen))
        if rows is None:
            m_feat = msa_embed(ms, m_proj, keep=m_key[1])
            ttnn.deallocate(s_m)
            dram_peak(f"trunk m_feat built [{tuple(m_feat.shape)} {m_feat.dtype}]")
        else:
            # The embedding is per alignment row, so embedding a cycle's rows equals picking them
            # out of the embedded whole; only the picked rows are built, padded to a few depths
            # (msa_row_bucket) and masked past the draw, and the host lane cuts the next cycle's rows
            # while this one runs. A fixed depth (OpenDDE's 1280) is one shape already: padding it
            # to the next 1024 would run every per-row op on 2048 rows, 60 % of them zeros.
            m_feat = None
            n_rows = ms.shape[1]
            step = 1024 if depth is None else 32
            bucket = lambda c: msa_row_bucket(len(rows[c]), n_rows, step)
            cut = lambda c: hostlane.submit(msa_rows_host, ms, rows[c], bucket(c))
            # The cycle's rows are picked on the chip from the alignment, uploaded once, when every cycle
            # would upload its rows in one piece, a test on the input alone: the host
            # then sends row indices, not up to ~0.9 GB of rows the chip waits for (1.5 s a cycle at
            # 9,216 rows x 736 tokens on a Wormhole host). Otherwise the host lane cuts the next cycle's
            # rows while this one runs. Both hand the MSA module the same bf16 tensor.
            if msa_upload_whole(msa_row_bucket(n_rows, n_rows, step), *ms.shape[2:]):
                table = msa_rows_table(ms)
            else:
                next_rows = cut(0)
        # Both are read once per cycle and never written, so past 1 GiB they wait on the host.
        z_init, tpl_a = host_park(z_init), host_park(tpl_a)

        def start():
            # Cycle 0's inputs, rebuilt from z_init and s_init whenever the trunk (re)starts.
            zi = host_unpark(z_init)
            z3 = ttnn.reshape(ttnn.mul(zi, 0.0), (1, N, N, self.C_Z))
            if zi is not z_init:
                ttnn.deallocate(zi)
            return [z3, ttnn.mul(s_init, 0.0)]

        def cycle(cyc, carry, m_feat, rows=None):
            # Unpacked and cleared, so the cycle's input pair dies at its first rebind exactly as
            # it did inline. `rows` marks a cycle's own row draw, freed with its mask once the
            # MSA module has read it.
            z3, s = carry
            carry.clear()
            zc = self._lin(self._ln(z3, "layernorm_z_cycle.weight", "layernorm_z_cycle.bias"), "linear_no_bias_z_cycle.weight")
            # The previous pair, zc and an unparked z_init are each a whole pair tensor (2 GiB in
            # bf16 at 2048 tokens, C_Z 256), and zc used to live to the end of the cycle: the add
            # held four of them and --fast died on the fourth on a 12 GiB Wormhole chip. The old
            # pair goes once zc is made, and zc and the upload go right after the add. Still
            # `ttnn.add`: `add_` into the upload saves one more pair but moved exact's l2048
            # digest on Blackhole.
            free = not ops.taping()
            if free:
                ttnn.deallocate(z3)
            zi = host_unpark(z_init)
            z3 = ttnn.add(ttnn.reshape(zi, (1, N, N, self.C_Z)), zc)
            if zi is not z_init:
                ttnn.deallocate(zi)
            if free:
                ttnn.deallocate(zc)
            del zc
            if nse_d is not None:
                z3 = ttnn.add(z3, self._noisy_structure(z3, nse_d))
            # Gate on BOTH the feature's template slots and the checkpoint's own template
            # pairformer depth. `nt` counts slots and protenix_data.dummy_template_features
            # always emits 4, so `nt > 0` alone is not a statement about the model. Upstream
            # v0.5.0 pairformer.py:1000 returns literal 0 from TemplateEmbedder.forward when
            # n_blocks < 1, and the v0.5.0 base checkpoint ships 0 blocks: its five template
            # projections are dead weight. Without `self.TPL` the port would add
            # linear_u(relu(mean(LN(tpl_a + linear_z(LN(z)))))) to z on every recycling cycle
            # where upstream adds nothing. Inert for protenix-v2 and opendde, which both ship
            # a 2-block stack (pinned by tests/test_protenix_template_gate.py).
            if nt > 0 and self.TPL:
                z3 = self._template(z3, tpl_a, host["tslot"], pmask_tt, attn_tt)
            z3 = self._msa(z3, m_feat, pmask_tt, attn_tt, rows)
            if rows is not None and not ops.taping():
                # Held through the Pairformer, the draw left the 1536-token OpenDDE trunk's
                # transition no room to join its blocks on device from cycle 1 on, and every
                # later recycle took the host join: ~12 min instead of ~4:20 on a Wormhole chip.
                # A list of chunks was consumed by the blocks, which free each one they replace.
                if not torch.is_tensor(m_feat) and not isinstance(m_feat, list):
                    ttnn.deallocate(m_feat)
                ttnn.deallocate(rows[0])
                del m_feat, rows
            sc = self._lin(self._ln(s, "layernorm_s.weight", "layernorm_s.bias"), "linear_no_bias_s.weight")
            s = ttnn.add(s_init, sc, dtype=ttnn.float32)
            s, z3 = self.PF(ttnn.reshape(s, (1, N, 384)), z3, pmask_tt, attn_tt, attn_tt)
            s = ttnn.reshape(s, (N, 384))
            # The one region cycle 0's MSA taps did not cover: the s update and the trunk-level
            # Pairformer. Cheap to tap every cycle -- z3 is ~62 MB here, not m_feat's ~0.7 GiB --
            # so this both tests cycle 0 and, if cycle 0 matches, names the first cycle that does not.
            trunk_tap(f"cyc{cyc}_after_PF:s", s, always=True)
            trunk_tap(f"cyc{cyc}_after_PF:z3", z3, always=True)
            return [z3, s]

        def sampled(cyc, carry, x=None, park=False):
            # One cycle over its sampled rows, the real ones first then zero rows to its bucket: the
            # host cut x [1, bucket, N, c], or, with x None, rows gathered on the chip from `table`.
            # `park` builds the cycle's m in depth chunks on the host and streams it, as a refused
            # resident cycle does below.
            # An m the MSA blocks would cut into depth chunks anyway is BUILT as those chunks, one
            # fixed size whatever the draw. Built whole, the m changed size every cycle and left DRAM
            # holes no later deep draw could use: 7ua2-assembly1 (712 tokens) was refused its
            # 2.96 GiB m at cycle 7 of 20 on a Wormhole chip with 414 MiB a bank free. Padding every
            # cycle to the fold's deepest draw fixed that and cost 4-7 % on Blackhole at 512 and
            # 1024 tokens, per-row work on rows no cycle drew.
            r, Bc = rows[cyc], bucket(cyc)
            row_bytes = m_key[1] // ms.shape[1]
            if _msa_take_whole_path(Bc * row_bytes):
                if x is None:
                    x = msa_rows_device(table, r, Bc, N)
                m_c = msa_embed(x, m_proj, keep=Bc * row_bytes, park=park)
            else:
                # Parked where msa_embed would park the whole m: a host cut past one upload whose m
                # is past what the chip joins.
                park = park or (x is not None and not msa_upload_whole(*x.shape[1:])
                                and Bc * row_bytes > MSA_JOIN_MAX_BYTES)
                C = _msa_row_chunk_size()
                m_c = msa_embed_chunks((msa_rows_device(table, r[s:s + C], min(C, Bc - s), N) if x is None
                                        else x[:, s:s + C] for s in range(0, Bc, C)), m_proj, park=park)
            mask = ttnn.from_torch(msa_rows_mask(len(r), Bc), layout=ttnn.TILE_LAYOUT, device=get_device(),
                                   dtype=ttnn.bfloat16)
            carry = cycle(cyc, carry, m_c, (mask, len(r)))
            del m_c, mask
            return carry

        # Where a restart begins: cycle 0, or the carry a past-1-GiB pair left on the host after its last cycle.
        # Such a pair already keeps z_init on the host (host_park), and `from_device` is one DMA of the same
        # tile bytes: ~2 GiB once a ~290 s cycle at 2048 tokens, where a refused cycle 7 of 10 would
        # otherwise redo seven cycles.
        # A sampled fold whose pair is a 32nd of the chip keeps the carry before each cycle that draws more
        # rows than any cycle before it in this mode, the cycles a refusal lands on. At 1024 Mol-1 tokens on
        # a Wormhole chip a deep draw late in the fold was refused and the restart redid up to 19 cycles
        # from cycle 0, so a fold's time hung on its seed: 937 s to 2352 s for one input, and a gang of 8
        # seeds waits for the slowest.
        resume = [0, None]
        keep = z_init.storage_type() != ttnn.StorageType.DEVICE and not ops.taping()
        mark = (rows is not None and not keep and not ops.taping()
                and 32 * N * N * self.C_Z * 2 >= dram_bytes())

        def run(mode, m_feat, next_rows):
            # Every cycle in one mode, from `resume`. `rows` was drawn for all cycles up front, so a
            # restart sees the same rows.
            c0, h = resume
            carry = start() if h is None else [ttnn.to_device(t, get_device()) for t in h]
            marks = deeper_than_before([bucket(c) for c in range(c0, n_cycles)], c0) if mark else ()
            for cyc in range(c0, n_cycles):
                # AF3 trains the recycling stack with every cycle but the LAST under no_grad, so
                # the tape holds one cycle instead of n_cycles of them. That is upstream's own
                # structure, not doing less of the model's work: all the cycles still run and the
                # last one still sees what the one before it produced. With no tape installed
                # no_grad only flips a flag nothing reads, so inference is untouched.
                with ops.recycle_region(cyc, n_cycles - 1):
                    if progress_fn:
                        progress_fn("trunk", step=cyc, total=n_cycles)
                    if mode == "table":
                        carry = sampled(cyc, carry)
                    elif rows is not None:
                        x, _ = next_rows.result()
                        if cyc + 1 < n_cycles:
                            next_rows = cut(cyc + 1)
                        carry = sampled(cyc, carry, x, park=mode == "park")
                    else:
                        carry = cycle(cyc, carry, m_feat)
                    if cyc + 1 < n_cycles and (keep or cyc + 1 in marks):
                        resume[:] = [cyc + 1, [ttnn.from_device(t) for t in carry]]
            return carry

        # Crash guard, not a regime. A cycle DRAM refuses restarts the trunk from `resume` one mode
        # lighter, for THIS fold only: rows picked on the chip from the resident alignment ("table"),
        # then rows cut on the host ("cut"), then each cycle's m built and streamed in depth chunks
        # ("park"); a resident m ("chip") streams from the host ("host"). Restarting, rather than
        # re-running the refused cycle from inputs kept on the chip, means no cycle ever holds its
        # input pair there past its first op: kept, that pair (0.94 GB at 1024 Mol-1 tokens) was what a 1024-token
        # cycle ran out of DRAM for. A row count drawn afresh every cycle changes the MSA shapes
        # every cycle, so a deep draw late in the fold can find the chip's DRAM in pieces where the
        # full-depth path reuses its blocks: 7ua2-assembly1 (712 tokens, 18,611 rows) was refused
        # 2.96 GiB at cycle 7 of 20 on a Wormhole chip. Nothing is remembered across folds, because
        # a process-wide switch made a served answer depend on what the process folded before
        # (state/spd-msaresid.md). The restart runs outside the handler: the traceback pins every
        # tensor the refused run made.
        if rows is None:
            mode = "host" if torch.is_tensor(m_feat) else "chip"
        else:
            mode = "table" if table is not None else "cut"

        def step_down(mode):
            nonlocal table, m_feat, next_rows
            what = (f"the MSA {tuple(m_feat.shape)}" if rows is None else
                    f"the MSA {tuple(ms.shape)}" if mode == "table" else "each cycle's MSA rows")
            how = {"table": "cutting each cycle's rows on the host", "cut": "streaming each cycle's rows from the host",
                   "chip": "streaming it from the host"}[mode]
            print(f"[tt-bio] DRAM refused a recycling cycle with {what} on the chip; restarting the trunk {how} for "
                  f"the rest of this fold. The tt-metal 'Out of Memory' line above is expected and handled.",
                  file=sys.stderr, flush=True)
            if mode == "table":
                ttnn.deallocate(table)
                table = None
            elif mode == "chip":
                h = ttnn.to_torch(m_feat)
                ttnn.deallocate(m_feat)
                m_feat = h
            gc.collect()
            _T.forget_trimul_inproj_refusals()
            if rows is not None:
                next_rows = cut(resume[0])

        carry = restart_lighter(lambda mode: run(mode, m_feat, next_rows), mode,
                                {"table": "cut", "cut": "park", "chip": "host"}, step_down)
        z3, s = carry
        if rows is not None:
            ttnn.deallocate(s_m)
            if table is not None:
                ttnn.deallocate(table)
        for t in [z_init, *tpl_a]:
            if t.storage_type() == ttnn.StorageType.DEVICE:
                ttnn.deallocate(t)
        if nse_d is not None:
            ttnn.deallocate(nse_d)
        # The trunk's final conditioning. If cycle 0's blocks matched but this differs, the
        # divergence is born in a later cycle; if this matches too, the trunk is fully exonerated
        # and only the diffusion path (and the allocator state it inherits) can explain the fold.
        if pad:
            s = ttnn.slice(s, (0, 0), (n_real, s.shape[1]))
            z3 = ttnn.slice(z3, (0, 0, 0, 0), (1, n_real, n_real, z3.shape[3]))
        trunk_tap("trunk_exit:s_trunk", s, always=True)
        trunk_tap("trunk_exit:z_trunk", z3, always=True)
        return s, z3


def merge_conds(diffusion_module, conds):
    """Stack B per-target diffusion conditionings into one M=B conditioning.

    The M-aware denoise already builds exactly these shapes when it replicates a shared
    conditioning over M samples, so nothing downstream changes: per-member tensors gain a
    leading B (c_la, ss_base, the atom<->token pooling matrices, the DiT pair biases) and
    the windowed atom-pair biases concatenate along their block dim to B*nb. Every target
    must share the atom count N and the token count NT.

    Returns a cond dict the batched denoise consumes directly. Host entries (shapes only,
    on this path) come from member 0.
    """
    B = len(conds)
    for c in conds:
        diffusion_module._atom_cond(c)
        if diffusion_module.device_dit and c.get("dit_z") is not None and "dit_block_biases" not in c:
            c["dit_block_biases"] = diffusion_module._dit_block_biases(
                c["dit_z"], c.get("structural_pair_attn_bias"))
    N = conds[0]["c_l"].shape[0]
    NT = conds[0]["s_inputs"].shape[0]
    for i, c in enumerate(conds[1:], 1):
        if c["c_l"].shape[0] != N or c["s_inputs"].shape[0] != NT:
            raise ValueError(
                f"batch member {i} has (atoms, tokens) "
                f"({c['c_l'].shape[0]}, {c['s_inputs'].shape[0]}), member 0 has ({N}, {NT}); "
                "bucket targets by shape before batching")
    cat = lambda ts: ttnn.to_layout(ttnn.concat(ts, dim=0), ttnn.TILE_LAYOUT)
    m = dict(conds[0])
    m["c_la_dev"] = cat([ttnn.reshape(c["c_la_dev"], (1, N, 128)) for c in conds])
    m["ss_base"] = cat([ttnn.reshape(c["ss_base"], (1, NT, c["ss_base"].shape[-1])) for c in conds])
    m["Smean_dev"] = cat([ttnn.reshape(c["Smean_dev"], (1, NT, N)) for c in conds])
    m["S_dev"] = cat([ttnn.reshape(c["S_dev"], (1, N, NT)) for c in conds])
    m["p_dev"] = cat([c["p_dev"] for c in conds])
    for key in ("atxE_bias", "atxD_bias"):
        z_pre = [c[key][0] for c in conds]
        m[key] = ([cat([z[b] for z in z_pre]) for b in range(len(z_pre[0]))],
                  None if conds[0][key][1] is None else cat([c[key][1] for c in conds]))
    if conds[0].get("dit_block_biases") is not None:
        m["dit_block_biases"] = [cat([_T.host_unpark(c["dit_block_biases"][b]) for c in conds])
                                 for b in range(len(conds[0]["dit_block_biases"]))]
    # dict(conds[0]) carried member 0's atom conditioning terms; the merged c_la has one row
    # block per member, so its terms are recomputed from it.
    diffusion_module._atom_terms(m)
    m["_members"] = B
    return m


def step_scale_schedule(step_scale, n_step):
    """Per-step eta for the AF3 Alg-18 Euler update, as a list of `n_step` floats.

    A float (Protenix-v2, OpenDDE) gives a constant schedule and the identical arithmetic
    it always had. PXDesign passes upstream's dict form, `{"type", "min", "max"}`; the
    fraction is `step / (n_step + 1)` because upstream indexes by position in the
    noise schedule, which is one longer than the step count.
    Reference: pxdesign/model/generator.py sample_diffusion."""
    if not isinstance(step_scale, dict):
        return [float(step_scale)] * n_step
    lo, hi = float(step_scale["min"]), float(step_scale["max"])
    kind, T = step_scale["type"], n_step + 1
    if kind == "const":
        if lo != hi:
            raise ValueError(f"const eta schedule needs min == max, got {lo} and {hi}")
        return [lo] * n_step
    fracs = [k / T for k in range(n_step)]
    if kind == "linear":
        return [lo + (hi - lo) * f for f in fracs]
    if kind == "poly":
        return [lo + (hi - lo) * f ** 2 for f in fracs]
    if kind == "cos":
        return [lo + 0.5 * (hi - lo) * (1 - math.cos(math.pi * f)) for f in fracs]
    if kind.startswith("piecewise"):
        cut = {"piecewise": 0.5, "piecewise_65": 0.65, "piecewise_70": 0.70}.get(kind)
        if cut is None:
            raise ValueError(f"unsupported eta schedule {kind!r}")
        return [lo if f < cut else hi for f in fracs]
    raise ValueError(f"unsupported eta schedule {kind!r}")


def edm_sample(diffusion_module, cond, n_atoms, *, multiplicity=1, max_parallel_samples=None,
               member_seeds=None, n_step=200, gamma0=0.8, gamma_min=1.0,
               noise_scale=1.003, step_scale=1.5, sigma_data=16.0, s_max=160.0, s_min=4e-4,
               rho=7.0, seed=None, trace=False, progress_fn=None, dump_fn=None, guidance=None,
               draws=None):
    """AF3 EDM ancestral sampler for Protenix-v2 (same family as Boltz-2's
    AtomDiffusion.sample; reuses tt_bio.boltz2.compute_random_augmentation). Produces
    atom coords by iteratively denoising from noise with diffusion_module.denoise.

    The v2 noise schedule uses denominator N_step (i/N), verified to reproduce the real
    v2 reference t_hat sequence to 4 sig figs (4608, 2490, ... 0.1264 for N_step=10):
        sigma[i] = sigma_data * (s_max^(1/rho) + (i/N_step)*(s_min^(1/rho)-s_max^(1/rho)))^rho
    then a final sigma=0; gammas[i] = gamma0 if sigma[i] > gamma_min else 0; per step
    (sigma_tm=sigmas[k], sigma_t=sigmas[k+1], gamma=gammas[k+1]); t_hat=sigma_tm*(1+gamma).
    cond is the fixed trunk conditioning dict passed to DiffusionModule.denoise.

    multiplicity (M): number of independent samples drawn in ONE batched trajectory.
    The conditioning is sample-invariant (same target -> same s_trunk/s_inputs/pair_z/
    c_l/p_lm/S/mask), so only the coordinate stream x_noisy carries the M dim -- mirrors
    boltz2.AtomDiffusion.sample's multiplicity pattern (repeat_interleave would be a no-op
    here since cond is shared, not per-sample). max_parallel_samples caps the per-step
    batched denoise chunk; the per-step device footprint is linear in the chunk, so this
    is the memory knob (None = M, one batched forward -- Protenix.fold and
    OpenDDE.fold substitute DEFAULT_MAX_PARALLEL_SAMPLES rather than pass None through).

    Parity: at multiplicity=1 (default) this is bit-exact with the prior per-sample loop
    -- same single seed, same (1,N,3) draws, one _denoise((1,N,3),...) call per step.
    At multiplicity>1 the sampler draws all M samples from one RNG stream (seeded once
    with `seed`), so each sample's noise differs from the old per-sample loop's seed+k
    draw but is statistically equivalent; the fold lands in the same basin within the
    seed-to-seed noise floor (PCC parity, the established diffusion-leg bar). This matches
    boltz2.AtomDiffusion.sample, which also uses one stream for its multiplicity batch.

    guidance (tt_bio.tfg.Guidance) replaces the Euler update of each step with its own
    ``step``, which may correct the denoised estimate and the sampled state (OpenDDE's
    constraint guidance). None leaves every step exactly as it was.

    step_scale (eta) is a float by default; PXDesign passes upstream's schedule dict
    ({"type": "piecewise_65", "min": 1.0, "max": 2.5}) -- see step_scale_schedule.

    trace=True replays a captured ttnn trace of the denoise device stream (lossless;
    collapses per-step dispatch on dispatch-bound diffusion), captured once per fold at the
    first chunk's (N, M); a shorter tail chunk runs untraced. Requires the device to have
    been opened with get_device(trace="protenix").

    draws replays an upstream sampler's random draws instead of the host RNG, so a fold can be
    graded against an upstream trajectory rather than against the seed floor: an iterator of
    (tag, tensor) in upstream Protenix / Mol-1 order for one sample, ("init", noise) then per
    step ("rot", R), ("trans", t), ("eps", noise). Upstream rotates x -> R x, this loop x @ R,
    hence the transpose."""
    import torch
    from .boltz2 import compute_random_augmentation
    from .runtime import serial_host
    M = max(1, int(multiplicity))
    if draws is not None:
        assert M == 1 and member_seeds is None, "a replayed draw stream is one sample's"

        def _take(tag, shape_):
            got, v = next(draws)
            assert got == tag, f"draw stream gives {got!r} where the sampler draws {tag!r}"
            return v.float().reshape(shape_)
    _denoise = diffusion_module.denoise_traced if trace else diffusion_module.denoise
    if seed is not None:
        torch.manual_seed(seed)
    inv_rho = 1.0 / rho
    i = torch.arange(n_step, dtype=torch.float64)
    sig = sigma_data * (s_max ** inv_rho + (i / n_step) * (s_min ** inv_rho - s_max ** inv_rho)) ** rho
    sigmas = torch.cat([sig, torch.zeros(1, dtype=torch.float64)]).float()      # (n_step+1,)
    gammas = torch.where(sigmas > gamma_min, torch.tensor(gamma0), torch.tensor(0.0))
    shape = (M, n_atoms, 3)
    # Shared-draws hook for the integration-parity gate (see tt_bio/boltz2.py
    # AtomDiffusion.sample for the full rationale). The ttnn and torch trunks
    # consume the global RNG differently between worker.py's single up-front
    # torch.manual_seed and this sampler, so device and CPU-reference folds would
    # otherwise draw DIFFERENT diffusion noise and the envelope numerator would
    # compare different basins, not arithmetic. edm_sample already re-seeds to
    # `seed` at its top, but that only holds when the caller threads a non-None
    # seed identically on both paths; TT_BIO_SHARED_DRAW_SEED forces an identical
    # global-RNG state immediately before the first draw regardless. Both protenix
    # and opendde route their initial noise through this one function, so this hook
    # covers both. Unset in production, so normal folds are untouched.
    import os as _os
    _sds = _os.environ.get("TT_BIO_SHARED_DRAW_SEED")
    if _sds:
        torch.manual_seed(int(_sds))
    # member_seeds gives each batch member its own host RNG stream, advanced in the order a
    # standalone fold advances it: initial noise, then per step the augmentation and eps. A
    # batch of DIFFERENT targets then draws exactly what each target would have drawn alone,
    # so a batched member is comparable to its own single fold rather than to a different
    # noise stream (memory diffusion-port-parity-shared-draws). Samples of one target keep
    # the single-stream behaviour (member_seeds=None).
    _per_member = None
    if member_seeds is not None:
        assert len(member_seeds) == M, f"member_seeds {len(member_seeds)} != multiplicity {M}"
        _states = []
        for _sd in member_seeds:
            torch.manual_seed(int(_sds) if _sds else (0 if _sd is None else int(_sd)))
            _states.append(torch.get_rng_state())

        def _per_member(fn):
            outs = []
            for _b in range(M):
                torch.set_rng_state(_states[_b])
                outs.append(fn())
                _states[_b] = torch.get_rng_state()
            return outs
        x = sigmas[0] * torch.cat(_per_member(lambda: torch.randn((1, n_atoms, 3))), 0)
    elif draws is not None:
        x = sigmas[0] * _take("init", shape)
    else:
        x = sigmas[0] * torch.randn(shape)
    if dump_fn is not None:                          # optional trajectory dump (default off)
        for _m in range(M):                          # preserve the (1,N,3) per-sample dump contract
            dump_fn(-1, x[_m:_m + 1].detach().cpu())  # step -1 == initial noise frame
    # Per-step chunked batched denoise (boltz2 max_parallel_samples pattern): one batched
    # _denoise call per chunk per step instead of one per sample per step. The chunking
    # is over the multiplicity dim only -- cond is shared (sample-invariant), so it is
    # NOT replicated; the device denoise is responsible for carrying the chunk's leading
    # dim through the atom encoder / DiT / decoder (see DiffusionModule.denoise).
    etas = step_scale_schedule(step_scale, n_step)
    width = resolve_sample_chunk_width(M, max_parallel_samples)
    # A multi-target batch concatenates its conditioning per member, so a chunk would slice
    # the coordinate stream but not the conditioning: it runs whole or not at all.
    narrowest = M if "_members" in cond else 1
    if guidance is not None and "_members" in cond:
        raise ValueError("guidance belongs to one target; fold guided targets one at a time")
    xdev, xdt = x.device, x.dtype

    def _draw(k):
        """Step k's augmentation and noise, `(R, tr, eps, t_hat, sigma_t, eta)`, in draw order."""
        sigma_tm, sigma_t, gamma = sigmas[k].item(), sigmas[k + 1].item(), gammas[k + 1].item()
        with serial_host():   # atom-sized host math, cheaper on one thread than fanned out
            if _per_member is not None:
                _aug = _per_member(lambda: compute_random_augmentation(1, device=xdev, dtype=xdt))
                R = torch.cat([a[0] for a in _aug], 0)
                tr = torch.cat([a[1] for a in _aug], 0)
            elif draws is not None:
                R, tr = _take("rot", (1, 3, 3)).transpose(-1, -2), _take("trans", (1, 1, 3))
            else:
                R, tr = compute_random_augmentation(M, device=xdev, dtype=xdt)
        t_hat = sigma_tm * (1 + gamma)
        noise_var = noise_scale ** 2 * (t_hat ** 2 - sigma_tm ** 2)
        if draws is not None:                        # upstream draws eps at every step, even at zero scale
            eps = max(noise_var, 0.0) ** 0.5 * _take("eps", shape)
        elif noise_var <= 0:
            eps = torch.zeros(shape)
        elif _per_member is not None:
            eps = (noise_var ** 0.5) * torch.cat(
                _per_member(lambda: torch.randn((1, n_atoms, 3))), 0)
        else:
            eps = (noise_var ** 0.5) * torch.randn(shape)
        return R, tr, eps, t_hat, sigma_t, etas[k]

    # edm_device: the trajectory stays on the card; the host only draws and stages each step.
    if (trace and guidance is None and dump_fn is None and width >= M and _T.lever("edm_device")
            and not os.environ.get("TT_BIO_TRUNK_TAP") and hasattr(diffusion_module, "rollout_ok")
            and diffusion_module.rollout_ok(cond, M)):
        return diffusion_module.rollout_device(x, cond, n_step, _draw, progress_fn)
    for k in range(n_step):
        if progress_fn:
            progress_fn("diffusion", step=k, total=n_step)
        R, tr, eps, t_hat, sigma_t, _ = _draw(k)
        with serial_host():
            x = x - x.mean(dim=-2, keepdim=True)
            x = torch.einsum("bmd,bds->bms", x, R) + tr
        x_noisy = x + eps
        t_dev = torch.tensor([t_hat], dtype=torch.float32)
        denoised, width = denoise_in_chunks(
            x_noisy, width, lambda chunk, _w: _denoise(chunk, t_dev, cond),
            narrowest=narrowest, tag="protenix diffusion")
        dram_peak(f"edm step {k}")
        trunk_tap_host(f"edm_denoised[step{k}]", denoised)
        if guidance is None:
            d = (x_noisy - denoised) / t_hat
            x = x_noisy + etas[k] * (sigma_t - t_hat) * d
        else:
            x = guidance.step(x_noisy, denoised, t_hat=t_hat, sigma_t=sigma_t, eta=etas[k],
                              step=k, n_step=n_step)
        trunk_tap_host(f"edm_x[step{k}]", x)
        if dump_fn is not None:                      # per-step coords (noise -> structure)
            for _m in range(M):
                dump_fn(k, x[_m:_m+1].detach().cpu())
    return x


class TrunkInput(_KeyedWeights, Module):
    """Protenix trunk input construction: s_inputs -> s_init, z_init.
    s_init = linear_sinit(s_inputs); z_init = zinit1(s_init)[:,None] + zinit2(s_init)[None]
    + relative_position_encoding(relp) + token_bond(token_bonds). All LinearNoBias.
    Reference: protenix/model/protenix.py get_pairformer_output (lines 208-226).
    Validated vs real v2 golden (PCC 0.999997). Mol-1-constraint's conditioner is folded into
    the token-bond projection at load (mol1_constraint.fold_weights), so token_bonds may carry
    1 + 5 channels."""

    def __init__(self, state_dict, compute_kernel_config):
        super().__init__(state_dict, compute_kernel_config)
        self._w = {k: v for k, v in self.weights.data.items()}

    def __call__(self, s_inputs, relp, token_bonds):
        """s_inputs (N,449); relp (N,N,139); token_bonds (N,N,1), or (N,N,6) under Mol-1-constraint. Returns (s_init (N,c_s),
        z_init (N,N,c_z))."""
        N = s_inputs.shape[0]
        s_init = self._lin(s_inputs, "linear_no_bias_sinit.weight")
        cz = self._w["linear_no_bias_zinit1.weight"].shape[0]
        z1 = ttnn.reshape(self._lin(s_init, "linear_no_bias_zinit1.weight"), (N, 1, cz))
        z2 = ttnn.reshape(self._lin(s_init, "linear_no_bias_zinit2.weight"), (1, N, cz))
        z = ttnn.add(z1, z2)
        rel = (self.relp_gather(*relp, N) if isinstance(relp, tuple)
               else self._lin(relp, "relative_position_encoding.linear_no_bias.weight"))
        z = ttnn.add(z, rel)
        z = ttnn.add(z, self._lin(token_bonds, "linear_no_bias_token_bond.weight"))
        return s_init, z

    # relp_gather: column k of the 139-wide one-hot -> its digit in one joint id per pair,
    # ((d_res * 66 + d_tok) * 2 + same_entity) * 6 + d_chain. Exact in fp32 (max 52271).
    _RELP_CODE = torch.cat([torch.arange(66) * 792, torch.arange(66) * 12, torch.tensor([6]),
                            torch.arange(6)]).float()

    def relp_index(self, relp):
        """Host half of `relp_gather`, run on the host lane: `(index [N, N] int32, table [U, c_z])`.

        Each pair's relp row is a one-hot of four offsets (or all zero in a token-bucket pad), so
        the projection is the sum of at most four weight rows. The table holds that sum once per
        distinct row of this fold, in fp32 from the bf16 weights the device multiplies, rounded
        once to bf16; the device then gathers rows instead of reading a 139-wide tensor.
        None when relp is not a 0/1 one-hot (a poisoned pad), which takes the matmul path."""
        flat = relp.reshape(-1, relp.shape[-1]).float()
        if flat.shape[-1] != self._RELP_CODE.numel() or _pad_poison() != 0.0:
            return None
        ids = flat @ self._RELP_CODE + (flat.sum(-1) == 0).float() * 52272
        uniq, first = torch.unique(ids, return_inverse=True)
        rep = torch.zeros(uniq.numel(), dtype=torch.long).scatter_(
            0, first, torch.arange(first.numel()))
        w = self._w["relative_position_encoding.linear_no_bias.weight"].to(torch.bfloat16).float()
        table = (flat[rep] @ w.t()).to(torch.bfloat16)
        return first.reshape(relp.shape[:-1]).to(torch.int32), table

    def relp_gather(self, index, table, N):
        """Device half of `relp_gather`: the relative-position projection, [N, N, c_z] bf16."""
        dev = get_device()
        tab = ttnn.from_torch(table, layout=ttnn.ROW_MAJOR_LAYOUT, device=dev, dtype=ttnn.bfloat16)
        idx = ttnn.from_torch(index.reshape(1, -1), layout=ttnn.ROW_MAJOR_LAYOUT, device=dev,
                              dtype=ttnn.uint32)
        g = ttnn.embedding(idx, tab, layout=ttnn.ROW_MAJOR_LAYOUT, memory_config=ttnn.DRAM_MEMORY_CONFIG)
        ttnn.deallocate(idx)
        ttnn.deallocate(tab)
        out = ttnn.to_layout(ttnn.reshape(g, (N, N, table.shape[-1])), ttnn.TILE_LAYOUT)
        ttnn.deallocate(g)
        return out
