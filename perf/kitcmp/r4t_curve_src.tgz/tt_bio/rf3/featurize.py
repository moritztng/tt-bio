"""RF3 host featurizer.

Turns a user input (JSON / CIF / PDB) into the 35-key ``f`` dict the on-device RF3
trunk and diffusion module consume, plus the ground-truth, confidence and sampler
tensors that ride alongside it.

The AF3 transform pipeline itself is upstream code, vendored under
``tt_bio._vendor.atomworks`` and ``tt_bio._vendor.rf3`` rather than reimplemented:
it is host-side, it is where every capability lives (nucleic acids, ligands,
covalent modifications, chirality perception, MSA pairing, templating), and
reimplementing it would buy nothing but a chance to diverge.

Upstream builds this pipeline from a config stored inside the checkpoint. That
config resolves to a flat kwargs dict, reproduced here as ``PIPELINE_CONFIG`` so
tt-bio needs neither hydra nor the checkpoint to featurize. It is verified against
committed reference captures by ``scripts/rf3_port/parity_gate.py``.

Two facts that bite if you touch this:

- Seed ``random``, ``numpy`` AND ``torch``. RDKit's ETKDG conformer embedding reads
  the python/numpy RNG, so a torch-only seed leaves ``f["ref_pos"]`` different run
  to run. :func:`seed_everything` does all three.
- ``f["cyclic_asym_ids"]`` is a plain list, not a tensor. The model reads it.
"""

from __future__ import annotations

import os
from typing import Any

import numpy as np
import torch

from tt_bio.runtime import seed_everything

# Resolved from `cfg.datasets.val.af3_validation.dataset.transform` merged with
# RF3InferenceEngine's transform_overrides, checkpoint rf3_foundry_01_24_latest_remapped.
# Values that are engine arguments rather than checkpoint constants are named in
# DEFAULTS below and can be overridden per call.
PIPELINE_CONFIG: dict[str, Any] = {
    "is_inference": True,
    "add_residue_is_paired_feature": True,
    "allowed_chain_types_for_conditioning": None,
    "crop_size": None,
    "fallback_conformer_to_input_coords": True,
    "max_atoms_in_crop": None,
    "n_msa": 1024,
    "p_dropout_atom_level_embeddings": 0.0,
    "p_dropout_ref_conf": 0.0,
    "p_give_non_polymer_ref_conf": 0.0,
    "p_give_polymer_ref_conf": 0.0,
    "p_unconditional": 1.0,
    "protein_msa_dirs": [],
    "raise_if_missing_msa_for_protein_of_length_n": None,
    "return_atom_array": True,
    "rna_msa_dirs": [],
    "run_confidence_head": True,
    "take_first_chiral_subordering": False,
    "template_noise_scales": {"atomized": 1e-05, "not_atomized": 1e-05},
    "undesired_res_names": [],
    "use_element_for_atom_names_of_atomized_tokens": True,
}

#: Engine-level knobs, exposed so the CLI can set them.
DEFAULTS = {"n_recycles": 10, "diffusion_batch_size": 5, "seed": 42}


def build_pipeline(
    n_recycles: int = DEFAULTS["n_recycles"],
    diffusion_batch_size: int = DEFAULTS["diffusion_batch_size"],
    **overrides: Any,
):
    """Build the AF3 transform pipeline with RF3's inference configuration."""
    from tt_bio._vendor.rf3.data.pipelines import build_af3_transform_pipeline

    cfg = dict(PIPELINE_CONFIG)
    cfg["n_recycles"] = n_recycles
    cfg["diffusion_batch_size"] = diffusion_batch_size
    cfg.update(overrides)
    return build_af3_transform_pipeline(**cfg)


def read_inputs(
    path: str | os.PathLike,
    *,
    template_selection: list[str] | None = None,
    ground_truth_conformer_selection: list[str] | None = None,
    cyclic_chains: list[str] | None = None,
) -> list:
    """Parse a JSON / CIF / PDB input (or a directory of them) into input specs.

    ``template_selection`` and ``ground_truth_conformer_selection`` given here
    override any selection carried in the file itself.
    """
    from pathlib import Path

    from tt_bio._vendor.rf3.utils.inference import (_process_single_path,
                                                     prepare_inference_inputs_from_paths)

    path = Path(os.path.abspath(path))
    if path.is_file():
        # Upstream parses through a process pool sized to the file count, so one file still forks a
        # worker and waits on it: 4.3 s of a 6.1 s featurize at 512 aa. The same parser, in process.
        specs = _process_single_path(path, None, None, template_selection,
                                     ground_truth_conformer_selection, True)
    else:
        specs = prepare_inference_inputs_from_paths(
            inputs=path,
            existing_outputs_dir=None,
            sharding_pattern=None,
            template_selection=template_selection,
            ground_truth_conformer_selection=ground_truth_conformer_selection,
            add_missing_atoms=True,
        )
    if cyclic_chains:
        for spec in specs:
            spec.cyclic_chains = cyclic_chains
    return specs


def apply_template_ca(atom_array, template_ca: dict) -> None:
    """Template residues by coordinate, in place.

    RF3's template is the input's own token-centre coordinates (CA for a protein residue) on
    the tokens ``is_input_file_templated`` marks, turned into a distogram by
    ``FeaturizeNoisedGroundTruthAsTemplateDistogram``. A spec built from sequences has no
    coordinates, so a template from another file is written onto those CAs: ``template_ca``
    maps a chain id to ``(ca (L, 3), mask (L,))`` over that chain's residues, from the
    template alignment shared with every other template model (``tt_bio.template_cif``).
    """
    cats = atom_array.get_annotation_categories()
    templated = (atom_array.get_annotation("is_input_file_templated").astype(bool)
                 if "is_input_file_templated" in cats else np.zeros(len(atom_array), bool))
    is_ca = atom_array.atom_name == "CA"
    for cid, (ca, mask) in template_ca.items():
        in_chain = np.flatnonzero(atom_array.chain_id == cid)
        res = atom_array.res_id[in_chain] - 1
        keep = (res >= 0) & (res < len(mask))
        in_chain, res = in_chain[keep], res[keep]
        hit = mask[res].astype(bool)
        templated[in_chain[hit]] = True
        ca_rows = hit & is_ca[in_chain]
        atom_array.coord[in_chain[ca_rows]] = ca[res[ca_rows]]
    atom_array.set_annotation("is_input_file_templated", templated)


def featurize(
    path: str | os.PathLike,
    *,
    n_recycles: int = DEFAULTS["n_recycles"],
    diffusion_batch_size: int = DEFAULTS["diffusion_batch_size"],
    seed: int = DEFAULTS["seed"],
    template_selection: list[str] | None = None,
    ground_truth_conformer_selection: list[str] | None = None,
    cyclic_chains: list[str] | None = None,
    template_ca: dict | None = None,
    pipeline=None,
) -> list[dict]:
    """Featurize every example in ``path``.

    Returns one pipeline-output dict per example, each with ``feats`` (the 35-key
    ``f``), ``ground_truth``, ``confidence_feats``, ``atom_array``, and the sampler
    inputs ``t`` / ``noise`` / ``coord_atom_lvl_to_be_noised``.

    Pass ``pipeline`` to reuse one across calls; building it is not free.
    ``template_ca`` templates residues by coordinate (:func:`apply_template_ca`).
    """
    if pipeline is None:
        pipeline = build_pipeline(n_recycles, diffusion_batch_size)
    specs = read_inputs(
        path,
        template_selection=template_selection,
        ground_truth_conformer_selection=ground_truth_conformer_selection,
        cyclic_chains=cyclic_chains,
    )
    out = []
    for spec in specs:
        if template_ca:
            apply_template_ca(spec.atom_array, template_ca)
        seed_everything(seed)
        out.append(pipeline(spec.to_pipeline_input()))
    return out


def network_input(out: dict) -> dict:
    """Assemble the model input from one pipeline output.

    Mirrors upstream's ``RF3Trainer._assemble_network_inputs`` and the
    with-confidence override on top of it. Two things to note: the feature dict
    goes under ``f``, not ``feats``, and the three confidence keys are pulled from
    ``confidence_feats`` / ``ground_truth``, not from ``feats``. The ttnn port has
    to build exactly this.
    """
    inp = {
        "X_noisy_L": out["coord_atom_lvl_to_be_noised"] + out["noise"],
        "t": out["t"],
        "f": out["feats"],
    }
    conf = out.get("confidence_feats")
    if conf is not None:
        inp.update({
            "seq": conf["rf2aa_seq"],
            "rep_atom_idxs": out["ground_truth"]["rep_atom_idxs"],
            "frame_atom_idxs": conf["pae_frame_idx_token_lvl_from_atom_lvl"],
        })
    return inp


def n_cycle(out: dict) -> int:
    """Recycle count the features were built for.

    Upstream reads it off the MSA stack rather than the config, because the
    featurizer draws one i.i.d. MSA sample per recycle.
    """
    return int(out["feats"]["msa_stack"].shape[0])
