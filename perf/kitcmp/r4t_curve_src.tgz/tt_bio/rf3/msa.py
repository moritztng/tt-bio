"""RF3 MSA module on ttnn.

Composed from tt-bio's shared `OuterProductMean`, `PairWeightedAveraging`,
`Transition` and `PairformerLayer` rather than reusing `MSALayer`, because RF3
differs from it in two ways that a weight remap cannot see:

- **Weight-shared.** The checkpoint holds one set of weights under
  ``recycler.msa_module`` with no block index at all; upstream constructs its
  sub-modules once and loops ``n_block`` times over them. `MSALayer` is built per
  block, so reusing it would mean four blocks fed from one block's weights.
- **Outer product first.** RF3 updates the pair representation from the previous
  iteration's MSA before pair-weighted averaging reads it. `MSALayer` runs
  pwa -> transition -> outer_product -> pairformer, which is a different
  computation, and the two orders are not rotations of each other because the
  pairformer sits differently relative to the outer product.

Conventions taken from the reference rather than guessed
(`rf3/model/layers/outer_product.py`, `model/RF3_blocks.py`):

- The outer product divides its right projection by the MSA depth before
  contracting and adds ``proj_out``'s bias at full strength afterwards, which is
  tt-bio's default (``scale_bias=False``).
- The inner pairformer uses the same RF3 settings as the trunk one:
  ``scale_pair_bias=False`` (q is pre-scaled, the pair bias added unscaled) and
  ``transpose_bias=False`` (the ending pair bias is built before the transpose).
"""

from __future__ import annotations

import ttnn

from tt_bio.envflags import env_flag
from tt_bio.rf3.remap import tri_att_fused_flags
from tt_bio.tenstorrent import (
    Module,
    OuterProductMean,
    PairformerLayer,
    PairWeightedAveraging,
    Transition,
    Weights,
)

#: MSA-module channel dims, from configs/model/components/rf3_net.yaml.
C_M = 64
PWA_HEAD_DIM, PWA_N_HEADS = 32, 8
TRI_ATT_HEAD_DIM, TRI_ATT_N_HEADS = 32, 4

#: Route this block's triangle attention through the fused SDPA, as the trunk stack, the
#: confidence head and the template embedder already do via `remap.PAIRFORMER_FLAGS`.
#:
#: This was the one RF3 triangle-attention site left on the materialised fp32-softmax chain,
#: and it is what sets the Wormhole size ceiling. That chain writes the whole score tensor,
#: [tokens, heads, S, S], and `_FP32_SOFTMAX_BLOCK_BYTES` is 8 GiB, so on a 12 GiB part it
#: never blocks: at 650 tokens the bf16 half alone is 650 x 4 x 672 x 672 x 2 = 2.348 GB and
#: the fp32 copy is 4.70 GB. That is the exact request the 650 aa fold died on at trunk 0/10
#: (measured 2026-09-02, 9mnb: "Not enough space to allocate 2348236800 B DRAM buffer"), and
#: 656 aa died on 2369912832 B, the same tensor six tokens wider. The fused kernel never
#: materialises it.
#:
#: `sdpa_ragged_pad` ships with it and never without: this block runs on the RAW token axis
#: (the trunk buckets to a multiple of 32 only around the 48-block stack downstream), so the
#: key tail is ragged on every input that is not a multiple of 32, and the fused kernel is
#: 71-76x wrong there unmasked -- `remap.PAIRFORMER_FLAGS` records the same pairing for the
#: trunk site.
#:
#: Set TT_BIO_RF3_MSA_FUSED_SDPA=0 for the old materialised route.
_MSA_FUSED_SDPA = env_flag("TT_BIO_RF3_MSA_FUSED_SDPA", True)


class MSASubsampleEmbedder(Module):
    """``emb_msa(msa) + emb_S_inputs(S_inputs)``. Both projections are bias-free."""

    def __init__(self, state_dict: Weights, compute_kernel_config):
        super().__init__(state_dict, compute_kernel_config)
        self.msa_weight = self.torch_to_tt("emb_msa.weight")
        self.s_weight = self.torch_to_tt("emb_S_inputs.weight")

    def __call__(self, msa: ttnn.Tensor, s_inputs: ttnn.Tensor) -> ttnn.Tensor:
        m = ttnn.linear(
            msa, self.msa_weight, compute_kernel_config=self.compute_kernel_config
        )
        s = ttnn.linear(
            s_inputs, self.s_weight, compute_kernel_config=self.compute_kernel_config
        )
        # s is per-token [I, c_m]; it broadcasts over the MSA depth axis of m.
        return ttnn.add_(m, s)


class MSAModule(Module):
    """RF3's MSA module: one weight-shared block applied ``n_block`` times."""

    def __init__(
        self,
        n_block: int,
        state_dict: Weights,
        compute_kernel_config,
    ):
        super().__init__(state_dict, compute_kernel_config)
        self.n_block = n_block
        self.subsampler = MSASubsampleEmbedder(
            self.scope("msa_subsampler"), compute_kernel_config
        )
        self.outer_product = OuterProductMean(
            self.scope("outer_product"), compute_kernel_config
        )
        self.pair_weighted_averaging = PairWeightedAveraging(
            PWA_HEAD_DIM,
            PWA_N_HEADS,
            self.scope("msa_pair_weighted_averaging"),
            compute_kernel_config,
        )
        self.msa_transition = Transition(
            self.scope("msa_transition"), compute_kernel_config
        )
        # transform_s=False: the block updates only the pair representation.
        self.pairformer_layer = PairformerLayer(
            TRI_ATT_HEAD_DIM,
            TRI_ATT_N_HEADS,
            None,
            None,
            False,
            self.scope("pairformer_layer"),
            compute_kernel_config,
            scale_pair_bias=False,
            transpose_bias=False,
            # fp32_softmax=True was "the reference's softmax stays fp32 under autocast"
            # (template.py). The fused route reached the same accuracy once the ragged key
            # tail was masked, which is why the trunk switched; see _MSA_FUSED_SDPA.
            **tri_att_fused_flags(_MSA_FUSED_SDPA),
        )

    def __call__(
        self,
        msa: ttnn.Tensor,
        z: ttnn.Tensor,
        s_inputs: ttnn.Tensor,
        mask: ttnn.Tensor | None = None,
        attn_mask: ttnn.Tensor | None = None,
        msa_mask: ttnn.Tensor | None = None,
        n_msa: int | None = None,
    ) -> ttnn.Tensor:
        m = self.subsampler(msa, s_inputs)
        for _ in range(self.n_block):
            # Outer product FIRST: z carries the previous iteration's MSA before
            # pair-weighted averaging reads it. This ordering is the whole reason
            # this class exists instead of reusing MSALayer.
            z_update = self.outer_product(m, msa_mask, n_msa)
            z = ttnn.add_(z, z_update)
            ttnn.deallocate(z_update)

            m_update = self.pair_weighted_averaging(m, z, attn_mask)
            m = ttnn.add_(m, m_update)
            ttnn.deallocate(m_update)

            m_update = self.msa_transition(m)
            m = ttnn.add_(m, m_update)
            ttnn.deallocate(m_update)

            z = self.pairformer_layer(
                None, z, mask=mask,
                attn_mask_start=attn_mask, attn_mask_end=attn_mask,
            )[1]
        ttnn.deallocate(m)
        return z
