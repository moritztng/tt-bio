// SPDX-FileCopyrightText: © 2026 Tenstorrent AI ULC
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include <cstdint>
#include <algorithm>
#include <tuple>
#include <utility>
#include "api/dataflow/dataflow_api.h"

namespace detail {
/**
 * Helper to create tuple of TensorAccessors from TensorAccessorArgs tuple.
 * Unlike make_tensor_accessor_tuple, this takes the actual page_size value,
 * not a Compile Time Argument (CTA) index.
 */
template <typename... Args, uint32_t... Indexes>
auto make_tensor_accessor_tuple_with_page_size(
    const std::tuple<Args...>& args_tuple,
    uint32_t address_rt_arg_index_start,
    uint32_t page_size,
    std::integer_sequence<uint32_t, Indexes...>) {
    return std::make_tuple(TensorAccessor(
        std::get<Indexes>(args_tuple), get_arg_val<uint32_t>(address_rt_arg_index_start + Indexes), page_size)...);
}
}  // namespace detail

/**
 * Create a tuple of TensorAccessors from a tuple of TensorAccessorArgs.
 * Each tensor gets its address from consecutive RT args starting at address_rt_arg_index_start.
 * All tensors share the same page_size (actual value, not CTA index).
 */
template <typename... Args>
auto make_tensor_accessor_tuple_uniform_page_size(
    const std::tuple<Args...>& args_tuple, uint32_t address_rt_arg_index_start, uint32_t page_size) {
    return detail::make_tensor_accessor_tuple_with_page_size(
        args_tuple, address_rt_arg_index_start, page_size, std::make_integer_sequence<uint32_t, sizeof...(Args)>());
}
void fill_zeros_async(uint32_t write_addr, uint32_t tile_bytes) {
    volatile tt_l1_ptr uint32_t* ptr = reinterpret_cast<volatile tt_l1_ptr uint32_t*>(write_addr);
    uint64_t zeros_noc_addr = get_noc_addr(MEM_ZEROS_BASE);
    // Fill tile with zeros
    uint32_t bytes_left = tile_bytes;
    for (;;) {
        uint32_t read_size = bytes_left > MEM_ZEROS_SIZE ? MEM_ZEROS_SIZE : bytes_left;
        noc_async_read(zeros_noc_addr, write_addr, read_size);
        write_addr += read_size;
        bytes_left -= read_size;
        if (bytes_left == 0) {
            break;
        }
    }
}

struct TensorShape2D {
    uint32_t logical_d0;
    uint32_t logical_d1;
    uint32_t padded_d0;
    uint32_t padded_d1;
    // Constructor to initialize with 2D shape
    TensorShape2D(uint32_t _d0, uint32_t _d1, uint32_t _padded_d0, uint32_t _padded_d1) :
        logical_d0(_d0), logical_d1(_d1), padded_d0(_padded_d0), padded_d1(_padded_d1) {
        ASSERT(_d0 > 0);
        ASSERT(_d1 > 0);
        ASSERT(_d0 <= _padded_d0);
        ASSERT(_d1 <= _padded_d1);
    }
};

/**
 * Read a block of in0 from a potentially padded tensor.
 * Since this is for matmul, no need to read when M >= logical_M
 * Otherwise, if K >= logical_K, fill with zeros.
 */
template <
    uint32_t M_block_tiles,
    uint32_t K_block_tiles,
    typename TensorAccessorType
#ifdef READ_FROM_LOCAL_INPUT
    ,
    typename LocalTensorAccessorType
#endif
    >
void read_in0_block_sync(
    const TensorAccessorType& tensor_accessor,
    const TensorShape2D& shape,
    uint32_t write_ptr,
    uint32_t tile_size_bytes,
#ifdef READ_FROM_LOCAL_INPUT
    const LocalTensorAccessorType& in3_accessor,
    uint32_t local_k_start,
    uint32_t local_k_end,
    uint32_t input_tensor_Wt,
#endif
    uint32_t d0_start,
    uint32_t d0_end,
    uint32_t d1_start,
    uint32_t d1_end) {
    ASSERT(d0_end > d0_start);
    ASSERT(d1_end > d1_start);

    for (uint32_t i = d0_start; i < d0_end; i++) {
        if (i >= shape.logical_d0) {
            break;
        }
        for (uint32_t j = d1_start; j < d1_end; j++) {
            if (j < shape.logical_d1) {
#ifdef READ_FROM_LOCAL_INPUT
                if (local_k_start <= j && j <= local_k_end) {
                    // read from self_tensor_accessor
                    uint32_t tile_id = i * input_tensor_Wt + (j - local_k_start);
                    noc_async_read_tile(tile_id, in3_accessor, write_ptr);
                } else {
#endif
                    uint32_t tile_id = i * shape.logical_d1 + j;
                    noc_async_read_tile(tile_id, tensor_accessor, write_ptr);
#ifdef READ_FROM_LOCAL_INPUT
                }
#endif
            } else {
                fill_zeros_async(write_ptr, tile_size_bytes);
            }
            write_ptr += tile_size_bytes;
        }
        // finish up incrementing write_ptr if (d1_end - d1_start) < K_block_tiles
        write_ptr += (K_block_tiles - (d1_end - d1_start)) * tile_size_bytes;
    }
    noc_async_read_barrier();
}

/**
 * Read a block of in1 from a potentially padded tensor.
 * Since this is for matmul, no need to read when N >= logical_N
 * Otherwise, if K >= logical_K, fill with zeros.
 */
template <uint32_t K_block_tiles, uint32_t N_block_tiles, typename TensorAccessorType>
void read_in1_block_sync(
    const TensorAccessorType& tensor_accessor,
    const TensorShape2D& shape,
    uint32_t write_ptr,
    uint32_t tile_size_bytes,
    uint32_t d0_start,
    uint32_t d0_end,
    uint32_t d1_start,
    uint32_t d1_end) {
    ASSERT(d0_end > d0_start);
    ASSERT(d1_end > d1_start);
    for (uint32_t i = d0_start; i < d0_end; i++) {
        for (uint32_t j = d1_start; j < d1_end; j++) {
            if (j >= shape.logical_d1) {
                write_ptr += tile_size_bytes;
                continue;
            }
            if (i < shape.logical_d0) {
                uint32_t tile_id = i * shape.logical_d1 + j;
                noc_async_read_tile(tile_id, tensor_accessor, write_ptr);
            } else {
                fill_zeros_async(write_ptr, tile_size_bytes);
            }
            write_ptr += tile_size_bytes;
        }
        // finish up incrementing write_ptr if (d1_end - d1_start) < K_block_tiles
        write_ptr += (N_block_tiles - (d1_end - d1_start)) * tile_size_bytes;
    }
    noc_async_read_barrier();
}

/**
 * Write a block of output to a potentially padded tensor.
 * Skip writing when M >= logical_M or N >= logical_N
 */
template <uint32_t M_block_tiles, uint32_t N_block_tiles, typename TensorAccessorType>
void write_block_sync(
    const TensorAccessorType& tensor_accessor,
    const TensorShape2D& shape,
    uint32_t read_ptr,
    uint32_t tile_size_bytes,
    uint32_t d0_start,
    uint32_t d0_end,
    uint32_t d1_start,
    uint32_t d1_end) {
    ASSERT(d0_end > d0_start);
    ASSERT(d1_end > d1_start);

    for (uint32_t i = d0_start; i < d0_end; i++) {
        if (i >= shape.logical_d0) {
            break;
        }
        for (uint32_t j = d1_start; j < d1_end; j++) {
            if (j >= shape.logical_d1) {
                read_ptr += tile_size_bytes;
                continue;
            }
            uint32_t tile_id = i * shape.logical_d1 + j;
            noc_async_write_tile(tile_id, tensor_accessor, read_ptr);
            read_ptr += tile_size_bytes;
        }
        // finish up incrementing read_ptr if (d1_end - d1_start) < N_block_tiles
        read_ptr += (N_block_tiles - (d1_end - d1_start)) * tile_size_bytes;
    }
    noc_async_writes_flushed();
}

/**
 * Read ternary inputs (ternary_a and ternary_b) and write data to CB
 *
 * For ternary_a: read M_block_tiles * N_block_tiles tiles (full block)
 * For ternary_b: only read 1 row of tiles (N_block_tiles). Compute kernel will bcast this row.
 *
 * Performance optimization: Unlike read_in0_block_sync and read_in1_block_sync, pushes ternary_a
 * tiles one row at a time. This allows the compute kernel to begin processing addcmul operations
 * as soon as the first row is ready, rather than waiting for the entire block. This overlapping
 * of data movement and compute improves overall throughput.
 */
template <uint32_t M_block_tiles, uint32_t N_block_tiles, typename TensorAccessorType>
void read_ternary_blocks_sync(
    const TensorAccessorType& ternary_a_accessor,
    const TensorAccessorType& ternary_b_accessor,
    const TensorShape2D& shape,
    uint32_t ternary_a_cb,
    uint32_t ternary_b_cb,
    uint32_t a_tile_size_bytes,
    uint32_t b_tile_size_bytes,
    uint32_t d0_start,
    uint32_t d0_end,
    uint32_t d1_start,
    uint32_t d1_end) {
    ASSERT(d0_end > d0_start);
    ASSERT(d1_end > d1_start);

    cb_reserve_back(ternary_b_cb, N_block_tiles);
    uint32_t ternary_b_write_ptr = get_write_ptr(ternary_b_cb);
    for (uint32_t n_tile_id = d1_start; n_tile_id < d1_end; n_tile_id++) {
        if (n_tile_id >= shape.logical_d1) {
            // Do not move tile data into CB if tile is outside ternary/output tensor.
            // This can happen when ternary/output tensor shape is not a multiple of block sizes:
            // For instance, if tensor shape is (M_tiles=7, N_tiles=3), but block sizes are (M_block_tiles=4,
            // N_block_tiles=4)
            break;
        }

        noc_async_read_tile(n_tile_id, ternary_b_accessor, ternary_b_write_ptr);
        ternary_b_write_ptr += b_tile_size_bytes;
    }
    noc_async_read_barrier();

    cb_push_back(ternary_b_cb, N_block_tiles);

    uint32_t m_id = 0;
    uint32_t i = d0_start;
    for (; i < d0_end; i++, m_id++) {
        cb_reserve_back(ternary_a_cb, N_block_tiles);

        uint32_t ternary_a_write_ptr = get_write_ptr(ternary_a_cb);
        for (uint32_t j = d1_start; j < d1_end; j++) {
            if (j >= shape.logical_d1) {
                // Do not move tile data into CB if tile is outside ternary/output tensor.
                // This can happen when ternary/output tensor shape is not a multiple of block sizes:
                // For instance, if tensor shape is (M_tiles=7, N_tiles=3), but block sizes are (M_block_tiles=4,
                // N_block_tiles=4)
                break;
            }
            if (i < shape.logical_d0) {
                uint32_t tile_id = i * shape.logical_d1 + j;
                noc_async_read_tile(tile_id, ternary_a_accessor, ternary_a_write_ptr);
            }
            ternary_a_write_ptr += a_tile_size_bytes;
        }
        noc_async_read_barrier();

        cb_push_back(ternary_a_cb, N_block_tiles);
    }
    for (; m_id < M_block_tiles; m_id++) {
        cb_reserve_back(ternary_a_cb, N_block_tiles);
        cb_push_back(ternary_a_cb, N_block_tiles);
    }
}

#ifdef MM_RESID
/**
 * tt-bio mm_resid: the residual's [M, N] output block into c_5, row by row, as read_ternary_blocks_sync reads
 * ternary_a (rows past the tensor are pushed unread).
 */
template <uint32_t M_block_tiles, uint32_t N_block_tiles, typename TensorAccessorType>
void read_resid_block(
    const TensorAccessorType& resid, const TensorShape2D& shape, uint32_t tile_size, uint32_t d0_start,
    uint32_t d0_end, uint32_t d1_start, uint32_t d1_end) {
    constexpr uint32_t cb = tt::CBIndex::c_5;
    uint32_t m_id = 0;
    for (uint32_t i = d0_start; i < d0_end; i++, m_id++) {
        cb_reserve_back(cb, N_block_tiles);
        uint32_t ptr = get_write_ptr(cb);
        for (uint32_t j = d1_start; j < d1_end && j < shape.logical_d1; j++, ptr += tile_size) {
            if (i < shape.logical_d0) {
                noc_async_read_tile(i * shape.logical_d1 + j, resid, ptr);
            }
        }
        noc_async_read_barrier();
        cb_push_back(cb, N_block_tiles);
    }
    for (; m_id < M_block_tiles; m_id++) {
        cb_reserve_back(cb, N_block_tiles);
        cb_push_back(cb, N_block_tiles);
    }
}
#endif

#ifdef MM_GRES
/**
 * tt-bio mm_gres: the gate's [M, N] output block into c_6, as read_resid_block reads the residual. The gate is a column
 * window of a tensor GATE_WT tiles wide whose output-tile (i, j) is page page0 + i * GATE_WT + j, so a conditioning
 * tensor that stacks several diffusion steps' gates side by side (and down its rows) is read in place, never cut.
 */
template <uint32_t M_block_tiles, uint32_t N_block_tiles, uint32_t GATE_WT, typename TensorAccessorType>
void read_gate_block(
    const TensorAccessorType& gate, const TensorShape2D& shape, uint32_t tile_size, uint32_t page0, uint32_t d0_start,
    uint32_t d0_end, uint32_t d1_start, uint32_t d1_end) {
    constexpr uint32_t cb = tt::CBIndex::c_6;
    uint32_t m_id = 0;
    for (uint32_t i = d0_start; i < d0_end; i++, m_id++) {
        cb_reserve_back(cb, N_block_tiles);
        uint32_t ptr = get_write_ptr(cb);
        for (uint32_t j = d1_start; j < d1_end && j < shape.logical_d1; j++, ptr += tile_size) {
            if (i < shape.logical_d0) {
                noc_async_read_tile(page0 + i * GATE_WT + j, gate, ptr);
            }
        }
        noc_async_read_barrier();
        cb_push_back(cb, N_block_tiles);
    }
    for (; m_id < M_block_tiles; m_id++) {
        cb_reserve_back(cb, N_block_tiles);
        cb_push_back(cb, N_block_tiles);
    }
}
#endif

/**
 * This write method is more granular, waiting on a row of output tiles
 * in the output CB before writing those out, rather than waiting on the entire block.
 */
template <uint32_t M_block_tiles, uint32_t N_block_tiles, typename TensorAccessorType>
void write_block_sync_granular(
    const TensorAccessorType& tensor_accessor,
    const TensorShape2D& shape,
    uint32_t cb_id_out,
    uint32_t tile_size_bytes,
    uint32_t d0_start,
    uint32_t d0_end,
    uint32_t d1_start,
    uint32_t d1_end) {
    for (uint32_t m_id = 0; m_id < M_block_tiles; m_id++) {
        cb_wait_front(cb_id_out, N_block_tiles);
        uint32_t m_tile = d0_start + m_id;
        if (m_tile < d0_end && m_tile < shape.logical_d0) {
            uint32_t out_read_ptr = get_read_ptr(cb_id_out);
            for (uint32_t n_tile_id = d1_start; n_tile_id < d1_end; n_tile_id++) {
                if (n_tile_id >= shape.logical_d1) {
                    break;
                }
                uint32_t tile_id = m_tile * shape.logical_d1 + n_tile_id;
                noc_async_write_tile(tile_id, tensor_accessor, out_read_ptr);
                out_read_ptr += tile_size_bytes;
            }
        }
        cb_pop_front(cb_id_out, N_block_tiles);
    }
    noc_async_writes_flushed();
}

/**
 * tt-bio mm_rope: the page of output tile (m, n) of a chunk d1 tiles wide. Under MM_HEADS_ST the chunk is written per
 * head, [B, H, S, 64] with S = MM_HEADS_ST tiles: row tile m is (batch m / S, position m % S) and column tile n is
 * (head n / 2, half n % 2), so the qkv matmul writes q, k and v in the layout SDPA reads, nlp_create_qkv_heads' layout.
 */
FORCE_INLINE uint32_t chunk_tile_id(uint32_t m, uint32_t n, uint32_t d1) {
#ifdef MM_HEADS_ST
    constexpr uint32_t st = MM_HEADS_ST;
    return ((m / st * (d1 >> 1) + (n >> 1)) * st + m % st) * 2 + (n & 1);
#else
    return m * d1 + n;
#endif
}

#ifdef MM_ROPE_T
/**
 * tt-bio mm_rope: the weight's columns are permuted per core so that each core's MM_ROPE_T tiles are MM_ROPE_P q / k
 * tiles (whole heads, so the compute epilogue can rotate them) then MM_ROPE_T - MM_ROPE_P v tiles. The original qkv
 * column of permuted column n; v starts at column MM_ROPE_V0.
 */
FORCE_INLINE uint32_t rope_col(uint32_t n) {
    constexpr uint32_t t = MM_ROPE_T, p = MM_ROPE_P;
    const uint32_t r = n / t, j = n % t;
    return j < p ? r * p + j : MM_ROPE_V0 + r * (t - p) + j - p;
}

/**
 * The cos and sin tiles of an output block's M_block_tiles rows into c_7 / c_8: row tile m is position m % MM_HEADS_ST,
 * page 2 (m % S) of the [1, 1, L, 64] tables (both column tiles are equal). Rows past m_tile_end are left unread.
 */
template <uint32_t M_block_tiles, typename CA, typename SA>
FORCE_INLINE void read_rope_block(const CA& cs, const SA& sn, uint32_t tile_size, uint32_t m_tile, uint32_t m_tile_end) {
    constexpr uint32_t st = MM_HEADS_ST;
    cb_reserve_back(tt::CBIndex::c_7, M_block_tiles);
    cb_reserve_back(tt::CBIndex::c_8, M_block_tiles);
    uint32_t wc = get_write_ptr(tt::CBIndex::c_7), ws = get_write_ptr(tt::CBIndex::c_8);
    for (uint32_t m = m_tile; m < m_tile_end; m++, wc += tile_size, ws += tile_size) {
        noc_async_read_tile((m % st) * 2, cs, wc);
        noc_async_read_tile((m % st) * 2, sn, ws);
    }
    noc_async_read_barrier();
    cb_push_back(tt::CBIndex::c_7, M_block_tiles);
    cb_push_back(tt::CBIndex::c_8, M_block_tiles);
}
#endif

/**
 * Helper: dispatch to correct tuple element using fold expression.
 * Each branch calls noc_async_write_tile with the concrete TensorAccessor type.
 */
template <typename Tuple, size_t... Is>
FORCE_INLINE void write_tile_to_chunk(
    const Tuple& accessors, uint32_t chunk_idx, uint32_t tile_id, uint32_t read_ptr, std::index_sequence<Is...>) {
    // Fold expression: expands to if/else chain at compile time
    // Each branch calls noc_async_write_tile with the concrete type
    ((chunk_idx == Is ? (noc_async_write_tile(tile_id, std::get<Is>(accessors), read_ptr), void()) : void()), ...);
}

#ifdef MM_HALF_PAIRS
/**
 * tt-bio mm_rope half pairs (mm_rope.half_pairs, heads narrower than 32): q / k column n is tile A (n even) or B of
 * head pair n / 2, and its four bf16 faces go to two [B, H, L, 32] head tiles: CB face (r, c) -> head (n & ~1) + c,
 * face (r, n & 1). v column n is head n, written whole. The chunks are d1 tiles wide but the outputs hold MM_HEADS_H
 * heads: tiles past it are mm_rope.half_pairs' zero pad heads (H is even, so a pair is all pad or none) and are dropped.
 */
template <typename Tuple, size_t... Is>
FORCE_INLINE void write_half_pair_tile(
    const Tuple& accessors, uint32_t chunk_idx, uint32_t m, uint32_t n, uint32_t d1, uint32_t read_ptr,
    std::index_sequence<Is...> seq) {
    constexpr uint32_t st = MM_HEADS_ST, face = 512, heads = MM_HEADS_H;
    if (n >= heads) {
        return;
    }
    const uint32_t row = m / st * heads, l = m % st;
    if (chunk_idx == 2) {
        write_tile_to_chunk(accessors, chunk_idx, (row + n) * st + l, read_ptr, seq);
        return;
    }
    for (uint32_t f = 0; f < 4; f++) {
        const uint32_t tile = (row + (n & ~1u) + (f & 1)) * st + l, dst = (f & 2) | (n & 1);
        ((chunk_idx == Is ? noc_async_write(read_ptr + f * face, std::get<Is>(accessors).get_noc_addr(tile, dst * face), face)
                          : void()),
         ...);
    }
}
#endif

/**
 * Write a block of output to a potentially padded tensor.
 * Skip writing when M >= logical_M or N >= logical_N
 *
 * Note: Unlike write_block_sync, this function takes a tuple of accessors, rather than a single accessor.
 */
template <
    uint32_t M_block_tiles,
    uint32_t N_block_tiles,
    uint32_t N_chunks,
    uint32_t N_tiles_per_chunk,
    typename... Accessors>
void write_block_sync_split(
    const std::tuple<Accessors...>& accessors,
    const TensorShape2D& chunk_shape,
    uint32_t read_ptr,
    uint32_t tile_size_bytes,
    uint32_t d0_start,
    uint32_t d0_end,
    uint32_t d1_start,
    uint32_t d1_end) {
    ASSERT(d0_end > d0_start);
    ASSERT(d1_end > d1_start);

    const uint32_t chunk_idx_start = d1_start / N_tiles_per_chunk;
    const uint32_t tile_idx_in_chunk_start = d1_start % N_tiles_per_chunk;

    for (uint32_t i = d0_start; i < d0_end; i++) {
        // Assumes that all chunks have same number of tiles on the M-axis
        if (i >= chunk_shape.logical_d0) {
            break;
        }

        uint32_t chunk_idx = chunk_idx_start;
        uint32_t tile_idx_in_chunk = tile_idx_in_chunk_start;

        for (uint32_t j = d1_start; j < d1_end; j++, tile_idx_in_chunk++) {
            // If we've reached the end of the current chunk, move to the next one
            if (tile_idx_in_chunk >= chunk_shape.logical_d1) {
                tile_idx_in_chunk = 0;
                chunk_idx++;  // Move to next chunk; if chunk is past last one then next branch will skip padding
            }

#ifdef MM_ROPE_T
            chunk_idx = rope_col(j) / N_tiles_per_chunk;
            tile_idx_in_chunk = rope_col(j) % N_tiles_per_chunk;
#endif
            // Skip padding
            if (chunk_idx >= N_chunks) {
                read_ptr += tile_size_bytes;
                continue;
            }

#ifdef MM_HALF_PAIRS
            write_half_pair_tile(accessors, chunk_idx, i, tile_idx_in_chunk, chunk_shape.logical_d1, read_ptr,
                                 std::index_sequence_for<Accessors...>{});
#else
            uint32_t tile_id_in_chunk = chunk_tile_id(i, tile_idx_in_chunk, chunk_shape.logical_d1);

            // Compile-time dispatch preserving concrete types
            write_tile_to_chunk(
                accessors, chunk_idx, tile_id_in_chunk, read_ptr, std::index_sequence_for<Accessors...>{});
#endif
            read_ptr += tile_size_bytes;
        }
        // finish up incrementing read_ptr if (d1_end - d1_start) < N_block_tiles
        read_ptr += (N_block_tiles - (d1_end - d1_start)) * tile_size_bytes;
    }
    noc_async_writes_flushed();
}

/**
 * Variadic write method for split operation with N output tensors.
 * Takes the tuple directly, preserving concrete TensorAccessor<DSpec> types for noc_async_write_tile.
 */
template <
    uint32_t M_block_tiles,
    uint32_t N_block_tiles,
    uint32_t N_chunks,
    uint32_t N_tiles_per_chunk,
    typename... Accessors>
void write_block_sync_granular_split(
    const std::tuple<Accessors...>& accessors,
    const TensorShape2D& chunk_shape,
    uint32_t cb_id_out,
    uint32_t tile_size_bytes,
    uint32_t d0_start,
    uint32_t d0_end,
    uint32_t d1_start,
    uint32_t d1_end) {
    const uint32_t chunk_idx_start = d1_start / N_tiles_per_chunk;
    const uint32_t tile_idx_in_chunk_start = d1_start % N_tiles_per_chunk;

    for (uint32_t m_id = 0; m_id < M_block_tiles; m_id++) {
        cb_wait_front(cb_id_out, N_block_tiles);
        uint32_t m_tile = d0_start + m_id;
        if (m_tile < d0_end && m_tile < chunk_shape.logical_d0) {
            uint32_t out_read_ptr = get_read_ptr(cb_id_out);

            uint32_t chunk_idx = chunk_idx_start;
            uint32_t tile_idx_in_chunk = tile_idx_in_chunk_start;

            for (uint32_t n_tile_id = d1_start; n_tile_id < d1_end; n_tile_id++, tile_idx_in_chunk++) {
                // If we've reached the end of the current chunk, move to the next one
                if (tile_idx_in_chunk >= chunk_shape.logical_d1) {
                    tile_idx_in_chunk = 0;
                    chunk_idx++;  // Move to next chunk; if chunk is past last one then next branch will skip padding
                }

#ifdef MM_ROPE_T
                chunk_idx = rope_col(n_tile_id) / N_tiles_per_chunk;
                tile_idx_in_chunk = rope_col(n_tile_id) % N_tiles_per_chunk;
#endif
                if (chunk_idx >= N_chunks) {
                    break;
                }

#ifdef MM_HALF_PAIRS
                write_half_pair_tile(accessors, chunk_idx, m_tile, tile_idx_in_chunk, chunk_shape.logical_d1,
                                     out_read_ptr, std::index_sequence_for<Accessors...>{});
#else
                uint32_t tile_id = chunk_tile_id(m_tile, tile_idx_in_chunk, chunk_shape.logical_d1);
                // Compile-time dispatch preserving concrete types
                write_tile_to_chunk(
                    accessors, chunk_idx, tile_id, out_read_ptr, std::index_sequence_for<Accessors...>{});
#endif

                out_read_ptr += tile_size_bytes;
            }
        }
        cb_pop_front(cb_id_out, N_block_tiles);
    }
    noc_async_writes_flushed();
}
