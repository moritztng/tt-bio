// SPDX-FileCopyrightText: © 2026 Tenstorrent USA, Inc.
//
// SPDX-License-Identifier: Apache-2.0

// reblock_permute GATED compute: per tile pair, out = transpose_wh(p * sigmoid(g)).
//
// The three phases mirror the two ops this kernel replaces, in the same order and with the same
// rounding points. That is what makes the result bit-exact rather than merely close, and two of the
// choices below are load-bearing for it. Both were measured, not read (perf/trimul_f2/e6_diag.py,
// qb2 card 0, N=320 C=32, forensics over 3.28 M elements):
//
//   * THE DESCRIPTOR MUST RUN 16-BIT DST (`fp32_dest_acc_en=False`). `calculate_sigmoid` branches
//     on that flag: under it, `_sfpu_exp_21f_bf16_` + one reciprocal iteration + an explicit
//     `float_to_fp16b`; over it, `_sfpu_exp_accurate_` + two iterations. ttnn takes the cheap
//     branch, so its sigmoid is a full bf16 ulp off the correctly rounded one on 10.4 % of
//     elements. A kernel compiled with fp32 DST computes the ACCURATE sigmoid and therefore misses.
//   * THE MULTIPLY MUST BE THE SFPU ONE. The FPU's `mul_tiles` truncates the product into a 16-bit
//     DST: 25.7 % of elements land one ulp low, on top of the ties. `mul_binary_tile` rounds, and
//     matches ttnn on every element.
//
// The two knobs interact, which is why the config could not be found by sweeping either alone.
// Packing the product from an fp32 DST instead is the third combination and it is also wrong, in a
// way worth naming because it looks harmless: the packer breaks ties AWAY FROM ZERO where ttnn
// breaks them to even, so exactly half the ties come out one ulp off and nothing else does. That
// is 0.91 % of elements at a 1.85 % tie rate, small enough to read as noise and it is not noise.
#include <cstdint>

#include "api/compute/common.h"
#include "api/compute/compute_kernel_api.h"
#include "api/compute/eltwise_binary.h"
#include "api/compute/eltwise_binary_sfpu.h"
#include "api/compute/tile_move_copy.h"
#include "api/compute/transpose_wh.h"
#include "api/compute/reconfig_data_format.h"

void kernel_main() {
    constexpr uint32_t p_cb = get_compile_time_arg_val(0);    // c_0,  value slice
    constexpr uint32_t g_cb = get_compile_time_arg_val(1);    // c_1,  gate slice
    constexpr uint32_t sig_cb = get_compile_time_arg_val(2);  // c_2,  sigmoid(g)
    constexpr uint32_t mul_cb = get_compile_time_arg_val(3);  // c_3,  p * sigmoid(g)
    constexpr uint32_t out_cb = get_compile_time_arg_val(4);  // c_16, post-WH, the writer's input
    // Diagnostic: drop the activation so the multiply can be compared on its own against
    // ttnn.multiply(p, g) with two generic bf16 operands. Never set in production.
    constexpr uint32_t skip_sigmoid = get_compile_time_arg_val(5);

    const uint32_t num_tiles = get_arg_val<uint32_t>(0);

    // Tiles per DST acquire. 1 is the incumbent, verbatim -- three acquire/pack/release cycles per
    // tile, one tile in flight. Above 1 the SAME three stages run over a group of tiles, in the
    // same order, through the same two bf16 circular buffers, so every rounding point named in the
    // header above is untouched and the result stays bit-exact; only the barriers move.
    //
    // Why this kernel: it is the densest instance in the tree of the defect measured in
    // `b2z-custom-sdpa` -- a per-tile `acquire_dst()` around an eltwise op. The SDPA's mask add
    // paid ONE barrier a tile; this pays THREE, because each stage round-trips through a CB to
    // hold its rounding. At 512 aa it is 3.149 ms of the 16.961 ms TriangleMultiplication chain
    // (18.6 %), and it is structurally unrelated to attention -- which is the point of testing it.
    //
    // Capped by DST, not by taste: stage 2 holds the value AND the gate for each tile, 2 slots a
    // tile, against 8 slots of a 16-bit DST. So 4 is the ceiling and the host will not pass more.
    constexpr uint32_t GRAN = get_compile_time_arg_val(6);
    // 1 when p_cb/g_cb carry a format other than the bf16 working CBs (a bfp8 in-projection, spd-trimul
    // INPROJ_B8). Every unpack then names its source format first: the unpacker keeps whatever format
    // it was last configured for, and a bfp8 tile read as bf16 (or the reverse) is garbage, not a
    // rounding. 0 compiles exactly the uniform-bf16 kernel above.
    constexpr uint32_t mixed_fmt = get_compile_time_arg_val(7);
    // 1 = the lean form (TT_BIO_GATED_LEAN, spd-trimul): NOT bit-exact. g is unpacked transposed,
    // its sigmoid taken in DST and packed (sig^T); then p is unpacked transposed and multiplied by sig^T
    // on the FPU straight out of DST (`binary_dest_reuse_tiles` ELWMUL). Two pack round trips a tile
    // instead of three, no SFPU multiply. Transposing before the elementwise ops is exact (both are
    // elementwise); what changes is the FPU multiply into the 16-bit DST, which truncates (the header's
    // second bullet): at most one bf16 ULP low, never a different value class.
    // 2 = the same two stages with the SFPU multiply of the incumbent: p^T and sig^T sit in two DST
    // slots and `mul_binary_tile` rounds as before. Every value the incumbent computes is computed
    // here on the transposed tile, so it is bit-exact, and it still drops the mul_cb round trip.
    constexpr uint32_t lean = get_compile_time_arg_val(8);

    binary_op_init_common(p_cb, sig_cb, mul_cb);

    if constexpr (lean) {
        for (uint32_t i = 0; i < num_tiles; i += GRAN) {
            const uint32_t n = (num_tiles - i < GRAN) ? (num_tiles - i) : GRAN;

            cb_wait_front(g_cb, n);
            cb_reserve_back(sig_cb, n);
            tile_regs_acquire();
            transpose_wh_init_short(g_cb);
            reconfig_data_format_srca(g_cb);
            for (uint32_t j = 0; j < n; ++j) {
                transpose_wh_tile(g_cb, j, j);
            }
            if constexpr (!skip_sigmoid) {
                sigmoid_tile_init();
                for (uint32_t j = 0; j < n; ++j) {
                    sigmoid_tile(j);
                }
            }
            tile_regs_commit();
            tile_regs_wait();
            for (uint32_t j = 0; j < n; ++j) {
                pack_tile(j, sig_cb);
            }
            tile_regs_release();
            cb_pop_front(g_cb, n);
            cb_push_back(sig_cb, n);

            cb_wait_front(p_cb, n);
            cb_wait_front(sig_cb, n);
            cb_reserve_back(out_cb, n);
            if constexpr (lean == 2) {
                tile_regs_acquire();
                for (uint32_t j = 0; j < n; ++j) {
                    transpose_wh_init_short(p_cb);
                    reconfig_data_format_srca(p_cb);
                    transpose_wh_tile(p_cb, j, 2 * j);
                    copy_tile_to_dst_init_short(sig_cb);
                    reconfig_data_format_srca(sig_cb);
                    copy_tile(sig_cb, j, 2 * j + 1);
                    mul_binary_tile_init();
                    mul_binary_tile(2 * j, 2 * j + 1, 2 * j);
                }
                tile_regs_commit();
                tile_regs_wait();
                for (uint32_t j = 0; j < n; ++j) {
                    pack_tile(2 * j, out_cb);
                }
                tile_regs_release();
                cb_pop_front(p_cb, n);
                cb_pop_front(sig_cb, n);
                cb_push_back(out_cb, n);
                continue;
            }
            tile_regs_acquire();
            transpose_wh_init_short(p_cb);
            reconfig_data_format_srca(p_cb);
            for (uint32_t j = 0; j < n; ++j) {
                transpose_wh_tile(p_cb, j, j);
            }
            binary_dest_reuse_tiles_init<EltwiseBinaryType::ELWMUL, EltwiseBinaryReuseDestType::DEST_TO_SRCA>(
                sig_cb);
            reconfig_data_format_srcb(sig_cb);
            for (uint32_t j = 0; j < n; ++j) {
                binary_dest_reuse_tiles<EltwiseBinaryType::ELWMUL, EltwiseBinaryReuseDestType::DEST_TO_SRCA>(
                    sig_cb, j, j);
            }
            tile_regs_commit();
            tile_regs_wait();
            for (uint32_t j = 0; j < n; ++j) {
                pack_tile(j, out_cb);
            }
            tile_regs_release();
            cb_pop_front(p_cb, n);
            cb_pop_front(sig_cb, n);
            cb_push_back(out_cb, n);
        }
        return;
    }

    for (uint32_t i = 0; i < num_tiles; i += GRAN) {
        const uint32_t n = (num_tiles - i < GRAN) ? (num_tiles - i) : GRAN;

        // sigmoid(g) -> its own CB. binary_ng applies an input activation in PREPROCESS
        // (eltwise_utils.hpp), which copies the operand to DST, runs the SFPU op and packs the
        // result before the binary op unpacks it again, so the activation is rounded to bf16
        // BEFORE the multiply. Keeping it in DST would multiply against more mantissa than ttnn.
        cb_wait_front(g_cb, n);
        cb_reserve_back(sig_cb, n);
        tile_regs_acquire();
        copy_tile_to_dst_init_short(g_cb);
        if constexpr (mixed_fmt) {
            reconfig_data_format_srca(g_cb);
        }
        for (uint32_t j = 0; j < n; ++j) {
            copy_tile(g_cb, j, j);
        }
        if constexpr (!skip_sigmoid) {
            sigmoid_tile_init();
            for (uint32_t j = 0; j < n; ++j) {
                sigmoid_tile(j);
            }
        }
        tile_regs_commit();
        tile_regs_wait();
        for (uint32_t j = 0; j < n; ++j) {
            pack_tile(j, sig_cb);
        }
        tile_regs_release();
        cb_pop_front(g_cb, n);
        cb_push_back(sig_cb, n);

        cb_wait_front(p_cb, n);
        cb_wait_front(sig_cb, n);
        cb_reserve_back(mul_cb, n);
        tile_regs_acquire();
        for (uint32_t j = 0; j < n; ++j) {
            // Two DST slots a tile, so the multiply reads the same two operands it always did.
            copy_tile_to_dst_init_short(p_cb);
            if constexpr (mixed_fmt) {
                reconfig_data_format_srca(p_cb);
            }
            copy_tile(p_cb, j, 2 * j);
            copy_tile_to_dst_init_short(sig_cb);
            if constexpr (mixed_fmt) {
                reconfig_data_format_srca(sig_cb);
            }
            copy_tile(sig_cb, j, 2 * j + 1);
            mul_binary_tile_init();
            mul_binary_tile(2 * j, 2 * j + 1, 2 * j);
        }
        tile_regs_commit();
        tile_regs_wait();
        for (uint32_t j = 0; j < n; ++j) {
            pack_tile(2 * j, mul_cb);
        }
        tile_regs_release();
        cb_pop_front(p_cb, n);
        cb_pop_front(sig_cb, n);
        cb_push_back(mul_cb, n);

        // The within-tile WH transpose, unchanged from compute_reblock_permute.cpp. It runs last,
        // as it does in production where `_transform_chunk` moves the already-gated chunk.
        cb_wait_front(mul_cb, n);
        cb_reserve_back(out_cb, n);
        transpose_wh_init(mul_cb, out_cb);
        if constexpr (mixed_fmt) {
            reconfig_data_format_srca(mul_cb);
        }
        tile_regs_acquire();
        for (uint32_t j = 0; j < n; ++j) {
            transpose_wh_tile(mul_cb, j, j);
        }
        tile_regs_commit();
        tile_regs_wait();
        for (uint32_t j = 0; j < n; ++j) {
            pack_tile(j, out_cb);
        }
        tile_regs_release();
        cb_pop_front(mul_cb, n);
        cb_push_back(out_cb, n);
    }
}
