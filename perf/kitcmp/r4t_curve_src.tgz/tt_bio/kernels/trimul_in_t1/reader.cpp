// SPDX-FileCopyrightText: (c) 2026 Tenstorrent USA, Inc.
//
// SPDX-License-Identifier: Apache-2.0

// trimul input side T1 reader. Once: [Wp^T | Wg^T] into c_0 (as gin_moved), Wg_out [K, N] into c_18,
// gamma / beta (Kt tiles each, row 0 carries the [K] vector) into c_8 / c_9, the 1/K reduce scaler
// into c_10 and a full fp32 eps tile into c_11 (as T2). Then per unit (b, xt, yt) the 32 raw z row
// tiles R_il = (b, x = xt*32 + il, yt), il = 0..31, in il order, Kt tiles each, RB rows per barrier,
// into c_7: compute normalises them row by row. With MASK the unit's 32 row-broadcast mask tiles
// follow in c_6, cut exactly as gin_moved's reader cuts them.
// A launch covers one channel group: [a | b] channel tiles Q0 .. Q0 + QN of CT2 and g_out tiles N0 .. N0 + NG
// of NTGT, so c_z 256 / 384 fit L1 as two / three launches that each read z once. IL = 16 or 8 cuts the
// unit to the rows h * IL .. h * IL + IL - 1 of its x tile (units (b, xt, h, yt)); the writer then fills
// those rows of each output tile.
// ABL (bench-only define, trimul_tail.T1_ABL; 0 in every model path): bits that skip one stage's
// work while keeping its circular-buffer traffic, to time each stage by difference (perf/spd_trimul/in_t1.py --abl).
//   1 layer_norm, 2 g_out matmul, 4 [a | b] matmuls, 8 gate multiply, 16 z reads, 32 writer gather, 64 writer writes.
#ifndef ABL
#define ABL 0
#endif
// T1PRE (trimul_tail.T1_LN1): x is the first launch's xn, already normalised, in z's layout; its row tiles go
// straight into compute's xn_cb at slot dt * IL + il, so this launch runs no layer_norm.
#ifndef T1PRE
#define T1PRE 0
#endif
// T1SPLIT (trimul_tail.T1_SPLIT): this reader also gathers and writes the launch's even [a | b] channel tiles, which
// compute sends to c_21 (gather.hpp, as writer.cpp does the odd ones). The first two z barriers of the next unit are
// read before this unit's gathers, so compute's next layer_norm does not wait on them; a T1PRE launch reads no z and
// gathers right after its unit's xn.
#ifndef T1SPLIT
#define T1SPLIT 0
#endif
// T1ZPRE (bench knob trimul_tail.T1_ZPRE): barriers of the next unit read ahead of the gathers, x_cb sized to hold them.
// T1ZIL (trimul_tail.T1_ZIL): the rest of the next unit is read between gather tiles, whenever x_cb has room.
// Neither changes which bytes land where: bit-identical.
#ifndef T1ZPRE
#define T1ZPRE 2
#endif
#ifndef T1ZIL
#define T1ZIL 0
#endif
#ifndef T1B8
#define T1B8 0
#endif
// T1MCAST (trimul_tail.T1_MCAST): every core needs every resident weight tile, so one core (per-core arg 2 set) reads
// [Wp^T | Wg^T], gamma, beta and Wg_out from DRAM and multicasts the four CB regions to the grid rectangle instead
// of each core pulling the same 575 KB (RFD4's key), common/weight_mcast.hpp. The same bytes land in the same CBs:
// bit-identical.
// T1STATS (trimul_tail.fused_in_ln `stats`): the row statistics come from the kernel that wrote z, as a ROW_MAJOR fp32
// tensor with one 256-byte page per z row tile (32 means, then 32 rstd). Each barrier's pages land in a scratch CB (c_22)
// and are spread into column 0 of one fp32 tile for cb_mean and one for cb_rstd per row tile, which compute's
// layer_norm reads in place of computing them (ln_prologue.hpp LN_STATS). T1STATS_RND rounds each rstd to bf16 on the way
// (1 to nearest even, 2 upward; 0 keeps fp32): an fp32 rstd under HiFi2's MUL_COL lost accuracy against fp64 that a
// bf16 one does not (in_t1.py --stats-diag, g_out rel_rms 0.0160 fp32 vs 0.0144 bf16, 0.0134 computed in place).
#ifndef T1STATS
#define T1STATS 0
#endif
#ifndef T1STATS_RND
#define T1STATS_RND 0
#endif
#ifndef T1MCAST
#define T1MCAST 0
#endif
#include "api/dataflow/dataflow_api.h"
#include "unit.hpp"
#if T1MCAST
#include "../common/weight_mcast.hpp"
#endif
#if T1SPLIT
#include "gather.hpp"
#endif
#include "ttnn/kernel/dataflow/generate_reduce_scaler.hpp"

void kernel_main() {
    constexpr uint32_t Kt = get_compile_time_arg_val(0);
    constexpr uint32_t QN = get_compile_time_arg_val(1);       // [a | b] channel tiles of this launch
    constexpr uint32_t St = get_compile_time_arg_val(2);
    constexpr uint32_t MASK = get_compile_time_arg_val(3);
    constexpr uint32_t NG = get_compile_time_arg_val(4);       // g_out channel tiles of this launch, 0: none
    constexpr uint32_t RB = get_compile_time_arg_val(5);       // row tiles per read barrier
    constexpr uint32_t SCALER = get_compile_time_arg_val(6);   // packed bf16 pair, 1/K
    constexpr uint32_t EPS = get_compile_time_arg_val(7);      // fp32 bits
    constexpr uint32_t Q0 = get_compile_time_arg_val(8);
    constexpr uint32_t N0 = get_compile_time_arg_val(9);
    constexpr uint32_t NTGT = get_compile_time_arg_val(10);    // g_out channel tiles in all
    constexpr uint32_t IL = get_compile_time_arg_val(11);      // row tiles per unit, 32, 16, 8 or 4
    constexpr uint32_t H = 32 / IL;
    constexpr auto x_args = TensorAccessorArgs<12>();
    constexpr auto wp_args = TensorAccessorArgs<x_args.next_compile_time_args_offset()>();
    constexpr auto wg_args = TensorAccessorArgs<wp_args.next_compile_time_args_offset()>();
    constexpr auto wo_args = TensorAccessorArgs<wg_args.next_compile_time_args_offset()>();
    constexpr auto gm_args = TensorAccessorArgs<wo_args.next_compile_time_args_offset()>();
    constexpr auto bt_args = TensorAccessorArgs<gm_args.next_compile_time_args_offset()>();
    constexpr auto m_args = TensorAccessorArgs<bt_args.next_compile_time_args_offset()>();
    static_assert(IL % RB == 0 && (IL == 32 || IL == 16 || IL == 8 || IL == 4), "RB must divide the IL row tiles of a unit");

    const auto x = TensorAccessor(x_args, get_common_arg_val<uint32_t>(0));
    const auto wp = TensorAccessor(wp_args, get_common_arg_val<uint32_t>(1));
    const auto wg = TensorAccessor(wg_args, get_common_arg_val<uint32_t>(2));
    const auto wo = TensorAccessor(wo_args, get_common_arg_val<uint32_t>(3));
    const auto gm = TensorAccessor(gm_args, get_common_arg_val<uint32_t>(4));
    const auto bt = TensorAccessor(bt_args, get_common_arg_val<uint32_t>(5));
    const auto mk = TensorAccessor(m_args, get_common_arg_val<uint32_t>(6));
    const uint32_t u0 = get_arg_val<uint32_t>(0);
    const uint32_t nunits = get_arg_val<uint32_t>(1);
#if T1SPLIT
    constexpr uint32_t CT = get_compile_time_arg_val(m_args.next_compile_time_args_offset()) / 2;
    constexpr uint32_t NB = get_compile_time_arg_val(m_args.next_compile_time_args_offset() + 1);
    constexpr auto a_args = TensorAccessorArgs<m_args.next_compile_time_args_offset() + 2>();
    constexpr auto b_args = TensorAccessorArgs<a_args.next_compile_time_args_offset()>();
    const auto oa = TensorAccessor(a_args, get_common_arg_val<uint32_t>(7));
    const auto ob = TensorAccessor(b_args, get_common_arg_val<uint32_t>(8));
    t1_gather::Gather<NB, IL, ABL, T1B8> gather;
    gather.init(tt::CBIndex::c_25, tt::CBIndex::c_27);
#endif
#if T1STATS
#if T1SPLIT
    constexpr auto st_args = TensorAccessorArgs<b_args.next_compile_time_args_offset()>();
#else
    constexpr auto st_args = TensorAccessorArgs<m_args.next_compile_time_args_offset()>();
#endif
    const auto sts = TensorAccessor(st_args, get_common_arg_val<uint32_t>(T1SPLIT ? 9 : 7));
    constexpr uint32_t st_cb = tt::CBIndex::c_22, mean_cb = tt::CBIndex::c_12, rstd_cb = tt::CBIndex::c_14;
#endif

    constexpr uint32_t w_cb = tt::CBIndex::c_0;
    constexpr uint32_t mscratch_cb = tt::CBIndex::c_3;
    constexpr uint32_t m_cb = tt::CBIndex::c_6;
    constexpr uint32_t x_cb = tt::CBIndex::c_7;
    constexpr uint32_t gamma_cb = tt::CBIndex::c_8;
    constexpr uint32_t beta_cb = tt::CBIndex::c_9;
    constexpr uint32_t scaler_cb = tt::CBIndex::c_10;
    constexpr uint32_t eps_cb = tt::CBIndex::c_11;
    constexpr uint32_t wo_cb = tt::CBIndex::c_18;
    constexpr uint32_t S = St * 32;
    const uint32_t tb = get_tile_size(x_cb);       // z's tile: bf16, or bfp8 under pair_bfp8z
    const uint32_t gtb = get_tile_size(gamma_cb);  // bf16
    const uint32_t wtb = get_tile_size(w_cb);    // bfp8 under trimul_t1w8, else tb
    const uint32_t otb = get_tile_size(wo_cb);

    generate_reduce_scaler(scaler_cb, SCALER);
    {
        cb_reserve_back(eps_cb, 1);
        volatile tt_l1_ptr uint32_t* p = reinterpret_cast<volatile tt_l1_ptr uint32_t*>(get_write_ptr(eps_cb));
        for (uint32_t i = 0; i < 1024; ++i) p[i] = EPS;
        cb_push_back(eps_cb, 1);
    }
    cb_reserve_back(w_cb, 2 * QN * Kt);
    cb_reserve_back(gamma_cb, Kt);
    cb_reserve_back(beta_cb, Kt);
    if constexpr (NG) cb_reserve_back(wo_cb, Kt * NG);
#if T1MCAST
    constexpr uint32_t MC = (T1SPLIT ? 9 : 7) + T1STATS;   // weight_mcast.hpp's common args
    const bool sender = get_arg_val<uint32_t>(2);
    if (sender) {
#endif
    uint32_t w = get_write_ptr(w_cb);
    for (uint32_t t = Q0 * Kt; t < (Q0 + QN) * Kt; ++t, w += wtb) noc_async_read_page(t, wp, w);
    for (uint32_t t = Q0 * Kt; t < (Q0 + QN) * Kt; ++t, w += wtb) noc_async_read_page(t, wg, w);
    w = get_write_ptr(gamma_cb);
    for (uint32_t t = 0; t < Kt; ++t, w += gtb) noc_async_read_page(t, gm, w);
    w = get_write_ptr(beta_cb);
    for (uint32_t t = 0; t < Kt; ++t, w += gtb) noc_async_read_page(t, bt, w);
    if constexpr (NG) {
        w = get_write_ptr(wo_cb);
        for (uint32_t k = 0; k < Kt; ++k)
            for (uint32_t n = N0; n < N0 + NG; ++n, w += otb) noc_async_read_page(k * NTGT + n, wo, w);
    }
    noc_async_read_barrier();
#if T1MCAST
    }
    if (sender) {
        const uint32_t addr[] = {get_write_ptr(w_cb), get_write_ptr(gamma_cb), get_write_ptr(beta_cb),
                                 NG ? get_write_ptr(wo_cb) : 0};
        const uint32_t bytes[] = {2 * QN * Kt * wtb, Kt * gtb, Kt * gtb, Kt * NG * otb};
        weight_mcast::send<MC>(addr, bytes, NG ? 4 : 3);
    } else {
        weight_mcast::receive<MC>();
    }
#endif
    cb_push_back(w_cb, 2 * QN * Kt);
    cb_push_back(gamma_cb, Kt);
    cb_push_back(beta_cb, Kt);
    if constexpr (NG) cb_push_back(wo_cb, Kt * NG);

    // Row tile (b, x, yt) of z is page ((b * S + x) * St + yt) * Kt + dt (trimul_tail.t1_x_page); z_page is unit u's
    // first row tile.
    constexpr bool PAIR = T1B8 && IL == 8;
    auto z_page = [](uint32_t u) -> uint32_t {
        const auto [b, xt, h, yt] = t1_unit::decode<St, H, PAIR>(u);
        return ((b * S + xt * 32 + h * IL) * St + yt) * Kt;
    };
    // Rows i0 .. i1 - 1 of the unit at `page`, RB per barrier, into x_cb.
    auto read_rows = [&](uint32_t page, uint32_t i0, uint32_t i1) {
        page += i0 * St * Kt;
        for (uint32_t il0 = i0; il0 < i1; il0 += RB) {
            cb_reserve_back(x_cb, RB * Kt);
            uint32_t dst = get_write_ptr(x_cb);
            for (uint32_t r = 0; r < RB; ++r, page += St * Kt)
                for (uint32_t dt = 0; dt < Kt; ++dt, dst += tb)
                    if constexpr (!(ABL & 16)) noc_async_read_page(page + dt, x, dst);
#if T1STATS
            const uint32_t sc = get_write_ptr(st_cb);
            for (uint32_t r = 0; r < RB; ++r)
                noc_async_read_page((page - (RB - r) * St * Kt) / Kt, sts, sc + r * 256);
#endif
            noc_async_read_barrier();
            cb_push_back(x_cb, RB * Kt);
#if T1STATS
            // column 0 of a 32 x 32 fp32 tile: rows 0-15 at face 0, 16 floats a row, rows 16-31 at face 2 (+512)
            cb_reserve_back(mean_cb, RB);
            cb_reserve_back(rstd_cb, RB);
            volatile tt_l1_ptr uint32_t* src = reinterpret_cast<volatile tt_l1_ptr uint32_t*>(sc);
            volatile tt_l1_ptr uint32_t* mt = reinterpret_cast<volatile tt_l1_ptr uint32_t*>(get_write_ptr(mean_cb));
            volatile tt_l1_ptr uint32_t* rt = reinterpret_cast<volatile tt_l1_ptr uint32_t*>(get_write_ptr(rstd_cb));
            for (uint32_t r = 0; r < RB; ++r, src += 64, mt += 1024, rt += 1024)
                for (uint32_t i = 0; i < 32; ++i) {
                    const uint32_t o = i < 16 ? i * 16 : 512 + (i - 16) * 16;
                    mt[o] = src[i];
                    const uint32_t v = src[32 + i];   // rstd > 0
                    if constexpr (T1STATS_RND == 1) rt[o] = (v + 0x7FFF + ((v >> 16) & 1)) & 0xFFFF0000u;
                    else if constexpr (T1STATS_RND == 2) rt[o] = (v + 0xFFFF) & 0xFFFF0000u;
                    else rt[o] = v;
                }
            cb_push_back(mean_cb, RB);
            cb_push_back(rstd_cb, RB);
#endif
        }
    };
    // Barriers of the next unit read ahead of this unit's gathers: x_cb holds T1ZPRE (T1SPLIT), none otherwise.
    constexpr uint32_t NBAR = IL / RB;
    constexpr uint32_t PRE = T1SPLIT && !T1PRE ? (NBAR < T1ZPRE ? NBAR : T1ZPRE) : 0;
    uint32_t pre = 0;   // barriers of unit u already read

    for (uint32_t u = u0; u < u0 + nunits; ++u) {
        [[maybe_unused]] const auto [b, xt, h, yt] = t1_unit::decode<St, H, PAIR>(u);   // the mask's and the gather's
        uint32_t page = z_page(u);
        if constexpr (T1PRE) {
            constexpr uint32_t xn_cb = tt::CBIndex::c_1;
            cb_reserve_back(xn_cb, IL * Kt);
            const uint32_t base = get_write_ptr(xn_cb), ntb = get_tile_size(xn_cb);   // the bf16 xn, not z
            for (uint32_t il = 0; il < IL; ++il, page += St * Kt)
                for (uint32_t dt = 0; dt < Kt; ++dt) noc_async_read_page(page + dt, x, base + (dt * IL + il) * ntb);
            noc_async_read_barrier();
            cb_push_back(xn_cb, IL * Kt);
        }
        if constexpr (!T1PRE) read_rows(page, pre * RB, IL);
        if constexpr (MASK) {
            const uint32_t scratch = get_write_ptr(mscratch_cb);
            noc_async_read_page((b * St + xt) * St + yt, mk, scratch);
            noc_async_read_barrier();
            cb_reserve_back(m_cb, IL);
            uint32_t d = get_write_ptr(m_cb);
            volatile tt_l1_ptr uint32_t* src = reinterpret_cast<volatile tt_l1_ptr uint32_t*>(scratch);
            // Row il of a bf16 tile: 16 elements in face (il / 16) * 2 and 16 in the face after it,
            // row il % 16 of each; row 0 of the destination is the first row of faces 0 and 1.
            for (uint32_t il = h * IL; il < h * IL + IL; ++il, d += gtb) {   // m_cb is bf16, as gamma
                volatile tt_l1_ptr uint32_t* dst = reinterpret_cast<volatile tt_l1_ptr uint32_t*>(d);
                const uint32_t s0 = (((il >> 4) * 2) * 256 + (il & 15) * 16) / 2;
                for (uint32_t k = 0; k < 8; ++k) {
                    dst[k] = src[s0 + k];
                    dst[128 + k] = src[s0 + 128 + k];
                }
            }
            cb_push_back(m_cb, IL);
        }
#if T1SPLIT
        const bool next = u + 1 < u0 + nunits;
        pre = next ? PRE : 0;
        if (next) read_rows(z_page(u + 1), 0, PRE * RB);
        const uint32_t cube = xt * St + yt;
        for (uint32_t q = Q0; q < Q0 + QN; q += 2) {
            const uint32_t pg = (b * CT + (q < CT ? q : q - CT)) * 32 * St * St + cube;
            if (q < CT) gather.tile(tt::CBIndex::c_21, oa, pg, h * IL, St * St, (q - Q0) / 2);
            else gather.tile(tt::CBIndex::c_21, ob, pg, h * IL, St * St, (q - Q0) / 2);
            if constexpr (T1ZIL && !T1PRE) {
                if (next && pre < NBAR && cb_pages_reservable_at_back(x_cb, RB * Kt)) {
                    read_rows(z_page(u + 1), pre * RB, pre * RB + RB);
                    ++pre;
                }
            }
        }
#endif
    }
#if T1SPLIT
    noc_async_write_barrier();
#endif
}
