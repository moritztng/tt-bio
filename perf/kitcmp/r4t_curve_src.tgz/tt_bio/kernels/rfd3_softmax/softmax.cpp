// SPDX-FileCopyrightText: © 2025 Tenstorrent AI ULC
//
// SPDX-License-Identifier: Apache-2.0

#include <cstdint>

#define REDUCE_OP PoolType::SUM
#define REDUCE_DIM ReduceDim::REDUCE_ROW

#include "api/compute/eltwise_binary.h"
#include "api/compute/tile_move_copy.h"
#include "api/compute/bcast.h"
#include "api/compute/softmax.h"
#include "api/compute/reduce.h"
#include "api/compute/eltwise_unary/typecast.h"
#include "experimental/circular_buffer.h"

// for scale+mask+softmax:
// bcast HW (mul by 1 tile)  example: (  [2,1,1024,64] * [1,1,32,32]  )
// bcast add H               example: ( [2,1,1024,64] + [2,1,32,64] ) (bcast W -> H)
// Note that the attention mask will not fit in L1 for the entire tensor
// The buffer for the att mask is currently sized as (1t,Wt) so we only reuse it for one HtWt-sized batch of x
// then read another Wt tiles of mask for the next batch

void calc_numeric_stable(
    uint32_t Wt, uint32_t ndst, uint32_t cb_in, uint32_t cb_bcast_scaler, uint32_t cb_max, uint32_t cb_out) {
    experimental::CircularBuffer cb_in_obj(cb_in);
    experimental::CircularBuffer cb_bcast_scaler_obj(cb_bcast_scaler);
    experimental::CircularBuffer cb_max_obj(cb_max);
    experimental::CircularBuffer cb_out_obj(cb_out);

    // calculate max val per row
    tile_regs_acquire();
    reconfig_data_format(cb_in, cb_bcast_scaler);
    cb_max_obj.reserve_back(1);
    cb_bcast_scaler_obj.wait_front(1);
    reduce_init<PoolType::MAX, ReduceDim::REDUCE_ROW, ENABLE_FP32_DEST_ACC>(cb_in, cb_bcast_scaler, cb_max);
    for (uint32_t wt = 0; wt < Wt; wt++) {
        cb_in_obj.wait_front(wt + 1);
        constexpr uint32_t bcast_scaler0 = 0;
        reduce_tile<PoolType::MAX, ReduceDim::REDUCE_ROW, ENABLE_FP32_DEST_ACC>(
            cb_in, cb_bcast_scaler, wt, bcast_scaler0, 0);
    }
    reduce_uninit<ENABLE_FP32_DEST_ACC>(cb_in);
    tile_regs_commit();
    tile_regs_wait();
    pack_tile(0, cb_max);
    tile_regs_release();
    cb_max_obj.push_back(1);

    // calculate x-max(x)
    exp_tile_init<EXP_APPROX>();
    reconfig_data_format_srcb(cb_max);
    cb_max_obj.wait_front(1);
    sub_bcast_cols_init_short(cb_in, cb_max);
    for (uint32_t wt = 0; wt < Wt; wt += ndst) {
        tile_regs_acquire();
        for (uint32_t wt8 = 0; wt8 < ndst; wt8++) {
            sub_tiles_bcast_cols(cb_in, cb_max, wt + wt8, 0, wt8);
        }
        cb_out_obj.reserve_back(ndst);
        for (uint32_t wt8 = 0; wt8 < ndst; wt8++) {
            exp_tile<EXP_APPROX>(wt8);  // exp on DST[0]
        }
        tile_regs_commit();
        tile_regs_wait();
        for (uint32_t wt8 = 0; wt8 < ndst; wt8++) {
            pack_tile(wt8, cb_out);     // reuse the exps buffer again, this time in a circular manner
        }
        tile_regs_release();
        cb_out_obj.push_back(ndst);
    }
    cb_in_obj.pop_front(Wt);
    cb_max_obj.pop_front(1);
    cb_out_obj.wait_front(Wt);
}

void kernel_main() {
    const uint32_t NCHt = get_arg_val<uint32_t>(0);
    const uint32_t Ht = get_arg_val<uint32_t>(1);
    const uint32_t Wt = get_arg_val<uint32_t>(2);
    const uint32_t ndst = get_arg_val<uint32_t>(3);
    const uint32_t start_ht = get_arg_val<uint32_t>(4);
    const uint32_t mask_padded_data = get_arg_val<uint32_t>(5);
    binary_op_init_common(tt::CBIndex::c_0, tt::CBIndex::c_2, tt::CBIndex::c_6);

    constexpr uint32_t onetile = 1;
    // reserve one tile for zeros on cb_in2
    // We only do the reserve for the intermediates once and use pack_tile
    // So effectively these are used as pre-allocated arrays
    // Note that the entire W dimension must fit in the intermed0 CB for this kernel to be correct
    constexpr auto cb_bcast_scaler = tt::CBIndex::c_2;
    constexpr auto cb_fused_scale = tt::CBIndex::c_3;
    constexpr auto cb_fused_attn = tt::CBIndex::c_4;
    constexpr auto cb_mask_padded = tt::CBIndex::c_5;
    constexpr auto cb_exps = tt::CBIndex::c_6;
    constexpr auto cb_scale_mask = tt::CBIndex::c_9;
    constexpr auto cb_recipsumexps = tt::CBIndex::c_7;
    constexpr auto cb_in0 = tt::CBIndex::c_0;
    constexpr auto cb_out0 = tt::CBIndex::c_11;
    experimental::CircularBuffer cb_bcast_scaler_obj(cb_bcast_scaler);
    experimental::CircularBuffer cb_fused_scale_obj(cb_fused_scale);
    experimental::CircularBuffer cb_fused_attn_obj(cb_fused_attn);
    experimental::CircularBuffer cb_mask_padded_obj(cb_mask_padded);
    experimental::CircularBuffer cb_exps_obj(cb_exps);
    experimental::CircularBuffer cb_scale_mask_obj(cb_scale_mask);
    experimental::CircularBuffer cb_recipsumexps_obj(cb_recipsumexps);
    experimental::CircularBuffer cb_in0_obj(cb_in0);
    experimental::CircularBuffer cb_out0_obj(cb_out0);
#ifdef NUMERIC_STABLE
    constexpr auto cb_max = tt::CBIndex::c_8;
    constexpr auto cb_x = tt::CBIndex::c_10;
    experimental::CircularBuffer cb_max_obj(cb_max);
#else
    constexpr auto cb_x = cb_exps;
#endif
    experimental::CircularBuffer cb_x_obj(cb_x);

    cb_bcast_scaler_obj.wait_front(1);  // comes from the reader

#if FUSED_SCALE_MASK
    cb_fused_scale_obj.wait_front(1);
#endif

    constexpr int dst0 = 0;
    uint32_t ht = start_ht;
    bool wait_mask = true;
    for (uint32_t ncht = 0; ncht < NCHt; ncht++) {
#if FUSED_SCALE_MASK
        reconfig_data_format(cb_in0, cb_fused_scale);
        pack_reconfig_data_format(cb_scale_mask);
        mul_tiles_bcast_scalar_init_short(cb_in0, cb_fused_scale);
        for (uint32_t wt = 0; wt < Wt; wt += ndst) {
            // apply fused scale [*= 1/sqrt(...)]
            tile_regs_acquire();
            cb_in0_obj.wait_front(ndst);
            cb_scale_mask_obj.reserve_back(ndst);
            for (uint32_t wt8 = 0; wt8 < ndst; wt8++) {
                mul_tiles_bcast_scalar(cb_in0, cb_fused_scale, wt8, 0, wt8);  // mul bcast-HW -> DST[wt8]
            }
            tile_regs_commit();
            tile_regs_wait();
            for (uint32_t wt8 = 0; wt8 < ndst; wt8++) {
                pack_tile(wt8, cb_scale_mask);                                // reuse exps buffer
            }
            tile_regs_release();
            cb_scale_mask_obj.push_back(ndst);
            cb_in0_obj.pop_front(ndst);
        }
        reconfig_data_format(cb_scale_mask, cb_fused_attn);

#ifndef NUMERIC_STABLE
        exp_tile_init<EXP_APPROX>();
#endif

#ifdef CAUSAL_MASK
        add_tiles_init(cb_scale_mask, cb_fused_attn);
#else
        add_bcast_rows_init_short(cb_scale_mask, cb_fused_attn);
#endif
        for (uint32_t wt = 0; wt < Wt; wt += ndst) {
            tile_regs_acquire();
            cb_scale_mask_obj.wait_front(ndst);
#ifdef CAUSAL_MASK
            cb_fused_attn_obj.wait_front(wt + ndst);  // cumulative wait for up to Wt tiles
            for (uint32_t wt8 = 0; wt8 < ndst; wt8++) {
                add_tiles(cb_scale_mask, cb_fused_attn, wt8, wt + wt8, wt8);  // tile *= 1/(sum(exp(x)))
            }
#else
            if (wait_mask) {
                cb_fused_attn_obj.wait_front(wt + ndst);  // cumulative wait for up to Wt tiles, only at first ht
            }

            for (uint32_t wt8 = 0; wt8 < ndst; wt8++) {
                add_tiles_bcast_rows(cb_scale_mask, cb_fused_attn, wt8, wt + wt8, wt8);  // tile *= 1/(sum(exp(x)))
            }
#endif
            cb_scale_mask_obj.pop_front(ndst);
            cb_x_obj.reserve_back(ndst);
#ifndef NUMERIC_STABLE
            for (uint32_t wt8 = 0; wt8 < ndst; wt8++) {
                exp_tile<EXP_APPROX>(wt8);  // exp on DST[0]
            }
#endif
            tile_regs_commit();
            tile_regs_wait();
            for (uint32_t wt8 = 0; wt8 < ndst; wt8++) {
                pack_tile(wt8, cb_x);  // reuse the exps buffer again, this time in a circular manner
            }
            tile_regs_release();
            cb_x_obj.push_back(ndst);
        }

// add numeric_stable
// fuse exp with sub tiles
#ifdef NUMERIC_STABLE
        calc_numeric_stable(Wt, ndst, cb_x, cb_bcast_scaler, cb_max, cb_exps);
#endif

#ifdef CAUSAL_MASK
        cb_fused_attn_obj.pop_front(Wt);
#else
        if (wait_mask) {
            wait_mask = false;
        }
        ht++;
        if (ht == Ht) {
            cb_fused_attn_obj.pop_front(Wt);
            ht = 0;
            wait_mask = true;
        }
#endif  // CAUSAL_MASK

        reconfig_data_format(cb_exps, cb_bcast_scaler);
#else
        reconfig_data_format(cb_in0, cb_in0);
        pack_reconfig_data_format(cb_exps);
        copy_tile_to_dst_init_short(cb_in0);  // need to copy from CB to DST to be able to run sfpu math
#ifndef NUMERIC_STABLE
        exp_tile_init<EXP_APPROX>();
#endif
        if (mask_padded_data) {
            for (uint32_t wt = 0; wt < Wt; wt += ndst) {
                tile_regs_acquire();
                cb_in0_obj.wait_front(ndst);
                for (uint32_t wt8 = 0; wt8 < ndst; ++wt8) {
                    if (wt == (Wt - ndst) && (wt8 == ndst - 1)) {
                        reconfig_data_format(cb_in0, cb_mask_padded);
                        add_bcast_rows_init_short(cb_in0, cb_mask_padded);
                        cb_mask_padded_obj.wait_front(1);
                        add_tiles_bcast_rows(cb_in0, cb_mask_padded, wt8, 0, wt8);
                    } else {
                        copy_tile(cb_in0, wt8, wt8);  // copy from c_in[0] to DST[0]
                    }
                }
                cb_in0_obj.pop_front(ndst);

                cb_x_obj.reserve_back(ndst);
#ifndef NUMERIC_STABLE
                for (uint32_t wt8 = 0; wt8 < ndst; ++wt8) {
                    exp_tile<EXP_APPROX>(wt8);  // exp on DST[0]
                }
#endif
                tile_regs_commit();
                tile_regs_wait();
                for (uint32_t wt8 = 0; wt8 < ndst; ++wt8) {
                    pack_tile(wt8, cb_x);  // DST[0]->cb_id[wt]
                }
                tile_regs_release();
                cb_x_obj.push_back(ndst);
            }

// add numeric_stable
// fuse exp with sub tiles
#ifdef NUMERIC_STABLE
            calc_numeric_stable(Wt, ndst, cb_x, cb_bcast_scaler, cb_max, cb_exps);
#endif

        } else {
// add numeric_stable
// fuse exp with sub tiles
#ifdef NUMERIC_STABLE
            calc_numeric_stable(Wt, ndst, cb_in0, cb_bcast_scaler, cb_max, cb_exps);
#else
            for (uint32_t wt = 0; wt < Wt; wt += ndst) {
                tile_regs_acquire();
                cb_in0_obj.wait_front(ndst);
                for (uint32_t wt8 = 0; wt8 < ndst; ++wt8) {
                    copy_tile(cb_in0, wt8, wt8);  // copy from c_in[0] to DST[0]
                }
                cb_in0_obj.pop_front(ndst);

                cb_exps_obj.reserve_back(ndst);
                for (uint32_t wt8 = 0; wt8 < ndst; ++wt8) {
                    exp_tile<EXP_APPROX>(wt8);  // exp on DST[0]
                }
                tile_regs_commit();
                tile_regs_wait();
                for (uint32_t wt8 = 0; wt8 < ndst; ++wt8) {
                    pack_tile(wt8, cb_exps);    // DST[0]->cb_id[wt]
                }
                tile_regs_release();
                cb_exps_obj.push_back(ndst);
            }
#endif
        }

        reconfig_data_format(cb_exps, cb_bcast_scaler);
#endif

        tile_regs_acquire();
        cb_recipsumexps_obj.reserve_back(onetile);
        reduce_init<REDUCE_OP, REDUCE_DIM, ENABLE_FP32_DEST_ACC>(cb_exps, cb_bcast_scaler, cb_recipsumexps);

        for (uint32_t wt = 0; wt < Wt; wt++) {
            cb_exps_obj.wait_front(wt + 1);        // must be a cumulative wait for correctness
            constexpr uint32_t bcast_scaler0 = 0;  // 0th index from bcast_scaler CB
            reduce_tile<REDUCE_OP, REDUCE_DIM, ENABLE_FP32_DEST_ACC>(
                /*iCB=*/cb_exps,
                /*icb_scaler=*/cb_bcast_scaler,
                /*itile=*/wt,
                /*itile_scaler=*/bcast_scaler0,
                /*idst0=*/dst0);
        }
        reduce_uninit<ENABLE_FP32_DEST_ACC>(cb_exps);
        recip_tile_init();
        recip_tile(dst0);  // DST[0] = 1/sum(exp(x))
        tile_regs_commit();
        tile_regs_wait();
        pack_tile(dst0, cb_recipsumexps);
        tile_regs_release();
        cb_recipsumexps_obj.push_back(1);

        cb_recipsumexps_obj.wait_front(1);  // will reuse Wt times for bcast

        reconfig_data_format(cb_exps, cb_recipsumexps);
        pack_reconfig_data_format(cb_out0);
        // now cb_sumexps has exp tiles, need to multiply by our DST[2]
        // by now we already did a cumulative wait for Wt tiles in cb_exps
#if defined(PACK_BF16_TYPECAST) && defined(TYPECAST_INIT_HOISTED)
        // candidate 3 (p134): the large kernel's `apply_recip` issues `typecast_tile_init` ONCE,
        // here, before the mul init and outside every `tile_regs_acquire()` block -- and it is
        // bit-exact. Both earlier attempts issued it inside the acquire block, where it reprograms
        // the math/SFPU config while `mul_tiles_bcast` results are still in flight in DST.
        typecast_tile_init<(uint32_t)DataFormat::Float32, (uint32_t)DataFormat::Float16_b>();
#endif
        mul_bcast_cols_init_short(cb_exps, cb_recipsumexps);
        for (uint32_t wt = 0; wt < Wt; wt += ndst) {
            tile_regs_acquire();
#ifndef PACK_BF16_TYPECAST
            cb_out0_obj.reserve_back(ndst);
#endif
            for (uint32_t wt8 = 0; wt8 < ndst; wt8++) {
                // wt+wt8 since we pop Wt after the entire loop
                mul_tiles_bcast<BroadcastType::COL>(
                    cb_exps, cb_recipsumexps, wt + wt8, 0, wt8);  // tile *= 1/(sum(exp(x)))
            }
#if defined(PACK_BF16_TYPECAST) && !defined(P134_TYPECAST_SKIP)
            // `P134_TYPECAST_SKIP` is p134b's negative control and is never set on a production
            // path: dropping the SFPU conversion must put the output back on the packer's own
            // rounding, i.e. back on `perf/p74/softmax_generic.json`'s 0.0009765625. A define that
            // does not move the output would mean `extra_defines` never reached the compiler.
            // `ttnn.typecast` is an SFPU op (eltwise_typecast.cpp: copy_tile then TYPECAST_LLK
            // then pack), and its rounding is not the packer s. Doing the same SFPU conversion
            // here and packing an already-bf16-valued DST reproduces it exactly.
            for (uint32_t wt8 = 0; wt8 < ndst; wt8++) {
#ifndef TYPECAST_INIT_HOISTED
                typecast_tile_init<(uint32_t)DataFormat::Float32,
                                   (uint32_t)DataFormat::Float16_b>();
#endif
                typecast_tile<(uint32_t)DataFormat::Float32, (uint32_t)DataFormat::Float16_b>(wt8);
            }
#endif
            tile_regs_commit();
            tile_regs_wait();
#ifdef PACK_BF16_TYPECAST
            // candidate 1: `apply_recip` in the large kernel reserves AFTER the commit and is
            // bit-exact; this loop reserved inside the acquire block and is not.
            cb_out0_obj.reserve_back(ndst);
#endif
            for (uint32_t wt8 = 0; wt8 < ndst; wt8++) {
                pack_tile(wt8, cb_out0);
            }
            tile_regs_release();
            cb_out0_obj.push_back(ndst);
        }
        cb_recipsumexps_obj.pop_front(1);
        cb_exps_obj.pop_front(Wt);
    }  // NCHt loop
    // cb_pop_front(cb_bcast_scaler, 1); // we don't actually have to do this
    // cb_pop_front(cb_fused_scale, 1); // we don't actually have to do this
}
