// SPDX-FileCopyrightText: © 2025 Tenstorrent AI ULC
//
// SPDX-License-Identifier: Apache-2.0
#include <cstdint>

#define REDUCE_OP PoolType::SUM
#define REDUCE_DIM ReduceDim::REDUCE_ROW

#include "api/compute/binary_max_min.h"
#include "api/compute/eltwise_binary.h"
#include "api/compute/tile_move_copy.h"
#include "api/compute/bcast.h"
#include "api/compute/softmax.h"
#include "api/compute/reduce.h"
#include "api/compute/eltwise_unary/typecast.h"
#include "api/compute/eltwise_binary_sfpu.h"
#include "api/compute/eltwise_unary/eltwise_unary.h"
#include "api/compute/eltwise_unary/sfpu_int_sum.h"
#include "api/compute/eltwise_unary/fill.h"
#include "api/compute/compute_kernel_api.h"
#ifdef PV_FUSED
#include "api/compute/matmul.h"
#include "api/compute/pack.h"
#endif

#include "api/debug/assert.h"
#include "experimental/circular_buffer.h"

// clang-format off
// 3 Loops in code
// 1: Optional Max value for numerical stability
//      1: (func: apply_fused_scale_mask) Apply optional fused scale mask followed by (func: apply_fused_attn_mask)
//      apply attention mask
//
//      2: (func: pad_input)Pad tile if step 1 is not done, otherwise -inf padding is done by apply
//      attention mask
// 1: Loop till we have parsed all of WT
// 2: Calculate ∑e^x
//      1: (func: apply_fused_scale_mask) Apply optional fused scale mask followed by (func: apply_fused_attn_mask)
//      apply attention mask
//
//      2: (func: pad_input)Pad tile if step 1 is not done, otherwise -inf padding is done by apply
//      attention mask
//
//      3: (func: exp_cb) calculate cb e^x
//
//      4: (func: reduce_cb) Sums across the width dimension to
//      calculate ∑e^x
// 2: Loop till we have parsed all of WT
// 3: Calculate Final value
//      1: (func: apply_fused_scale_mask) Apply optional fused scale mask followed by apply (func:
//      apply_fused_attn_mask)  attention mask
//
//      2: (func: pad_input) Pad tile if step 1 is not done, otherwise -inf
//      padding is done by apply attention mask
//
//      3: (func: exp_cb) calculate cb e^x
//
//      4: (func: apply_recip) Apply_recip
//      e^x * 1/∑e^x
// 2: Loop till we have parsed all of WT
//clang-format on
void apply_fused_scale_mask(
    uint32_t cb_in, uint32_t cb_fused_scale_mask, uint32_t cb_out, uint32_t cb_length_t, uint32_t blk);
void apply_fused_attn_mask(
    uint32_t cb_in, uint32_t cb_fused_attn_mask, uint32_t cb_out, uint32_t cb_length_t, uint32_t blk, bool do_mask);
void pad_input(uint32_t cb_in, uint32_t cb_out, uint32_t cb_length_t, uint32_t blk);
void exp_cb(uint32_t cb_in, uint32_t cb_out, uint32_t cb_max, uint32_t cb_length_t, uint32_t blk);

template <PoolType reduce_type>
void reduce_cb(
    uint32_t cb_in,
    uint32_t cb_scaler,
    uint32_t cb_prev_out,
    uint32_t cb_out,
    bool use_prev_reduce,
    uint32_t cb_length_t);
void apply_recip(uint32_t cb_in, uint32_t cb_recip, uint32_t cb_out, uint32_t cb_length_t, uint32_t blk);
#ifdef PV_FUSED
void apply_recip_mac(
    uint32_t cb_in,
    uint32_t cb_recip,
    uint32_t cb_norm,
    uint32_t cb_vv,
    uint32_t cb_acc,
    uint32_t cb_out,
    uint32_t cb_length_t,
    uint32_t blk,
    uint32_t k_base,
    uint32_t num_blocks);
#endif

// for scale+mask+softmax:
// bcast HW (mul by 1 tile)  example: (  [2,1,1024,64] * [1,1,32,32]  )
// bcast add H               example: ( [2,1,1024,64] + [2,1,32,64] ) (bcast W -> H)
// Note that the attention mask will not fit in L1 for the entire tensor
// The buffer for the att mask is currently sized as (1t,Wt) so we only reuse it for one HtWt-sized batch of x
// then read another Wt tiles of mask for the next batch
void apply_fused_scale_mask(
    uint32_t cb_in, uint32_t cb_fused_scale_mask, uint32_t cb_out, uint32_t cb_length_t, uint32_t blk) {
    // Requirements:
    //   cb_length_t of cb_in and cb_out are the same.
    //   blk is a divisor of cb_length_t
    experimental::CircularBuffer cb_in_obj(cb_in);
    experimental::CircularBuffer cb_out_obj(cb_out);
    reconfig_data_format(cb_in, cb_fused_scale_mask);
    pack_reconfig_data_format(cb_out);
    mul_tiles_bcast_scalar_init_short(cb_in, cb_fused_scale_mask);
    for (uint32_t cur_blk = 0; cur_blk < cb_length_t; cur_blk += blk) {
        if(cb_length_t -cur_blk < blk){
            blk = cb_length_t- cur_blk;
        }
        tile_regs_acquire();
        cb_in_obj.wait_front(blk);
        cb_out_obj.reserve_back(blk);
        if (cb_length_t - cur_blk < blk) {
            blk = cb_length_t - cur_blk;
        }
        for (uint32_t cur_dst = 0; cur_dst < blk; cur_dst++) {
            mul_tiles_bcast_scalar(cb_in, cb_fused_scale_mask, cur_dst, 0, cur_dst);
        }
        tile_regs_wait();
        tile_regs_commit();
        for (uint32_t cur_dst = 0; cur_dst < blk; cur_dst++) {
            pack_tile(cur_dst, cb_out);
        }
        cb_out_obj.push_back(blk);
        cb_in_obj.pop_front(blk);
        tile_regs_release();
    }
}
void apply_fused_attn_mask(
    uint32_t cb_in, uint32_t cb_fused_attn_mask, uint32_t cb_out, uint32_t cb_length_t, uint32_t blk, bool do_mask) {
    auto cb_mask_padded = tt::CBIndex::c_5;
    experimental::CircularBuffer cb_in_obj(cb_in);
    experimental::CircularBuffer cb_fused_attn_mask_obj(cb_fused_attn_mask);
    experimental::CircularBuffer cb_out_obj(cb_out);
    experimental::CircularBuffer cb_mask_padded_obj(cb_mask_padded);
    reconfig_data_format(cb_in, cb_fused_attn_mask);
    pack_reconfig_data_format(cb_out);
#ifdef CAUSAL_MASK
    add_tiles_init(cb_in, cb_fused_attn_mask);
#else
    add_bcast_rows_init_short(cb_in, cb_fused_attn_mask);
#endif
    for (uint32_t cur_blk = 0; cur_blk < cb_length_t; cur_blk += blk) {
        tile_regs_acquire();
        if(cb_length_t -cur_blk < blk){
            blk = cb_length_t- cur_blk;
        }
        tile_regs_wait();
        cb_in_obj.wait_front(blk);
        cb_fused_attn_mask_obj.wait_front(blk);  // cumulative wait for up to wt tiles
        cb_out_obj.reserve_back(blk);
        if (cb_length_t - cur_blk < blk) {
            blk = cb_length_t - cur_blk;
        }
#ifdef CAUSAL_MASK
        for (uint32_t cur_dst = 0; cur_dst < blk; cur_dst++) {
            add_tiles(cb_in, cb_fused_attn_mask, cur_dst, cur_dst, cur_dst);  // tile *= 1/(sum(exp(x)))
        }
#else
        for (uint32_t cur_dst = 0; cur_dst < blk; cur_dst++) {
            add_tiles_bcast_rows(cb_in, cb_fused_attn_mask, cur_dst, cur_dst, cur_dst);
        }
#endif
        if (do_mask && cur_blk == cb_length_t - blk) {
            // add mask to the last register to pad with -inf
            reconfig_data_format_srca(cb_mask_padded);
            binary_dest_reuse_tiles_init<ELWADD, EltwiseBinaryReuseDestType::DEST_TO_SRCB>(cb_mask_padded);
            cb_mask_padded_obj.wait_front(1);
            binary_dest_reuse_tiles<ELWADD, EltwiseBinaryReuseDestType::DEST_TO_SRCB>(cb_mask_padded, 0, blk - 1);
        }
        tile_regs_commit();
        for (uint32_t cur_dst = 0; cur_dst < blk; cur_dst++) {
            pack_tile(cur_dst, cb_out);
        }
        cb_out_obj.push_back(blk);
        cb_in_obj.pop_front(blk);
        cb_fused_attn_mask_obj.pop_front(blk);
        tile_regs_release();
    }
}

// applies pad to the last pass cb if needed
void pad_input(uint32_t cb_in, uint32_t cb_out, uint32_t cb_length_t, uint32_t blk) {
    auto cb_mask_padded = tt::CBIndex::c_5;
    experimental::CircularBuffer cb_in_obj(cb_in);
    experimental::CircularBuffer cb_out_obj(cb_out);
    experimental::CircularBuffer cb_mask_padded_obj(cb_mask_padded);
    reconfig_data_format(cb_in, cb_mask_padded);
    pack_reconfig_data_format(cb_out);
    copy_tile_init(cb_in);  // need to copy from CB to DST to be able to run sfpu math
    for (uint32_t cur_blk = 0; cur_blk < cb_length_t; cur_blk += blk) {
        tile_regs_acquire();
        cb_in_obj.wait_front(blk);
        cb_out_obj.reserve_back(blk);
        if (cb_length_t - cur_blk < blk) {
            blk = cb_length_t - cur_blk;
        }
        for (uint32_t cur_dst = 0; cur_dst < blk; cur_dst++) {
            if (cur_dst == blk - 1 && cur_blk == cb_length_t - blk) {
                add_tiles_init(cb_in, cb_mask_padded);
                cb_mask_padded_obj.wait_front(1);
                add_tiles(cb_in, cb_mask_padded, cur_dst, 0, cur_dst);
            } else {
                copy_tile(cb_in, cur_dst, cur_dst);
            }
        }
        tile_regs_wait();
        tile_regs_commit();
        for (uint32_t cur_dst = 0; cur_dst < blk; cur_dst++) {
            pack_tile(cur_dst, cb_out);
        }
        cb_out_obj.push_back(blk);
        cb_in_obj.pop_front(blk);
        tile_regs_release();
    }
}

void exp_cb(uint32_t cb_in, uint32_t cb_out, uint32_t cb_max, const uint32_t cb_length_t, uint32_t blk) {
    // requirements:
    //   cb_length_t of cb_in and cb_out are the same.
    //   blk is a divisor of cb_length_t
    //   Calculates e^cb_in for cb_length_t num of tiles
    //      Also if numeric stable calcs e^(cb_in- BCASTCOL(cb_max))
    ASSERT(cb_length_t % blk == 0);

    experimental::CircularBuffer cb_in_obj(cb_in);
    experimental::CircularBuffer cb_out_obj(cb_out);
    reconfig_data_format_srca(cb_in);
    pack_reconfig_data_format(cb_out);
#ifdef NUMERIC_STABLE
    reconfig_data_format_srcb(cb_max);
    init_bcast<EltwiseBinaryType::ELWSUB, BroadcastType::COL>(cb_in, cb_max, cb_out);
#else
    copy_tile_init(cb_in);  // need to copy from CB to DST to be able to run sfpu math
#endif
    exp_tile_init<EXP_APPROX>();
    uint32_t loop = 0;
    for (uint32_t cur_blk = 0; cur_blk < cb_length_t; cur_blk += blk) {
        if (cb_length_t - cur_blk < blk) {
            blk = cb_length_t - cur_blk;
        }
        cb_in_obj.wait_front(blk);
        cb_out_obj.reserve_back(blk);
        tile_regs_acquire();
#ifdef NUMERIC_STABLE
        for (uint32_t cur_dst = 0; cur_dst < blk; cur_dst++) {
            sub_tiles_bcast_cols(cb_in, cb_max, cur_dst, 0, cur_dst);
        }
#else
        for (uint32_t cur_dst = 0; cur_dst < blk; cur_dst++) {
            copy_tile(cb_in, cur_dst, cur_dst);
        }
#endif
        cb_in_obj.pop_front(blk);
        for (uint32_t cur_dst = 0; cur_dst < blk; cur_dst++) {
            exp_tile<EXP_APPROX>(cur_dst);  // exp on DST[0]
        }
        tile_regs_wait();
        tile_regs_commit();
        for (uint32_t cur_dst = 0; cur_dst < blk; cur_dst++) {
            pack_tile(cur_dst, cb_out);
        }
        cb_out_obj.push_back(blk);
        tile_regs_release();
    }
}

template <PoolType reduce_type>
void reduce_cb(
    uint32_t cb_in,
    uint32_t cb_scaler,
    uint32_t cb_prev_out,
    uint32_t cb_out,
    bool use_prev_reduce,
    uint32_t cb_length_t) {
    // Requirements:
    //   blk is a divisor of cb_length_t reconfig_data_format(cb_in, cb_scaler);
    //   len(Data) fed into cb_in, does not need all at once== cb_length_t
    //   len(cb_out) == 1

    experimental::CircularBuffer cb_in_obj(cb_in);
    experimental::CircularBuffer cb_prev_out_obj(cb_prev_out);
    experimental::CircularBuffer cb_out_obj(cb_out);
    reconfig_data_format(cb_in, cb_scaler);
    pack_reconfig_data_format(cb_out);
    reduce_init<reduce_type, REDUCE_DIM, ENABLE_FP32_DEST_ACC>(cb_in, cb_scaler, cb_out);
    tile_regs_acquire();
    cb_out_obj.reserve_back(1);
    for (uint32_t cur_tile = 0; cur_tile < cb_length_t; cur_tile++) {
        cb_in_obj.wait_front(1);
        reduce_tile<reduce_type, REDUCE_DIM, ENABLE_FP32_DEST_ACC>(cb_in, cb_scaler, 0, 0, 0);
        cb_in_obj.pop_front(1);
    }

    if (use_prev_reduce) {
        reconfig_data_format_srca(cb_prev_out);
        cb_prev_out_obj.wait_front(1);
        copy_tile_init(cb_prev_out);
        copy_tile(cb_prev_out, 0, 1);
        if (reduce_type == PoolType::MAX) {
            // path if we are doing a max redudce
            binary_max_tile_init();
            // garbage data will be in data outside the first column, but since we broadcast this column it shouldn't
            // matter
            binary_max_tile(0, 1, 0);
        } else {
            // path if we are doing a sum redudce
            add_binary_tile_init();
            add_binary_tile(0, 1, 0);
        }
        cb_prev_out_obj.pop_front(1);
    }
    tile_regs_wait();
    tile_regs_commit();
    pack_tile(0, cb_out);
    cb_out_obj.push_back(1);
    tile_regs_release();
    reduce_uninit();
}
void apply_recip(uint32_t cb_in, uint32_t cb_recip, uint32_t cb_out, uint32_t cb_length_t, uint32_t blk) {
    experimental::CircularBuffer cb_in_obj(cb_in);
    experimental::CircularBuffer cb_recip_obj(cb_recip);
    experimental::CircularBuffer cb_out_obj(cb_out);
    reconfig_data_format(cb_in, cb_recip);
    pack_reconfig_data_format(cb_out);
    cb_recip_obj.wait_front(1);
#ifdef PACK_BF16_TYPECAST
    typecast_tile_init<(uint32_t)DataFormat::Float32, (uint32_t)DataFormat::Float16_b>();
#endif
    mul_bcast_cols_init_short(cb_in, cb_recip);
    for (uint32_t cur_blk = 0; cur_blk < cb_length_t; cur_blk += blk) {
        cb_in_obj.wait_front(blk);
        tile_regs_acquire();
        tile_regs_wait();
        if (cb_length_t - cur_blk < blk) {
            blk = cb_length_t - cur_blk;
        }
        for (uint32_t cur_dst = 0; cur_dst < blk; cur_dst++) {
            mul_tiles_bcast_cols(cb_in, cb_recip, cur_dst, 0, cur_dst);
        }
#ifdef PACK_BF16_TYPECAST
        // see softmax.cpp: reproduce ttnn.typecast s SFPU rounding, not the packer s.
        for (uint32_t cur_dst = 0; cur_dst < blk; cur_dst++) {
            typecast_tile<(uint32_t)DataFormat::Float32, (uint32_t)DataFormat::Float16_b>(cur_dst);
        }
#endif
        tile_regs_commit();
        cb_out_obj.reserve_back(blk);
        for (uint32_t cur_dst = 0; cur_dst < blk; cur_dst++) {
            pack_tile(cur_dst, cb_out);
        }
        cb_in_obj.pop_front(blk);
        cb_out_obj.push_back(blk);
        tile_regs_release();
    }
}

#ifdef PV_FUSED
// L5b: the normalise pass MACs against the value tiles instead of writing the row out.
//
// The normalise half is `apply_recip` unchanged -- same `mul_tiles_bcast_cols`, same
// `PACK_BF16_TYPECAST`, same `pack_tile` -- only the destination moves, from `cb_out0` (which the
// writer drains to DRAM) to `cb_norm`, a local L1 CB. No matmul entry point takes a DST tile as an
// operand (`api/compute/matmul.h`: every one of them unpacks both operands through
// `llk_unpack_AB_matmul`), so the pack has to happen; what L5b deletes is the DRAM write and the
// PV matmul's DRAM read of it, not the pack.
//
// The MAC half is a transcription of `bmm_large_block_zm_fused_bias_activation.cpp` -- the kernel
// `MatmulMultiCoreReuseProgramConfig` actually runs, through
// `MatmulMultiCoreReuseOptimizedProgramFactory` -- at `out_subblock_h = out_subblock_w = 1`, with
// `PACKER_L1_ACC` and `FP32_DEST_ACC_EN` on, which is what that factory selects for this call
// (`packer_l1_acc && num_blocks > 2`, and `interm0` is Float32 whenever `fp32_dest_acc_en`).
// The partial is therefore NOT rounded between blocks; the packer accumulates it in fp32:
//
//     block 0            DST = sum of in0_block_w products      -> pack, l1_acc off  (overwrite)
//     block 1 .. n-3     DST = sum of in0_block_w products      -> pack, l1_acc on   (add)
//     block n-2          same, and the partial is left in the CB for the reload
//     block n-1          DST = reload(partial) + this block     -> pack to cb_out, l1_acc off
//
// The grouping is `in0_block_w` because the packer's fp32 add happens once per block and fp32
// addition is not associative. That is the whole reason the host asserts `blk == in0_block_w`.
void apply_recip_mac(
    uint32_t cb_in,
    uint32_t cb_recip,
    uint32_t cb_norm,
    uint32_t cb_vv,
    uint32_t cb_acc,
    uint32_t cb_out,
    uint32_t cb_length_t,
    uint32_t blk,
    uint32_t k_base,
    uint32_t num_blocks) {
    experimental::CircularBuffer cb_in_obj(cb_in);
    experimental::CircularBuffer cb_recip_obj(cb_recip);
    experimental::CircularBuffer cb_norm_obj(cb_norm);
    experimental::CircularBuffer cb_acc_obj(cb_acc);
    experimental::CircularBuffer cb_out_obj(cb_out);
    cb_recip_obj.wait_front(1);

    for (uint32_t cur_blk = 0; cur_blk < cb_length_t; cur_blk += blk) {
        const uint32_t k = k_base + cur_blk;
        const uint32_t block = k / blk;
        const bool last = block == num_blocks - 1;

        // --- normalise, byte for byte what apply_recip does, into cb_norm ---
        pack_reconfig_l1_acc(0);
        reconfig_data_format(cb_in, cb_recip);
        pack_reconfig_data_format(cb_norm);
#ifdef PACK_BF16_TYPECAST
        typecast_tile_init<(uint32_t)DataFormat::Float32, (uint32_t)DataFormat::Float16_b>();
#endif
        mul_bcast_cols_init_short(cb_in, cb_recip);
        cb_in_obj.wait_front(blk);
        tile_regs_acquire();
        for (uint32_t cur_dst = 0; cur_dst < blk; cur_dst++) {
            mul_tiles_bcast_cols(cb_in, cb_recip, cur_dst, 0, cur_dst);
        }
#ifdef PACK_BF16_TYPECAST
        for (uint32_t cur_dst = 0; cur_dst < blk; cur_dst++) {
            typecast_tile<(uint32_t)DataFormat::Float32, (uint32_t)DataFormat::Float16_b>(cur_dst);
        }
#endif
        tile_regs_commit();
        tile_regs_wait();
        cb_norm_obj.reserve_back(blk);
        for (uint32_t cur_dst = 0; cur_dst < blk; cur_dst++) {
            pack_tile(cur_dst, cb_norm);
        }
        cb_in_obj.pop_front(blk);
        cb_norm_obj.push_back(blk);
        tile_regs_release();

        // --- MAC one K block into the running fp32 partial ---
        //
        // ONLY the `_short` inits, and this is load-bearing rather than an optimisation. The full
        // `mm_init` runs `llk_math_pack_sync_init`, which resets the MATH<->PACK dest-register
        // semaphore; calling it mid-stream, after `binary_op_init_common` has already established
        // that sync and the normalise half has been using it, hangs the core with unpack at UABD,
        // math at MWDD and the writer parked in `cb_wait_front`. The reference matmul kernel
        // full-inits once before its loop and uses `mm_block_init_short` inside for the same
        // reason. In matmul the operands land the other way round from eltwise -- srcA takes in1
        // and srcB takes in0 (`mm_init`: `llk_unpack_hw_configure(in1, in0)`) -- so the reconfig
        // is (cb_vv, cb_norm), not (cb_norm, cb_vv).
        cb_norm_obj.wait_front(blk);
        reconfig_data_format(cb_vv, cb_norm);
        mm_init_short(cb_norm, cb_vv);
        tile_regs_acquire();
        if (last) {
            copy_tile_to_dst_init_short_with_dt(cb_vv, cb_acc);
            cb_acc_obj.wait_front(1);
            copy_block_matmul_partials(cb_acc, 0, 0, 1);
            cb_acc_obj.pop_front(1);
            mm_init_short_with_dt(cb_norm, cb_vv, cb_acc);
        }
        for (uint32_t i = 0; i < blk; i++) {
            matmul_tiles(cb_norm, cb_vv, i, k + i, 0);
        }
        tile_regs_commit();
        tile_regs_wait();
        if (last) {
            pack_reconfig_data_format(cb_out);
            pack_reconfig_l1_acc(0);
            cb_out_obj.reserve_back(1);
            pack_tile(0, cb_out);
            cb_out_obj.push_back(1);
        } else {
            pack_reconfig_data_format(cb_acc);
            pack_reconfig_l1_acc(block == 0 ? 0 : 1);
            cb_acc_obj.reserve_back(1);
            pack_tile(0, cb_acc);
            cb_acc_obj.push_back(1);
        }
        cb_norm_obj.pop_front(blk);
        tile_regs_release();

        // The partial CB is one tile deep, so this returns the read and write pointers to the same
        // L1 address on every block, which is what makes the packer's accumulate land on the
        // running partial. The block before last leaves its tile in place for the reload above.
        if (block + 2 < num_blocks) {
            cb_acc_obj.wait_front(1);
            cb_acc_obj.pop_front(1);
        }
    }
}
#endif

void kernel_main() {
    const uint32_t NCHt = get_arg_val<uint32_t>(0);
    const uint32_t Ht = get_arg_val<uint32_t>(1);
    const uint32_t Wt = get_arg_val<uint32_t>(2);
    const uint32_t blk = get_arg_val<uint32_t>(3);
    const uint32_t start_ht = get_arg_val<uint32_t>(4);
    const uint32_t mask_padded_data = get_arg_val<uint32_t>(5);
    const uint32_t cb_length_t = get_arg_val<uint32_t>(6);

    // reserve one tile for zeros on cb_in2
    // We only do the reserve for the intermediates once and use pack_tile
    // So effectively these are used as pre-allocated arrays
    // Note that the entire W dimension must fit in the intermed0 CB for this kernel to be correct
    auto cb_scaler = tt::CBIndex::c_2;
    auto cb_fused_scale = tt::CBIndex::c_3;
    auto cb_fused_attn = tt::CBIndex::c_4;
    auto cb_exps = tt::CBIndex::c_6;
    auto cb_scale_mask = tt::CBIndex::c_9;
    auto cb_sumexps = tt::CBIndex::c_7;
    auto cb_prev_reduce = tt::CBIndex::c_12;
    auto cb_in0 = tt::CBIndex::c_0;
    auto cb_out0 = tt::CBIndex::c_11;
    auto cb_max = tt::CBIndex::c_8;
    auto cb_x = tt::CBIndex::c_10;
    // TODO: need to add this cb
    auto cb_recip = tt::CBIndex::c_16;
    auto cb_prev_max = tt::CBIndex::c_15;
#ifdef PV_FUSED
    // c_1, c_13 and c_14 are the three indices this program leaves free.
    constexpr auto cb_vv = tt::CBIndex::c_1;      // Wt value tiles, resident for one head
    constexpr auto cb_norm = tt::CBIndex::c_13;   // the normalised row, in L1 instead of DRAM
    constexpr auto cb_acc = tt::CBIndex::c_14;    // bmm_large_block_zm.cpp's cb_intermed0
    experimental::CircularBuffer cb_vv_obj(cb_vv);
#endif
    constexpr auto cb_mask_padded = tt::CBIndex::c_5;
    experimental::CircularBuffer cb_scaler_obj(cb_scaler);
    experimental::CircularBuffer cb_fused_scale_obj(cb_fused_scale);
    experimental::CircularBuffer cb_recip_obj(cb_recip);
    experimental::CircularBuffer cb_mask_padded_obj(cb_mask_padded);
    binary_op_init_common(tt::CBIndex::c_0, tt::CBIndex::c_2, tt::CBIndex::c_6);
    init_sfpu(cb_mask_padded, cb_mask_padded);

    cb_scaler_obj.wait_front(1);  // comes from the reader

#if FUSED_SCALE_MASK
    cb_fused_scale_obj.wait_front(1);
#endif

    uint32_t num_cb_passes = 1 + ((Wt - 1) / cb_length_t);  // ceiling divide

    // First loop is to parse and find the sum
    uint32_t dst0 = 0;
    uint32_t cb_processed_input;

#ifdef PV_FUSED
    // The value tiles belong to a head, and a core's rows are consecutive, so at most one head
    // boundary falls inside a core's work. The reader loads Wt tiles on every boundary and this
    // side releases the previous head's before waiting, which is also what stops the reader's
    // reserve_back(Wt) from deadlocking on a CB sized at exactly Wt tiles.
    // Per-head, not per-`Ht`: `Ht` spans every head because `plan` folds them into the row axis.
    const uint32_t pv_row = get_arg_val<uint32_t>(7);
    const uint32_t pv_mt = get_arg_val<uint32_t>(8);
    uint32_t ht_pv = pv_row % pv_mt;
#endif

    for (uint32_t ncht = 0; ncht < NCHt; ncht++) {
#ifdef PV_FUSED
        if (ncht == 0 || ht_pv == 0) {
            if (ncht != 0) {
                cb_vv_obj.pop_front(Wt);
            }
            cb_vv_obj.wait_front(Wt);
        }
#endif
        // This and all inner loops are for parsing the length of Wt in terms of chunks of the width that can fit in the
        // cb This specific loop is for generaating the sum
        // reads through and finds the max value
        bool use_prev_reduce = false;
        uint32_t length_left_t = Wt;
        uint32_t cur_cb_length_t = cb_length_t;
#ifdef NUMERIC_STABLE
        /*
         * --------------------------------------------------------
         * --------------------------------------------------------
         * ------------------Calcualte max of input values---------
         * --------------------------------------------------------
         * --------------------------------------------------------
         */
        for (uint32_t cur_pass = 0; cur_pass < num_cb_passes; cur_pass++) {
            bool do_mask = mask_padded_data && (cur_pass == num_cb_passes - 1);
#if FUSED_SCALE_MASK
            apply_fused_scale_mask(cb_in0, cb_fused_scale, cb_scale_mask, cb_length_t, blk);
            apply_fused_attn_mask(cb_scale_mask, cb_fused_attn, cb_x, cb_length_t, blk, do_mask);
            cb_processed_input = cb_x;
#else
            if (do_mask && cur_pass == num_cb_passes - 1) {
                // pad
                pad_input(cb_in0, cb_x, cb_length_t, blk);
                cb_processed_input = cb_x;
            } else {
                // no Pad
                cb_processed_input = cb_in0;
            }
#endif
            reduce_cb<PoolType::MAX>(cb_processed_input, tt::CBIndex::c_2, cb_prev_max, cb_max, use_prev_reduce, cur_cb_length_t);
            use_prev_reduce = true;
            length_left_t -= cur_cb_length_t;
            cur_cb_length_t = std::min(cur_cb_length_t, length_left_t);
            if (cur_pass != num_cb_passes - 1) {
                std::swap(cb_max, cb_prev_max);
            }
        }
        use_prev_reduce = false;
        length_left_t = Wt;
        cur_cb_length_t = cb_length_t;
#endif
#ifdef NUMERIC_STABLE
        experimental::CircularBuffer(cb_max).wait_front(1);
#endif

        /*
         * --------------------------------------------------------
         * --------------------------------------------------------
         * ------------------Calcualte sum of exp values-----------
         * --------------------------------------------------------
         * --------------------------------------------------------
         */
        for (uint32_t cur_pass = 0; cur_pass < num_cb_passes; cur_pass++) {
            bool do_mask = mask_padded_data && (cur_pass == num_cb_passes - 1);
#if FUSED_SCALE_MASK
            apply_fused_scale_mask(cb_in0, cb_fused_scale, cb_scale_mask, cb_length_t, blk);
            apply_fused_attn_mask(cb_scale_mask, cb_fused_attn, cb_x, cb_length_t, blk, do_mask);
            cb_processed_input = cb_x;
#else
            // Following code is focuesed on padding the last tile that need -inf for sections of the tile that are not
            // a part of the tensor
            if (do_mask && cur_pass == num_cb_passes - 1) {
                // pad
                pad_input(cb_in0, cb_x, cb_length_t, blk);
                cb_processed_input = cb_x;
            } else {
                // no Pad
                cb_processed_input = cb_in0;
            }

#endif
            exp_cb(cb_processed_input, cb_exps, cb_max, cur_cb_length_t, blk);

            reduce_cb<PoolType::SUM>(
                cb_exps, tt::CBIndex::c_2, cb_prev_reduce, cb_sumexps, use_prev_reduce, cur_cb_length_t);
            use_prev_reduce = true;  // We want to accumulate the previous cb reductions
            length_left_t -= cur_cb_length_t;
            cur_cb_length_t = std::min(cur_cb_length_t, length_left_t);
            if (cur_pass != num_cb_passes - 1) {
                std::swap(cb_sumexps, cb_prev_reduce);
            }
        }
        /*
         * --------------------------------------------------------
         * --------------------------------------------------------
         * ------------Find denominator 1/∑e^x from ∑e^x-----------
         * --------------------------------------------------------
         * --------------------------------------------------------
         */
        experimental::CircularBuffer(cb_sumexps).wait_front(1);

        reconfig_data_format_srca(cb_sumexps);
        pack_reconfig_data_format(cb_sumexps, cb_recip);
        tile_regs_acquire();
        copy_tile_init(cb_sumexps);
        copy_tile(cb_sumexps, 0, dst0);

        experimental::CircularBuffer(cb_sumexps).pop_front(1);

        recip_tile_init();
        recip_tile(dst0);

        tile_regs_commit();
        tile_regs_wait();

        cb_recip_obj.reserve_back(1);
        pack_tile(dst0, cb_recip);
        cb_recip_obj.push_back(1);

        tile_regs_release();

        cb_recip_obj.wait_front(1);
        /*
         * --------------------------------------------------------
         * --------------------------------------------------------
         * ------------------Calcualte final values----------------
         * --------------------------------------------------------
         * --------------------------------------------------------
         */
        length_left_t = Wt;
        cur_cb_length_t = cb_length_t;
#ifdef PV_FUSED
        uint32_t k_base = 0;
#endif
        for (uint32_t cur_pass = 0; cur_pass < num_cb_passes; cur_pass++) {
            bool do_mask = mask_padded_data && (cur_pass == num_cb_passes - 1);
#if FUSED_SCALE_MASK
            apply_fused_scale_mask(cb_in0, cb_fused_scale, cb_scale_mask, cb_length_t, blk);
            apply_fused_attn_mask(cb_scale_mask, cb_fused_attn, cb_x, cb_length_t, blk, do_mask);
            cb_processed_input = cb_x;
#else
            if (do_mask && cur_pass == num_cb_passes - 1) {
                // pad
                pad_input(cb_in0, cb_x, cb_length_t, blk);
                cb_processed_input = cb_x;
            } else {
                // no Pad
                cb_processed_input = cb_in0;
            }
#endif
            exp_cb(cb_processed_input, cb_exps, cb_max, cur_cb_length_t, blk);

#ifdef PV_FUSED
            apply_recip_mac(
                cb_exps, cb_recip, cb_norm, cb_vv, cb_acc, cb_out0, cur_cb_length_t, blk, k_base,
                Wt / blk);
            k_base += cur_cb_length_t;
#else
            apply_recip(cb_exps, cb_recip, cb_out0, cur_cb_length_t, blk);
#endif
            length_left_t -= cur_cb_length_t;
            cur_cb_length_t = std::min(cur_cb_length_t, length_left_t);
        }
        cb_recip_obj.pop_front(1);
#ifdef NUMERIC_STABLE
        experimental::CircularBuffer(cb_max).pop_front(1);
#endif
#ifdef PV_FUSED
        ht_pv++;
        if (ht_pv == pv_mt) {
            ht_pv = 0;
        }
#endif
    }
#ifdef PV_FUSED
    cb_vv_obj.pop_front(Wt);
#endif
    cb_mask_padded_obj.pop_front(1);
}  // MAIN
