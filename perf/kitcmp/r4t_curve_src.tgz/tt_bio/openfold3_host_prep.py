"""Host-side derivation of every OpenFold3 ``fold()`` input that the P11/P12 accuracy
path used to read from the ``~/of3_ref_out.pkl`` golden fixture.

Everything here is a pure function of ``build_openfold3_features()`` output plus the
checkpoint state dict -- no golden intermediates anywhere:

- ``derive_template_feat``: the template-embedder feature block from the raw
  ``template_*`` feature keys (the same construction
  ``scripts/of3_template_embedder_golden.py`` used to capture the fixture). For a
  template-free query this is the all-dummy block (restype one-hot 31, zeros elsewhere).
- ``derive_relpos``: the 139-d ``relpos_complex`` feature (input-embedder config
  ``max_relative_idx=32``, ``max_relative_chain=2``).
- ``derive_block_aux``: the atom-attention block/mask auxiliaries (``nb``, ``NP``,
  ``key_block_idxs``, ``invalid_mask``, ``mask_trunked``, ``npe_q/k_indices``,
  ``zij_mask``, ``atom_to_token_mean``, ``max_atom_per_token_mask``, ``ca_mask``) from
  ``atom_mask`` / ``atom_to_token_index`` / ``token_mask`` -- the same derivations the
  golden capture scripts ran once and froze into the pickle.
- ``ref_atom_embed``: host replica of OF3 ``RefAtomFeatureEmbedder`` (eight bias-free
  linears + the block construction), yielding the DM encoder's pre-noisy-position
  conditioning ``cl0``/``plm0`` and the input embedder's ``cl``/``plm``.
- ``run_input_atom_encoder``: the input embedder's atom-encoder leg (-> ``ai``):
  host ref-atom embedding + ``linear_l``/``linear_m``/``pair_mlp`` pair completion,
  then the PCC-gated device ``OF3AtomTransformer`` and the mean aggregation to tokens.

Validated tensor-by-tensor against the 1UBQ fixture by
``scripts/of3_host_prep_check.py`` (PCC / exact-match per tensor).
"""
from __future__ import annotations

import math

import torch
import torch.nn.functional as F
import ttnn

from ._vendor.openfold3.core.utils.atom_attention_block_utils import (
    convert_single_rep_to_blocks,
    get_block_indices,
    get_pair_atom_block_mask,
    get_query_block_padding,
)
from ._vendor.openfold3.core.utils.relpos import apply_cyclic_offsets, relpos_complex
from .envflags import env_flag
from .openfold3_weights import _sub

N_QUERY = 32
N_KEY = 128
MAX_RELATIVE_IDX = 32
MAX_RELATIVE_CHAIN = 2
ATOM_SLOTS_PER_TOKEN = 23


def derive_template_feat(features: dict) -> dict:
    """Template-embedder feature block from the raw ``template_*`` keys.

    Mirrors the fixture capture in ``scripts/of3_template_embedder_golden.py``:
    pair masks are the outer product of the per-token mask with itself, restricted to
    same-chain pairs; ``restype_ti/tj`` broadcast the per-token restype one-hot over
    the pair axes; the unit vector is split per component.
    """
    asym = features["asym_id"]
    mcm = (asym[:, None] == asym[None, :]).float()          # [N, N]
    pbm = features["template_pseudo_beta_mask"].float()      # [N_t, N]
    bbfm = features["template_backbone_frame_mask"].float()  # [N_t, N]
    restype = features["template_restype"].float()           # [N_t, N, 32]
    n_tok = restype.shape[-2]
    uv = features["template_unit_vector"].float()            # [N_t, N, N, 3]
    ux, uy, uz = uv.unbind(dim=-1)
    return {
        "distogram": features["template_distogram"].float(),
        "pseudo_beta_pair_mask": (pbm[..., None] * pbm[..., None, :])[..., None] * mcm[..., None],
        # Stride-0 views: the template embedder projects the row they broadcast (_unbroadcast).
        "restype_ti": restype[..., None, :].expand(*restype.shape[:-2], -1, n_tok, -1),
        "restype_tj": restype[..., None, :, :].expand(*restype.shape[:-2], n_tok, -1, -1),
        "unit_vec_x": ux[..., None],
        "unit_vec_y": uy[..., None],
        "unit_vec_z": uz[..., None],
        "backbone_frame_pair_mask": (bbfm[..., None] * bbfm[..., None, :])[..., None] * mcm[..., None],
    }


def dedup_template_slots(feat: dict) -> tuple[dict, list[int]]:
    """Drop template slots that repeat an earlier one, and say where each slot went.

    A query with fewer real templates than ``n_templates`` fills the rest of the slots
    from the same GAP/NaN precursor, so every derived feature is byte-identical across
    them and the pair stack runs the same two blocks on the same values several times.
    Returns the feature dict restricted to the distinct slots plus, per original slot,
    the row of that dict it maps to. Slots that genuinely differ are all kept, so a
    query with real templates takes the unchanged path.
    """
    nt = int(next(iter(feat.values())).shape[0])
    reps: list[int] = []          # original index of each distinct slot
    slot_index: list[int] = []    # per original slot, its row in the returned dict
    for t in range(nt):
        for j, r in enumerate(reps):
            if all(torch.equal(v[t], v[r]) for v in feat.values()):
                slot_index.append(j)
                break
        else:
            slot_index.append(len(reps))
            reps.append(t)
    if len(reps) == nt:
        return feat, slot_index
    return {k: v[reps].contiguous() for k, v in feat.items()}, slot_index


# The raw per-slot keys `derive_template_feat` reads. Each derived slot is an injective function
# of its own raw slot (the pair masks keep their diagonal, so a mask that differs anywhere shows),
# so two slots derive byte-identically exactly when these match.
TEMPLATE_RAW_KEYS = ("template_distogram", "template_pseudo_beta_mask",
                     "template_backbone_frame_mask", "template_restype", "template_unit_vector")


def derived_template_slots(features: dict) -> tuple[dict, list[int]]:
    """``dedup_template_slots(derive_template_feat(features))``, deduped on the raw keys first.

    Same tensors and slot map, but the [N, N] blocks are built once per distinct slot instead of
    once per slot: on a query with one real template or none, the duplicate slots are never
    expanded (0.20 -> 0.06 s on one core at 512 tokens).
    """
    raw, slot_index = dedup_template_slots({k: features[k] for k in TEMPLATE_RAW_KEYS})
    return derive_template_feat({**features, **raw}), slot_index


def derive_relpos(features: dict) -> torch.Tensor:
    """139-d ``relpos_complex`` feature, input-embedder clipping config."""
    return relpos_complex(
        batch=features,
        max_relative_idx=MAX_RELATIVE_IDX,
        max_relative_chain=MAX_RELATIVE_CHAIN,
    ).float()


# The relpos feature as codes: `table[codes]` is `derive_relpos` exactly, but the host builds [N, N] int32
# and a few hundred one-hot rows instead of 145 MB of float one-hots (0.16 s) and tilizing them (0.26 s on
# pc), and the device expands it with one embedding. Same digest as the dense feature on OpenFold3 and
# OpenBind-0 (qb2 p300c, cdk2x2_512). OF3_RELPOS_CODES=0 uploads the dense feature.
RELPOS_CODES = "OF3_RELPOS_CODES"


def derive_relpos_codes(features: dict) -> tuple[torch.Tensor, torch.Tensor]:
    """``(codes [N, N] int32, table [U, 139] float32)`` with ``table[codes] == derive_relpos(features)``.

    The same bins as ``relpos_complex``: three clipped offsets and the same-entity bit, packed into one
    integer per pair; each distinct packed value is one row of the table."""
    asym, ent = features["asym_id"], features["entity_id"]
    same_chain = asym[:, None] == asym[None, :]
    same_ent = ent[:, None] == ent[None, :]
    res = features["residue_index"]
    cyc = features.get("cyclic_mask")

    def binned(pos, cond, clip):
        off = apply_cyclic_offsets(offset=pos[:, None] - pos[None, :], pos=pos, cyclic_mask=cyc,
                                   asym_id=asym)
        return torch.where(cond, torch.clamp(off + clip, 0, 2 * clip), 2 * clip + 1).long()

    nr, nc = 2 * MAX_RELATIVE_IDX + 2, 2 * MAX_RELATIVE_CHAIN + 2
    parts = (binned(res, same_chain, MAX_RELATIVE_IDX),
             binned(features["token_index"], same_chain & (res[:, None] == res[None, :]), MAX_RELATIVE_IDX),
             same_ent.long(), binned(features["sym_id"], same_ent, MAX_RELATIVE_CHAIN))
    packed = ((parts[0] * nr + parts[1]) * 2 + parts[2]) * nc + parts[3]
    uniq, codes = torch.unique(packed, return_inverse=True)
    ch, rest = uniq % nc, uniq // nc
    e, rest = rest % 2, rest // 2
    table = torch.cat([F.one_hot(rest // nr, nr), F.one_hot(rest % nr, nr), e[:, None],
                       F.one_hot(ch, nc)], dim=-1).float()
    return codes.to(torch.int32), table


def derive_block_aux(features: dict) -> dict:
    """Atom-attention block auxiliaries from ``atom_mask``/``atom_to_token_index``.

    Same derivations as the ``diffusion_module_xlout`` / ``atom_transformer`` golden
    captures (scripts/of3_diffusion_module_xlout_golden.py).
    """
    atom_mask = features["atom_mask"].float()
    atom_to_token_index = features["atom_to_token_index"].long()
    n_atom = int(atom_mask.shape[0])
    n_token = int(features["token_mask"].shape[0])
    nb = math.ceil(n_atom / N_QUERY)
    NP = nb * N_QUERY
    pad_right = get_query_block_padding(n_atom, N_QUERY)
    key_block_idxs, invalid_mask = get_block_indices(
        atom_mask=atom_mask, n_query=N_QUERY, n_key=N_KEY, device=torch.device("cpu"))
    mask_trunked = get_pair_atom_block_mask(
        atom_mask=atom_mask, num_blocks=nb, n_query=N_QUERY, n_key=N_KEY,
        pad_len_right_q=pad_right, key_block_idxs=key_block_idxs,
        invalid_mask=invalid_mask)
    npe_q_indices = F.pad(atom_to_token_index, (0, pad_right), value=0).reshape(nb, N_QUERY).long()
    npe_k_indices = torch.gather(
        atom_to_token_index.unsqueeze(0).expand(nb, n_atom), 1, key_block_idxs.long())
    zij_mask = ((~invalid_mask).float())[:, None, :].expand(nb, N_QUERY, N_KEY) * mask_trunked

    atom_to_token_mean = torch.zeros(n_token, n_atom)
    atom_to_token_mean[atom_to_token_index, torch.arange(n_atom)] = atom_mask
    atom_to_token_mean = atom_to_token_mean / atom_to_token_mean.sum(-1, keepdim=True).clamp_min(1.0)

    # broadcast_token_feat_to_atoms layout: per token, the first num_atoms_per_token
    # slots carry the token value, the remaining 23 - n slots are zero.
    napt = features["num_atoms_per_token"].long() * features["token_mask"].long()
    max_atom_per_token_mask = (
        (torch.arange(ATOM_SLOTS_PER_TOKEN)[None, :] < napt[:, None]).float()
        * features["token_mask"].float()[:, None]
    ).reshape(-1)

    # Representative ("token center") atom per token for the confidence head: CA for
    # protein, C1' for nucleic acids — the upstream TOKEN_CENTER_ATOMS convention the
    # vendored tokenizer already annotates. A protein-only "== CA" mask leaves RNA/DNA
    # tokens with zero representatives and crashes the confidence head on an empty
    # one-hot. Fall back to CA only if the annotation is absent.
    #
    # `atom_array` is the biotite structure, and it is the one input here that a TRAINING
    # batch does not carry: upstream's featuriser emits tensors, and its own convention for
    # the representative atom is `ground_truth.start_atom_index` (each token's first atom)
    # rather than a name lookup. `None` says the caller has to supply its own; every
    # inference path builds `features` through `build_openfold3_features`, which always
    # sets it, so this branch is unreachable there and nothing about a fold moves.
    atom_array = features.get("atom_array")
    if atom_array is None:
        ca_mask = None
    elif "token_center_atom" in atom_array.get_annotation_categories():
        ca_mask = torch.from_numpy(atom_array.token_center_atom).bool()
    else:
        ca_mask = torch.from_numpy(atom_array.atom_name == "CA").bool()

    return dict(
        atom_mask=atom_mask, atom_to_token_index=atom_to_token_index,
        n_atom=n_atom, n_token=n_token, nb=nb, NP=NP,
        key_block_idxs=key_block_idxs, invalid_mask=invalid_mask,
        mask_trunked=mask_trunked, npe_q_indices=npe_q_indices,
        npe_k_indices=npe_k_indices, zij_mask=zij_mask,
        atom_to_token_mean=atom_to_token_mean,
        max_atom_per_token_mask=max_atom_per_token_mask, ca_mask=ca_mask)


def _lin(x: torch.Tensor, w: dict, name: str) -> torch.Tensor:
    out = x @ w[f"{name}.weight"].t().float()
    bias = w.get(f"{name}.bias")
    if bias is not None:
        out = out + bias.float()
    return out


# The gate that moves the atom-featurization legs off the host and onto the card. Default OFF:
# a device linear in bf16 or fp32 is not bit-identical to the host float32 one it replaces, and
# the OF3T charter's hard constraint is that nothing may change inference's output or slow it
# down. On, the eight `ref_atom_feature_embedder` linears and the input embedder's
# `linear_q.0.weight` run where a cotangent can reach them -- which is what `HOST_APPLIED`
# names in `perf/of3t_readable_mass/READABLE_MASS.json`.
DEVICE_REF_ATOM = "TT_BIO_OF3_DEVICE_REFATOM"


def ref_atom_single_inputs(features: dict, n_pad: int | None = None) -> list[torch.Tensor]:
    """The five per-atom feature blocks the single leg consumes, in reference order.

    ``n_pad`` zero-pads the atom axis to that many rows. All five linears are bias-free, so a
    zero row is a zero row out and the padded ``cl`` equals the host ``cl`` padded after the
    fact -- which is exactly what ``build_dm_device_aux`` does when the leg runs on the host.
    """
    x = [features["ref_pos"].float(),
         torch.arcsinh(features["ref_charge"].unsqueeze(-1).float()),
         features["ref_mask"].unsqueeze(-1).float(),
         features["ref_element"].float(),
         features["ref_atom_name_chars"].flatten(start_dim=-2).float()]
    if n_pad is not None:
        x = [F.pad(t, (0, 0, 0, n_pad - t.shape[-2])) for t in x]
    return x


def ref_atom_block_inputs(features: dict, atom_mask: torch.Tensor):
    """``dlm``, ``vlm``, ``inv_sq_dists``: the pair leg's inputs, and no weight in any of them.

    Mask-derived gathers (``convert_single_rep_to_blocks``) plus one reciprocal. Shared by the
    host and device legs so that only the eight linears differ between them, and so the device
    leg's gradient is the gradient of the same function.
    """
    ref_pos = features["ref_pos"].float()
    d_l, d_m, pair_mask = convert_single_rep_to_blocks(
        ql=ref_pos, n_query=N_QUERY, n_key=N_KEY, atom_mask=atom_mask)
    v_l, v_m, _ = convert_single_rep_to_blocks(
        ql=features["ref_space_uid"].unsqueeze(-1).float(),
        n_query=N_QUERY, n_key=N_KEY, atom_mask=atom_mask)
    dlm = (d_l.unsqueeze(-2) - d_m.unsqueeze(-3)) * pair_mask.unsqueeze(-1)
    vlm = (v_l.unsqueeze(-2) == v_m.unsqueeze(-3)).float() * pair_mask.unsqueeze(-1)
    inv_sq_dists = 1.0 / (1.0 + (dlm ** 2).sum(dim=-1, keepdim=True))
    return dlm, vlm, inv_sq_dists


def ref_atom_embed(w: dict, features: dict) -> tuple[torch.Tensor, torch.Tensor]:
    """Host replica of OF3 ``RefAtomFeatureEmbedder`` (Algorithm 5, line 1-7).

    ``w`` is the encoder's ``ref_atom_feature_embedder`` sub-state-dict (all eight
    linears are bias-free in the OF3 checkpoint). Returns ``cl`` [n_atom, c_atom] and
    ``plm`` [nb, n_query, n_key, c_atom_pair].
    """
    names = ("linear_ref_pos", "linear_ref_charge", "linear_ref_mask",
             "linear_ref_element", "linear_ref_atom_chars")
    cl = sum(_lin(x, w, n) for x, n in zip(ref_atom_single_inputs(features), names))
    dlm, vlm, inv_sq_dists = ref_atom_block_inputs(
        features, features["atom_mask"].float())
    pair = ("linear_ref_offset", "linear_inv_sq_dists", "linear_valid_mask")
    if any(f"{n}.bias" in w for n in pair):
        plm = (
            _lin(dlm, w, "linear_ref_offset") * vlm
            + _lin(inv_sq_dists, w, "linear_inv_sq_dists") * vlm
            + _lin(vlm, w, "linear_valid_mask") * vlm
        )
        return cl, plm
    # The same sum in one buffer. vlm is 0/1, so multiplying each term by it and then the sum
    # once are equal values, and a one-wide linear is one product per element. Bit-identical
    # to the three-term form, at half the host time (eight 34 MB passes become four).
    plm = _lin(dlm, w, "linear_ref_offset")
    plm.add_(inv_sq_dists * w["linear_inv_sq_dists.weight"].float()[:, 0])
    plm.add_(w["linear_valid_mask.weight"].float()[:, 0])
    return cl, plm.mul_(vlm)


def ref_atom_device_inputs(dev, features: dict, atom_mask: torch.Tensor,
                           n_pad: int | None = None, dtype=None) -> list:
    """The eight device tensors ``RefAtomFeatureEmbedder`` consumes, built once.

    Kept separate from the call so a taped instrument can hoist the transfers out of the loop
    and re-run only the module inside each tape, which is what makes the 48 structures
    accumulate into one weight gradient instead of 48 copies of the transfer. ``dtype`` is the
    consuming module's; the default is the one a bf16 module is built at.
    """
    from .tenstorrent import _dtype

    dtype = dtype or _dtype(ttnn.bfloat16)
    ft = lambda t: ttnn.from_torch(t.float().unsqueeze(0), layout=ttnn.TILE_LAYOUT,
                                   device=dev, dtype=dtype)
    return [ft(t) for t in ref_atom_single_inputs(features, n_pad)] + \
           [ft(t) for t in ref_atom_block_inputs(features, atom_mask)]


def ref_atom_embed_device(compute_kernel_config, w: dict, features: dict,
                          atom_mask: torch.Tensor, n_pad: int | None = None):
    """The same eight linears on the card, returning DEVICE ``cl`` and ``plm``.

    The point of this path is that nothing crosses back to the host between a weight and its
    consumer. ``cl`` is [1, ``n_pad`` or n_atom, 128] and ``plm`` is
    [1, nb, N_QUERY, N_KEY, 16], which is the shape ``OF3DiffusionModule`` already takes.
    """
    from .openfold3 import RefAtomFeatureEmbedder
    from .tenstorrent import get_device

    dev = get_device()
    rafe = RefAtomFeatureEmbedder(w, compute_kernel_config)
    return rafe(*ref_atom_device_inputs(dev, features, atom_mask, n_pad))


def input_atom_transformer(compute_kernel_config, sd: dict):
    """The input embedder's ``OF3AtomTransformer``. Build it once per model and pass it to
    every ``run_input_atom_encoder`` call: a fresh one uploads its weights again on each fold."""
    from .openfold3_atom_transformer import OF3AtomTransformer

    return OF3AtomTransformer(_sub(sd, "input_embedder.atom_attn_enc.atom_transformer"),
                              compute_kernel_config)


def atom_pair_completion(enc: dict, cl: torch.Tensor, plm: torch.Tensor,
                         atom_mask: torch.Tensor) -> torch.Tensor:
    """Algorithm 5 lines 13-14 (pair completion), host replica."""
    cl_l, cl_m, pair_mask = convert_single_rep_to_blocks(
        ql=cl, n_query=N_QUERY, n_key=N_KEY, atom_mask=atom_mask)
    # In place, in two scratch buffers: the same ops in the same order as
    # (plm + cl_lm*mask) -> 3-layer relu MLP -> (plm + h)*mask, bit for bit, without
    # allocating a fresh 34 MB tensor per op.
    pm = pair_mask.unsqueeze(-1)
    cl_lm = torch.add(_lin(cl_l.relu().unsqueeze(-2), enc, "linear_l"),
                      _lin(cl_m.relu().unsqueeze(-3), enc, "linear_m"))
    plm = cl_lm.mul_(pm).add_(plm)
    flat = plm.view(-1, plm.shape[-1])
    a, b = torch.empty_like(flat), torch.empty_like(flat)
    torch.clamp_min(flat, 0, out=a)
    for i, key in enumerate(("pair_mlp.1", "pair_mlp.3", "pair_mlp.5")):
        torch.mm(a, enc[f"{key}.weight"].t().float(), out=b)
        if f"{key}.bias" in enc:
            b.add_(enc[f"{key}.bias"].float())
        a, b = (b.clamp_min_(0) if i < 2 else b), a
    plm = a.view_as(plm).add_(plm).mul_(pm)
    return plm


def run_input_atom_encoder(dev, compute_kernel_config, sd: dict, features: dict,
                           aux: dict, at=None) -> torch.Tensor:
    """Input-embedder atom-encoder leg -> ``ai`` [n_token, 384].

    Host: ref-atom embedding + pair-rep completion. Device: the PCC-gated
    ``OF3AtomTransformer`` (P7), ``at`` from ``input_atom_transformer`` (built here when
    None). Host: ``relu(linear_q(...))`` + mean aggregation to tokens via
    ``atom_to_token_mean``.
    """
    enc = _sub(sd, "input_embedder.atom_attn_enc")
    atom_mask = aux["atom_mask"]
    n_atom, nb, NP = aux["n_atom"], aux["nb"], aux["NP"]

    cl, plm = ref_atom_embed(_sub(enc, "ref_atom_feature_embedder"), features)
    plm = atom_pair_completion(enc, cl, plm, atom_mask)

    at = at or input_atom_transformer(compute_kernel_config, sd)

    from .tenstorrent import upload

    def ft(x):
        return upload(x.float(), ttnn.bfloat16, dev)

    a_pad = torch.zeros(1, NP, 128)
    a_pad[0, :n_atom] = cl
    atom_mask_col = torch.zeros(1, NP, 1)
    atom_mask_col[0, :n_atom, 0] = atom_mask
    valid = (~aux["invalid_mask"]).float().reshape(1, nb, N_KEY, 1)
    mask_bias = (1e9 * (aux["mask_trunked"] - 1)).reshape(1, nb, 1, N_QUERY, N_KEY)
    kidx = aux["key_block_idxs"].reshape(1, nb * N_KEY).to(torch.int32)
    kidx_tt = ttnn.from_torch(kidx, layout=ttnn.ROW_MAJOR_LAYOUT, device=dev,
                              dtype=ttnn.uint32)
    # One upload of a_pad, copied on the card; the channel-1 masks go up without their unit
    # dim (a trailing 1 tile-pads 32x in the host tilize) and get it back on the card.
    a_d = ft(a_pad)
    ql_d = at(a_d, ttnn.clone(a_d), ft(plm.unsqueeze(0)),
              ttnn.unsqueeze(ft(atom_mask_col.squeeze(-1)), -1),
              kidx_tt, ttnn.unsqueeze(ft(valid.squeeze(-1)), -1), ft(mask_bias), n_atom, NP, nb)
    if env_flag(DEVICE_REF_ATOM, False):
        # The aggregation head on the card. `linear_q.0.weight` is 0.74055 % of the model's
        # squared gradient norm on its own -- the single heaviest of the seventeen tensors
        # READABLE_MASS.json files as HOST_APPLIED -- and it is the last op of this leg, so
        # moving it moves the `ttnn.to_torch` with it: `ai` [n_token, 384] comes back instead
        # of `ql` [n_atom, 128], which is the smaller transfer on every real target.
        from .openfold3 import AtomEncoderTokenHead

        n_token = aux["atom_to_token_mean"].shape[0]
        head = AtomEncoderTokenHead(_sub(enc, "linear_q"), compute_kernel_config)
        amc_na = torch.zeros(1, n_atom, 1)
        amc_na[0, :, 0] = atom_mask
        ai_d = head(ql_d, ft(amc_na), ft(aux["atom_to_token_mean"].unsqueeze(0)))
        ai = ttnn.to_torch(ai_d).float().reshape(n_token, 384)
        ttnn.deallocate(ai_d)
        ttnn.deallocate(ql_d)
        return ai

    ql = ttnn.to_torch(ql_d).float().reshape(n_atom, 128)
    ttnn.deallocate(ql_d)

    lq_w = _sub(enc, "linear_q")["0.weight"]
    q = F.linear(ql * atom_mask[:, None], lq_w.float()).relu()
    ai = aux["atom_to_token_mean"] @ q
    return ai
