"""`tt-bio evaluate --model rfd4`: upstream's `rfd4-evaluate`, on tt-bio's own stack.

Same inputs (a directory of generated structures, searched recursively), same `metrics_tags`
gating, same output: `<out_dir>/evaluation_metrics/per_example_metrics[_job<N>].csv`, one row per
design, upstream's column names, rounded to 4 decimals with NaN written as an empty cell, and beside
it `aggregated_metrics[_job<N>].csv`, the per-dataset reductions upstream's generate path writes
(medians, `frac_under_<T>` on `min_ipae_coi`, per-target solve rates).

What upstream does and this keeps, on purpose:
* the inline block is all-or-nothing per design. If any inline metric raises, the design gets no
  inline columns and `pre_oracle_pass = 0` (rfproteina `evaluate.py:192-193`). Hiding that would
  make the two arms disagree exactly where a grader needs them to agree.
* a pre-oracle filter whose metric is missing counts as a failure (`pass_criterion_metric.py:131`).

Metrics not ported yet are listed in `NOT_PORTED`; asking for a tag that gates one of them is an
error rather than a silently shorter CSV.
"""

import csv
import hashlib
import logging
import math
from pathlib import Path

import numpy as np

from tt_bio.rfd4 import eval_metrics as M
from tt_bio.rfd4 import eval_refold as R
from tt_bio.rfd4.eval_io import read_design

log = logging.getLogger(__name__)

_STRUCTURE_SUFFIXES = (".cif", ".cif.gz", ".cif.zst", ".bcif", ".pdb", ".pdb.gz")


def _gate(any_of=(), all_of=(), none_of=()):
    """rfproteina `metric.py:397-419`: required-any, required-all, prohibited."""
    any_of, all_of, none_of = set(any_of), set(all_of), set(none_of)

    def applies(tags):
        if tags is None:
            return True
        return (
            (not all_of or tags >= all_of)
            and (not any_of or bool(tags & any_of))
            and not (tags & none_of)
        )

    return applies


# Inline metrics in upstream's config order (configs/metrics/inline_metrics/design_metrics.yaml),
# each with its gate and its port.
INLINE = (
    ("amino_acid_composition", _gate(), lambda d, i: M.compute_amino_acid_composition(d)),
    (
        "bond_length_metrics",
        _gate(any_of=["design"], none_of=["small_molecule_only", "structure_prediction"]),
        lambda d, i: M.compute_bond_length_stats(d.atoms, d.is_polymer),
    ),
    (
        "clash_metrics",
        _gate(any_of=["design", "structure_prediction"], none_of=["small_molecule_only"]),
        lambda d, i: M.compute_clash_stats(d.atoms, d.is_polymer, d.is_crd),
    ),
    ("sequence_adherence", _gate(any_of=["design"]), lambda d, i: M.compute_sequence_adherence(d)),
    ("sequence_probability_adherence", _gate(any_of=["design"]), lambda d, i: M.compute_sequence_probability_adherence(d)),
    (
        "sse_distribution",
        _gate(any_of=["design"], none_of=["small_molecule_only", "structure_prediction"]),
        lambda d, i: M.compute_sse_distribution(d),
    ),
    (
        "sse_accuracy",
        _gate(any_of=["design"], none_of=["small_molecule_only", "structure_prediction"]),
        lambda d, i: M.compute_sse_accuracy(d),
    ),
    ("rasa_adherence", _gate(any_of=["rasa_conditioning"]), lambda d, i: M.compute_rasa_adherence(d)),
    (
        "centroid_conditioning_adherence",
        _gate(any_of=["centroid_conditioning"]),
        lambda d, i: M.compute_centroid_conditioning_adherence(d),
    ),
    ("hotspot_obedience", _gate(any_of=["hotspot_conditioning"]), lambda d, i: M.compute_hotspot_obedience(d)),
    (
        "design_motif_allatom_rmsd",
        _gate(any_of=["3d_coordinate_conditioning", "unindexed", "internal_coordinate_conditioning"]),
        lambda d, i: R.design_motif_rmsd(d),
    ),
    ("sequence_similarity_to_input", _gate(any_of=["partial_diffusion"]), M.compute_sequence_similarity_to_input),
    ("ca_rmsd_to_input", _gate(any_of=["partial_diffusion"]), M.compute_ca_rmsd_to_input),
)

# Upstream inline metrics this port does not compute yet, with the tags that switch them on.
NOT_PORTED = {
    "interchain_interactions": _gate(any_of=["interchain_interactions"]),
    "posebusters_metrics": _gate(any_of=["small_molecule_only"]),
    "chiral_accuracy": _gate(any_of=["has_small_molecule"]),
    "design_unindexed_motif_allatom_rmsd": _gate(all_of=["unindexed"]),
    "unindexed_insertion_mapping": _gate(all_of=["unindexed"]),
    "contact_molecular_surface": _gate(any_of=["cms"]),
    "cath_metric": _gate(any_of=["cath"]),
    "structure_prediction_lddt": _gate(any_of=["structure_prediction"]),
    "sequence_developability": _gate(any_of=["developability"]),
    "rosetta_developability": _gate(any_of=["developability"]),
    "antibody_contacts": _gate(any_of=["antibody"]),
}

# configs/metrics/pre_oracle_filters/all_pre_oracle_filters.yaml: (key, gate, {column: max}).
PRE_ORACLE_FILTERS = (
    ("unknown_residue_filter", _gate(), {"amino_acid_composition.n_generated_unknown_residues": 0}),
    ("sequence_adherence_filter", _gate(any_of=["design"]), {"sequence_adherence.n_violations": 0}),
    # Reads `motif_rmsd.rmsd`, a key no upstream metric writes, so the tag always fails a design there.
    ("motif_rmsd_filter", _gate(all_of=["motif_rmsd_filter"]), {"motif_rmsd.rmsd": 1.0}),
    (
        "ligand_clash_filter",
        _gate(all_of=["ligand_clash_filter"], none_of=["no_ligand"]),
        {"clash_metrics.frac_atoms_clashing_inter_residue_polymer_ligand_1p5A": 0},
    ),
)
PRE_ORACLE_NOT_PORTED = {
    "unindexed_insertion_mapping_filter": _gate(all_of=["unindexed"]),
    "insertion_rmsd_filter": _gate(all_of=["unindexed", "insertion_rmsd_filter"]),
}

#: Upstream metrics no tag reaches: they are deliberately left out of `all_inline_metrics.yaml`
#: and a user copies one into a metric set. Each is bound to a dependency tt-bio does not take
#: (DECISIONS.md, 2026-10-21), so each is refused by name with that dependency.
OPT_IN_NOT_PORTED = {
    "ligand_interface_ddg": "tmol, a torch-CUDA energy stack",
    "ligand_interface_hbonds": "tmol, a torch-CUDA energy stack",
    "ligand_interface_electrostatics": "tmol, a torch-CUDA energy stack",
    "soft_ddg": "tmol, a torch-CUDA energy stack",
    "ppi_interface_ddg": "tmol, a torch-CUDA energy stack",
    "ppi_interface_coulomb": "tmol, a torch-CUDA energy stack",
    "mutation_interface_ddg": "tmol, a torch-CUDA energy stack",
    "mutation_interface_ddg_scan": "tmol, a torch-CUDA energy stack",
    "charge_complementarity": "PyRosetta (ddg_salt_metrics), which is licence-encumbered",
    "ipa_interaction_energy": "the IPA QM binary ($IPA_PATH)",
    "foldseek_novelty": "the Foldseek binary ($FOLDSEEK_EXEC) and its passer database",
}

# Tags that switch on a refolding oracle. The oracle itself is not run here: `eval_refold` reads
# the refold the oracle cached, which is how upstream resumes too.
ORACLE_TAGS = {tag for _, _, gate in R.ORACLES for tag in gate}


def parse_tags(raw):
    """rfproteina `evaluate.py:69-75`: a string is split on commas, a list is taken as is."""
    if raw is None:
        return None
    if isinstance(raw, str):
        raw = raw.strip().strip("[]")
        return [t.strip().strip("'\"") for t in raw.split(",") if t.strip()]
    return list(raw)


def unsupported(tags):
    tagset = None if tags is None else set(tags)
    names = [n for n, g in {**NOT_PORTED, **PRE_ORACLE_NOT_PORTED}.items() if g(tagset)]
    return names + R.not_ported(tagset)


def structure_files(inputs):
    root = Path(inputs)
    files = sorted(p for p in root.glob("**/*") if p.is_file() and p.name.lower().endswith(_STRUCTURE_SUFFIXES))
    if not files:
        raise ValueError(f"No structure files found in {inputs}")
    return files


def structure_stem(path):
    name = path.name
    for suffix in sorted(_STRUCTURE_SUFFIXES, key=len, reverse=True):
        if name.lower().endswith(suffix):
            return name[: -len(suffix)]
    return path.stem


def example_id(path, inputs):
    """rfproteina `evaluate.py:129-134`: stem plus the first 8 hex of sha256(relative path as .cif)."""
    rel = path.relative_to(inputs)
    stem = structure_stem(rel)
    identity = rel.with_name(stem + ".cif")
    return f"{stem}_{hashlib.sha256(str(identity).encode()).hexdigest()[:8]}"


def input_structure(path):
    """rfproteina `evaluate.py:58-62`: generation writes `<base>_input.cif` beside `<base>_generated.cif`."""
    base = structure_stem(path)
    if base.endswith("_generated"):
        base = base[: -len("_generated")]
    for suffix in _STRUCTURE_SUFFIXES:
        candidate = path.parent / f"{base}_input{suffix}"
        if candidate.exists():
            return candidate
    return None


def inline_metrics(design, tags, input_design=None):
    tagset = None if tags is None else set(tags)
    out = {}
    for name, gate, fn in INLINE:
        if gate(tagset):
            out.update({f"{name}.{k}": v for k, v in fn(design, input_design).items()})
    return out


def pre_oracle_pass(metrics, tags):
    tagset = None if tags is None else set(tags)
    for _, gate, limits in PRE_ORACLE_FILTERS:
        if not gate(tagset):
            continue
        for column, maximum in limits.items():
            value = metrics.get(column)
            if value is None or (isinstance(value, float) and math.isnan(value)) or value > maximum:
                return 0.0
    return 1.0


def _cell(value):
    if value is None:
        return ""
    if isinstance(value, float):
        return "" if math.isnan(value) else repr(round(value, 4))
    return value


def evaluate(inputs, metrics_tags, out_dir, task_csv=None, job_id=None, gen_njobs=1,
             extra_metrics=None, cluster_with_foldseek=False):
    """Run the ported inline metrics over `inputs` and write upstream's CSV. Returns its path.

    `extra_metrics` names upstream metrics that no tag reaches: the ones a user copies into a
    metric set by hand (`configs/metrics/inline_metrics/{tmol_block_pair,ipa}_metrics.yaml`).
    None of them is ported, so naming one is refused with the dependency it would pull in, rather
    than scored short. `cluster_with_foldseek` is refused the same way.
    """
    tags = parse_tags(metrics_tags)
    for name in extra_metrics or ():
        if name in OPT_IN_NOT_PORTED:
            raise NotImplementedError(
                f"{name} is not ported: it needs {OPT_IN_NOT_PORTED[name]}, which tt-bio does "
                "not ship (state/rfd4/DECISIONS.md). Run it upstream.")
        raise ValueError(f"unknown metric: {name}")
    if cluster_with_foldseek:
        raise NotImplementedError(
            f"cluster_with_foldseek is not ported: it needs {OPT_IN_NOT_PORTED['foldseek_novelty']}. "
            "A clustering or novelty number against a database tt-bio does not ship is not "
            "reproducible for a user (state/rfd4/DECISIONS.md).")
    missing = unsupported(tags)
    if missing:
        raise NotImplementedError(
            "these upstream metrics are switched on by the requested tags but are not ported yet: "
            + ", ".join(missing)
        )
    inputs = Path(inputs)
    files = structure_files(inputs)
    tasks = {}
    if task_csv is not None:
        with open(task_csv, newline="") as fh:
            tasks = {r["designed_structure_path"]: r["task"] for r in csv.DictReader(fh)}
    if job_id is not None:
        chunk = (len(files) + gen_njobs - 1) // gen_njobs
        files = files[job_id * chunk : (job_id + 1) * chunk]
        if not files:
            raise ValueError("No structure files remain after chunking.")

    out_dir = Path(out_dir)
    samples_dir = out_dir / "evaluation_samples"
    metrics_dir = out_dir / "evaluation_metrics"
    metrics_dir.mkdir(parents=True, exist_ok=True)

    rows, uncached, no_crd = [], [], []
    for path in files:
        eid = example_id(path, inputs)
        row = {
            "example_id": eid,
            "dataset_name": inputs.name,
            "task": tasks.get(str(path), "all"),
            "designed_structure_path": str(path),
            "output_base_dir": str(samples_dir),
            "metrics_tags": ",".join(tags) if tags else "",
        }
        design = None
        try:
            design = read_design(path)
            sidecar = input_structure(path)
            metrics = inline_metrics(design, tags, read_design(sidecar) if sidecar else None)
        except Exception as exc:  # upstream drops the whole inline block for this design
            log.warning("Design metrics failed for %s: %s", eid, exc)
            metrics = {}
        row.update(metrics)
        row["pre_oracle_pass"] = pre_oracle_pass(metrics, tags)
        # rfproteina `proteina.py:283-290` fills this from metric keys ending in `chain_of_interest`;
        # only the oracles emit one, so on the inline-only path it is always empty.
        row["chain_of_interest"] = None

        oracle_active = tags is None or set(tags) & ORACLE_TAGS
        # A design that fails a pre-oracle filter is dropped before the oracle stage
        # (rfproteina `evaluate.py:200-209`), so it gets no oracle or refolding columns at all.
        if oracle_active and design is not None and row["pre_oracle_pass"] == 1.0:
            tagset = None if tags is None else set(tags)
            columns, refolds, coi = R.oracle_metrics(samples_dir, eid, tagset)
            if not columns:
                uncached.append(eid)
            row.update(columns)
            row["chain_of_interest"] = coi
            refold_columns = R.refolding_metrics(design, refolds, tagset, coi)
            if not design.is_crd.any():
                no_crd.append(eid)
            row.update(refold_columns)
            row.update(R.pass_criteria({**metrics, **columns, **refold_columns}, tagset))
        elif oracle_active:
            # Upstream still writes the criterion's columns for a design the filter dropped, zeroed
            # at merge time (rfproteina `evaluate.py:251-256`).
            row.update({k: 0.0 for k in R.pass_criteria({}, None if tags is None else set(tags))})
        rows.append(row)

    crd_metrics = R.crd_aligned_metrics(None if tags is None else set(tags))
    if no_crd and crd_metrics:
        # A design pinned by an internal coordinate group (`C_CRDGRP`, upstream's recommended PPI
        # recipe) carries no absolute coordinates, so a metric that aligns on `C_CRD` has nothing
        # to align on and is absent. Upstream drops it silently and the criterion then reads
        # `pass=0, all_metrics_present=0`, which is easy to mistake for a design that was scored
        # and failed. Say it once instead.
        log.warning(
            "%d of %d designs have no absolute coordinate conditioning (C_CRD), so %s %s not "
            "computed and every criterion reading them scores all_metrics_present=0 "
            "(indeterminate, not failed). Their target is pinned as an internal coordinate group; "
            "condition it with C_CRD instead to make these scoreable. First: %s.",
            len(no_crd), len(rows), ", ".join(crd_metrics),
            "is" if len(crd_metrics) == 1 else "are", no_crd[0],
        )

    if uncached:
        raise NotImplementedError(
            f"{len(uncached)} of {len(rows)} designs have no cached refold under {samples_dir} "
            f"(first: {uncached[0]}), and this port folds nothing itself. Refold them with "
            "`tt_bio.rfd4.oracle` or upstream's rfd4-evaluate, then score the same out_dir again."
        )

    columns = []
    for row in rows:
        columns += [c for c in row if c not in columns]
    suffix = f"_job{job_id}" if job_id is not None else ""
    path = metrics_dir / f"per_example_metrics{suffix}.csv"
    with open(path, "w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=columns)
        writer.writeheader()
        for row in rows:
            writer.writerow({c: _cell(row.get(c)) for c in columns})
    with open(metrics_dir / f"aggregated_metrics{suffix}.csv", "w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=("dataset", "metric", "reduction", "value", "n"))
        writer.writeheader()
        for agg in aggregate(rows, columns):
            writer.writerow({**agg, "value": _cell(agg["value"])})
    return path


# The aggregate step upstream runs after its per-example CSV (rfproteina `proteina.py:1436-1503`).
# Its `rfd4-evaluate` stops at the per-example CSV; this writes the same `aggregated_metrics.csv`
# its generate path does, so a run scored here reads like one scored there.

#: Metrics whose config sets `aggregation: [median]` (configs/metrics/**/*.yaml); every other column
#: is a mean (`Metric.__init__` default, and the fallback for a column no metric owns).
MEDIAN = {
    "design_motif_allatom_rmsd", "design_unindexed_motif_allatom_rmsd", "ca_rmsd_to_input",
    "refolded_backbone_rmsd", "refolded_target_aligned_binder_rmsd",
    "refolded_target_backbone_aligned_binder_rmsd", "refolded_motif_allatom_rmsd",
    "refolded_motif_ca_rmsd", "refolded_backbone_aligned_ligand_rmsd", "refolded_apo_holo_rmsd",
    *(key for key, _, _ in R.ORACLES),
}  # fmt: skip
#: `frac_under_thresholds` (af3.yaml): one `frac_under_<T>` row per threshold, strict `<`, keyed by
#: the bare output name (`OracleMetric.aggregate`).
FRAC_UNDER = {key: {"min_ipae_coi": (1, 1.5, 2)} for key, _, _ in R.ORACLES}
#: `inference_utils/solve_rate_metrics.py`: share of targets with at least this pass rate.
SOLVE_RATE = {"1pct": 0.01, "5pct": 0.05, "10pct": 0.10, "20pct": 0.20}
_NOT_METRICS = {
    "example_id", "dataset_name", "task", "designed_structure_path", "chain_of_interest",
    "foldseek_cluster_id", "ckpt_path", "ckpt_name", "seed", "input_cif_path", "input_json_path",
    "metrics_tags", "output_base_dir",
}  # fmt: skip


def _number(value):
    """`pd.to_numeric(errors="coerce")` for one cell: None for anything that is not a finite-or-inf number."""
    try:
        x = float(value)
    except (TypeError, ValueError):
        return None
    return None if math.isnan(x) else x


def aggregate(rows, columns):
    """Upstream's aggregated rows for per-example `rows`: per dataset, each metric column's reductions
    over the designs that have a value (`n`), then that dataset's per-target solve rates."""
    out = []
    criteria = [f"{name}.pass" for name, *_ in R.PASS_CRITERIA]
    for ds in dict.fromkeys(r["dataset_name"] for r in rows):
        group = [r for r in rows if r["dataset_name"] == ds]
        for col in columns:
            if col in _NOT_METRICS or col.startswith("generation."):
                continue
            vals = [x for r in group if (x := _number(r.get(col))) is not None]
            if not vals:
                continue
            name, _, suffix = col.partition(".")
            red = "median" if name in MEDIAN else "mean"
            reductions = {red: float(np.median(vals) if red == "median" else np.mean(vals))}
            for t in FRAC_UNDER.get(name, {}).get(suffix.rpartition(".")[2], ()):
                reductions[f"frac_under_{t}"] = sum(v < t for v in vals) / len(vals)
            out += [{"dataset": ds, "metric": col, "reduction": k, "value": round(v, 4), "n": len(vals)}
                    for k, v in reductions.items()]
        for col in (c for c in criteria if c in columns):
            by_task = {}
            for r in group:
                if (x := _number(r.get(col))) is not None:
                    by_task.setdefault(r["task"], []).append(x)
            rates = [sum(v) / len(v) for v in by_task.values()]
            if not rates:
                continue
            prefix, top = col[: -len("pass")], max(SOLVE_RATE.values())
            solve = {"n_targets": float(len(rates)), "any": sum(p > 0 for p in rates) / len(rates)}
            solve.update({k: sum(p >= t for p in rates) / len(rates) for k, t in SOLVE_RATE.items()})
            solve["auc"] = sum(min(p, top) for p in rates) / len(rates) / top
            out += [{"dataset": ds, "metric": f"{prefix}solve_rate_{k}", "reduction": "", "value": round(v, 4),
                     "n": len(rates)} for k, v in solve.items()]
    return out
