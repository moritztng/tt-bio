"""Boltz model — vendored from BoltzGen with PyTorch-Lightning removed.

The class is now a plain ``nn.Module``. Training-only methods
(``training_step``, ``validation_step``, ``configure_optimizers``,
``on_*_epoch_end``, ``on_before_optimizer_step``, ``training_log``,
``configure_callbacks``, ``on_load_checkpoint``) are gone, along with
their associated loss / optimizer / validator imports and the
``MeanMetric`` training-loss loggers. Training-time constructor args are
still accepted for backward compatibility with older checkpoints but
their values are ignored.

``convert_to_tt`` is applied at the end of ``__init__`` so every
constructed model runs on Tenstorrent — there's no CPU/GPU path here.
"""

import math
from pathlib import Path
from typing import Any, Dict, Optional, List

import numpy as np
import torch
from torch import Tensor, nn

from tt_bio import tenstorrent
from tt_bio.boltz2 import _device_conditioning, _device_zinit, _fuse_bias_stack
from tt_bio.tenstorrent import (
    MiniformerModule as TTMiniformerModule,
    MSAModule as TTMSAModule,
    PairformerModule as TTPairformerModule,
)

from tt_bio.boltzgen.progress import progress as _emit_progress
import tt_bio.boltzgen.model.layers.initialize as init
from tt_bio.data import const
from tt_bio.boltzgen.model.modules.confidence import ConfidenceModule
from tt_bio.boltzgen.model.modules.diffusion import AtomDiffusion
from tt_bio.boltzgen.model.modules.diffusion_conditioning import (
    DiffusionConditioning,
)
from tt_bio.boltzgen.model.modules.encoders import RelativePositionEncoder
from tt_bio.boltzgen.model.modules.affinity import AffinityModule
from tt_bio.boltzgen.model.modules.masker import BoltzMasker
from tt_bio.boltzgen.model.modules.trunk import (
    BFactorModule,
    ContactConditioning,
    DistogramModule,
    InputEmbedder,
    TemplateModule,
    TokenDistanceModule,
)
from tt_bio.boltzgen.model.modules.inverse_fold import (
    InverseFoldingEncoder,
    InverseFoldingDecoder,
)

# BoltzGen's precision levers per mode (`tenstorrent.model_levers`). The device modules are built at
# state-dict load and run in `forward`, both inside `lever_scope`, so the process-wide `--fast` switch
# (`tenstorrent._FAST_MODE`: bfp8 activations and weights, narrower chunks) is off inside BoltzGen, as
# in Boltz-2. At 512 aa that switch designed slower than normal mode (p150a 44.52 vs 38.40 s/design).
# Fast is pinned by name so a lever added to tenstorrent.FAST_LEVERS later is not in BoltzGen's fast
# mode ungraded. It is the shared fast set without dit_sdpa_pm (at 544 tokens its kernel loses to the
# stock SDPA on the 768 pad: Wormhole 66.3 -> 61.7 s/design) plus adaln_mod and dit_cond_hifi2 (the
# hoisted conditioning matmuls at HiFi2: 61.7 -> 60.4). Grade (Wormhole, bg_R3, 8 designs at each of
# seeds 0, 1, 3-7 against exact normal at the same seed, floor = exact at the next seed,
# perf/spd/bg_grade.py): 56 designs, filter pass 56 of 56 in both, every confidence CI covers 0
# (design ipTM -0.020 [-0.047, +0.006], design pTM -0.011, complex pLDDT -0.001). Same-seed design CA
# RMSD is no bar here: a design rollout decorrelates under any numeric change (floor median 11.8 A).
# Normal is the shared normal set as of 2026-10-12, pinned by name for the same reason. Grade (same protocol,
# seeds 0-7, on top of the device conditioning and fused bias stacks, against the exact normal stack): 64
# designs, filter pass 64 of 64 in both, design ipTM +0.002 [-0.031, +0.035], design pTM -0.000 [-0.019,
# +0.016], complex pLDDT +0.001. Wormhole 61.2 -> 58.0 s/design, all of it in the trunk (35.3 -> 31.5 s).
LEVERS_NORMAL = frozenset({"trimul_ibw", "trimul_tail", "trunk_hifi3", "dit_sdpa32", "silu_f32", "triatt_tail",
                           "atom_k1", "dit_mm16", "dit_qkv16", "msa_sample", "dit_sdpa", "dit_chunk", "conf_bins"})
LEVERS_FAST = frozenset({"acc_off", "diffusion_bf16", "dit_sdpa", "transition_b8", "opm_b8", "atom_sdpa",
                         "trimul_ibw", "trimul_tail", "trimul_gin", "trunk_hifi3", "dit_sdpa32", "silu_f32",
                         "ln_f32", "triatt_tail", "transition_bw", "transition_shard", "dit_mm16", "atom_k1",
                         "dit_b8", "dit_qkv16", "swiglu_fc12g", "msa_sample", "adaln_mod", "dit_cond_hifi2"})
# Every arch set also featurizes the next design in a spawned process (bg_featproc) rather than a thread, so its Python
# no longer takes the GIL from the thread dispatching the current design. Host-only, the designs are byte-identical
# (bg_R3, seed 0, 6 designs, b,p,p,b on a p300 chip at AICLK mean 1312 MHz, 2026-10-31): fast 15.60 -> 15.08 s/design,
# host pre 0.98 -> 0.38 s.
HOST_LEVERS = frozenset({"bg_featproc"})
# Wormhole adds placement-only levers that design byte-identical CIFs on bg_R3 (seed 0, 6 designs, b,l,l,b on a Galaxy
# chip at 1000 MHz, spd-m-boltzgen lev 2026-10-26), so they need no grade: atom_l1 normal 57.58 -> 56.43 s/design,
# fast 52.98 -> 51.84; trimul_bres fast 53.00 -> 51.40 (in normal it read +0.3 s, noise, and stays off).
# Wormhole normal also takes the weight-stationary transition, the fused triangle-attention LN and dit_cond_steps,
# graded as one stack by the normal protocol (bg_grade.py, bg_R3, seeds 0-3 x 8 designs vs exact WH normal,
# 2026-10-26): design_ptm -0.008, complex_plddt +0.003, iptm +0.002, filter 32/32 vs 32/32. Galaxy chip at 1000 MHz:
# 55.80 -> 53.26 s/design. The T1/T2 trimul kernels on top of that set pass the normal grade pooled over seeds 0-7
# (64 designs; design_ptm -0.002 [-0.016, +0.012], iptm -0.007, complex_plddt -0.001, filter 64/64). An earlier
# 4-seed grade of a five-lever stack failed on design_ptm alone; the 8-seed retest was pre-registered.
# dit_pad_short stages the token DiT bias at 576 rather than 768 for the 544-token page design: normal grade over seeds
# 0-7 (2026-10-27) design_ptm +0.002, iptm +0.013, complex_plddt -0.002, filter 64/64; 46.4 -> 45.2 s/design.
# adaln_mod fuses each fp32 AdaLN modulation into one addcmul and so lets dit_cond_steps condition several DiT steps
# ahead (without it dit_cond_steps does nothing in normal): 43.3 -> 40.9 s/design at 1000 MHz. Normal grade over seeds
# 0-7 (2026-10-27, 64 designs): design_ptm +0.001 [-0.010, +0.012], iptm +0.014, complex_plddt -0.002.
# Normal also takes the DiT linears and trunk four that fast carries (dit_qkvf, dit_bpad, dit_shard, dit_fc123g, apb_ln,
# ws_l1dest, ws_resid, trimul_t2cm): 37.6 -> 33.9 s/design at 1000 MHz (whx2, 2026-10-31). trimul_bres and opm_jd on
# top leave the CIFs byte-identical: 34.0 -> 33.0 (wnl, 2026-11-01). Normal grade vs exact WH normal over seeds 0-7 (64
# designs, 2026-11-01): PASS, design_ptm +0.016 [+0.008, +0.025], iptm -0.019 [-0.041, +0.002], filter 64/64.
# Both Wormhole sets take the windowed atom attention reading its key windows in place (atom_kvw: one fused q|k|v
# linear, one head split, kv_window SDPA over the 160-key superset) and six shared pair-stack levers: the transition's
# LayerNorm in-kernel (ws_ln_resid, ws_ln_t1l1), T1 split (trimul_t1split), the six-tile sigmoid (trimul_sig6) and T2's
# tail reading the moved x as bfp8 (trimul_x8, pair_x8t). On a Galaxy chip at 1000 MHz (kvw, b s k k s b, 6 designs,
# 2026-11-19): fast 28.95 -> 27.98 s/design, normal 30.03 -> 29.37. Graded with each set vs TT_BIO_LEVERS=none (8 seeds x
# 8 designs, 2026-11-19): normal PASS, median paired design CA 4.33 A vs a 10.27 A seed floor, design_ptm +0.006
# [-0.008, +0.024], iptm -0.003 [-0.024, +0.019], complex_plddt -0.001, filter 64/64; fast PASS, iptm +0.004,
# design_ptm +0.003, complex_plddt +0.001, filter 64/64.
WH_KVW_STACK = frozenset({"atom_kvw", "ws_ln_resid", "ws_ln_t1l1", "trimul_t1split", "trimul_sig6", "trimul_x8",
                          "pair_x8t"})
WH_LEVERS_NORMAL = LEVERS_NORMAL | HOST_LEVERS | {"atom_l1", "transition_ws", "triatt_ln", "dit_cond_steps", "trimul_t1",
                                    "trimul_t2", "dit_pad_short", "adaln_mod", "dit_qkvf", "dit_bpad", "dit_shard",
                                    "dit_fc123g", "apb_ln", "ws_l1dest", "ws_resid", "trimul_t2cm", "trimul_bres",
                                    "opm_jd", "dit_kl1", "adaln_at", "ws_psilu", "trimul_t1_psig"} | WH_KVW_STACK
# dit_kl1 (both Wormhole sets) keeps the token DiT attention at the full k chunk with the PV sums added in L1, so the
# Wormhole fp32-dest erratum guard holds without the 32-key chunk: ~-1.2 ms a diffusion step at 1000 MHz (kl1ab,
# 2026-11-03, b l l b). Graded as a stack with device z_init on Wormhole vs TT_BIO_LEVERS=none (seed-cluster bootstrap,
# 2026-11-06): normal 8 seeds x 8 designs, design_iptm +0.009 [-0.014, +0.031], design_ptm +0.026 [+0.007, +0.045],
# complex_plddt +0.007 [+0.002, +0.013]; fast 5 seeds, iptm +0.013 [-0.015, +0.040], ptm +0.023, plddt +0.008.
# Wormhole fast also runs the trunk on the T1/T2 trimul kernels, the weight-stationary transition, the fused triangle-
# attention LN and conditions several DiT steps ahead (dit_cond_steps). These move the CIFs, graded as one stack by the
# fast protocol (perf/spd/bg_grade.py, bg_R3, seeds 0-3 x 8 designs vs exact normal, 2026-10-26): every confidence
# metric within 0.03 of base (design_ptm -0.016, complex_plddt -0.007, iptm +0.031), filter 32/32 vs 32/32. Speed on a
# Galaxy chip at 1000 MHz: 50.2 -> 42.1 s/design.
# Fast also takes Blackhole's DiT linears (dit_qkvf, dit_chunk, dit_pad_short, dit_bpad, dit_shard, dit_fc123g) and its
# trunk four (apb_ln, ws_l1dest, ws_resid, trimul_t2cm): 37.2 -> 33.2 s/design on a Galaxy chip at 1000 MHz (whx2,
# 2026-10-31), 41.6 -> 35.0 ms a diffusion step. Fast grade vs exact WH normal (seeds 0-3, 32 designs): PASS,
# design_ptm +0.016 [+0.001, +0.032], iptm -0.027 [-0.062, +0.004], complex_plddt +0.010, filter 32/32.
# opm_jd (the outer-product mean's j-blocked matmul, as in Boltz-2) leaves the CIFs byte-identical: 33.7 -> 33.4
# s/design at 1000 MHz (wnl, 2026-11-01).
# dit_kc gives the token DiT attention the full k chunk on Wormhole (as Pxdesign and OpenFold3 do): 37.3 -> 34.2-34.7
# ms a diffusion step, 34.1 -> 32.6 s/design at 1000 MHz (whf2, 2026-11-01, measured with dit_hifi2, which alone reads
# nothing in fast). Fast grade vs exact WH normal (seeds 0-3, 32 designs): PASS, design_ptm +0.017 [+0.004, +0.029], iptm
# -0.015 [-0.051, +0.021], complex_plddt +0.017. Normal fails its grade with dit_kc (iptm -0.028 [-0.050, -0.007]).
# adaln_at runs the token DiT's AdaLN as one ln_split program reading the step's scale and shift windows, and the
# conditioning computed steps ahead now takes the set's dit_cond_hifi2: 33.1 -> 31.9 ms a diffusion step, ~-0.8 s/design
# at 1000 MHz (abwsf, 2026-11-01). Fast grade of the whole set vs TT_BIO_LEVERS=none (seed-cluster bootstrap, 7 seeds x 8
# designs vs 8 x 8, 2026-11-05): design_iptm +0.003 [-0.024, +0.029], design_ptm +0.026 [+0.007, +0.046], complex_plddt
# +0.004 [-0.002, +0.009]. Normal first failed with adaln_at against a base that was already a lever stack; graded
# against TT_BIO_LEVERS=none (seed-cluster bootstrap, 8 seeds x 8 designs, 2026-11-07) it passes: design_iptm -0.008
# [-0.030, +0.014], design_ptm +0.009 [-0.017, +0.035], complex_plddt +0.003 [-0.003, +0.010], so normal carries it too.
# Fast also takes four trunk levers from the shared kernels (trimul_sig6, triatt_ln_b8 with triatt_ln_b8g, trimul_t1w8):
# trunk loop 11.96 -> 11.48 s/design at 1000 MHz on both pairs of a b g a b g a A/B (trgab, 2026-11-07); five more
# shared trunk levers leave the CIFs byte-identical in BoltzGen and stay out. Fast grade vs TT_BIO_LEVERS=none (5 seeds
# x 8 designs, 2026-11-07): design_iptm +0.023 [-0.011, +0.063], design_ptm +0.026 [+0.008, +0.046], complex_plddt
# +0.001 [-0.005, +0.008].
# Both Wormhole sets run the transition's SwiGLU silu and T1's gate sigmoid on the packer thread (ws_psilu,
# trimul_t1_psig, as OpenDDE does), overlapping the matmuls. The CIFs stay byte-identical; trunk loop 12.25 -> 11.97
# s/design normal, 11.47 -> 11.34 fast, at 1000 MHz on both pairs of a b p b p A/B (psab, 2026-11-07).
WH_LEVERS_FAST = LEVERS_FAST | HOST_LEVERS | {"atom_l1", "trimul_bres", "trimul_t1", "trimul_t2", "transition_ws", "triatt_ln",
                                "dit_cond_steps", "dit_qkvf", "dit_chunk", "dit_pad_short", "dit_bpad", "dit_shard",
                                "dit_fc123g", "apb_ln", "ws_l1dest", "ws_resid", "trimul_t2cm", "opm_jd", "dit_kc",
                                "adaln_at", "dit_kl1", "trimul_sig6", "triatt_ln_b8",
                                "triatt_ln_b8g", "trimul_t1w8", "ws_psilu", "trimul_t1_psig"} | WH_KVW_STACK
# Blackhole fast runs the same trunk kernels Boltz-2 uses on Blackhole (T1/T2 trimul with the column-major T2, banded
# residual, two-buffer L1) plus atom_l1. Graded as one stack by the fast protocol (bg_grade.py, bg_R3, seeds 0-3 x 8
# designs vs exact BH normal, 2026-10-26): design_ptm -0.000, complex_plddt -0.005, iptm +0.004, filter 32/32 vs 32/32.
# Speed on a p300 chip (AICLK mean 1323 MHz): 23.93 -> 20.68 s/design. It replays the diffusion step from a trace, which
# computes each step's own conditioning, so dit_cond_steps is not in the set: on a host-bound p300 box (qb1, ~1349 MHz)
# the trace takes a fast design from 32.4 to 23.3 s.
# Blackhole normal runs the T1/T2 trimul kernels with the column-major T2: normal grade PASS pooled over seeds 0-7 vs
# plain BH normal (64 designs, 2026-10-26): design_ptm +0.019, iptm +0.025, complex_plddt -0.004 [-0.008, +0.001],
# filter 64/64.
# Both Blackhole sets also run the token DiT's attention as one fused q|k|v program (dit_qkvf), normal on the bias
# staged at 576 rather than 768 for BoltzGen's 544 tokens (dit_pad_short). Graded per mode vs exact BH normal, bg_R3,
# 2026-10-27: normal (seeds 0-7, with the 576 stage) design_ptm +0.001, iptm +0.011, complex_plddt -0.001, filter
# 64/64; fast (seeds 0-3)
# design_ptm +0.022, iptm +0.011, complex_plddt +0.002, filter 32/32. Speed on a p300 chip at ~1320 MHz: normal
# 22.9 -> 21.2 s/design from dit_qkvf and -0.6 s from the stage, fast 21.3 -> 19.8.
# Every Blackhole grade above was taken against "the default of that day", which was itself already a lever stack, so
# the per-lever readings never measured the set as a whole. Graded against TT_BIO_LEVERS=none on 2026-11-02 (main
# e11e990dc, bg_R3, 8 designs a seed) the whole shipped stack costs interface quality: normal (seeds 0,1,3,4,5)
# design_iptm -0.0414 [-0.0780, -0.0071], fast (seeds 0-3) mean drop 0.0397, both outside the charter's bar, while
# design_ptm and complex_plddt move the right way. Splitting it by group (unpaired seed-cluster bootstrap against all
# seven none seeds, since any numeric change re-rolls a design trajectory): the trunk group -0.034 [-0.052, -0.016],
# the diffusion group -0.024 [-0.052, +0.002], base + host alone -0.012 [-0.039, +0.017]. Re-running only the Boltz-2
# refold on the none runs' own inverse-folded sequences (exact pairs) shows no arm losing design_iptm there, and the
# trunk group is the one arm that moves the refolded backbone, bb_rmsd +2.71 A [+0.23, +5.65]. Two independent reads
# name the trunk group, so it is OUT of both Blackhole defaults; Blackhole was at 0.81-0.84x of an A100 SXM4 80 GB and
# can afford the trunk time. The levers themselves still work: TT_BIO_LEVERS=...+trimul_t1+trimul_t2+trimul_t2cm+
# trimul_bres+triatt_ln+apb_ln+transition_ws+ws_l1dest+ws_resid+opm_jd puts them back (fast also had trimul_l1x2 and
# triatt_ln_b8/triatt_ln_b8g, which only act on the kernels this drop removes).
BH_LEVERS_NORMAL = LEVERS_NORMAL | HOST_LEVERS | {"dit_qkvf", "dit_pad_short", "dit_bpad", "dit_shard", "dit_fc123g",
                                     "adaln_mod", "dit_shoist", "atom_l1"}
# Blackhole fast also chunks the token DiT's fused SDPA and stages its bias at 576 (dit_chunk + dit_pad_short, the
# pair normal already runs). On a p300 chip (AICLK mean 1321 MHz, 56 of 1152 samples below 1300): 18.28/18.46 -> 17.64/17.77
# s/design (-0.6, -3.4 %), 19.9 -> 18.8 ms/diffusion step. Fast grade vs exact BH normal (bg_grade.py, bg_R3, seeds 0-3 x 8 designs,
# 2026-10-29): PASS, design_ptm +0.014 [-0.006, +0.038], iptm +0.013, complex_plddt -0.002, filter 32/32 vs 32/32.
# Both Blackhole sets run the token DiT's activations at the staged bias width (dit_bpad), which lets the transition
# and attention linears shard over the token rows (dit_shard). On a p300 chip (AICLK mean 1334 MHz): fast 17.64 -> 17.32
# s/design, normal 19.1 -> 18.74. Graded vs exact BH normal (bg_grade.py, bg_R3, 2026-10-29): normal seeds 0-7 PASS,
# design_ptm +0.023 [+0.004, +0.045], iptm +0.005, complex_plddt +0.002, filter 64/64; fast seeds 0-3 PASS, design_ptm
# +0.025 [+0.009, +0.044], iptm +0.005, complex_plddt +0.003, filter 32/32.
# On top, dit_fc123g runs the sharded transition's three hidden products and both multiplies as one fc12g pass. On a
# p300 chip (AICLK mean 1317 MHz): fast 17.30 -> 16.92 s/design, normal 18.94 -> 18.44. Graded as the whole Blackhole
# stack vs exact BH normal (2026-10-29): normal seeds 0-7 PASS, design_ptm +0.021 [+0.004, +0.042], iptm -0.000,
# complex_plddt -0.003, filter 64/64; fast seeds 0-3 PASS, design_ptm +0.018 [+0.003, +0.038], iptm -0.002, filter 32/32.
# Both sets also run the trunk's triangle attention behind the fused LN (triatt_ln, apb_ln; fast writes q, k, v and the
# gate bfp8 as Boltz-2 does). On a p300 chip (AICLK mean 1315-1325 MHz): fast 16.95 -> 16.42 s/design, normal 18.33 ->
# 18.07, all of it in the trunk. Graded as the whole Blackhole stack vs exact BH normal (2026-10-30): normal seeds 0-7
# PASS, design_ptm +0.024 [+0.006, +0.046], iptm +0.017, complex_plddt -0.000, filter 64/64; fast seeds 0-3 PASS,
# design_ptm +0.012 [-0.007, +0.032], iptm +0.025, complex_plddt -0.006, filter 32/32.
# Both sets run the pair transition weight-stationary (transition_ws). At 514 tokens the pair update fits L1 and the
# pairformer asks for an L1 result, so ws_l1dest is what lets it serve; ws_resid folds the residual add in. On a p300
# chip (AICLK mean 1330-1337 MHz): normal 17.91 -> 17.09 s/design, trunk 7.87 -> 6.99; fast 16.47 -> 15.9, trunk
# 7.40 -> 6.59. Graded as the whole Blackhole stack vs exact BH normal (2026-10-30): normal seeds 0-7 PASS, design_ptm
# +0.019 [+0.001, +0.041], iptm -0.003, complex_plddt +0.001, filter 64/64; fast seeds 0-3 PASS, design_ptm +0.024
# [+0.004, +0.044], iptm +0.022, complex_plddt +0.026, filter 32/32.
# Fast also runs the token DiT's conditioning as three wide linears a step that each layer reads in place (dit_shoist,
# on fast's adaln_mod). On a p300 chip under the diffusion trace (~1315 MHz): 15.71 -> 14.91 s/design, 17.3 -> 15.9 ms
# a diffusion step. Fast grade vs exact BH normal (seeds 0-3, 2026-10-31): PASS, design_ptm +0.023 [+0.005, +0.046],
# iptm -0.002, complex_plddt -0.002, filter 32/32. Normal takes it with adaln_mod, which dit_shoist needs. On a p300
# chip under the trace: 17.35 -> 16.29 s/design (qb2, ~1332 MHz) and 18.91/19.59 -> 18.48/17.80 (qb1, 1350 MHz, loaded
# host); adaln_mod alone reads as noise. Normal grade vs exact BH normal (seeds 0-7, 2026-10-31): PASS, design_ptm
# +0.022 [+0.003, +0.044], iptm -0.005, complex_plddt +0.002, filter 64/64.
# opm_jd in both sets, and trimul_bres + atom_l1 in normal (fast had them), leave the CIFs byte-identical in both modes
# (bpl, qb2 p300 chip at ~1330 MHz, 2026-11-01): trunk 6.70 -> 6.26 s normal, 6.25 -> 6.00 fast.
# Fast also reads the windowed atom attention's key windows in place (atom_kvw, as both Wormhole sets do). On a p300 chip
# at 1350 MHz modal in both arms (kvwbh, 2026-11-19): 18.32 -> 17.45 s/design; normal reads -1.3 % and stays off. Fast
# grade of the set vs TT_BIO_LEVERS=none (bg_R3, 5 seeds x 8 designs, 2026-11-19): PASS, median paired design CA 4.36 A
# vs a 9.55 A seed floor, design_iptm -0.010 [-0.048, +0.026], design_ptm +0.032 [+0.012, +0.057], complex_plddt
# +0.001 [-0.005, +0.007], filter 40/40.
BH_LEVERS_FAST = LEVERS_FAST | HOST_LEVERS | {"atom_l1", "dit_qkvf", "dit_chunk", "dit_pad_short",
                                "dit_bpad", "dit_shard", "dit_fc123g", "dit_shoist", "atom_kvw"}


def design_levers() -> frozenset:
    """BoltzGen's lever set for this host's arch and the current mode (TT_BIO_LEVERS when a harness names one).
    The arch is read from sysfs, so the featurizer can ask before the model is built or a card is open."""
    return tenstorrent.model_levers(
        *((WH_LEVERS_NORMAL, WH_LEVERS_FAST) if tenstorrent.is_wormhole() else (BH_LEVERS_NORMAL, BH_LEVERS_FAST)))


def _under_levers(method):
    import functools

    @functools.wraps(method)
    def run(self, *a, **kw):
        return tenstorrent.under_lever_scope(method)(self, *a, **kw)
    return run


class Boltz(nn.Module):
    """Boltz model (vendored from BoltzGen, inference-only)."""

    def __init__(
        self,
        atom_s: int,
        atom_z: int,
        token_s: int,
        token_z: int,
        num_bins: int,
        embedder_args: Dict[str, Any],
        msa_args: Dict[str, Any],
        pairformer_args: Dict[str, Any],
        score_model_args: Dict[str, Any],
        diffusion_process_args: Dict[str, Any],
        affinity_model_args: Dict[str, Any] = {},
        affinity_mw_correction: bool = True,
        affinity_ensemble: bool = False,
        affinity_model_args1: Dict[str, Any] = {},
        affinity_model_args2: Dict[str, Any] = {},
        confidence_model_args: Optional[Dict[str, Any]] = None,
        masker_args: dict[str, Any] = {},
        atom_feature_dim: int = 128,
        template_args: Optional[Dict] = None,
        use_miniformer: bool = True,
        confidence_prediction: bool = False,
        affinity_prediction: bool = False,
        token_level_confidence: bool = True,
        alpha_pae: float = 0.0,
        atoms_per_window_queries: int = 32,
        atoms_per_window_keys: int = 128,
        exclude_ions_from_lddt: bool = False,
        ignore_ckpt_shape_mismatch: bool = False,
        min_dist: float = 2.0,
        max_dist: float = 22.0,
        predict_args: Optional[Dict[str, Any]] = None,
        checkpoints: Optional[Dict[str, Any]] = None,
        step_scale_schedule: Optional[List[Dict[str, float]]] = None,
        noise_scale_schedule: Optional[List[Dict[str, float]]] = None,
        aggregate_distogram: bool = True,
        bond_type_feature: bool = False,
        no_random_recycling_training: bool = False,
        conditioning_cutoff_min: float = 4.0,
        conditioning_cutoff_max: float = 20.0,
        use_templates: bool = False,
        use_token_distances: bool = False,
        token_distance_args: Optional[Dict] = None,
        predict_bfactor: bool = False,
        log_loss_every_steps: int = 50,
        checkpoint_diffusion_conditioning: bool = False,
        freeze_template_weights: bool = False,
        refolding_validator=None,
        predict_res_type: bool = False,
        inverse_fold: bool = False,
        inverse_fold_args: Optional[Dict[str, Any]] = None,
        inference_logging: bool = False,
        use_kernels: bool = False,
        use_resident_trunk: bool = True,
        diffusion_trace: Optional[bool] = False,
    ) -> None:
        super().__init__()
        self._levers = design_levers()
        """
        Module that does either:
        1. Design
        2. Folding with confidence prediction
        3. Inverse folding
        4. Affinity prediction
        """
        # None (the design step's default) replays the DiT trace on Blackhole, and the 1831-residue
        # ceiling holds with the region reserved. Not under dit_cond_steps: the captured step computes
        # its own conditioning, so it would drop that lever. Wormhole stays opt-in until its ceiling
        # is re-walked.
        if diffusion_trace is None:
            diffusion_trace = not tenstorrent.is_wormhole() and "dit_cond_steps" not in self._levers
        # Reserve the DiT trace region BEFORE any module opens the device: the first
        # get_device() opens, so this must precede module construction.
        if diffusion_trace:
            from tt_bio.tenstorrent import get_device
            get_device(trace="diffusion")
        self.inverse_fold = inverse_fold
        self.inference_logging = inference_logging
        self.use_kernels = use_kernels
        self.use_resident_trunk = use_resident_trunk
        self.ignore_ckpt_shape_mismatch = ignore_ckpt_shape_mismatch

        # Inference-relevant args
        self.predict_args = predict_args
        self.predict_res_type = predict_res_type

        # Checkpoints (multi-ckpt schedule used at inference time)
        self.checkpoints = checkpoints
        self.inference_counter = 0
        if checkpoints:
            self.first_checkpoint_num_samples = checkpoints.get(
                "first_checkpoint_num_samples", 1.0
            )
            self.checkpoint_list = checkpoints.get("checkpoint_list", [])
            self.total_samples = None
            self.switch_points = []
            self.checkpoint_paths = []
            self.current_checkpoint_index = -1

        # Noise and step scales (used at inference time per predict_step)
        self.step_scale_schedule = step_scale_schedule
        self.noise_scale_schedule = noise_scale_schedule
        self.step_scale_switch_points = []
        self.step_scale_values = []
        self.noise_scale_switch_points = []
        self.noise_scale_values = []

        if "affinity_args" not in affinity_model_args:
            affinity_model_args["affinity_args"] = {}
        if "groups" not in affinity_model_args["affinity_args"]:
            affinity_model_args["affinity_args"]["groups"] = {0: 1}
        if "val_groups" not in affinity_model_args["affinity_args"]:
            affinity_model_args["affinity_args"]["val_groups"] = set([0])

        self.exclude_ions_from_lddt = exclude_ions_from_lddt

        # Distogram
        self.num_bins = num_bins
        self.min_dist = min_dist
        self.max_dist = max_dist
        self.aggregate_distogram = aggregate_distogram

        # Trunk
        self.use_miniformer = use_miniformer

        # Masker
        self.masker = BoltzMasker(**masker_args)

        # Input embeddings
        full_embedder_args = {
            "atom_s": atom_s,
            "atom_z": atom_z,
            "token_s": token_s,
            "token_z": token_z,
            "atoms_per_window_queries": atoms_per_window_queries,
            "atoms_per_window_keys": atoms_per_window_keys,
            "atom_feature_dim": atom_feature_dim,
            **embedder_args,
        }
        if not self.inverse_fold:
            self.input_embedder = InputEmbedder(**full_embedder_args)

            self.s_init = nn.Linear(token_s, token_s, bias=False)
            self.z_init_1 = nn.Linear(token_s, token_z, bias=False)
            self.z_init_2 = nn.Linear(token_s, token_z, bias=False)

            self.rel_pos = RelativePositionEncoder(token_z)

            self.token_bonds = nn.Linear(
                1,
                token_z,
                bias=False,
            )
            self.bond_type_feature = bond_type_feature
            if bond_type_feature:
                self.token_bonds_type = nn.Embedding(len(const.bond_types) + 1, token_z)

            self.contact_conditioning = ContactConditioning(
                token_z=token_z,
                cutoff_min=conditioning_cutoff_min,
                cutoff_max=conditioning_cutoff_max,
            )

            # Normalization layers
            self.s_norm = nn.LayerNorm(token_s)
            self.z_norm = nn.LayerNorm(token_z)

            # Recycling projections
            self.s_recycle = nn.Linear(token_s, token_s, bias=False)
            self.z_recycle = nn.Linear(token_z, token_z, bias=False)
            init.gating_init_(self.s_recycle.weight)
            init.gating_init_(self.z_recycle.weight)

        # Pairwise stack
        self.use_token_distances = use_token_distances
        if self.use_token_distances:
            self.token_distance_module = TokenDistanceModule(
                token_z, **token_distance_args
            )

        self.use_templates = use_templates

        if use_templates:
            self.template_module = TemplateModule(token_z, **template_args)

        if not self.inverse_fold:
            # Direct ttnn construction — no PyTorch fallback path. MSA + Pairformer
            # are the heavy modules and run on the TT device; their state_dict
            # layout is byte-identical to BoltzGen's PyTorch versions, so the
            # production checkpoints load cleanly via the TorchWrapper.
            self.msa_module = TTMSAModule(
                n_blocks=msa_args["msa_blocks"],
                avg_head_dim=32, avg_n_heads=8,
                tri_att_head_dim=32, tri_att_n_heads=4,
            )
            num_heads = pairformer_args.get("num_heads", 16)
            att_head_dim = token_s // num_heads
            if use_miniformer:
                self.pairformer_module = TTMiniformerModule(
                    n_blocks=pairformer_args["num_blocks"],
                    att_head_dim=att_head_dim, att_n_heads=num_heads,
                )
            else:
                self.pairformer_module = TTPairformerModule(
                    n_blocks=pairformer_args["num_blocks"],
                    tri_att_head_dim=pairformer_args.get("pairwise_head_width", 32),
                    tri_att_n_heads=pairformer_args.get("pairwise_num_heads", 4),
                    att_head_dim=att_head_dim, att_n_heads=num_heads,
                    transform_s=True,
                )
            self.checkpoint_diffusion_conditioning = checkpoint_diffusion_conditioning

            self.diffusion_conditioning = DiffusionConditioning(
                token_s=token_s,
                token_z=token_z,
                atom_s=atom_s,
                atom_z=atom_z,
                atoms_per_window_queries=atoms_per_window_queries,
                atoms_per_window_keys=atoms_per_window_keys,
                atom_encoder_depth=score_model_args["atom_encoder_depth"],
                atom_encoder_heads=score_model_args["atom_encoder_heads"],
                token_transformer_depth=score_model_args["token_transformer_depth"],
                token_transformer_heads=score_model_args["token_transformer_heads"],
                atom_decoder_depth=score_model_args["atom_decoder_depth"],
                atom_decoder_heads=score_model_args["atom_decoder_heads"],
                atom_feature_dim=atom_feature_dim,
                conditioning_transition_layers=score_model_args[
                    "conditioning_transition_layers"
                ],
            )

            # Output modules
            self.structure_module = AtomDiffusion(
                score_model_args={
                    "token_s": token_s,
                    "atom_s": atom_s,
                    "atoms_per_window_queries": atoms_per_window_queries,
                    "atoms_per_window_keys": atoms_per_window_keys,
                    "predict_res_type": predict_res_type,
                    **score_model_args,
                },
                diffusion_trace=diffusion_trace,
                **diffusion_process_args,
            )
            self.distogram_module = DistogramModule(token_z, num_bins)
            self.predict_bfactor = predict_bfactor
            if predict_bfactor:
                self.bfactor_module = BFactorModule(token_s, num_bins)

        self.confidence_prediction = confidence_prediction
        self.token_level_confidence = token_level_confidence
        self.alpha_pae = alpha_pae

        ### Affinity ###
        self.affinity_prediction = affinity_prediction
        self.affinity_ensemble = affinity_ensemble
        self.affinity_mw_correction = affinity_mw_correction

        if self.affinity_prediction:
            if self.affinity_ensemble:
                self.affinity_module1 = AffinityModule(
                    token_s,
                    token_z,
                    **affinity_model_args1,
                )
                self.affinity_module2 = AffinityModule(
                    token_s,
                    token_z,
                    **affinity_model_args2,
                )
            else:
                self.affinity_module = AffinityModule(
                    token_s,
                    token_z,
                    **affinity_model_args,
                )

        if self.confidence_prediction:
            self.confidence_module = ConfidenceModule(
                token_s,
                token_z,
                token_level_confidence=token_level_confidence,
                bond_type_feature=bond_type_feature,
                conditioning_cutoff_min=conditioning_cutoff_min,
                conditioning_cutoff_max=conditioning_cutoff_max,
                **confidence_model_args,
            )

        if self.inverse_fold:
            self.enable_if_input_embedder = False
            if inverse_fold_args.get("enable_input_embedder", False):
                self.enable_if_input_embedder = True
                self.input_embedder = InputEmbedder(**full_embedder_args)
            self.predict_bfactor = False
            self.inverse_folding_encoder = InverseFoldingEncoder(**inverse_fold_args)
            self.structure_module = InverseFoldingDecoder(**inverse_fold_args)

    def setup_for_inference(self, dataloader) -> None:
        """Compute per-run inference schedules from the loaded dataloader.

        Replaces ``LightningModule.setup`` — the validator/training half of
        that hook is gone (we never call .setup() with stage != "predict"),
        and the predict half is rewritten to take the dataloader as a plain
        argument instead of reading ``self.trainer.datamodule``.
        """
        self.total_samples = len(dataloader.dataset)

        if self.checkpoints:
            fractions = [self.first_checkpoint_num_samples] + [
                ckpt["checkpoint"]["num_samples"] for ckpt in self.checkpoint_list
            ]
            cumulative_samples = np.cumsum(
                [int(math.ceil(f * self.total_samples)) for f in fractions]
            )
            self.switch_points = cumulative_samples.tolist()
            self.checkpoint_paths = [
                ckpt["checkpoint"]["path"] for ckpt in self.checkpoint_list
            ]
            for path in self.checkpoint_paths:
                if not Path(path).exists():
                    raise ValueError(f"Missing checkpoint path: {path}")
            self.next_switch_point = (
                self.switch_points[0] if self.switch_points else None
            )

        if self.step_scale_schedule:
            self.step_scale_values = [
                item["step_scale"] for item in self.step_scale_schedule
            ]
            fractions = [item["period"] for item in self.step_scale_schedule]
            cumulative_samples = np.cumsum(
                [int(f * self.total_samples) for f in fractions]
            )
            self.step_scale_switch_points = cumulative_samples.tolist()
            self.current_step_scale_index = 0
            self.next_step_scale_switch_point = self.step_scale_switch_points[0]
            self.current_step_scale = self.step_scale_values[0]

        if self.noise_scale_schedule:
            self.noise_scale_values = [
                item["noise_scale"] for item in self.noise_scale_schedule
            ]
            fractions = [item["period"] for item in self.noise_scale_schedule]
            cumulative_samples = np.cumsum(
                [int(f * self.total_samples) for f in fractions]
            )
            self.noise_scale_switch_points = cumulative_samples.tolist()
            self.current_noise_scale_index = 0
            self.next_noise_scale_switch_point = self.noise_scale_switch_points[0]
            self.current_noise_scale = self.noise_scale_values[0]

    @property
    def device(self) -> torch.device:
        """Tenstorrent-only — host scaffolding around ttnn runs on CPU."""
        return torch.device("cpu")

    def load_checkpoint_weights(self, checkpoint_path):
        """Hot-swap weights mid-pipeline (used by the multi-ckpt schedule)."""
        from tt_bio.boltzgen.adapter import read_checkpoint, _remap_legacy_state_dict_keys
        checkpoint = read_checkpoint(checkpoint_path)
        state = _remap_legacy_state_dict_keys(checkpoint["state_dict"])
        self.load_state_dict(state, strict=False)
        print(f"Loaded weights from {checkpoint_path}")

    def _tt_trunk_module(self):
        """Build the device-resident trunk driver (see ``Boltz2Model``'s driver
        of the same name in ``tt_bio/boltz2.py`` for the pattern this mirrors).
        Reuses the inner MSA/Pairformer device modules owned by the existing
        wrappers (created during state-dict load), a ``TrunkRecycle`` built
        from the recycle weights, and (BoltzGen-specific) a
        ``TokenDistanceRecycle`` for the token-distance injection. The
        template module is not ported to run resident -- its feature pipeline
        (frame rotation/translation, visibility, CB/CA distances) is computed
        inline rather than through a factored helper like Boltz2's, and it is
        called unconditionally every iteration (no ``has_templates`` gate) --
        so it runs via one host round-trip per iteration instead (still
        collapsing 4 host<->device crossings/iteration to 2).

        Unlike Boltz2Model (single checkpoint for the whole run), BoltzGen's
        design pipeline hot-swaps weights mid-run (``load_checkpoint_weights``,
        the multi-ckpt schedule) -- so this is rebuilt fresh every call rather
        than cached on ``self``: caching would (a) silently re-run stale
        weights after a swap, and (b) get auto-registered as an ``nn.Module``
        submodule (plain attribute assignment of an ``nn.Module``), which the
        next ``load_state_dict`` call then tries to load into and crashes
        (``TrunkModule`` has no state-dict, it borrows already-loaded weights).
        The construction cost (wrapping already-loaded torch weights as ttnn
        tensors) is small next to the 4-iteration trunk compute it drives.
        """
        recycle = tenstorrent.TrunkRecycle(
            self.s_norm, self.z_norm, self.s_recycle, self.z_recycle,
            self.msa_module.compute_kernel_config,
        )
        token_distance_recycle = None
        if self.use_token_distances:
            token_distance_recycle = tenstorrent.TokenDistanceRecycle(
                self.token_distance_module, self.msa_module.compute_kernel_config,
            )
        return tenstorrent.TrunkModule(
            recycle, self.msa_module.module, self.pairformer_module.module,
            token_distance_recycle=token_distance_recycle,
            template_module_torch=(self.template_module if self.use_templates else None),
            use_kernels=self.use_kernels,
        )

    def _tt_zinit_module(self):
        """The device z_init assembly. Built per call like the trunk driver above: BoltzGen
        swaps checkpoints mid-run, and the assembly holds device copies of the weights."""
        return tenstorrent.PairAssemblyDevice.for_trunk(self, self.msa_module.compute_kernel_config)

    @_under_levers
    def load_state_dict(self, *a, **kw):
        return super().load_state_dict(*a, **kw)

    @_under_levers
    def forward(
        self,
        feats: Dict[str, Tensor],
        recycling_steps: int = 0,
        num_sampling_steps: Optional[int] = None,
        multiplicity_diffusion_train: int = 1,
        diffusion_samples: int = 1,
        run_confidence_sequentially: bool = False,
        return_z_feats: bool = False,
        step_scale: Optional[float] = None,
        noise_scale: Optional[float] = None,
    ) -> Dict[str, Tensor]:
        dict_out = {}
        if self.inference_logging:
            print("\nRunning Trunk.\n")
        with torch.no_grad():
            if self.inverse_fold:
                if self.enable_if_input_embedder:
                    s_inputs = self.input_embedder(feats)
                    feats["s_inputs"] = s_inputs
                edge_idx, valid_mask, s, z = self.inverse_folding_encoder(feats)
                # Remove s_inputs from feats dictionary
                feats.pop("s_inputs", None)
            else:
                s_inputs = self.input_embedder(feats)

                # Initialize the sequence embeddings
                s_init = self.s_init(s_inputs)

                # Initialize pairwise embeddings. Boltz-2's `device_zinit`: the resident trunk
                # builds z_init where it consumes it, so the [1, n, n, token_z] host sum and its
                # 134 MB upload never happen. The host relative position encoding is then only
                # built for the one reader that still needs it, the token-distance features.
                device_zinit = self.use_resident_trunk and _device_zinit()
                z_init = z_init_build = relative_position_encoding = None
                if device_zinit:
                    z_init_build = self._tt_zinit_module()
                    if self.use_token_distances and (
                            self.token_distance_module.use_token_distance_feats):
                        relative_position_encoding = self.rel_pos(feats)
                else:
                    z_init = (
                        self.z_init_1(s_inputs)[:, :, None]
                        + self.z_init_2(s_inputs)[:, None, :]
                    )
                    relative_position_encoding = self.rel_pos(feats)
                    z_init = z_init + relative_position_encoding
                    z_init = z_init + self.token_bonds(feats["token_bonds"].float())
                    if self.bond_type_feature:
                        z_init = z_init + self.token_bonds_type(feats["type_bonds"].long())
                    z_init = z_init + self.contact_conditioning(feats)

                # Perform rounds of the pairwise stack
                s = torch.zeros_like(s_init)
                z = None if z_init is None else torch.zeros_like(z_init)

                # Compute pairwise mask
                mask = feats["token_pad_mask"].float()
                pair_mask = mask[:, :, None] * mask[:, None, :]

            device_z = None
            if not self.inverse_fold:
                # Run the whole recycling loop resident on the Tenstorrent device
                # (no per-iteration host round-trips for the recycle glue,
                # token-distance, MSA, or pairformer stages -- see
                # tenstorrent.TrunkModule and _tt_trunk_module above). The
                # template stage is the one exception (one host round-trip/
                # iteration); host loop kept as an explicit fallback.
                if self.use_resident_trunk:
                    _trunk = self._tt_trunk_module()
                    # Boltz-2's TT_BIO_DEVICE_CONDITIONING: the conditioning's pair track reads
                    # the trunk's pair tensor where it already is (see the conditioning below).
                    device_conditioning = (
                        not self.checkpoint_diffusion_conditioning and _device_conditioning())
                    s, z = _trunk(
                        s_inputs, s_init, z_init, feats, recycling_steps,
                        relative_position_encoding, keep_device_z=device_conditioning,
                        z_init_build=z_init_build,
                    )
                    if device_conditioning:
                        device_z = _trunk.pop_device_z()
                    # Its staged inputs are dead now; see the same call in boltz2.py.
                    _trunk.reset_static_cache()
                    _emit_progress("trunk", recycling_steps + 1, recycling_steps + 1)
                else:
                    for i in range(recycling_steps + 1):
                        _emit_progress("trunk", i + 1, recycling_steps + 1)
                        with torch.no_grad():
                            # Apply recycling
                            s = s_init + self.s_recycle(self.s_norm(s))
                            z = z_init + self.z_recycle(self.z_norm(z))

                            # Compute pairwise stack
                            if self.use_token_distances:
                                z = z + self.token_distance_module(
                                    z, feats, pair_mask, relative_position_encoding
                                )

                            # Compute pairwise stack
                            if self.use_templates:
                                z = z + self.template_module(
                                    z, feats, pair_mask, use_kernels=self.use_kernels
                                )

                            if not self.inverse_fold:
                                z = z + self.msa_module(
                                    z, s_inputs, feats, use_kernels=self.use_kernels
                                )

                            s, z = self.pairformer_module(
                                s,
                                z,
                                mask=mask,
                                pair_mask=pair_mask,
                                use_kernels=self.use_kernels,
                            )

            if not self.inverse_fold:
                pdistogram = self.distogram_module(z)
                dict_out["pdistogram"] = pdistogram.float()

            if not self.inverse_fold:
                if relative_position_encoding is None and device_z is None:
                    # `device_zinit` skipped it; the host conditioning is the only other reader.
                    relative_position_encoding = self.rel_pos(feats)
                if self.checkpoint_diffusion_conditioning:
                    # TODO decide whether this should be with bf16 or not
                    (
                        q,
                        c,
                        to_keys,
                        atom_enc_bias,
                        atom_dec_bias,
                        token_trans_bias,
                    ) = torch.utils.checkpoint.checkpoint(
                        self.diffusion_conditioning,
                        s,
                        z,
                        relative_position_encoding,
                        feats,
                    )
                elif device_z is not None:
                    # Built per call, like the trunk driver: BoltzGen swaps checkpoints mid-run.
                    dc = self.diffusion_conditioning
                    weight, bias, _shape, eps = _fuse_bias_stack(dc.token_trans_proj_z)
                    cond = tenstorrent.PairConditioningDevice(
                        dc.pairwise_conditioner, weight, bias, eps, dc.atom_encoder.z_to_p_trans,
                        self.msa_module.compute_kernel_config,
                    )
                    z_to_p, token_trans_bias = cond(
                        device_z[0], relative_position_encoding
                        if relative_position_encoding is not None else (self.rel_pos, feats),
                        z.shape[1], device_z[1])
                    tenstorrent.free(device_z[0])
                    device_z = None
                    q, c, to_keys, atom_enc_bias, atom_dec_bias = dc.forward_atoms(
                        s_trunk=s, z_to_p=z_to_p, feats=feats)
                else:
                    (
                        q,
                        c,
                        to_keys,
                        atom_enc_bias,
                        atom_dec_bias,
                        token_trans_bias,
                    ) = self.diffusion_conditioning(
                        s_trunk=s,
                        z_trunk=z,
                        relative_position_encoding=relative_position_encoding,
                        feats=feats,
                    )
                diffusion_conditioning = {
                    "q": q,
                    "c": c,
                    "to_keys": to_keys,
                    "atom_enc_bias": atom_enc_bias,
                    "atom_dec_bias": atom_dec_bias,
                    "token_trans_bias": token_trans_bias,
                }

                if self.predict_bfactor:
                    pbfactor = self.bfactor_module(s)
                    dict_out["pbfactor"] = pbfactor

            # Inference always samples (training-only structure-module forward,
            # lddt symmetry and confidence/affinity coord asserts removed).
            if self.inference_logging:
                print("\nRunning Structure Module.\n")
            with torch.autocast("cuda", enabled=False):
                if not self.inverse_fold:
                    struct_out = self.structure_module.sample(
                        s_trunk=s.float(),
                        s_inputs=s_inputs.float(),
                        feats=feats,
                        num_sampling_steps=num_sampling_steps,
                        atom_mask=feats["atom_pad_mask"].float(),
                        multiplicity=diffusion_samples,
                        diffusion_conditioning=diffusion_conditioning,
                        step_scale=step_scale,
                        noise_scale=noise_scale,
                        inference_logging=self.inference_logging,
                    )
                else:
                    struct_out = self.structure_module.sample(
                        s=s,
                        z=z,
                        edge_idx=edge_idx,
                        valid_mask=valid_mask,
                        feats=feats,
                    )
                dict_out.update(struct_out)
            # The sampler's staged conditioning is dead too, and the confidence head is next.
            for m in self.structure_module.modules():
                if hasattr(m, "reset_static_cache"):
                    m.reset_static_cache()

        if self.confidence_prediction:
            dict_out.update(
                self.confidence_module(
                    s_inputs=s_inputs.detach(),
                    s=s.detach(),
                    z=z.detach(),
                    x_pred=(dict_out["sample_atom_coords"].detach()),
                    feats=feats,
                    pred_distogram_logits=(dict_out["pdistogram"][:, :, :, 0].detach()),
                    multiplicity=diffusion_samples,
                    run_sequentially=run_confidence_sequentially,
                    use_kernels=self.use_kernels,
                )
            )

        if self.affinity_prediction:
            pad_token_mask = feats["token_pad_mask"][0]
            rec_mask = feats["mol_type"][0] == 0
            rec_mask = rec_mask * pad_token_mask
            lig_mask = feats["affinity_token_mask"][0].to(torch.bool)
            lig_mask = lig_mask * pad_token_mask
            cross_pair_mask = (
                lig_mask[:, None] * rec_mask[None, :]
                + rec_mask[:, None] * lig_mask[None, :]
                + lig_mask[:, None] * lig_mask[None, :]
            )
            z_affinity = z * cross_pair_mask[None, :, :, None]

            argsort = torch.argsort(dict_out["iptm"], descending=True)
            best_idx = argsort[0].item()
            coords_affinity = dict_out["sample_atom_coords"].detach()[best_idx][
                None, None
            ]
            s_inputs = self.input_embedder(feats, affinity=True)

            with torch.autocast("cuda", enabled=False):
                if self.affinity_ensemble:
                    dict_out_affinity1 = self.affinity_module1(
                        s_inputs=s_inputs.detach(),
                        z=z_affinity.detach(),
                        x_pred=coords_affinity,
                        feats=feats,
                        multiplicity=1,
                        use_kernels=self.use_kernels,
                    )

                    dict_out_affinity1["affinity_probability_binary"] = (
                        torch.nn.functional.sigmoid(
                            dict_out_affinity1["affinity_logits_binary"]
                        )
                    )
                    dict_out_affinity2 = self.affinity_module2(
                        s_inputs=s_inputs.detach(),
                        z=z_affinity.detach(),
                        x_pred=coords_affinity,
                        feats=feats,
                        multiplicity=1,
                        use_kernels=self.use_kernels,
                    )
                    dict_out_affinity2["affinity_probability_binary"] = (
                        torch.nn.functional.sigmoid(
                            dict_out_affinity2["affinity_logits_binary"]
                        )
                    )

                    dict_out_affinity_ensemble = {
                        "affinity_pred_value": (
                            dict_out_affinity1["affinity_pred_value"]
                            + dict_out_affinity2["affinity_pred_value"]
                        )
                        / 2,
                        "affinity_probability_binary": (
                            dict_out_affinity1["affinity_probability_binary"]
                            + dict_out_affinity2["affinity_probability_binary"]
                        )
                        / 2,
                    }

                    dict_out_affinity1 = {
                        "affinity_pred_value1": dict_out_affinity1[
                            "affinity_pred_value"
                        ],
                        "affinity_probability_binary1": dict_out_affinity1[
                            "affinity_probability_binary"
                        ],
                    }
                    dict_out_affinity2 = {
                        "affinity_pred_value2": dict_out_affinity2[
                            "affinity_pred_value"
                        ],
                        "affinity_probability_binary2": dict_out_affinity2[
                            "affinity_probability_binary"
                        ],
                    }

                    if self.affinity_mw_correction:
                        model_coef = 1.03525938
                        mw_coef = -0.59992683
                        bias = 2.83288489
                        mw = feats["affinity_mw"][0] ** 0.3
                        dict_out_affinity_ensemble["affinity_pred_value"] = (
                            model_coef
                            * dict_out_affinity_ensemble["affinity_pred_value"]
                            + mw_coef * mw
                            + bias
                        )

                    dict_out.update(dict_out_affinity_ensemble)
                    dict_out.update(dict_out_affinity1)
                    dict_out.update(dict_out_affinity2)
                else:
                    dict_out_affinity = self.affinity_module(
                        s_inputs=s_inputs.detach(),
                        z=z_affinity.detach(),
                        x_pred=coords_affinity,
                        feats=feats,
                        multiplicity=1,
                        use_kernels=self.use_kernels,
                    )
                    dict_out.update(
                        {
                            "affinity_pred_value": dict_out_affinity[
                                "affinity_pred_value"
                            ],
                            "affinity_probability_binary": torch.nn.functional.sigmoid(
                                dict_out_affinity["affinity_logits_binary"]
                            ),
                        }
                    )
        if return_z_feats:
            dict_out["z_feats"] = z

        # For stability checking as in, https://github.com/IntelliGen-AI/IntFold
        dict_out["s_trunk"] = s
        return dict_out

    def predict_step(
        self, batch: Any, batch_idx: int = 0, dataloader_idx: int = 0
    ) -> Dict:
        # Skip invalid samples
        if "exception" in batch and any(batch["exception"]):
            print(f"WARNING: Skipping batch. Exception for {batch['id'][0]}")
            return {"exception": True}
        if "skip" in batch and any(batch["skip"]):
            print(f"WARNING: Skipping batch. Skip was set true for {batch['id'][0]}")
            return {"skip": True}

        # Tenstorrent: the ttnn modules cache per-design static data (masks,
        # biases, q/c projections, atom padding) so it is computed once and
        # reused across the diffusion sampling steps. That cache is only valid
        # for a single design — reset it for each new design. Otherwise a design
        # with a different atom/token count reuses the previous design's cached
        # atom padding, mismatching tensor shapes and crashing ttnn.add with
        # "Invalid subtile broadcast type". Mirrors the main path (boltz2.py).
        for m in self.modules():
            if hasattr(m, "reset_static_cache"):
                m.reset_static_cache()

        # Checkpoint switching logic
        if self.checkpoints and self.next_switch_point is not None:
            if self.inference_counter == self.next_switch_point:
                self.current_checkpoint_index += 1
                if 0 <= self.current_checkpoint_index < len(self.checkpoint_paths):
                    checkpoint_path = self.checkpoint_paths[
                        self.current_checkpoint_index
                    ]
                    self.load_checkpoint_weights(checkpoint_path)
                    print(f"Switched checkpoint.")
                if self.current_checkpoint_index + 1 < len(self.switch_points):
                    self.next_switch_point = self.switch_points[
                        self.current_checkpoint_index + 1
                    ]
                else:
                    self.next_switch_point = None

        # Temperature switching logic
        if self.step_scale_schedule and self.next_step_scale_switch_point is not None:
            if self.inference_counter == self.next_step_scale_switch_point:
                self.current_step_scale_index += 1
                if self.current_step_scale_index < len(self.step_scale_values):
                    self.current_step_scale = self.step_scale_values[
                        self.current_step_scale_index
                    ]
                    if self.current_step_scale_index + 1 < len(
                        self.step_scale_switch_points
                    ):
                        self.next_step_scale_switch_point = (
                            self.step_scale_switch_points[
                                self.current_step_scale_index + 1
                            ]
                        )
                    else:
                        self.next_step_scale_switch_point = None
                print(f"Switched step_scale to {self.current_step_scale}")

        if self.noise_scale_schedule and self.next_noise_scale_switch_point is not None:
            if self.inference_counter == self.next_noise_scale_switch_point:
                self.current_noise_scale_index += 1
                if self.current_noise_scale_index < len(self.noise_scale_values):
                    self.current_noise_scale = self.noise_scale_values[
                        self.current_noise_scale_index
                    ]
                    if self.current_noise_scale_index + 1 < len(
                        self.noise_scale_switch_points
                    ):
                        self.next_noise_scale_switch_point = (
                            self.noise_scale_switch_points[
                                self.current_noise_scale_index + 1
                            ]
                        )
                    else:
                        self.next_noise_scale_switch_point = None
                print(f"Switched noise_scale to {self.current_noise_scale}")

        step_scale = getattr(self, "current_step_scale", None)
        noise_scale = getattr(self, "current_noise_scale", None)

        try:
            feat_masked = self.masker(batch)
            out = self(
                feat_masked,
                recycling_steps=self.predict_args["recycling_steps"],
                num_sampling_steps=self.predict_args["sampling_steps"],
                diffusion_samples=self.predict_args["diffusion_samples"],
                run_confidence_sequentially=True,
                step_scale=step_scale,
                noise_scale=noise_scale,
                return_z_feats=(
                    self.predict_args["return_z_feats"]
                    if "return_z_feats" in self.predict_args
                    else False
                ),
            )
            pred_dict = {"exception": False}
            pred_dict.update(feat_masked)

            if "keys_dict_batch" in self.predict_args:
                for key in self.predict_args["keys_dict_batch"]:
                    pred_dict[key] = batch[key]
            if (
                "return_z_feats" in self.predict_args
                and self.predict_args["return_z_feats"]
            ):
                pred_dict["z_feats"] = out["z_feats"]
            pred_dict["masks"] = batch["atom_pad_mask"]
            pred_dict["token_masks"] = batch["token_pad_mask"]
            if "keys_dict_out" in self.predict_args:
                for key in self.predict_args["keys_dict_out"]:
                    pred_dict[key] = out[key]

            # also save these keys for computing refolding metrics like scRMSD
            pred_dict["input_coords"] = batch["coords"]
            pred_dict["token_index"] = batch["token_index"]
            pred_dict["atom_resolved_mask"] = batch["atom_resolved_mask"]
            pred_dict["atom_to_token"] = batch["atom_to_token"]
            pred_dict["mol_type"] = batch["mol_type"]
            pred_dict["backbone_mask"] = batch["backbone_mask"]

            pred_dict["coords"] = out["sample_atom_coords"]
            if not self.inverse_fold:
                pred_dict["coords_traj"] = out["coords_traj"]
                pred_dict["x0_coords_traj"] = out["x0_coords_traj"]
            if self.confidence_prediction:
                # pred_dict["confidence"] = out.get("ablation_confidence", None)
                pred_dict["pde"] = out["pde"]
                pred_dict["plddt"] = out["plddt"]
                pred_dict["confidence_score"] = (
                    4 * out["complex_plddt"]
                    + (
                        out["iptm"]
                        if not torch.allclose(
                            out["iptm"], torch.zeros_like(out["iptm"])
                        )
                        else out["ptm"]
                    )
                ) / 5

                pred_dict["complex_plddt"] = out["complex_plddt"]
                pred_dict["complex_iplddt"] = out["complex_iplddt"]
                pred_dict["complex_pde"] = out["complex_pde"]
                pred_dict["complex_ipde"] = out["complex_ipde"]
                if self.alpha_pae > 0:
                    pred_dict["pae"] = out["pae"]
                    pred_dict["ptm"] = out["ptm"]
                    pred_dict["iptm"] = out["iptm"]
                    pred_dict["ligand_iptm"] = out["ligand_iptm"]
                    pred_dict["protein_iptm"] = out["protein_iptm"]
                    pred_dict["pair_chains_iptm"] = out["pair_chains_iptm"]
                    pred_dict["design_ipsae_min"] = out["design_ipsae_min"]
                    pred_dict["design_to_target_ipsae"] = out["design_to_target_ipsae"]
                    pred_dict["target_to_design_ipsae"] = out["target_to_design_ipsae"]

                if self.affinity_prediction:
                    pred_dict["affinity_pred_value"] = out["affinity_pred_value"]
                    pred_dict["affinity_probability_binary"] = out[
                        "affinity_probability_binary"
                    ]
                    if self.affinity_ensemble:
                        pred_dict["affinity_pred_value1"] = out["affinity_pred_value1"]
                        pred_dict["affinity_probability_binary1"] = out[
                            "affinity_probability_binary1"
                        ]
                        pred_dict["affinity_pred_value2"] = out["affinity_pred_value2"]
                        pred_dict["affinity_probability_binary2"] = out[
                            "affinity_probability_binary2"
                        ]
            self.inference_counter += 1
            return pred_dict

        except RuntimeError as e:  # catch out of memory exceptions
            if "out of memory" in str(e):
                print("| WARNING: ran out of memory, skipping batch")
                torch.cuda.empty_cache()
                return {"exception": True}
            else:
                raise e

