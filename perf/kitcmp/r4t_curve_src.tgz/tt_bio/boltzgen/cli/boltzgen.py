#!/usr/bin/env python3
"""BoltzGen pipeline CLI (Tenstorrent-only build).

Two halves:

1. ``configure`` resolves the per-step YAML configs and writes an
   ``OUTPUT/config/<step>.yaml`` for each enabled pipeline step, plus a
   manifest ``OUTPUT/steps.yaml`` listing them in execution order.

2. ``execute`` reads the manifest and runs each step in-process by
   instantiating the YAML config and calling ``Task.run(...)``. Steps share
   the Tenstorrent device handle and program cache across the whole
   pipeline — spawning subprocesses would discard both and re-pay model
   load per step.

``run`` configures and executes in one shot.

Pipeline tasks live alongside this file:
    * Predict — tt_bio/boltzgen/task/predict/predict.py
    * Analyze — tt_bio/boltzgen/task/analyze/analyze.py
    * Filter  — tt_bio/boltzgen/task/filter/filter.py
"""

# Select the Tenstorrent device(s) BEFORE importing anything under
# ``tt_bio.boltzgen`` — its package __init__ pulls in the ttnn adapters,
# and ttnn reads TT_VISIBLE_DEVICES at import time. Mirrors how tt-bio's
# worker processes set TT_VISIBLE_DEVICES before importing ttnn so the
# chosen physical chip becomes logical device 0 (the one get_device() opens).
import os as _os
import sys as _sys


def _apply_device_selection_from_argv(argv: list[str]) -> None:
    """Honour ``--device_ids`` (e.g. ``--device_ids 2``) before ttnn loads.

    boltzgen runs a single logical TT device per process, so the value is
    used as TT_VISIBLE_DEVICES: the selected chip(s) become the only ones
    ttnn enumerates, and get_device() opens logical device 0 among them.
    An explicit TT_VISIBLE_DEVICES already in the environment wins.
    """
    value = None
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--device_ids":
            value = argv[i + 1] if i + 1 < len(argv) else None
            i += 2
            continue
        if arg.startswith("--device_ids="):
            value = arg.split("=", 1)[1]
        i += 1
    if value is None or value == "":
        return
    if _os.environ.get("TT_VISIBLE_DEVICES"):
        return
    _os.environ["TT_VISIBLE_DEVICES"] = value


_apply_device_selection_from_argv(_sys.argv[1:])

from tt_bio.boltzgen.utils.quiet import quiet_startup

quiet_startup()

import collections
import argparse
import contextlib
import copy
from dataclasses import dataclass
import os
import subprocess
import time
import math
import re
import shutil
import sys
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Any, Dict, List, Tuple
import yaml

from tt_bio.boltzgen._config import (
    check_overrides as _check_overrides,
    deep_merge as _deep_merge,
    dotlist_to_dict as _dotlist_to_dict,
    instantiate as _instantiate,
    load_yaml as _load_yaml,
    resolve_interpolations as _resolve_interpolations,
    save_yaml as _save_yaml,
)

from tt_bio.data import const
from tt_bio.data.mol import load_canonicals
from tt_bio.boltzgen.data.parse.schema import YamlDesignParser
from tt_bio.boltzgen.data.write_mmcif import to_mmcif
from tt_bio.boltzgen.task.task import Task
from tt_bio.runtime import seed_everything
from importlib.metadata import PackageNotFoundError, version as pkg_version

### Paths and constants ####
# Get the path to the project root (where main.py and configs/ are located)
# Since we're now in src/boltzgen/, we need to go up 3 levels
path_to_script = Path(__file__)
project_root = (
    path_to_script.parent.parent
)  # Go up from src/boltzgen/cli to project root
config_dir = project_root / "resources/config"

step_names = [
    "design",
    "inverse_folding",
    "design_folding",
    "folding",
    "affinity",
    "analysis",
    "filtering",
]

### Protocol-specific configuration overrides (which can be overridden by user) ####
protocol_configs = {
    "protein-anything": {},  # base config corresponds to protein-anything
    "peptide-anything": {
        # Note that in inverse folding step we also avoid cysteines by default; this is implemented elsewhere.
        "analysis": ["largest_hydrophobic=false", "largest_hydrophobic_refolded=false"],
        "filtering": [
            "filter_cysteine=true",
            "alpha=0.01",
            "refolding_rmsd_threshold=2",
        ],
    },
    "protein-small_molecule": {
        "analysis": ["affinity_metrics=true"],
        "filtering": ["use_affinity=true"],
    },
    "nanobody-anything": {
        "analysis": ["largest_hydrophobic=false", "largest_hydrophobic_refolded=false"],
        "filtering": ["filter_cysteine=true"],
    },
    "antibody-anything": {
        "analysis": ["largest_hydrophobic=false", "largest_hydrophobic_refolded=false"],
        "filtering": ["filter_cysteine=true"],
    },
    "protein-redesign": {
        # For redesigning/optimizing existing proteins (e.g., symmetric dimers)
        # where all chains may have designed residues. Skips design_folding and
        # uses design_mask (not chain_design_mask) for target/template definition.
        "folding": ["data.design_mask_templates=true"],
        "analysis": ["use_design_mask_for_target=true"],
        "filtering": [
            "metrics_override={design_to_target_iptm: null, neg_min_design_to_target_pae: null, design_ptm: null, plip_hbonds_refolded: null, plip_saltbridge_refolded: null, delta_sasa_refolded: null, plip_hbonds: null, plip_saltbridge: null, delta_sasa_original: null, design_residue_iptm: 1, iptm: 2, ptm: 3, neg_filter_rmsd_design: 4}",
        ],
    },
}
assert all(
    step_name in step_names for cfg in protocol_configs.values() for step_name in cfg
)


### Model checkpoints and other artifacts ####
# BoltzGen weights + molecules are hosted on the Hugging Face Hub and fetched
# with huggingface_hub, unified with the rest of tt-bio. Spec form
# `huggingface:<repo_id>:<filename>`, resolved by get_artifact_path.
BOLTZGEN_REPO = "moritztng/boltzgen"
ARTIFACTS: dict[str, tuple[str, str]] = {
    "design-diverse":   (f"huggingface:{BOLTZGEN_REPO}:boltzgen1_diverse.ckpt",   "model"),
    "design-adherence": (f"huggingface:{BOLTZGEN_REPO}:boltzgen1_adherence.ckpt", "model"),
    "inverse-fold":     (f"huggingface:{BOLTZGEN_REPO}:boltzgen1_ifold.ckpt",     "model"),
    "folding":          (f"huggingface:{BOLTZGEN_REPO}:boltz2_conf_final.ckpt",   "model"),
    "affinity":         (f"huggingface:{BOLTZGEN_REPO}:boltz2_aff.ckpt",          "model"),
    "moldir":           (f"huggingface:{BOLTZGEN_REPO}:mols.zip",                 "dataset"),
}


### CLI arguments ###
def add_configure_arguments(
    parser: argparse.ArgumentParser, *, output_required: bool = False
) -> None:
    # General configuration options
    p = parser.add_argument_group("general configuration")
    p.add_argument(
        "--protocol",
        type=str,
        choices=list(protocol_configs.keys()),
        default="protein-anything",
        help="Protocol to use for the design. This determines default settings and in some cases what steps "
        "are run. Default: %(default)s",
    )
    p.add_argument(
        "--output",
        type=Path,
        required=output_required,
        help="Output directory for pipeline results",
    )
    p.add_argument(
        "--config",
        nargs="+",
        action="append",
        help="Override pipeline step configuration, in format <step_name> <arg1>=<value1> <arg2>=<value2> ..."
        "(example: '--config design sampling_steps=200 --config folding recycling_steps=1'). "
        "Can be used multiple times; an unknown key is refused by name.",
    )
    p.add_argument(
        "--devices",
        type=int,
        help="Number of devices to use. Default is all devices available.",
    )
    p.add_argument(
        "--num_workers",
        type=int,
        help="Number of DataLoader worker processes.",
        default=1,
    )
    p.add_argument(
        "--config_dir",
        type=Path,
        help=f"Path to the directory of default config files. Default: %(default)s",
        default=config_dir,
    )
    p.add_argument(
        "--moldir",
        type=str,
        help="Path to the moldir. Default: %(default)s",
        default=ARTIFACTS["moldir"][0],
    )
    p.add_argument(
        "--reuse",
        action="store_true",
        help="Reuse existing results across all steps. Generate only as many new designs are "
        "needed to achieve the specified total number of designs.",
    )

    # Design configuration options
    p = parser.add_argument_group("design")
    p.add_argument(
        "--num_designs",
        type=int,
        help="Number of total designs to generate. This commonly would be something like 10,000"
        "After generating 10,000 designs we then filter down to --budget many designs in the filter step",
        default=10000,
    )
    p.add_argument(
        "--diffusion_batch_size",
        type=int,
        default=None,
        help="Number of diffusion samples to generate per trunk run. If not specified, "
        "this defaults to 1 if --num-designs is less than 100, and 10 otherwise. Note that "
        "for design tasks that randomly sample the binder length (or use randomness in other "
        "ways), all designs generated in the same batch will share the same length. "
        "Having a large diffusion batch size compared to the total number of designs to "
        "generate will therefore not evenly sample the possible lengths.",
    )
    p.add_argument(
        "--design_checkpoints",
        type=str,
        nargs="+",
        help="Path to the boltzgen checkpoint(s). One or more checkpoints are supported. Just specifying an individual path here will work."
        "Each will be used for an equal fraction of the designs. By default, two checkpoints are used. "
        "Default: %(default)s",
        default=[
            ARTIFACTS["design-diverse"][0],
            ARTIFACTS["design-adherence"][0],
        ],
    )
    p.add_argument(
        "--step_scale",
        type=str,
        help="Fixed step scale to use (e.g. 1.8). Default is to use a schedule",
        default=None,
    )
    p.add_argument(
        "--noise_scale",
        type=str,
        help="Fixed noise scale to use (e.g. 0.98). Default is to use a schedule",
        default=None,
    )
    p.add_argument(
        "--diffusion_trace",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Replay a captured ttnn trace of the per-step diffusion DiT device "
        "stream in the design step (lossless; collapses per-step host dispatch; "
        "reserves 0.2-0.3 GB of device memory). Default: on for Blackhole "
        "normal mode, else off.",
    )

    # Inverse folding configuration options
    p = parser.add_argument_group("inverse folding")
    p.add_argument(
        "--skip_inverse_folding",
        action="store_true",
        help="Skip inverse folding step",
    )
    p.add_argument(
        "--inverse_fold_num_sequences",
        type=int,
        help="Number of sequences per backbone to generate in the inverse fold step. Default: %(default)s",
        default=1,
    )
    p.add_argument(
        "--inverse_fold_checkpoint",
        type=str,
        help="Path to the inverse fold checkpoint. Default: %(default)s",
        default=ARTIFACTS["inverse-fold"][0],
    )
    p.add_argument(
        "--inverse_fold_avoid",
        type=str,
        default=None,
        help="Disallowed residues as a string of one letter amino acid codes, e.g. 'KEC'. "
        "This is implemented at the inverse fold step, so it only affects results if inverse folding is "
        "enabled. Default: none for protein design, 'C' for peptide and antibody/nanobody design. Pass an empty list if you want Cysteins to be generated if you are using antibody/nanobody/peptide protocol",
    )
    p.add_argument(
        "--only_inverse_fold",
        action="store_true",
        help="Skip design step and only run inverse folding. Requires a fully specified structure.",
    )

    # Folding and affinity prediction configuration options
    p = parser.add_argument_group("folding and affinity prediction")
    p.add_argument(
        "--folding_checkpoint",
        type=str,
        help="Path to the folding checkpoint. Default: %(default)s",
        default=ARTIFACTS["folding"][0],
    )
    p.add_argument(
        "--affinity_checkpoint",
        type=str,
        help="Path to the affinity predictor checkpoint. Default: %(default)s",
        default=ARTIFACTS["affinity"][0],
    )

    # Filtering configuration options
    p = parser.add_argument_group("filtering")
    p.add_argument(
        "--budget",
        type=int,
        help="How many designs should be in the final diversity optimized set. This is used in the filtering step.",
        default=30,
    )
    p.add_argument(
        "--alpha",
        type=float,
        help="Trade-off for sequence diversity selection: 0.0=quality-only, 1.0=diversity-only. Default is "
        "0.01 (peptide-anything protocol) or 0.001 (other protocols).",
        default=None,
    )
    p.add_argument(
        "--filter_biased",
        choices=["true", "false"],
        help="Remove amino-acid composition outliers (default caps on ALA/GLY/GLU/LEU/VAL). Default: %(default)s.",
        default="true",
    )
    p.add_argument(
        "--metrics_override",
        nargs="+",
        help="Per-metric inverse-importance weights for ranking. "
        "Format: metric_name=weight (e.g., plip_hbonds_refolded=4 delta_sasa_refolded=2). "
        "A larger value down-weights that metric's rank. Use 'metric_name=none' to remove a metric.",
        default=None,
    )
    p.add_argument(
        "--additional_filters",
        nargs="+",
        help="Extra hard filters. Format: feature>threshold or feature<threshold "
        "(e.g., 'design_ALA>0.3' 'design_GLY<0.2'). Use '>' if higher is better, '<' if lower is better. "
        "Make sure to single-quote the strings so your shell doesn't get confused by < and > characters.",
        default=None,
    )
    p.add_argument(
        "--size_buckets",
        nargs="+",
        help="Optional constraint for maximum number of designs in size ranges. "
        "Format: min-max:count (e.g., 10-20:5 20-30:10 30-40:5).",
        default=None,
    )
    p.add_argument(
        "--refolding_rmsd_threshold",
        type=float,
        help="Threshold used for RMSD-based filters (lower is better).",
        default=None,
    )


def add_models_download_options(p: argparse.ArgumentParser) -> None:
    p = p.add_argument_group("model and data download options")
    p.add_argument(
        "--force_download",
        help="Force a (re)-download of models and data.",
        action="store_true",
        default=False,
    )
    p.add_argument(
        "--cache",
        type=Path,
        help="Directory where downloaded models will be stored. Default: ~/.cache",
        default=None,
    )


def add_device_arguments(p: argparse.ArgumentParser) -> None:
    p.add_argument(
        "--device_ids",
        type=str,
        default=None,
        metavar="IDS",
        help="Tenstorrent device ID(s) to run on. Default: all available cards. "
        "A single ID (e.g. '2') runs on that chip; a comma-separated list (e.g. "
        "'0,1,2,3') splits the designs evenly across those cards. Multi-card runs "
        "merge into one result identical in layout to a single-device run.",
    )
    p.add_argument(
        "--fast",
        action="store_true",
        help="Use block-fp8 for some operations (slightly lower precision, faster). "
        "Mirrors `tt-bio predict --fast`.",
    )
    p.add_argument(
        "--controller",
        type=str,
        default=None,
        metavar="URL",
        help="Dispatch design shards to the running `tt-bio controller` at URL "
        "(e.g. http://127.0.0.1:8765), whose workers run them on their own "
        "cards, then merge + filter here. Mirrors `tt-bio predict --controller`.",
    )
    p.add_argument(
        "--run-id", dest="run_id", type=str, default=None, metavar="ID",
        help="Use this run id on the controller (lets the submitter cancel the "
        "run later). Requires --controller.",
    )
    p.add_argument(
        "--owner", dest="owner", type=str, default=None, metavar="KEY",
        help="Opaque fairness key (e.g. a hashed session id) the controller uses "
        "to fair-share devices across users. Requires --controller.",
    )


def add_execute_core_arguments(p: argparse.ArgumentParser) -> None:
    p.add_argument(
        "--steps",
        nargs="+",
        choices=step_names,
        help="Run only the specified pipeline steps (default: run all steps)",
    )
    p.add_argument(
        "--debug",
        action="store_true",
        help="Debug mode: no Rich display, no output suppression",
    )
    p.add_argument(
        "--log",
        action="store_true",
        help="With --debug: print per-stage progress lines",
    )
    p.add_argument(
        "--seed",
        type=int,
        default=None,
        help="Seed every random draw of the pipeline so the same inputs and seed give "
        "the same designs. Multi-card runs give shard i seed+i. Default: a fresh draw "
        "per run.",
    )


def build_run_parser(subparsers) -> argparse.ArgumentParser:
    run_parser = subparsers.add_parser(
        "run",
        description="Boltzgen binder design pipeline",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        help="Run the binder design pipeline",
        epilog=__doc__,
    )
    group = run_parser.add_argument_group("design specification")
    group.add_argument(
        "design_spec",
        nargs="+",
        type=Path,
        help="Path(s) to design specification YAML file(s), or a directory containing prepared configs",
    )
    add_configure_arguments(run_parser, output_required=False)
    add_execute_core_arguments(run_parser)
    add_device_arguments(run_parser)
    add_models_download_options(run_parser)
    return run_parser


def build_execute_parser(subparsers) -> argparse.ArgumentParser:
    execute_parser = subparsers.add_parser(
        "execute",
        description="Execute a pre-configured pipeline from a directory of config files",
        help="Run pipeline from pre-generated configuration files",
    )
    execute_parser.add_argument(
        "output",
        type=Path,
        help="Directory containing pre-configured pipeline files (generated by 'configure' command)",
    )
    add_execute_core_arguments(execute_parser)
    add_device_arguments(execute_parser)
    return execute_parser


def build_configure_parser(subparsers) -> argparse.ArgumentParser:
    configure_parser = subparsers.add_parser(
        "configure",
        description="Generate resolved pipeline configuration files without executing steps",
        help="Create configuration files for later execution",
    )
    group = configure_parser.add_argument_group("design specification")
    group.add_argument(
        "design_spec",
        nargs="+",
        type=Path,
        help="Path(s) to design specification YAML file(s)",
    )

    group = configure_parser.add_argument_group("steps to configure")
    group.add_argument(
        "--steps",
        nargs="+",
        choices=step_names,
        help="Configure only the specified pipeline steps (default: all steps)",
    )

    add_configure_arguments(configure_parser, output_required=True)
    add_device_arguments(configure_parser)
    add_models_download_options(configure_parser)

    return configure_parser


def build_download_parser(subparsers) -> argparse.ArgumentParser:
    download_parser = subparsers.add_parser(
        "download",
        help="Download boltzgen model weights and supporting assets",
    )
    group = download_parser.add_argument_group(
        "artifacts to download (positional argument)"
    )
    group.add_argument(
        "artifacts",
        nargs="+",
        default=[],
        choices=sorted(ARTIFACTS.keys()) + ["all"],
        help="Subset of artifacts to download, or 'all' to download all artifacts.",
    )
    add_models_download_options(download_parser)
    return download_parser


def build_check_parser(subparsers) -> argparse.ArgumentParser:
    check_parser = subparsers.add_parser(
        "check",
        description="Check design specification files for validity and optionally output mmCIF",
        help="Validate design specification files",
    )
    check_parser.add_argument(
        "design_spec",
        nargs="+",
        type=Path,
        help="Path(s) to design specification YAML file(s)",
    )
    check_parser.add_argument(
        "--output",
        type=Path,
        help="Output directory to write mmCIF files (optional)",
    )
    check_parser.add_argument(
        "--moldir",
        type=str,
        help="Path to the moldir. Default: %(default)s",
        default=ARTIFACTS["moldir"][0],
    )

    add_models_download_options(check_parser)
    return check_parser


def build_merge_parser(subparsers) -> argparse.ArgumentParser:
    merge_parser = subparsers.add_parser(
        "merge",
        description="Merge multiple BoltzGen output directories so filtering can be rerun on the combined set.",
        help="Combine finished pipeline outputs into a single directory",
    )
    merge_parser.add_argument(
        "sources",
        nargs="+",
        type=Path,
        help="Paths to completed BoltzGen output directories (results of 'run' or 'execute')",
    )
    merge_parser.add_argument(
        "--output",
        type=Path,
        required=True,
        help="Destination directory for the merged outputs",
    )
    return merge_parser


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="boltzgen",
        description="Boltzgen command line interface",
    )
    # Support: boltzgen -v / --version
    def get_package_version() -> str:
        try:
            return pkg_version("boltzgen")
        except PackageNotFoundError:
            return "unknown"
    parser.add_argument(
        "-v",
        "--version",
        action="version",
        version=f"boltzgen {get_package_version()}",
        help="Print version and exit",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    build_run_parser(subparsers)
    build_configure_parser(subparsers)
    build_execute_parser(subparsers)
    build_download_parser(subparsers)
    build_check_parser(subparsers)
    build_merge_parser(subparsers)
    return parser


#### Commands ####
def _rewrite_run_argv(argv: list[str], strip: set[str], additions: list[str]) -> list[str]:
    """Drop ``strip`` options (and their values) from a ``run`` argv, then append
    ``additions``. Positionals (design specs) come before options, so skipping
    value tokens up to the next ``-`` handles both single- and multi-value opts."""
    out: list[str] = []
    i = 0
    while i < len(argv):
        tok = argv[i]
        if tok.split("=", 1)[0] in strip:
            i += 1
            if "=" not in tok:
                while i < len(argv) and not argv[i].startswith("-"):
                    i += 1
            continue
        out.append(tok)
        i += 1
    return out + additions


def _default_diffusion_batch_size(num_designs: int) -> int:
    """Default diffusion batch size when the user didn't pin one: small runs go
    one-at-a-time for snappier first results, big runs batch 10 for throughput."""
    return 1 if num_designs < 100 else 10


def _planned_batches(num_designs: int, diffusion_batch_size: int | None) -> int:
    dbs = diffusion_batch_size if diffusion_batch_size else _default_diffusion_batch_size(num_designs)
    return math.ceil(num_designs / max(1, dbs))


def _device_label() -> str:
    """Row label for the local device, from TT_VISIBLE_DEVICES (set by the pre-scan)."""
    vd = (os.environ.get("TT_VISIBLE_DEVICES") or "").split(",")[0].strip()
    return f"device {vd}" if vd else "device"


@contextlib.contextmanager
def _quiet(active: bool):
    """Silence stdout (configure/merge chatter) while a spinner/summary owns the
    terminal. No-op when ``active`` is False (e.g. --debug)."""
    if not active:
        yield
        return
    with open(os.devnull, "w") as devnull, contextlib.redirect_stdout(devnull):
        yield


def run_command(args: argparse.Namespace) -> None:
    """Run the binder-design pipeline end to end.

        $ tt-bio gen run design.yaml --output out --device_ids 0,1,2,3

    One device runs in-process. Several devices (``--device_ids 0,1,2,3``) split
    the designs evenly across the cards — one single-device run per card on its
    own shard — then merge and filter once, so the output directory is identical
    in layout to a single-device run.
    """
    from tt_bio.boltzgen import progress as P

    # Guard degenerate sizing: num_designs must be >= 1, otherwise every shard
    # gets zero designs, all devices are dropped, and the CPU split divides by
    # zero (ZeroDivisionError) deep in the distributed path.
    if args.num_designs is not None and args.num_designs < 1:
        raise ValueError("--num_designs must be at least 1")
    if getattr(args, "budget", None) is not None and args.budget < 1:
        raise ValueError("--budget must be at least 1")
    dbs = getattr(args, "diffusion_batch_size", None)
    if dbs is not None and dbs < 1:
        # ceil(num_designs / diffusion_batch_size) divides by zero otherwise.
        raise ValueError("--diffusion_batch_size must be at least 1")

    # Default --output to ./<spec basename>/ (documented), so a bare
    # `tt-bio gen run spec.yaml` works.
    if not args.output:
        args.output = Path(Path(args.design_spec[0]).stem or "boltzgen_output")

    # A fresh run (no --reuse) into an existing dir must not inherit a previous
    # run's designs: the stages append rather than clean, so leftovers would
    # inflate counts. (filter cleans final_ranked_designs; config is regenerated.)
    if not getattr(args, "reuse", False) and args.output.exists():
        for sub in ("shards", "intermediate_designs", "intermediate_designs_inverse_folded"):
            shutil.rmtree(args.output / sub, ignore_errors=True)

    # Default to every available card; --device_ids picks specific ones and
    # --devices N picks the first N (same detection as `tt-bio predict`).
    from tt_bio.runtime import detect_tenstorrent_devices
    devices = detect_tenstorrent_devices(
        args.device_ids, getattr(args, "devices", None) or 0, 10_000)
    P.header(specs=[str(s) for s in args.design_spec],
             protocol=getattr(args, "protocol", "protein-anything"),
             num_designs=args.num_designs,
             batches=_planned_batches(args.num_designs, getattr(args, "diffusion_batch_size", None)),
             budget=getattr(args, "budget", 30), devices=devices, output=str(args.output))

    t0, ok = time.time(), True
    try:
        if getattr(args, "controller", None):
            _run_via_controller(args, args.controller)
        elif not devices:
            # A local run with zero detected cards would sail through configure
            # (which never opens the device) and then hang silently inside
            # execute_command's device-open. Surface the real problem now.
            raise RuntimeError(
                "No Tenstorrent devices found under /dev/tenstorrent for a local "
                "run. Ensure tt-kmd is loaded and the card is visible (ls "
                "/dev/tenstorrent/), or use --controller to dispatch to a fleet."
            )
        elif len(devices) > 1:
            _run_distributed(args, devices)
        else:
            _configure(args)
            execute_command(args)
    except BaseException:
        ok = False
        raise
    finally:
        P.summary(output=str(args.output), elapsed=time.time() - t0, ok=ok)


def _configure(args: argparse.Namespace) -> None:
    """Configure the pipeline, quietly with a spinner unless --debug."""
    if getattr(args, "debug", False):
        configure_command(args)
        return
    from rich.console import Console
    with Console(stderr=True).status("[cyan]preparing pipeline…[/]", spinner="dots"), \
            _quiet(True):
        configure_command(args)


def _run_distributed(args: argparse.Namespace, devices: list[int]) -> None:
    """Fan the designs out across ``devices``, render a per-device view, then
    merge + filter once. Each worker is just a single-device ``run`` on a shard."""
    from tt_bio.boltzgen import progress as P

    n, total = len(devices), args.num_designs
    debug = getattr(args, "debug", False)
    # Split designs as evenly as possible; the first cards take the remainder.
    counts = {d: total // n + (1 if i < total % n else 0) for i, d in enumerate(devices)}
    # Drop cards that got no work (num_designs < card count) — an empty shard
    # produces nothing for the merge to combine. Recompute n for the CPU split.
    devices = [d for d in devices if counts[d] > 0]
    n = len(devices)

    # Inverse folding's decode runs on the host CPU; each worker's torch would
    # grab every core, so N workers oversubscribe N× and thrash. Hand each an
    # equal slice (respecting an explicit user setting) from the same builder
    # `predict` uses, so this path also gets its idle-thread parking once the
    # slice is too thin to leave a spare core for a pool thread to spin on.
    # sched_getaffinity, not cpu_count: a cgroup- or taskset-confined run owns
    # fewer cores than the box has, and the slice has to come out of what we own.
    try:
        n_cpu = len(os.sched_getaffinity(0))
    except AttributeError:
        n_cpu = os.cpu_count() or n
    from tt_bio import runtime as _runtime
    worker_env = _runtime.host_thread_cap_env(n, host_threads=n_cpu)

    # P300 chips are a custom topology; like the `predict` path, each single-chip
    # worker needs the 1x1 Blackhole mesh-graph descriptor or ttnn.open_device
    # aborts with "Custom fabric mesh graph descriptor path must be specified".
    from tt_bio.device_lease import orphan_guard_env
    from tt_bio.main import _detect_p300_devices, _find_ttnn_mesh_graph_descriptor
    p300_devices = set(_detect_p300_devices())
    p300_mgd = (
        _find_ttnn_mesh_graph_descriptor("p150_mesh_graph_descriptor.textproto")
        if p300_devices and not os.environ.get("TT_MESH_GRAPH_DESC_PATH")
        else None
    )

    workers = []
    for i, d in enumerate(devices):
        shard = args.output / "shards" / f"device_{d}"
        shard.mkdir(parents=True, exist_ok=True)
        argv = _rewrite_run_argv(sys.argv[1:], {"--output", "--num_designs", "--device_ids", "--seed"},
                                 ["--output", str(shard), "--num_designs", str(counts[d]),
                                  "--device_ids", str(d), *_shard_seed_argv(args, i)])
        env = {**os.environ, **orphan_guard_env(), "TT_VISIBLE_DEVICES": str(d)}
        if d in p300_devices and p300_mgd:
            env.setdefault("TT_MESH_GRAPH_DESC_PATH", p300_mgd)
        for var, val in worker_env.items():
            env.setdefault(var, val)
        cmd = [sys.executable, "-m", "tt_bio.boltzgen.cli.boltzgen", *argv]
        if debug:
            # Stream every worker's raw output to the terminal (interleaved).
            print(f"\n=== device {d}: {counts[d]} designs (--debug, streaming) ===", flush=True)
            proc, log, pfile = subprocess.Popen(cmd, env=env), None, None
        else:
            pfile = shard / "progress.jsonl"
            pfile.write_text("")
            env["BOLTZGEN_PROGRESS_FILE"] = str(pfile)
            log = open(shard / "run.log", "w")
            proc = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT, env=env)
        workers.append({"dev": d, "dir": shard, "proc": proc, "log": log, "file": pfile})

    if debug:
        for w in workers:
            w["proc"].wait()
    else:
        devs = {w["dev"]: P.Device(f"device {w['dev']}") for w in workers}
        view = P.View(list(devs.values()))
        with view.show():
            while any(w["proc"].poll() is None for w in workers):
                time.sleep(0.4)
                for w in workers:
                    P.tail(devs[w["dev"]], w["file"])
                view.refresh()
            for w in workers:
                P.tail(devs[w["dev"]], w["file"])
                P.finish(devs[w["dev"]], ok=(w["proc"].returncode == 0))
            view.refresh()
        for w in workers:
            w["log"].close()

    failed = [w["dev"] for w in workers if w["proc"].returncode != 0]
    if failed:
        raise RuntimeError(
            f"Shard(s) on device(s) {failed} failed — see "
            f"{args.output}/shards/device_<id>/run.log. Re-run with --reuse to resume.")

    _merge_and_filter(args, [w["dir"] for w in workers], debug=debug)


def _shard_seed_argv(args: argparse.Namespace, shard: int) -> list[str]:
    """``--seed`` for one shard: seed+shard, so shards of a seeded run draw different
    designs and the run still reproduces. Nothing when the run is unseeded."""
    seed = getattr(args, "seed", None)
    return [] if seed is None else ["--seed", str(seed + shard)]


def _merge_and_filter(args: argparse.Namespace, shard_dirs: list[Path], *, debug: bool) -> None:
    """Global reduce shared by every distributed path: combine all shard
    directories, then filter once over the union so the kept set is ranked
    against every design, not per shard. Output layout matches a single run."""
    with _quiet(not debug):
        merge_command(argparse.Namespace(sources=list(shard_dirs), output=args.output))
    if args.steps and "filtering" not in args.steps:
        return
    filter_args = copy.copy(args)
    filter_args.steps, filter_args.reuse = ["filtering"], True
    with _quiet(not debug):
        configure_command(filter_args)
    # Headless filter: the per-shard view already covered the run; the summary
    # panel reports the kept count.
    execute_command(filter_args, headless=not debug)


def _run_via_controller(args: argparse.Namespace, controller_url: str) -> None:
    """Fan design shards across a persistent controller's workers, then merge +
    filter here — the controller twin of ``_run_distributed``.

    Each shard is a job carrying a slice of num_designs; any connected worker
    leases one, runs a single-device
    ``gen run`` on it, and ships its output dir back. We collect those into
    ``shards/`` and reuse the same global reduce as the local path.
    """
    import base64
    import json as _json

    from tt_bio.host_controller import connect_controller
    from tt_bio.main import _write_job_outputs

    debug = getattr(args, "debug", False)
    client, online = connect_controller(controller_url)

    # Spread across the fleet, but keep shards from getting pathologically thin:
    # each shard reloads the models once (overhead) and a too-small shard is
    # fragile (its few designs may all fail refolding). Aim for >= _MIN_PER_SHARD
    # designs per shard, capped by the number of workers. Big production runs
    # still use every worker; a small "quick look" uses just a few.
    _MIN_PER_SHARD = 2   # smaller shards = more parallelism = faster wall-clock.
    _MAX_SHARDS = 10     # ...but cap concurrent shards: each opens a fresh mesh
    # device, and opening too many at once deadlocks get_device() on the Galaxy
    # (verified: 10 shards reliable even under load, 25 hangs). 10 also leaves the
    # rest of the fleet for other users. Large runs just put more designs per shard.
    total = args.num_designs
    n = max(1, min(online, math.ceil(total / _MIN_PER_SHARD), _MAX_SHARDS))
    counts = [total // n + (1 if i < total % n else 0) for i in range(n)]

    specs = [{"name": Path(s).name, "content": Path(s).read_text()} for s in args.design_spec]
    config = {
        "kind": "design",
        "protocol": getattr(args, "protocol", "protein-anything"),
        "fast": bool(getattr(args, "fast", False)),
        "specs": specs,
    }
    # Honour an explicit --steps; otherwise each shard runs the full pipeline
    # (the central filter below still re-ranks the merged union).
    if getattr(args, "steps", None):
        config["steps"] = list(args.steps)
    if getattr(args, "moldir", None):
        config["moldir"] = str(args.moldir)
    seed = getattr(args, "seed", None)
    jobs = [{"id": f"shard_{i}", "name": f"shard_{i}",
             "input_b64": base64.b64encode(_json.dumps(
                 {"num_designs": c, **({"seed": seed + i} if seed is not None else {})}
             ).encode()).decode()}
            for i, c in enumerate(counts)]
    run_payload = {"data": str(args.design_spec[0]), "out_dir": str(args.output),
                   "result_dir": str(args.output), "jobs": jobs, "config": config,
                   "owner": getattr(args, "owner", None)}
    # A caller-supplied run id (the platform passes its job id) lets the run be
    # cancelled later via the controller; otherwise the controller assigns one.
    if getattr(args, "run_id", None):
        run_payload["run_id"] = args.run_id
    run_id = client.create_run(run_payload)["run_id"]
    print(f"Dispatched {len(jobs)} design shard(s) across {online} worker(s) "
          f"on the fleet at {controller_url}", flush=True)

    shards_root = args.output / "shards"
    shards_root.mkdir(parents=True, exist_ok=True)
    shard_dirs: list[Path] = []
    failures: dict[str, str] = {}
    after = 0
    seen_stage = None
    while True:
        snap = client.events(run_id, after)
        for ev in snap.get("events", []):
            after = max(after, int(ev.get("seq", after)))
            etype = ev.get("event")
            if etype == "stage" and ev.get("stage") != seen_stage:
                seen_stage = ev.get("stage")
                # Echo stage words so log-tailing progress (e.g. the platform) advances.
                print(f"stage: {seen_stage}", flush=True)
            elif etype == "done":
                row = ev.get("row") or {}
                sid = str(row.get("id"))
                if row.get("status") == "ok":
                    d = shards_root / sid
                    _write_job_outputs(client, run_id, sid, d)
                    shard_dirs.append(d)
                else:
                    failures[sid] = (row.get("error") or "failed").strip()
        st = snap.get("status")
        if st == "canceled":
            print("Run canceled — stopping without merge.", flush=True)
            return
        if st in ("ok", "failed"):
            break
        time.sleep(0.5)

    # A shard can legitimately yield nothing (e.g. a thin shard whose designs all
    # fail refolding) — one bad shard must not throw away the others. Report what
    # failed, then merge + filter over whatever succeeded; only abort if *no*
    # shard produced designs.
    if failures:
        print(f"\n{len(failures)} of {len(jobs)} design shard(s) failed "
              f"({len(shard_dirs)} succeeded):", flush=True)
        for sid, err in failures.items():
            print(f"  ✗ {sid}: {(err.splitlines() or ['failed'])[0]}", flush=True)
    if not shard_dirs:
        raise RuntimeError(
            "Every design shard failed — no designs were produced. First error:\n"
            + next(iter(failures.values()), "unknown (see worker logs)"))
    _merge_and_filter(args, shard_dirs, debug=debug)


def download_command(args: argparse.Namespace) -> list[Path]:
    """
    Download **BoltzGen model checkpoints and the molecules directory** from the GCP bucket.

    Parameters
    ----------
    args.artifacts : list[str]
        List of artifact keys to download, or `["all"]` to fetch all available assets.
    args.cache : Path
        Cache directory for storing downloaded artifacts.

    Returns
    -------
    list[Path]
        Local file paths of successfully downloaded artifacts.

    Usually this is executed by `boltzgen run ...` but it can be used like:
        $ boltzgen download all
        $ boltzgen download design-diverse inverse-fold
    """
    selections = sorted(set(args.artifacts))
    if "all" in selections:
        selections = list(ARTIFACTS.keys())

    download_paths: list[Path] = []
    for name in selections:
        artifact, repo_type = ARTIFACTS[name]
        resolved_path = get_artifact_path(args, artifact, repo_type=repo_type)
        print(f"Downloading {name} to {resolved_path}")
        download_paths.append(resolved_path)

    return download_paths


def configure_command(args: argparse.Namespace) -> None:
    """
    Generate **resolved per-step YAML configuration files** for the binder-design pipeline.

    This command constructs a `BinderDesignPipeline` from user and protocol parameters,
    validates design specifications, and writes out all configuration files required for running the pipeline. It does NOT run the pipeline.

    Outputs
    -------
    * `<output_dir>/config/<step>.yaml` — fully resolved config for each pipeline step.
    * `<output_dir>/steps.yaml` — manifest of steps and config file paths.

    This stage does **not execute** any model code; it only prepares the YAMLs used by
    `execute_command(...)`.

    Usually this is executed by `boltzgen run ...` but it can be used like:
        $ boltzgen configure path/to/design.yaml --output out_dir --protocol peptide-anything
    """
    moldir = get_artifact_path(args, args.moldir, repo_type="dataset")
    print(f"Loading molecule library from {Path(moldir).name}...")
    mols = load_canonicals(moldir=moldir)

    # Setup output directory
    output_dir = args.output
    if output_dir.exists():
        if not output_dir.is_dir():
            raise ValueError(f"Output path exists and is not a directory: {output_dir}")
    else:
        print(f"Creating output directory: {output_dir}")
        output_dir.mkdir(parents=True)

    check_design_specs(args, moldir, mols)

    pipeline = BinderDesignPipeline(args, moldir)
    pipeline.pretty_print()

    # Check that tasks can be instantiated
    for step in pipeline.steps:
        step.check()

    # Make the config subdir in output
    config_dir = output_dir / "config"
    if config_dir.exists():
        # Rename it to be previous-config-XXX
        counter = 1
        while config_dir.with_name(f"previous-config-{counter}").exists():
            counter += 1
        prev_config_dir = config_dir.with_name(f"previous-config-{counter}")
        print(f"Renaming existing config directory to {prev_config_dir}")
        config_dir.rename(prev_config_dir)
    config_dir.mkdir(parents=True)

    # Prepare step configurations and collect step info
    steps_info = []
    for step in pipeline.steps:
        config = step.get_config()
        config_filename = f"{step.name}.yaml"
        config_path = config_dir / config_filename
        _save_yaml(config, config_path)

        # Add step info for steps.yaml (use relative path from output directory)
        steps_info.append(
            {"name": step.name, "config_file": str(config_path.relative_to(output_dir))}
        )

    # Write steps.yaml file
    steps_yaml_path = output_dir / "steps.yaml"
    steps_data = {"steps": steps_info}

    with open(steps_yaml_path, "w") as f:
        yaml.dump(steps_data, f, default_flow_style=False, sort_keys=False)

    print(f"Configuration complete. Configs written to {config_dir}")
    print(f"Steps manifest written to {steps_yaml_path}")


def check_command(args: argparse.Namespace) -> None:
    """
    Validate **design specification YAML files** and write cif file for visualization.

    This command parses input design specs using `YamlDesignParser`, verifies structure
    integrity, highlights unresolved residues, and  outputs colored mmCIF visualizations.

    Parameters
    ----------
    args.design_spec : list[Path]
        Input YAML file(s) describing the binder design.
    args.output : Path, optional
        Directory to write mmCIF outputs (optional).
    args.moldir : str
        Path or Hugging Face reference to the molecule dataset.

    Typical CLI usage:
        $ boltzgen check path/to/design.yaml --output checked/

    This function does **not** execute the pipeline — it only validates inputs.
    """
    moldir = get_artifact_path(args, args.moldir, repo_type="dataset")
    print(f"Loading molecule library from {Path(moldir).name}...")
    mols = load_canonicals(moldir=moldir)

    if args.output:
        output_dir = args.output
        if output_dir.exists():
            if not output_dir.is_dir():
                raise ValueError(
                    f"Output path exists and is not a directory: {output_dir}"
                )
        else:
            print(f"Creating output directory: {output_dir}")
            output_dir.mkdir(parents=True)

    check_design_specs(args, moldir, mols)


def execute_command(args: argparse.Namespace, *, headless: bool = False) -> None:
    """
    Execute a **pre-configured binder design pipeline** from a directory of YAML files.

    Reads the `steps.yaml` manifest written by `configure_command(...)` and runs
    each step sequentially in-process (sharing the Tenstorrent device handle and
    program cache across the whole pipeline).

    Options
    --------
    * `--steps` : Restrict to specific pipeline steps.
    * `--reuse` : Skip recomputation for existing results.

    Expected directory structure (produced by `configure_command(...)`):
        output_dir/
            ├── config/
            │     ├── design.yaml
            │     ├── folding.yaml
            │     └── ...
            └── steps.yaml

    Usually this is executed by `boltzgen run ...` but it can be used like:
        $ boltzgen execute --output out_dir
    """
    # Set block-fp8 fast mode before any ttnn module is built (the dtype/chunk
    # choices read this global at construction). Covers the in-process single
    # run, each multi-device worker (which re-parses --fast), and the parent's
    # in-process filter pass. Mirrors tt-bio predict's worker setup.
    from tt_bio.tenstorrent import set_fast_mode
    set_fast_mode(getattr(args, "fast", False))

    config_dir = args.output

    if not config_dir.exists() or not config_dir.is_dir():
        raise FileNotFoundError(f"Configuration directory not found: {config_dir}")

    # Look for steps.yaml file
    steps_yaml_path = config_dir / "steps.yaml"
    if not steps_yaml_path.exists():
        raise FileNotFoundError(
            f"Steps manifest not found: {steps_yaml_path}. Run 'boltzgen configure' first."
        )

    # Load steps from steps.yaml
    with open(steps_yaml_path, "r") as f:
        steps_data = yaml.safe_load(f)

    if not isinstance(steps_data, dict) or "steps" not in steps_data:
        raise ValueError(f"Invalid steps.yaml format in {steps_yaml_path}")

    # Filter steps if specific steps are requested
    enabled_steps = set(args.steps) if args.steps else None
    resolved_steps: List[Tuple[str, Path]] = []

    for step_info in steps_data["steps"]:
        step_name = step_info["name"]
        config_filename = step_info["config_file"]

        # Skip if this step is not in the enabled steps list
        if enabled_steps is not None and step_name not in enabled_steps:
            continue

        # Build full path to config file
        config_path = config_dir / config_filename
        if not config_path.exists():
            raise FileNotFoundError(f"Config file not found: {config_path}")

        resolved_steps.append((step_name, config_path))

    if not resolved_steps:
        if enabled_steps:
            print(f"No matching steps found for: {', '.join(enabled_steps)}")
        else:
            print(f"No steps found in {steps_yaml_path}")
        return

    total_steps = len(resolved_steps)

    from tt_bio.boltzgen import progress as P

    debug = getattr(args, "debug", False)
    worker_file = os.environ.get("BOLTZGEN_PROGRESS_FILE")

    # Pick the reporter for this run, and route the model's fd-level chatter to a
    # log so it can't scroll over a live display.
    with contextlib.ExitStack() as stack:
        if worker_file:                       # multi-device shard worker
            reporter = P.FileReporter(worker_file)
        elif debug:                           # raw passthrough (--debug[ --log])
            reporter = P.DebugReporter() if getattr(args, "log", False) else P.Reporter()
        elif headless:                        # quiet (multi-device global filter)
            stack.enter_context(P.redirect_output(config_dir / "run.log"))
            reporter = P.Reporter()
        else:                                 # single-card live view
            term = stack.enter_context(P.redirect_output(config_dir / "run.log"))
            view = P.View([P.Device(_device_label())])
            stack.enter_context(view.show(term))
            reporter = P.LiveReporter(view)

        stack.enter_context(reporter)
        P.set_reporter(reporter)
        for index, (step_name, config_path) in enumerate(resolved_steps, start=1):
            reporter.stage_start(step_name, index, total_steps)
            ok = True
            try:
                # Each step reseeds, so a step's draws do not depend on which steps ran
                # before it in this process (--steps, --reuse).
                if getattr(args, "seed", None) is not None:
                    seed_everything(args.seed)
                config = _resolve_interpolations(_load_yaml(config_path))
                task = _instantiate(config)
                if not isinstance(task, Task):
                    raise TypeError("Config must be an instance of Task.")
                task.run(config)
            except Exception:
                ok = False
                raise
            finally:
                reporter.stage_done(ok)


#### Pipeline implementation ####
@dataclass
class PipelineStep:
    name: str
    config_path: str
    args: List[str]

    def check(self):
        if self.name not in step_names:
            raise ValueError(
                f"Invalid step name: {self.name}. Available steps: {step_names}"
            )
        if not os.path.exists(self.config_path):
            raise FileNotFoundError(f"Config file not found: {self.config_path}")
        # Every override, ours and the user's, has to name something this step's
        # config schema accepts. Checked here rather than at instantiate time so a
        # typo costs nothing instead of the steps that run before it.
        _check_overrides(
            _load_yaml(self.config_path), _dotlist_to_dict(self.args), self.name
        )

    def get_config(self) -> dict:
        config = _load_yaml(self.config_path)
        if self.args:
            config = _deep_merge(config, _dotlist_to_dict(self.args))
        return config


class BinderDesignPipeline:
    """
    The class itself does **not** execute work or write files; instead it builds a
    structured list of `PipelineStep` objects (name + config path + dot-list args)
    corresponding to the selected protocol and user flags. Those steps are then:

    1) **Written to yaml files** when `configure_command(...)` is executed
       - For each `PipelineStep`, the resolved config is written to
         `OUTPUT/config/<step>.yaml`.
       - A manifest `OUTPUT/steps.yaml` is also written, listing the enabled
         steps and their config files in execution order.

    2) **Executed from YAML** when `execute_command(...)` is executed —
       each step's config is instantiated in-process and ``Task.run(...)``
       is called directly. Subprocess mode existed in upstream BoltzGen
       for multi-GPU scheduling; on Tenstorrent we always run in-process
       so the device handle and program cache survive across steps.

    Pipeline task implementations live alongside this file:
        - Predict — tt_bio/boltzgen/task/predict/predict.py
        - Analyze — tt_bio/boltzgen/task/analyze/analyze.py
        - Filter  — tt_bio/boltzgen/task/filter/filter.py

    Usage
    -----
    The class is constructed inside `configure_command(...)` and `run_command(...)`,
    not usually called directly by end users.

    Attributes
    ----------
    steps : list[PipelineStep]
        The ordered list of configured steps. Each entry carries the
        `name`, a `config_path` (base template under `--config_dir`), and a
        list of Hydra **dot-list** overrides that will be merged and written to YAML
        by `configure_command(...)`.

    Methods
    -------
    Notes
    -----
    * The pipeline distinguishes *where* configurations are **written** (in
      `configure_command`) from **how** they are **executed** (in `execute_command`).
      This separation makes it easy to tweak or re-run any step by editing the
      generated YAMLs.
    """

    def __init__(self, args: argparse.Namespace, moldir: Path):
        protocol = args.protocol
        if protocol not in protocol_configs:
            raise ValueError(
                f"Invalid protocol: {protocol}. Valid protocols: {list(protocol_configs.keys())}"
            )

        # Tenstorrent runs the heavy modules through ttnn; cuequivariance
        # kernels are GPU-only and would never fire here, so they're always off.
        use_kernels = False
        print(f"Using kernels: {use_kernels} (Tenstorrent backend)")

        protocol_config = protocol_configs[protocol]
        print(f"Config overrides for protocol {protocol}: {protocol_config}")

        # Set protocol-specific and user-specified step specific args
        config_args_by_step = parse_config_args(
            protocol_config, args.config, step_names
        )

        # ``--steps`` restricts which pipeline stages run; checking enabled
        # *before* building each stage's config means we never resolve (and
        # so never download) artifacts for stages we won't execute.
        enabled = set(args.steps) if args.steps else None

        def _enabled(name: str) -> bool:
            return enabled is None or name in enabled

        self.steps = []

        # Design generation
        output_dir = args.output / "intermediate_designs"
        print(f"Raw designs will be saved to: {output_dir}")
        diffusion_batch_size = args.diffusion_batch_size
        if diffusion_batch_size is None:
            diffusion_batch_size = _default_diffusion_batch_size(args.num_designs)
        num_batches = math.ceil(args.num_designs / max(1, diffusion_batch_size))
        print(f"Using diffusion batch size: {diffusion_batch_size}")
        print(f"Number of diffusion batches: {num_batches}")

        # Configure design checkpoint arguments. Only resolve (and download)
        # the design checkpoints if the design step will actually run.
        checkpoint_args = []
        if not args.only_inverse_fold and _enabled("design"):
            first_checkpoint_path = get_artifact_path(args, args.design_checkpoints[0])
            checkpoint_args.append(f"checkpoint={first_checkpoint_path}")
            if len(args.design_checkpoints) > 1:
                fraction_per_checkpoint = 1.0 / len(args.design_checkpoints)
                checkpoint_args.append(
                    f"override.checkpoints.first_checkpoint_num_samples={fraction_per_checkpoint}"
                )
                checkpoint_args.append(
                    f"override.checkpoints.checkpoint_list=["
                    + ",".join(
                        f"{{'checkpoint': {{'num_samples': {fraction_per_checkpoint}, 'path': '{get_artifact_path(args, checkpoint)}'}}}}"
                        for checkpoint in args.design_checkpoints[1:]
                    )
                    + "]"
                )
        design_step_and_noise_scale_args = []
        if args.step_scale is not None:
            design_step_and_noise_scale_args.append(
                f"override.diffusion_process_args.step_scale={args.step_scale}"
            )
            # Also disable the schedule when applying a fixed step scale
            design_step_and_noise_scale_args.append(
                f"override.step_scale_schedule=null"
            )
        if args.noise_scale is not None:
            design_step_and_noise_scale_args.append(
                f"override.diffusion_process_args.noise_scale={args.noise_scale}"
            )
            design_step_and_noise_scale_args.append(
                f"override.noise_scale_schedule=null"
            )
        if getattr(args, "diffusion_trace", None) is not None:
            design_step_and_noise_scale_args.append(
                f"override.diffusion_trace={str(args.diffusion_trace).lower()}"
            )

        if args.only_inverse_fold:
            exclude_residues = []
            inverse_fold_avoid = (
                args.inverse_fold_avoid
                if args.inverse_fold_avoid is not None
                else (
                    "C"
                    if protocol
                    in [
                        "peptide-anything",
                        "nanobody-anything",
                        "antibody-anything",
                    ]
                    else ""
                )
            )

            for one_letter_code in inverse_fold_avoid:
                exclude_residues.append(const.prot_letter_to_token[one_letter_code])

            if len(exclude_residues) > 0:
                print(
                    f"Inverse fold will avoid the following residues: {exclude_residues}"
                )
            print(f"Inverse-folded designs will be saved to: {output_dir}")
            # Designs from inverse folding
            if _enabled("inverse_folding"):
                self.steps.append(
                    PipelineStep(
                        name="inverse_folding",
                        config_path=args.config_dir / "inverse_fold_only.yaml",
                        args=[
                            f"output={output_dir}",
                            f"data.cfg.yaml_path=[{', '.join(str(s) for s in args.design_spec)}]",
                                f"data.cfg.multiplicity={getattr(args, 'inverse_fold_num_sequences', 10)}",
                            f"data.cfg.skip_existing={args.reuse}",
                            f"data.cfg.output_dir={output_dir}",
                            f"override.use_kernels={use_kernels}",
                            f"checkpoint={get_artifact_path(args, args.inverse_fold_checkpoint)}",
                            f"data.cfg.moldir={moldir}",
                            f"override.inverse_fold_args.inverse_fold_restriction=[{', '.join(exclude_residues)}]",
                        ]
                        + config_args_by_step.get("inverse_folding", []),
                    )
                )
        else:
            # Designs from diffusion model
            if _enabled("design"):
                self.steps.append(
                    PipelineStep(
                        name="design",
                        config_path=args.config_dir / "design.yaml",
                        args=[
                            f"output={output_dir}",
                            f"data.cfg.yaml_path=[{', '.join(str(s) for s in args.design_spec)}]",
                                f"data.num_workers={args.num_workers}",
                            f"data.cfg.skip_existing={args.reuse}",
                            f"data.cfg.multiplicity={num_batches}",
                            f"diffusion_samples={diffusion_batch_size}",
                            f"override.use_kernels={use_kernels}",
                            f"data.cfg.moldir={moldir}",
                        ]
                        + design_step_and_noise_scale_args
                        + checkpoint_args
                        + config_args_by_step["design"],
                    )
                )

            # Inverse folding of diffusion-generated backbones.
            if not args.skip_inverse_folding:
                exclude_residues = []
                inverse_fold_avoid = (
                    args.inverse_fold_avoid
                    if args.inverse_fold_avoid is not None
                    else (
                        "C"
                        if protocol in ["peptide-anything", "nanobody-anything", "antibody-anything"]
                        else ""
                    )
                )

                for one_letter_code in inverse_fold_avoid:
                    exclude_residues.append(const.prot_letter_to_token[one_letter_code])

                if len(exclude_residues) > 0:
                    print(
                        f"Inverse fold will avoid the following residues: {exclude_residues}"
                    )

                input_dir = output_dir
                output_dir = args.output / "intermediate_designs_inverse_folded"
                print(f"Inverse-folded designs will be saved to: {output_dir}")
                if _enabled("inverse_folding"):
                    self.steps.append(
                        PipelineStep(
                            name="inverse_folding",
                            config_path=args.config_dir / "inverse_fold.yaml",
                            args=[
                                f"output={output_dir}",
                                f"data.design_dir={input_dir}",
                                f"data.cfg.multiplicity={args.inverse_fold_num_sequences}",
                                f"data.cfg.num_workers={args.num_workers}",
                                f"data.skip_existing={args.reuse}",
                                f"data.skip_existing_kind=inverse_fold",
                                f"override.use_kernels={use_kernels}",
                                f"checkpoint={get_artifact_path(args, args.inverse_fold_checkpoint)}",
                                f"data.cfg.moldir={moldir}",
                                        f"override.inverse_fold_args.inverse_fold_restriction=[{', '.join(exclude_residues)}]",
                            ]
                            + config_args_by_step["inverse_folding"],
                        )
                    )

        # Folding
        input_dir = output_dir
        if _enabled("folding"):
            self.steps.append(
                PipelineStep(
                    name="folding",
                    config_path=args.config_dir / "fold.yaml",
                    args=[
                        f"output={output_dir}",
                        f"data.design_dir={input_dir}",
                        f"data.cfg.num_workers={args.num_workers}",
                        f"data.skip_existing={args.reuse}",
                        f"data.skip_existing_kind=folded",
                        f"override.use_kernels={use_kernels}",
                        f"checkpoint={get_artifact_path(args, args.folding_checkpoint)}",
                        f"data.cfg.moldir={moldir}",
                    ]
                    + config_args_by_step["folding"],
                )
            )

        # Design folding
        input_dir = output_dir
        do_design_folding = protocol in ["protein-anything", "protein-small_molecule"]
        if do_design_folding and _enabled("design_folding"):
            self.steps.append(
                PipelineStep(
                    name="design_folding",
                    config_path=args.config_dir / "fold.yaml",
                    args=[
                        f"output={output_dir}",
                        f"data.design_dir={input_dir}",
                        f"data.cfg.num_workers={args.num_workers}",
                        f"data.skip_existing={args.reuse}",
                        f"data.skip_existing_kind=design_folded",
                        f"override.use_kernels={use_kernels}",
                        f"checkpoint={get_artifact_path(args, args.folding_checkpoint)}",
                        f"data.cfg.moldir={moldir}",
                        f"writer.designfolding=True",
                        f"data.cfg.return_designfolding=True",
                    ]
                    + config_args_by_step["design_folding"],
                )
            )

        # Affinity
        use_affinity = protocol in ["protein-small_molecule"]
        if use_affinity and _enabled("affinity"):
            self.steps.append(
                PipelineStep(
                    name="affinity",
                    config_path=args.config_dir / "affinity.yaml",
                    args=[
                        f"output={output_dir}",
                        f"data.design_dir={input_dir}",
                        f"data.cfg.num_workers={args.num_workers}",
                        f"data.skip_existing={args.reuse}",
                        f"data.skip_existing_kind=affinity",
                        f"override.use_kernels={use_kernels}",
                        f"checkpoint={get_artifact_path(args, args.affinity_checkpoint)}",
                        f"data.cfg.moldir={moldir}",
                    ]
                    + config_args_by_step["affinity"],
                )
            )

        # Analysis
        if _enabled("analysis"):
            self.steps.append(
                PipelineStep(
                    name="analysis",
                    config_path=args.config_dir / "analysis.yaml",
                    args=[
                        f"design_dir={input_dir}",
                        f"data.skip_existing={args.reuse}",
                        f"data.skip_existing_kind=analyzed",
                        f"data.cfg.moldir={moldir}",
                        f"designfolding_metrics={do_design_folding}",
                        f"delta_sasa_original={args.skip_inverse_folding}",
                        f"noncovalents_original={args.skip_inverse_folding}",
                        f"allatom_fold_metrics={args.skip_inverse_folding}",
                    ]
                    + config_args_by_step["analysis"],
                )
            )

        # Filtering
        output_dir = args.output / "final_ranked_designs"
        print(f"Final ranked designs will be saved to: {output_dir}")

        # Build filter arguments
        filter_args = [
            f"design_dir={input_dir}",
            f"outdir={args.output}",
            f"from_inverse_folded={not args.skip_inverse_folding}",
            f"use_affinity={use_affinity}",
            f"filter_designfolding={do_design_folding}",
            f"budget={args.budget}",
        ]

        # Add optional filtering arguments
        if args.alpha is not None:
            filter_args.append(f"alpha={args.alpha}")
        if args.filter_biased is not None:
            filter_args.append(f"filter_biased={args.filter_biased}")
        if args.refolding_rmsd_threshold is not None:
            filter_args.append(
                f"refolding_rmsd_threshold={args.refolding_rmsd_threshold}"
            )
        if args.metrics_override is not None:
            parsed_metrics = parse_metrics_override(args.metrics_override)
            print(f"Filtering metrics override: {parsed_metrics}")
            filter_args.append(f"metrics_override={parsed_metrics}")
        if args.additional_filters is not None:
            parsed_filters = parse_additional_filters(args.additional_filters)
            print(f"Filtering additional filters: {parsed_filters}")
            filter_args.append(f"additional_filters={parsed_filters}")
        if args.size_buckets is not None:
            parsed_size_buckets = parse_size_buckets(args.size_buckets)
            print(f"Filtering size buckets: {parsed_size_buckets}")
            filter_args.append(f"size_buckets={parsed_size_buckets}")

        if _enabled("filtering"):
            self.steps.append(
                PipelineStep(
                    name="filtering",
                    config_path=args.config_dir / "filtering.yaml",
                    args=filter_args + config_args_by_step["filtering"],
                )
            )

    def pretty_print(self):
        for i, step in enumerate(self.steps):
            print(f"[{i + 1}] {step.name:25s}")


### Misc utiltiies ###
def check_design_specs(args: argparse.Namespace, moldir: Path, mols: Dict[str, Any]):
    # The preview structure each check writes draws its binder lengths.
    if getattr(args, "seed", None) is not None:
        seed_everything(args.seed)
    last_banner = ""
    for design_spec in args.design_spec:
        banner = f"************** Checking design spec: {design_spec} **************"
        last_banner = banner
        print(banner)
        check_design_spec(args, moldir, design_spec, mols)
    if last_banner:
        print("*" * len(last_banner))


def check_design_spec(
    args: argparse.Namespace, moldir: Path, design_spec: Path, mols: Dict[str, Any]
):
    """
    Validate a single design specification, color/annotate its structure, and
    write an mmCIF visualization.

    This function parses a YAML design spec with `YamlDesignParser`, applies visual
    annotations to the parsed structure (via B-factors and per-residue color features),
    reports unresolved residues/atoms, and writes a colored mmCIF file if `--output`
    was provided on the CLI.

    - Writes `<output>/<design_spec.stem>.cif` if `args.output` is set.

        * B-factor encodes design/binding (100 for designed, +80 if binding).
        * `design_color_features`: 1.0 for binding residues, 0.8 otherwise.

    Examples
    --------
    From the CLI (via the `check` subcommand):

        $ boltzgen check path/to/design.yaml --output checked/

    From Python:

        moldir = PATH TO MOLDIR
        mols = load_canonicals(moldir=moldir)
        check_design_spec(args, moldir, Path("design.yaml"), mols)
    """
    parser = YamlDesignParser(moldir)
    print(f"  Parsing design spec {design_spec.name}...")
    parsed = parser.parse_yaml(design_spec, mols, moldir)
    structure = parsed.structure
    design_info = parsed.design_info
    design_color_features = np.ones_like(design_info.res_binding_type) * 0.8
    design_color_features[design_info.res_binding_type.astype(bool)] = 1.0
    extract_mask = np.zeros(len(structure.residues), dtype=bool)
    for i, residue in enumerate(structure.residues):
        structure.atoms["bfactor"][
            residue["atom_idx"] : residue["atom_idx"] + residue["atom_num"]
        ] = 100 * design_info.res_design_mask[i] + 80 * design_info.res_binding_type[i]

        atom_positions = structure.atoms["coords"][
            residue["atom_idx"] : residue["atom_idx"] + residue["atom_num"]
        ]
        zero_position_count = ((atom_positions**2).sum(axis=1) < 1e-6).sum()
        if not zero_position_count == len(atom_positions):
            extract_mask[i] = True

    structure_write = structure
    if extract_mask.sum() > 0:
        structure_write = structure.extract_residues(structure, extract_mask)
        design_color_features = design_color_features[extract_mask]

    mmcif = to_mmcif(
        structure_write,
        design_coloring=True,
        color_features=design_color_features,
    )

    # Check for unresolved residues and atoms to log a warning
    unresolved_residues = (~structure.residues["is_present"]).nonzero()[0]
    unresolved_atoms = (~structure.atoms["is_present"]).nonzero()[0]

    print(f"Total designed residues: {design_info.res_design_mask.sum()}")

    if len(unresolved_residues) > 0 or len(unresolved_atoms) > 0:
        atom_to_residue = {}
        for residue_idx, residue in enumerate(structure.residues):
            start = residue["atom_idx"]
            end = start + residue["atom_num"]
            for i in range(start, end):
                atom_to_residue[i] = residue_idx

        residue_to_chain = {}
        residue_in_chain = {}
        for chain in structure.chains:
            start = chain["res_idx"]
            end = start + chain["res_num"]
            j = 1
            for i in range(start, end):
                residue_to_chain[i] = chain["name"]
                residue_in_chain[i] = j
                j += 1

        atom_to_chain = {}
        for chain in structure.chains:
            start = chain["atom_idx"]
            end = start + chain["atom_num"]
            for i in range(start, end):
                atom_to_chain[i] = chain["name"]

        msg = f"There are {len(unresolved_residues)} unresolved residues and {len(unresolved_atoms)} unresolved atoms in the target."
        print(msg)

    if args.output is not None:
        output_path = args.output / (design_spec.stem + ".cif")
    else:
        output_path = design_spec.stem + ".cif"
    with open(output_path, "w") as f:
        f.write(mmcif)
    print(f"Design specification visualization is written to {str(output_path)}")


def get_artifact_path(
    args, artifact: str, repo_type: str = "model", verbose: bool = True
) -> Path:
    """Resolve an artifact spec to a local file path.

    Three accepted forms (cache defaults to ``~/.boltz/boltzgen/``; override
    with ``--cache``):
      * ``huggingface:<repo_id>:<filename>`` — fetched once from the Hugging
        Face Hub. Used by the ``ARTIFACTS`` defaults (the tt-bio weight repos).
      * ``http(s)://...``  — fetched once from that URL.
      * Anything else — treated as a local file path.

    The fetching itself lives in ``tt_bio.weights``: one implementation of
    stage -> verify -> atomic rename, shared with every other tt-bio model, so a
    download killed mid-flight can never leave a truncated file that a later run
    treats as present. This function is only the spec parser, because the flags
    accept an arbitrary repo/URL/path, not just the registry rows.
    """
    from tt_bio import weights

    cache = args.cache if args.cache is not None else (Path.home() / ".boltz" / "boltzgen")
    force = bool(getattr(args, "force_download", False))
    if artifact.startswith("huggingface:"):
        _, repo_id, filename = artifact.split(":", 2)
        source = f"hf://{repo_id}/{filename}"
    elif artifact.startswith(("http://", "https://")):
        source = artifact
    else:
        source = None
    if source:
        result = weights.fetch_file(
            (source,), Path(cache) / source.rsplit("/", 1)[-1], force=force)
    else:
        result = Path(artifact)
    if not result.exists():
        raise FileNotFoundError(f"Model not found: {result}")
    if verbose:
        print(f"Using {repo_type} artifact: {result}")
    return result


def parse_config_args(base_config, config_args, valid_step_names):
    config_args_by_step = collections.defaultdict(list)
    config_args_by_step.update(base_config)
    if config_args:
        for config in config_args:
            if len(config) < 2:
                raise ValueError(
                    f"Invalid config: {config}. Expected format: <step_name> <arg1>=<value1> <arg2>=<value2> ..."
                )
            step_name = config[0]
            if step_name not in valid_step_names:
                raise ValueError(
                    f"Invalid step name: {step_name}. Available steps: {valid_step_names}"
                )
            key_value_pairs = config[1:]
            config_args_by_step[step_name].extend(key_value_pairs)
    return config_args_by_step


### Filtering argument parsing functions ####
def parse_metrics_override(value_list):
    """Parse metrics_override from key=value pairs."""
    if not value_list:
        return None

    metrics_override = {}
    for item in value_list:
        if "=" in item:
            key, value = item.split("=", 1)
            if value == "" or value.lower() == "none":
                metrics_override[key] = None  # Remove metric
            else:
                try:
                    metrics_override[key] = float(value)
                except ValueError:
                    raise ValueError(
                        f"Invalid weight value for metric '{key}': '{value}'. Must be a number."
                    )
        else:
            raise ValueError(
                f"Invalid metrics_override format: '{item}'. Use 'metric_name=weight' format."
            )
    return metrics_override


def parse_additional_filters(value_list):
    """Parse additional_filters from feature>threshold or feature<threshold format."""
    if not value_list:
        return None

    additional_filters = []
    for item in value_list:
        if ">" in item:
            feature, threshold_str = item.split(">", 1)
            try:
                threshold = float(threshold_str)
                additional_filters.append(
                    {
                        "feature": feature,
                        "threshold": threshold,
                        "lower_is_better": False,  # > means higher is better
                    }
                )
            except ValueError:
                raise ValueError(
                    f"Invalid threshold value: '{threshold_str}'. Must be a number."
                )
        elif "<" in item:
            feature, threshold_str = item.split("<", 1)
            try:
                threshold = float(threshold_str)
                additional_filters.append(
                    {
                        "feature": feature,
                        "threshold": threshold,
                        "lower_is_better": True,  # < means lower is better
                    }
                )
            except ValueError:
                raise ValueError(
                    f"Invalid threshold value: '{threshold_str}'. Must be a number."
                )
        else:
            raise ValueError(
                f"Invalid additional_filters format: '{item}'. Use 'feature>threshold' or 'feature<threshold' format."
            )
    return additional_filters


def parse_size_buckets(value_list):
    """Parse size_buckets from min-max:count format."""
    if not value_list:
        return None

    size_buckets = []
    for item in value_list:
        if ":" in item and "-" in item:
            range_part, count_str = item.split(":", 1)
            if "-" in range_part:
                min_str, max_str = range_part.split("-", 1)
                try:
                    min_size = int(min_str)
                    max_size = int(max_str)
                    count = int(count_str)
                    size_buckets.append(
                        {"num_designs": count, "min": min_size, "max": max_size}
                    )
                except ValueError as e:
                    if "invalid literal" in str(e):
                        raise ValueError(
                            f"Invalid size_buckets format: '{item}'. All values must be integers. Use 'min-max:count' format."
                        )
                    else:
                        raise e
            else:
                raise ValueError(
                    f"Invalid size_buckets format: '{item}'. Use 'min-max:count' format."
                )
        else:
            raise ValueError(
                f"Invalid size_buckets format: '{item}'. Use 'min-max:count' format."
            )
    return size_buckets


def merge_command(args: argparse.Namespace) -> None:
    """
    Merge multiple BoltzGen output directories into a single destination directory so
    the filtering step can be rerun over the combined set of designs.
    """

    def _merge_design_dir(
        sources: list[Path],
        run_tags: dict[Path, str],
        dir_name: str,
        dest_dir: Path,
        id_map: dict[tuple[Path, str], str],
    ) -> int:
        metrics_frames: list[pd.DataFrame] = []
        seq_frames: list[pd.DataFrame] = []
        per_target_frames: list[pd.DataFrame] = []
        merged_count = 0

        for root in sources:
            src_dir = root / dir_name
            if not src_dir.exists():
                continue

            run_tag = run_tags[root]
            source_mappings: list[tuple[str, str, str, str]] = []

            metrics_path = src_dir / "aggregate_metrics_analyze.csv"
            if metrics_path.exists():
                df = pd.read_csv(metrics_path)
                if not df.empty:
                    updated_rows = []
                    for _, row in df.iterrows():
                        if "id" not in row or "file_name" not in row:
                            raise ValueError(
                                "aggregate_metrics_analyze.csv must contain 'id' and 'file_name' columns."
                            )
                        original_id = str(row["id"])
                        original_file = str(row["file_name"])
                        key = (root, original_id)
                        new_id = id_map.setdefault(key, f"{run_tag}_{original_id}")
                        new_file = _make_new_file_name(original_file, new_id)
                        updated_rows.append(
                            {**row, "id": new_id, "file_name": new_file}
                        )
                        source_mappings.append(
                            (original_id, new_id, original_file, new_file)
                        )
                    metrics_frames.append(pd.DataFrame(updated_rows))
                    merged_count += len(source_mappings)
            else:
                known_ids = [
                    (orig, new_id)
                    for (src, orig), new_id in id_map.items()
                    if src == root
                ]
                for original_id, new_id in known_ids:
                    original_file = f"{original_id}.cif"
                    new_file = _make_new_file_name(original_file, new_id)
                    source_mappings.append(
                        (original_id, new_id, original_file, new_file)
                    )

            if not source_mappings:
                continue

            dest_dir.mkdir(parents=True, exist_ok=True)

            seq_path = src_dir / "ca_coords_sequences.pkl.gz"
            if seq_path.exists():
                seq_df = pd.read_pickle(seq_path)
                original_ids = [orig for orig, _, _, _ in source_mappings]
                seq_subset = seq_df[seq_df["id"].astype(str).isin(original_ids)].copy()
                if not seq_subset.empty:
                    id_lookup = {orig: new for orig, new, _, _ in source_mappings}
                    seq_subset["id"] = seq_subset["id"].astype(str).map(id_lookup)
                    seq_frames.append(seq_subset)

            per_target_path = src_dir / "per_target_metrics_analyze.csv"
            if per_target_path.exists():
                per_target_frames.append(pd.read_csv(per_target_path))

            for original_id, new_id, original_file, new_file in source_mappings:
                _copy_design_files(
                    src_dir=src_dir,
                    dest_dir=dest_dir,
                    original_id=original_id,
                    new_id=new_id,
                    original_file=original_file,
                    new_file=new_file,
                    include_refold=True,
                )

        if metrics_frames:
            pd.concat(metrics_frames, ignore_index=True).to_csv(
                dest_dir / "aggregate_metrics_analyze.csv", index=False
            )
        if seq_frames:
            pd.concat(seq_frames, ignore_index=True).to_pickle(
                dest_dir / "ca_coords_sequences.pkl.gz", compression="gzip"
            )
        if per_target_frames:
            pd.concat(per_target_frames, ignore_index=True).to_csv(
                dest_dir / "per_target_metrics_analyze.csv", index=False
            )

        return merged_count


    def _copy_design_files(
        src_dir: Path,
        dest_dir: Path,
        original_id: str,
        new_id: str,
        original_file: str,
        new_file: str,
        include_refold: bool,
    ) -> None:
        _copy_path(src_dir / original_file, dest_dir / new_file, required=True)
        _copy_path(
            src_dir / f"{original_id}.npz",
            dest_dir / f"{new_id}.npz",
            required=False,
        )
        _copy_path(
            src_dir / f"{original_id}_native.cif",
            dest_dir / f"{new_id}_native.cif",
            required=False,
        )
        _copy_path(
            src_dir / f"{original_id}_native.pdb",
            dest_dir / f"{new_id}_native.pdb",
            required=False,
        )
        if include_refold:
            _copy_path(
                src_dir / const.refold_cif_dirname / original_file,
                dest_dir / const.refold_cif_dirname / new_file,
                required=False,
            )
            _copy_path(
                src_dir / const.refold_design_cif_dirname / original_file,
                dest_dir / const.refold_design_cif_dirname / new_file,
                required=False,
            )


    def _make_new_file_name(original_file: str, new_id: str) -> str:
        path = Path(original_file)
        suffix = "".join(path.suffixes)
        return f"{new_id}{suffix}" if suffix else new_id


    def _slugify_run_tag(path: Path, index: int) -> str:
        slug = re.sub(r"[^0-9A-Za-z]+", "-", path.name).strip("-").lower()
        return slug or f"run{index}"


    def _copy_path(src: Path, dst: Path, *, required: bool) -> None:
        if src.exists():
            dst.parent.mkdir(parents=True, exist_ok=True)
            if dst.exists():
                dst.unlink()
            # Try to make a hard link if possible, otherwise copy
            try:
                os.link(src, dst)
            except OSError:
                shutil.copy2(src, dst)
        elif required:
            raise FileNotFoundError(f"Required file missing during merge: {src}")

    if not args.sources:
        raise ValueError("Provide at least one source directory to merge.")

    dest_root = args.output.expanduser().resolve()

    source_roots: list[Path] = []
    for src in args.sources:
        root = Path(src).expanduser().resolve()
        if root == dest_root:
            print(f"Skipping {root} as it is the destination directory")
            continue
        if not root.exists() or not root.is_dir():
            raise FileNotFoundError(f"Source directory not found: {root}")
        source_roots.append(root)

    dest_root.mkdir(parents=True, exist_ok=True)

    run_tags = {
        root: _slugify_run_tag(root, idx + 1) for idx, root in enumerate(source_roots)
    }
    id_map: dict[tuple[Path, str], str] = {}

    total_designs = 0
    for dir_name in [
        "intermediate_designs_inverse_folded",
        "intermediate_designs",
    ]:
        dest_dir = dest_root / dir_name
        merged = _merge_design_dir(
            sources=source_roots,
            run_tags=run_tags,
            dir_name=dir_name,
            dest_dir=dest_dir,
            id_map=id_map,
        )
        if merged:
            total_designs += merged
            print(f"- merged {merged} designs into {dest_dir}")

    if total_designs == 0:
        print("No designs found to merge.")
    else:
        print("===============================================")
        print(f"Merged {len(source_roots)} source(s) into {dest_root}")
        print(f"Total designs available for filtering: {total_designs}")


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.command == "run":
        run_command(args)
    elif args.command == "configure":
        configure_command(args)
    elif args.command == "execute":
        execute_command(args)
    elif args.command == "download":
        download_command(args)
    elif args.command == "check":
        check_command(args)
    elif args.command == "merge":
        merge_command(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
