"""OpenFold3 ``DiffusionModule`` device port (P8 assembly + P9 merge gate).

Contains two device modules:

  * ``OF3NoisyPositionEmbedder`` -- the entry leg of the ``DiffusionModule`` atom
    encoder (AF3 Algorithm 5, lines 8-12), PCC-gated on device in P8 tick 16.
  * ``OF3DiffusionModule`` -- the full post-conditioning ``DiffusionModule`` forward
    (AF3 Algorithm 20): conditioning -> atom encoder -> DiT -> atom decoder -> EDM
    output scaling -> ``xl_out``, PCC-gated against the full-module golden.

``OF3NoisyPositionEmbedder`` fuses the trunk single/pair representations into the
reference-conformer atom conditioning and seeds the atom single rep ``ql`` from the
noisy coordinates. Reference topology
(``openfold3.core.model.layers.sequence_local_atom_attention.NoisyPositionEmbedder``):

    cl = cl0 + broadcast_to_atoms(linear_s(LN_s(si_trunk)))      # single broadcast
    plm = plm0 + to_blocks(linear_z(LN_z(zij_trunk)))            # pair broadcast (blocked)
    ql = cl + linear_r(rl_noisy)                                 # noisy-coordinate projection

``cl0``/``plm0`` are the ``RefAtomFeatureEmbedder`` outputs (gated separately); ``zij``
is the *conditioned* pair (diffusion-conditioning output). All five linears are
bias-free; both LNs are weight-only (``create_offset=False``, eps=1e-5).

The two broadcasts are mask-derived gathers (token -> atom, token-pair -> atom-block)
precomputed on host in the golden and replayed on device via ``ttnn.embedding`` -- the
same isolation discipline as the P7 atom-transformer key gather:
  * single: ``atom_to_token_index`` [NP] gathers ``linear_s(LN_s(si_trunk))`` [N_tok, c]
    to [NP, c] (padded atoms -> 0, zeroed by ``atom_mask_col``);
  * pair: ``zij_flat_idx`` [nb*nq*nk] gathers ``linear_z(LN_z(zij))`` [N_tok*N_tok, c]
    (flattened with stride = N_tok_pad) to [nb, nq, nk, c], masked by ``zij_mask``
    (``(1-invalid_key) * atom_pair_mask``).

Padded atom positions (n_atom -> NP = nb*N_QUERY) are zeroed via ``atom_mask_col`` so
the additive single broadcast does not leak into real atoms; the pair broadcast is
zeroed at padded query positions by ``zij_mask``.
"""
import math

import ttnn

from . import ops
from .tenstorrent import (Module, CORE_GRID_MAIN, _dtype, _cached, pad_dim, pair_row_blocks,
                          row_block_after_refusal, stack_samples)
from .openfold3_atom_transformer import OF3AtomTransformer
from .openfold3_diffusion_transformer import OF3DiffusionTransformer
from .openfold3_diffusion_decoder import OF3AtomAttentionDecoder
from .eltwise_fusion import mask_add

# Pair shapes whose single-pass NPE pair projection DRAM refused, and the block they settled at.
_NPE_PAIR_ROWS_REFUSED: dict = {}


def _sub(sd, prefix):
    p = prefix + "."
    return {k[len(p):]: v for k, v in sd.items() if k.startswith(p)}


class OF3NoisyPositionEmbedder(Module):
    """Device port of OF3 ``NoisyPositionEmbedder`` (Algorithm 5 L8-12).

    Inputs (device bf16):
        cl0:  [1, NP, 128]         RefAtomFeatureEmbedder single out (atom-padded, 0 at pad).
        plm0: [1, nb, 32, 128, 16] RefAtomFeatureEmbedder pair out (blocked).
        si_trunk: [1, N_tok_pad, 384]  raw trunk single (seq-padded to a tile).
        zij:  [1, N_tok_pad, N_tok_pad, 128]  conditioned pair (seq-padded).
        rl:   [1, NP, 3]           noisy atom positions (atom-padded, 0 at pad).
        atom_mask_col:       [1, NP, 1] device.
        atom_to_token_idx:   [1, NP] uint32 device (real atoms -> token idx; pad -> 0).
        zij_flat_idx:        [1, nb*32*128] uint32 device
                                 (= q_token*N_tok_pad + k_token per (b,q,k)).
        zij_mask:            [1, nb, 32, 128, 1] device.
        n_atom, NP: ints.

    Outputs (device bf16):
        cl:  [1, n_atom, 128] ; plm: [1, nb, 32, 128, 16] ; ql: [1, n_atom, 128]
    """

    def __init__(self, state_dict, compute_kernel_config):
        super().__init__(state_dict, compute_kernel_config)
        self._act_dtype = _dtype(ttnn.bfloat16)
        self.w_ls = self.torch_to_tt("linear_s.weight")         # (384, 128) tiled
        self.w_lz = self.torch_to_tt("linear_z.weight")         # (128, 16) tiled
        self.w_lr = self.torch_to_tt("linear_r.weight")         # (3, 128) tiled
        self.ln_s_w = self.torch_to_tt("layer_norm_s.weight", transform=lambda x: x)
        self.ln_z_w = self.torch_to_tt("layer_norm_z.weight", transform=lambda x: x)

    def _z_tok(self, zij):
        """linear_z(LN_z(zij)), per pair position. At 1536 tokens the fp32 norm alone is
        1207959552 B, refused on a Wormhole chip holding the trunk's outputs, so a refusal
        re-runs it in row blocks and only the 16-channel result is ever whole."""
        ckc = self.compute_kernel_config
        zn = ttnn.layer_norm(zij, weight=self.ln_z_w, epsilon=1e-5, compute_kernel_config=ckc)
        out = ttnn.linear(zn, self.w_lz, compute_kernel_config=ckc, core_grid=CORE_GRID_MAIN)
        ttnn.deallocate(zn)
        return out

    def invariants(self, cl0, plm0, si_trunk, zij, atom_mask_col,
                   atom_to_token_idx_tt, zij_flat_idx_tt, zij_mask, NP):
        """The two broadcasts, at the padded atom length: ``cl`` [1, NP, 128] and ``plm``.

        Pure functions of (cl0, plm0, si_trunk, zij), all four fixed across the sampler
        rollout, so this is where the per-step work stops being per-step. Only
        ``ql = cl + linear_r(rl)`` sees the noisy coordinates."""
        ckc = self.compute_kernel_config

        # --- single broadcast: cl = cl0 + broadcast_to_atoms(linear_s(LN_s(si_trunk))) ---
        si_ln = ttnn.layer_norm(si_trunk, weight=self.ln_s_w, epsilon=1e-5,
                                compute_kernel_config=ckc)                      # [1, Ntk, 384]
        si_tok = ttnn.linear(si_ln, self.w_ls, compute_kernel_config=ckc,
                             core_grid=CORE_GRID_MAIN)                          # [1, Ntk, 128]
        if self._act_dtype != ttnn.bfloat16:
            # ttnn.embedding requires a bf16 table; the gather is exact in any
            # dtype, so downcast the (single-use) table and upcast the rows.
            _bf = ttnn.typecast(si_tok, ttnn.bfloat16)
            ttnn.deallocate(si_tok)
            si_tok = _bf
        si_tok_2d = ttnn.reshape(ttnn.to_layout(si_tok, ttnn.ROW_MAJOR_LAYOUT),
                                 (si_tok.shape[1], 128))
        si_atoms = ttnn.embedding(atom_to_token_idx_tt, si_tok_2d,
                                  layout=ttnn.ROW_MAJOR_LAYOUT,
                                  memory_config=ttnn.DRAM_MEMORY_CONFIG)        # [NP, 128]
        si_atoms = ttnn.to_layout(ttnn.reshape(si_atoms, (1, NP, 128)), ttnn.TILE_LAYOUT)
        if self._act_dtype != ttnn.bfloat16:
            si_atoms = ttnn.typecast(si_atoms, self._act_dtype)
        si_atoms = ttnn.multiply(si_atoms, atom_mask_col)                       # zero padded
        ttnn.deallocate(si_tok)
        cl = ttnn.add(cl0, si_atoms)
        ttnn.deallocate(si_atoms)

        # --- pair broadcast: plm = plm0 + to_blocks(linear_z(LN_z(zij))) ---
        zij_tok = row_block_after_refusal(
            _NPE_PAIR_ROWS_REFUSED, tuple(zij.padded_shape), lambda: self._z_tok(zij),
            lambda rows: pair_row_blocks(self._z_tok, (zij,), rows),
            rows=256, tag="of3 npe pair")                                       # [1, Ntk, Ntk, 16]
        ntk = zij_tok.shape[1]
        if self._act_dtype != ttnn.bfloat16:
            _bf = ttnn.typecast(zij_tok, ttnn.bfloat16)
            ttnn.deallocate(zij_tok)
            zij_tok = _bf
        zij_tok_2d = ttnn.reshape(ttnn.to_layout(zij_tok, ttnn.ROW_MAJOR_LAYOUT),
                                  (ntk * ntk, 16))
        zij_blocks = ttnn.embedding(zij_flat_idx_tt, zij_tok_2d,
                                    layout=ttnn.ROW_MAJOR_LAYOUT,
                                    memory_config=ttnn.DRAM_MEMORY_CONFIG)      # [1, nb*nq*nk, 16]
        nb = zij_mask.shape[1]
        zij_blocks = ttnn.to_layout(
            ttnn.reshape(zij_blocks, (1, nb, 32, 128, 16)), ttnn.TILE_LAYOUT)
        if self._act_dtype != ttnn.bfloat16:
            zij_blocks = ttnn.typecast(zij_blocks, self._act_dtype)
        zij_blocks = ttnn.multiply(zij_blocks, zij_mask)
        ttnn.deallocate(zij_tok)
        plm = ttnn.add(plm0, zij_blocks)
        ttnn.deallocate(zij_blocks)

        return cl, plm

    def ql_at_np(self, cl, rl):
        """ql = cl + linear_r(rl), both [1, NP, 128] -- the only per-step part."""
        rl_proj = ttnn.linear(rl, self.w_lr,
                              compute_kernel_config=self.compute_kernel_config,
                              core_grid=CORE_GRID_MAIN)                         # [1, NP, 128]
        ql = ttnn.add(cl, rl_proj)
        ttnn.deallocate(rl_proj)
        return ql

    def __call__(self, cl0, plm0, si_trunk, zij, rl, atom_mask_col,
                 atom_to_token_idx_tt, zij_flat_idx_tt, zij_mask, n_atom, NP):
        cl_np, plm = self.invariants(cl0, plm0, si_trunk, zij, atom_mask_col,
                                     atom_to_token_idx_tt, zij_flat_idx_tt, zij_mask, NP)
        ql_np = self.ql_at_np(cl_np, rl)

        # slice atom-padded outputs back to n_atom.
        cl = ttnn.to_layout(cl_np, ttnn.ROW_MAJOR_LAYOUT)
        cl = ttnn.slice(cl, [0, 0, 0], [1, n_atom, 128])
        cl = ttnn.to_layout(cl, ttnn.TILE_LAYOUT)
        ql = ttnn.to_layout(ql_np, ttnn.ROW_MAJOR_LAYOUT)
        ql = ttnn.slice(ql, [0, 0, 0], [1, n_atom, 128])
        ql = ttnn.to_layout(ql, ttnn.TILE_LAYOUT)
        ttnn.deallocate(cl_np); ttnn.deallocate(ql_np)
        return cl, plm, ql


class AtomPairUpdate(Module):
    """AF3 Algorithm 5 lines 13-14: the atom encoder's pair update, ``(cl, plm) -> plm``.

        plm += (linear_l(relu(cl_l)) + linear_m(relu(cl_m))) * pair_mask
        plm  = (plm + pair_mlp(plm)) * pair_mask

    Both OF3 atom encoders run it with their own weights: the diffusion module's, and the input
    embedder's (``openfold3.InputAtomEncoder``). ``state_dict`` is the encoder's sub-dict.
    Weights are uploaded at the dtype in force at construction, as ``OF3DiffusionModule``'s are.
    """

    def __init__(self, state_dict, compute_kernel_config):
        super().__init__({}, compute_kernel_config)
        self._act_dtype = _dtype(ttnn.bfloat16)
        up = lambda k: ttnn.from_torch(  # noqa: E731
            state_dict[k].t().contiguous(), layout=ttnn.TILE_LAYOUT, device=self.device,
            dtype=self._act_dtype)
        self.w_ll = up("linear_l.weight")           # (16, 128) tiled
        self.w_lm = up("linear_m.weight")           # (16, 128) tiled
        self.w_pm1 = up("pair_mlp.1.weight")        # (16, 16) tiled
        self.w_pm3 = up("pair_mlp.3.weight")
        self.w_pm5 = up("pair_mlp.5.weight")

    def _lin(self, x, w, activation=None):
        return ops.linear(x, w, activation=activation,
                          compute_kernel_config=self.compute_kernel_config,
                          core_grid=CORE_GRID_MAIN)

    def __call__(self, cl_pad, plm, key_block_idxs_tt, valid_mask, pair_mask, NP, nb):
        """cl_pad [1, NP, 128], plm [1, nb, 32, 128, 16] -> updated plm, same shape."""
        lin = self._lin
        N_QUERY, N_KEY = OF3DiffusionModule.N_QUERY, OF3DiffusionModule.N_KEY
        # cl_l = reshape to query blocks [1, nb, NQ, 128].
        cl_l = ttnn.to_layout(cl_pad, ttnn.ROW_MAJOR_LAYOUT)
        cl_l = ttnn.reshape(cl_l, (1, nb, N_QUERY, 128))
        cl_l = ttnn.to_layout(cl_l, ttnn.TILE_LAYOUT)
        # cl_m = gather cl by key_block_idxs -> [1, nb, NK, 128], invalid -> 0.
        _cl_src = cl_pad
        if self._act_dtype != ttnn.bfloat16:
            _cl_src = ttnn.typecast(cl_pad, ttnn.bfloat16)
        cl2d = ttnn.reshape(ttnn.to_layout(_cl_src, ttnn.ROW_MAJOR_LAYOUT), (NP, 128))
        if _cl_src is not cl_pad:
            ttnn.deallocate(_cl_src)
        cl_m = ttnn.embedding(key_block_idxs_tt, cl2d, layout=ttnn.ROW_MAJOR_LAYOUT,
                              memory_config=ttnn.DRAM_MEMORY_CONFIG)
        cl_m = ttnn.reshape(cl_m, (1, nb, N_KEY, 128))
        cl_m = ttnn.to_layout(cl_m, ttnn.TILE_LAYOUT)
        if self._act_dtype != ttnn.bfloat16:
            cl_m = ttnn.typecast(cl_m, self._act_dtype)
        cl_m = ttnn.multiply(cl_m, valid_mask)                  # [1, nb, NK, 128]
        # relu -> linear_l/m outer sum -> [1, nb, NQ, NK, 16], * pair_mask.
        # (reference: linear_l(relu(cl_l)) + linear_m(relu(cl_m)) -- relu is applied to
        #  the INPUT, before the linear, NOT as a post-activation.)
        ll = lin(ttnn.relu(cl_l), self.w_ll)                  # [1, nb, NQ, 16]
        ll = ttnn.unsqueeze(ll, -2)                            # [1, nb, NQ, 1, 16]
        lm = lin(ttnn.relu(cl_m), self.w_lm)                  # [1, nb, NK, 16]
        lm = ttnn.unsqueeze(lm, -3)                            # [1, nb, 1, NK, 16]
        ttnn.deallocate(cl_l); ttnn.deallocate(cl_m)
        cl_lm = ttnn.add(ll, lm)                               # [1, nb, NQ, NK, 16]
        ttnn.deallocate(ll); ttnn.deallocate(lm)
        plm = mask_add(plm, cl_lm, pair_mask)                  # + cl_lm * mask_trunked
        ttnn.deallocate(cl_lm)
        # pair_mlp = Sequential(ReLU, Linear, ReLU, Linear, ReLU, Linear): relu BEFORE
        # each linear (no trailing relu). out = L5(relu(L3(relu(L1(relu(plm)))))).
        pm = lin(ttnn.relu(plm), self.w_pm1)
        pm = lin(ttnn.relu(pm), self.w_pm3)
        pm = lin(ttnn.relu(pm), self.w_pm5)
        plm = ttnn.add(plm, pm)
        ttnn.deallocate(pm)
        plm = ttnn.multiply(plm, pair_mask)
        return plm


class OF3DiffusionModule(Module):
    """Full OF3 ``DiffusionModule`` (AF3 Algorithm 20) device assembly -- the post-
    conditioning forward that turns the conditioned ``(si, zij)`` plus the
    reference-conformer atom conditioning ``(cl0, plm0)`` and a noisy sample
    ``rl_noisy`` into the denoised atom positions ``xl_out``.

    Topology (reference ``openfold3.core.model.structure.diffusion_module``):

        cl, plm, ql = NoisyPositionEmbedder(cl0, plm0, si_trunk, zij, rl_noisy)  # gated
        plm = AtomAttentionEncoder.pair_update(cl, plm)                          # fresh
        ql = AtomAttentionEncoder.atom_transformer(ql, cl, plm)                  # gated
        ai = aggregate_to_tokens(linear_q(ql))                                   # fresh
        ai = ai + linear_s(LN_s(si))                                             # fresh glue
        ai = DiffusionTransformer(ai, si, zij, token_mask)                       # gated
        ai = layer_norm_a(ai)                                                    # fresh glue
        rl_update = AtomAttentionDecoder(ai, ql, cl, plm)                        # gated
        xl_out = EDM_scaling(xl_noisy, rl_update, t, sigma_data)                 # fresh

    The conditioned ``(si, zij)`` come from ``OF3DiffusionConditioning`` (gated
    separately, PCC 1.00000/0.99999) and ``(cl0, plm0)`` from ``RefAtomFeatureEmbedder``
    (gated P7) -- both are fed from their goldens here, the same bisect discipline the
    NPE / decoder gates use, so this gate isolates the post-conditioning assembly
    (encoder pair update, linear_q aggregation, the two glue linears/LNs, EDM output
    scaling) plus the already-gated NPE / DiT / atom-transformer / decoder wiring.
    The encoder ``atom_transformer`` is the same ``OF3AtomTransformer`` topology as the
    decoder's (3-block windowed cross-attention), with the encoder's own weights.

    The fresh device work is small: ``linear_l``/``linear_m`` (128->16, ReLU-gated
    outer-sum into the blocked pair) + ``pair_mlp`` (3x 16->16 ReLU MLP) + ``linear_q``
    (128->768 + ReLU, atom->token mean aggregation via the host ``atom_to_token_mean``
    matrix) + the top-level ``linear_s``/``layer_norm_s`` glue + ``layer_norm_a`` +
    the EDM output scaling (two host scalars applied as multiplies). The mask-derived
    atom windowing and broadcasts are precomputed on host (golden) and replayed on
    device via ``ttnn.embedding`` -- identical isolation to the other OF3 legs.
    """
    N_QUERY = 32
    N_KEY = 128

    def __init__(self, state_dict, compute_kernel_config):
        # state_dict = _sub(sd, "diffusion_module")
        super().__init__({}, compute_kernel_config)
        self._act_dtype = _dtype(ttnn.bfloat16)
        self._w = dict(state_dict)

        enc = _sub(self._w, "atom_attn_enc")
        self.npe = OF3NoisyPositionEmbedder(
            _sub(enc, "noisy_position_embedder"), compute_kernel_config)
        self.enc_at = OF3AtomTransformer(_sub(enc, "atom_transformer"),
                                         compute_kernel_config)
        self.dit = OF3DiffusionTransformer(_sub(self._w, "diffusion_transformer"),
                                           compute_kernel_config)
        self.dec = OF3AtomAttentionDecoder(_sub(self._w, "atom_attn_dec"),
                                           compute_kernel_config)

        # Fresh: encoder pair update (linear_l/linear_m + pair_mlp).
        self.pair_update = AtomPairUpdate(enc, compute_kernel_config)
        # Fresh: linear_q (128 -> 768) aggregation head.
        self.w_lq = self._w_tt(enc["linear_q.0.weight"])         # (768, 128) tiled
        # Fresh: top-level glue linear_s (384 -> 768) + weight-only layer_norm_s/a.
        self.w_ls = self._w_tt(self._w["linear_s.weight"])       # (768, 384) tiled
        self.ln_s_w = self._w_tt(self._w["layer_norm_s.weight"], False)  # (384,)
        self.ln_a_w = self._w_tt(self._w["layer_norm_a.weight"], False)  # (768,)

    def _w_tt(self, w, transpose=True):
        # No memo: each of the four is uploaded once, here. One keyed by id(w) put the
        # object's address in the weight's walk path, so a checkpoint named those four
        # parameters differently in every process and could not be loaded back.
        return ttnn.from_torch(w.t().contiguous() if transpose else w,
                               layout=ttnn.TILE_LAYOUT, device=self.device,
                               dtype=self._act_dtype)

    def _lin(self, x, w, activation=None):
        return ops.linear(x, w, activation=activation,
                          compute_kernel_config=self.compute_kernel_config,
                          core_grid=CORE_GRID_MAIN)

    def __call__(self, si_trunk, si, zij, cl0, plm0, rl_noisy, xl_noisy,
                 atom_mask_col, atom_mask_col_na, atom_to_token_idx_tt,
                 npe_flat_idx_tt, npe_zij_mask,
                 enc_key_block_idxs_tt, enc_valid_mask, enc_mask_bias, enc_pair_mask,
                 atom_to_token_mean_tt, token_mask_pad_tt, tok_mask_col_pad_tt,
                 n_atom, NP, nb, n_token, n_tok_pad, t, sigma_data,
                 _return_intermediates=False, cache=None, samples=None, edm=True):
        """Run the post-conditioning ``DiffusionModule`` forward -> ``xl_out``.

        See the class docstring for the topology. Device bf16 inputs:
          si_trunk: [1, n_tok_pad, 384]  raw trunk single (NPE input).
          si, zij:            conditioned single/pair (zij tile-padded to n_tok_pad).
          cl0: [1, NP, 128]   RefAtom single (atom-padded, 0 at pad).
          plm0:[1, nb, 32, 128, 16]  RefAtom pair (blocked).
          rl_noisy: [1, NP, 3]  noisy atom positions (atom-padded, 0 at pad).
          xl_noisy: [1, n_atom, 3]  noisy sample (atom-masked) for EDM.
          atom_mask_col: [1, NP, 1]; atom_mask_col_na: [1, n_atom, 1].
          atom_to_token_idx_tt: [1, NP] uint32 (NPE single broadcast).
          npe_flat_idx_tt: [1, nb*32*128] uint32 (NPE pair broadcast).
          npe_zij_mask: [1, nb, 32, 128, 1].
          enc_key_block_idxs_tt: [1, nb*128] uint32 (encoder pair-update + atom-transformer).
          enc_valid_mask: [1, nb, 128, 1]; enc_mask_bias: [1, nb, 1, 32, 128].
          enc_pair_mask: [1, nb, 32, 128, 1] (multiplicative mask_trunked).
          atom_to_token_mean_tt: [1, n_token, n_atom] (mean aggregation matrix).
          token_mask_pad_tt: [1, n_tok_pad]; tok_mask_col_pad_tt: [1, n_tok_pad, 1].
        Returns [1, n_atom, 3] device bf16.

        ``samples`` gives the module a sample axis: a list of ``(si, rl_noisy, xl_noisy, t)``,
        one per noised structure, which replaces the four per-sample arguments above and
        returns a list of ``xl_out`` in the same order. See ``_denoise_samples``. A caller
        must check ``self.dit.supports_multiplicity`` before passing it. With ``edm=False``
        (sample axis only) it returns each sample's ``rl_update`` [1, n_atom, 3] instead and
        the caller applies the EDM scaling, which is how a traced step leaves ``t`` out.
        """
        lin = self._lin

        # --- Loop invariants: the NPE broadcasts + the whole encoder pair update. ---
        # cl and plm are pure functions of (cl0, plm0, si_trunk, zij), and the pair update
        # is a pure function of those two, so on a cached rollout this whole block runs
        # once instead of 200 times. Only ql sees the noisy coordinates.
        cl_pad, plm = _cached(
            cache, (id(self), "npe_and_pair_update"),
            lambda: self._invariants(cl0, plm0, si_trunk, zij, atom_mask_col,
                                     atom_to_token_idx_tt, npe_flat_idx_tt, npe_zij_mask,
                                     enc_key_block_idxs_tt, enc_valid_mask, enc_pair_mask,
                                     NP, nb))
        if samples is not None:
            if _return_intermediates:
                raise NotImplementedError(
                    "_return_intermediates is the parity scripts' single-sample route; the "
                    "sample axis has no per-sample intermediates to hand back.")
            return self._denoise_samples(
                samples, cl_pad, plm, zij, atom_mask_col, atom_mask_col_na,
                atom_to_token_idx_tt, enc_key_block_idxs_tt, enc_valid_mask, enc_mask_bias,
                atom_to_token_mean_tt, token_mask_pad_tt, tok_mask_col_pad_tt,
                n_atom, NP, nb, n_token, n_tok_pad, sigma_data, cache, edm)
        ql_pad = self.npe.ql_at_np(cl_pad, rl_noisy)               # [1, NP, 128]
        plm_postpu = ttnn.clone(plm) if _return_intermediates else None

        # --- Encoder atom_transformer (gated OF3AtomTransformer) -> ql [1, n_atom, 128]. ---
        ql_enc = self.enc_at(ql_pad, cl_pad, plm, atom_mask_col,
                             enc_key_block_idxs_tt, enc_valid_mask, enc_mask_bias,
                             n_atom, NP, nb, cache=cache)          # [1, n_atom, 128]
        ttnn.deallocate(ql_pad)
        ql_enc_cp = ttnn.clone(ql_enc) if _return_intermediates else None
        return self._post_encoder(
            ql_enc, ql_enc_cp, plm_postpu, cl_pad, plm, si, zij, xl_noisy,
            atom_mask_col, atom_mask_col_na, atom_to_token_idx_tt,
            enc_key_block_idxs_tt, enc_valid_mask, enc_mask_bias,
            atom_to_token_mean_tt, token_mask_pad_tt, tok_mask_col_pad_tt,
            n_atom, NP, nb, n_token, n_tok_pad, t, sigma_data,
            _return_intermediates, cache)

    def _denoise_samples(self, samples, cl_pad, plm, zij, atom_mask_col, atom_mask_col_na,
                         atom_to_token_idx_tt, enc_key_block_idxs_tt, enc_valid_mask,
                         enc_mask_bias, atom_to_token_mean_tt, token_mask_pad_tt,
                         tok_mask_col_pad_tt, n_atom, NP, nb, n_token, n_tok_pad,
                         sigma_data, cache, edm=True):
        """``S`` noised structures through one encoder, one token DiT and one decoder call.

        ``samples`` is ``[(si, rl_noisy, xl_noisy, t), ...]``; the return is one ``xl_out``
        per entry, in order. Only the per-sample token aggregation (``_pre_dit``) and the EDM
        scaling loop over the samples; everything else takes the axis as its leading dim:

        * The atom encoder and decoder stack the samples on the leading dim of the evolving
          atom rep only. ``plm``, the masks and every per-block invariant stay ``[1, ...]``
          and broadcast, so nothing the size of the pair is replicated. This is one call per
          step instead of S, but not faster: at 730 tokens on Wormhole the same-chip A/B read
          235.05 s per sample against 235.14 s batched, because the atom transformers are
          device-bound and their cost scales with S.
        * The 24-block DiT is 3-D and 4-D throughout, so a leading sample dim is a taller
          matmul. Its per-block pair bias is a pure function of ``zij``, stays
          ``[1, 16, N, N]`` in ``cache`` and broadcasts in the QK-scale add, the same call
          Protenix makes. Its conditioning ``si`` is one per step, so it stays ``[1, N, 384]``
          and every block's conditioning linears run once, not S times.

        At ``len(samples) == 1`` this runs exactly the ops ``_post_encoder`` runs, in the same
        order, with no concat and no slice: the S=1 arm is the A/B control and it is
        bit-identical to the loop by construction, not by measurement.
        """
        S = len(samples)
        rl = samples[0][1] if S == 1 else stack_samples([x[1] for x in samples])
        ql_pad = self.npe.ql_at_np(cl_pad, rl)                     # [S, NP, 128]
        if S > 1:
            ttnn.deallocate(rl)
        ql = self.enc_at(ql_pad, cl_pad, plm, atom_mask_col, enc_key_block_idxs_tt,
                         enc_valid_mask, enc_mask_bias, n_atom, NP, nb, cache=cache)
        ttnn.deallocate(ql_pad)
        # The samples of one step share their noise level, so the sampler hands every one the
        # same ``si``. Its glue term and the DiT's conditioning are then computed once and
        # broadcast over the axis instead of once per sample.
        si = samples[0][0]
        shared = all(x[0] is si for x in samples)
        glue = self._si_glue(si, n_token) if shared and S > 1 else None
        # The token aggregation is per sample: its [1, n_token, n_atom] mean matrix is the
        # matmul's in0, and ttnn broadcasts a batch over in1 only.
        ai = [self._pre_dit(ql if S == 1 else ql[k:k + 1], si_k, atom_to_token_mean_tt,
                            n_token, n_tok_pad, si_proj=glue)[0]
              for k, (si_k, _rl, _xl, _t) in enumerate(samples)]
        if glue is not None:
            ttnn.deallocate(glue)

        # At S=1 nothing is stacked and nothing is sliced, so the control arm allocates
        # exactly what the per-replicate loop allocates. Above 1 the parts are freed as soon
        # as the axis they were stacked into exists: an open tape declines the deallocate and
        # evicts instead, so this costs a taped step nothing and gives an inference one back
        # S-1 copies of the largest tensor on the token path.
        if S == 1:
            a_b, s_b = ai[0], si
        else:
            a_b = stack_samples(ai)
            s_b = si if shared else stack_samples([x[0] for x in samples])
            for t in ai:
                ttnn.deallocate(t)
        a_b = self.dit(a_b, s_b, zij, token_mask_pad_tt, tok_mask_col_pad_tt, cache=cache)
        if s_b is not si:
            ttnn.deallocate(s_b)

        rl_update = self._decode(a_b, ql, cl_pad, plm, atom_mask_col, atom_to_token_idx_tt,
                                 enc_key_block_idxs_tt, enc_valid_mask, enc_mask_bias,
                                 n_atom, NP, nb, cache)            # [S, n_atom, 3]
        if not edm:
            if S == 1:
                return [rl_update]
            out = [rl_update[k:k + 1] for k in range(S)]
            ttnn.deallocate(rl_update)
            return out
        if S == 1:
            return [self._edm(samples[0][2], rl_update, atom_mask_col_na, samples[0][3],
                              sigma_data)]
        out = [self._edm(xl_k, rl_update[k:k + 1], atom_mask_col_na, t_k, sigma_data)
               for k, (_si, _rl, xl_k, t_k) in enumerate(samples)]
        ttnn.deallocate(rl_update)
        return out

    def _invariants(self, cl0, plm0, si_trunk, zij, atom_mask_col,
                    atom_to_token_idx_tt, npe_flat_idx_tt, npe_zij_mask,
                    enc_key_block_idxs_tt, enc_valid_mask, enc_pair_mask, NP, nb):
        """cl [1, NP, 128] and the post-pair-update plm -- the rollout invariants."""
        cl_pad, plm = self.npe.invariants(cl0, plm0, si_trunk, zij, atom_mask_col,
                                          atom_to_token_idx_tt, npe_flat_idx_tt,
                                          npe_zij_mask, NP)
        plm = self.pair_update(cl_pad, plm, enc_key_block_idxs_tt, enc_valid_mask,
                               enc_pair_mask, NP, nb)
        return cl_pad, plm

    def _post_encoder(self, ql_enc, ql_enc_cp, plm_postpu, cl_pad, plm, si, zij, xl_noisy,
                      atom_mask_col, atom_mask_col_na, atom_to_token_idx_tt,
                      enc_key_block_idxs_tt, enc_valid_mask, enc_mask_bias,
                      atom_to_token_mean_tt, token_mask_pad_tt, tok_mask_col_pad_tt,
                      n_atom, NP, nb, n_token, n_tok_pad, t, sigma_data,
                      _return_intermediates, cache):
        """Everything downstream of the encoder atom transformer: it all depends on ql."""
        ai_pad, ai_postglue = self._pre_dit(ql_enc, si, atom_to_token_mean_tt,
                                            n_token, n_tok_pad, _return_intermediates)
        ai_pad = self.dit(ai_pad, si, zij, token_mask_pad_tt, tok_mask_col_pad_tt,
                          cache=cache)
        return self._post_dit(
            ai_pad, ql_enc, ql_enc_cp, plm_postpu, ai_postglue, cl_pad, plm, xl_noisy,
            atom_mask_col, atom_mask_col_na, atom_to_token_idx_tt,
            enc_key_block_idxs_tt, enc_valid_mask, enc_mask_bias,
            n_atom, NP, nb, t, sigma_data, _return_intermediates, cache)

    def _si_glue(self, si, n_token):
        """linear_s(LN_s(si)) [1, n_token, 768]: the noise-level glue added to the aggregation."""
        si_ln = ttnn.layer_norm(si, weight=self.ln_s_w, epsilon=1e-5,
                                compute_kernel_config=self.compute_kernel_config)
        si_proj = self._lin(si_ln, self.w_ls)                  # [1, n_tok_pad, 768]
        ttnn.deallocate(si_ln)
        if int(si_proj.shape[1]) == n_token:                  # tile-aligned tokens: nothing to cut
            return si_proj
        si_proj = ttnn.to_layout(si_proj, ttnn.ROW_MAJOR_LAYOUT)
        si_proj = ttnn.slice(si_proj, [0, 0, 0], [1, n_token, 768])
        return ttnn.to_layout(si_proj, ttnn.TILE_LAYOUT)

    def _pre_dit(self, ql_enc, si, atom_to_token_mean_tt, n_token, n_tok_pad,
                 _return_intermediates=False, si_proj=None):
        """Encoder output -> the DiT's input ``ai_pad`` [1, n_tok_pad, 768], one sample.

        Split out of ``_post_encoder`` so the sample-batched route runs the same ops in the
        same order rather than a second copy of them. ``ql`` carries the noisy coordinates and
        ``si`` the noise-level embedding; a caller whose samples share ``si`` passes its glue
        ``si_proj`` (``_si_glue``) once for all of them.
        """
        lin = self._lin

        # --- linear_q aggregation (fresh): ai = atom_to_token_mean @ relu(linear_q(ql)). ---
        qproj = lin(ql_enc, self.w_lq, activation="relu")      # [1, n_atom, 768]
        ai = ttnn.matmul(atom_to_token_mean_tt, qproj,
                         compute_kernel_config=self.compute_kernel_config)  # [1, n_token, 768]
        ttnn.deallocate(qproj)
        # Glue: ai += linear_s(LN_s(si)) (si tile-padded; slice the result to n_token).
        own = si_proj is None
        if own:
            si_proj = self._si_glue(si, n_token)
        ai = ttnn.add(ai, si_proj)
        if own:
            ttnn.deallocate(si_proj)
        ai_postglue = ttnn.clone(ai) if _return_intermediates else None

        # Feed the DiT padded (n_tok_pad) with the padded token mask.
        ai_pad = pad_dim(ai, self._act_dtype, n_token, n_tok_pad)  # [1, n_tok_pad, 768]
        if ai_pad is not ai:
            ttnn.deallocate(ai)
        return ai_pad, ai_postglue

    def _post_dit(self, ai_pad, ql_enc, ql_enc_cp, plm_postpu, ai_postglue, cl_pad, plm,
                  xl_noisy, atom_mask_col, atom_mask_col_na, atom_to_token_idx_tt,
                  enc_key_block_idxs_tt, enc_valid_mask, enc_mask_bias,
                  n_atom, NP, nb, t, sigma_data, _return_intermediates, cache):
        """DiT output -> ``xl_out`` [1, n_atom, 3], one sample. The other half of the split."""
        ai_postdit = ttnn.clone(ai_pad) if _return_intermediates else None
        rl_update = self._decode(ai_pad, ql_enc, cl_pad, plm, atom_mask_col,
                                 atom_to_token_idx_tt, enc_key_block_idxs_tt, enc_valid_mask,
                                 enc_mask_bias, n_atom, NP, nb, cache)
        rl_update_cp = ttnn.clone(rl_update) if _return_intermediates else None
        xl_out = self._edm(xl_noisy, rl_update, atom_mask_col_na, t, sigma_data)
        if _return_intermediates:
            return xl_out, ai_postglue, ai_postdit, rl_update_cp, plm_postpu, ql_enc_cp
        return xl_out

    def _decode(self, ai_pad, ql_enc, cl_pad, plm, atom_mask_col, atom_to_token_idx_tt,
                enc_key_block_idxs_tt, enc_valid_mask, enc_mask_bias, n_atom, NP, nb, cache):
        """DiT output [S, n_tok_pad, 768] + encoder ql [S, n_atom, 128] -> ``rl_update``
        [S, n_atom, 3]. Consumes both inputs."""
        # --- layer_norm_a (fresh glue), keep padded for the decoder. ---
        ai_ln = ttnn.layer_norm(ai_pad, weight=self.ln_a_w, epsilon=1e-5,
                                compute_kernel_config=self.compute_kernel_config)
        ttnn.deallocate(ai_pad)

        # --- AtomAttentionDecoder (gated) -> rl_update [S, n_atom, 3]. ---
        # Decoder reuses the encoder's ql (atom_transformer output), cl, and the
        # post-pair-update plm -- the same (ql, cl, plm) the reference decoder consumes.
        ql_dec = pad_dim(ql_enc, self._act_dtype, n_atom, NP)  # [S, NP, 128]
        if ql_dec is not ql_enc:
            ttnn.deallocate(ql_enc)
        rl_update = self.dec(ai_ln, ql_dec, cl_pad, plm, atom_mask_col,
                             atom_to_token_idx_tt, enc_key_block_idxs_tt,
                             enc_valid_mask, enc_mask_bias, n_atom, NP, nb,
                             cache=cache)
        ttnn.deallocate(ai_ln); ttnn.deallocate(ql_dec)
        return rl_update

    @staticmethod
    def _edm(xl_noisy, rl_update, atom_mask_col_na, t, sigma_data):
        """EDM output scaling (fresh): ``xl_out = c_skip * xl_noisy + c_out * rl_update``,
        atom-masked; consumes ``rl_update``."""
        sd2 = sigma_data * sigma_data
        t2 = t * t
        c_skip = sd2 / (sd2 + t2)
        c_out = sigma_data * t / math.sqrt(sd2 + t2)
        xl_out = ttnn.add(ttnn.multiply(xl_noisy, c_skip),
                          ttnn.multiply(rl_update, c_out))
        ttnn.deallocate(rl_update)
        return ttnn.multiply(xl_out, atom_mask_col_na)
